1. SqlDbx Installation

Unzip SqlDbxPro.zip or SqlDbxPro64.zip to the directory of your choice.
Copy SqlDbx.lic file to the same directory.
Start SqlDbx.exe

2. SqlDbx versions

SqlDbx.exe    - 32 bit ANSI version
SqlDbxU.exe   - 32 bit UNICODE version
SqlDbx64.exe  - 64 bit ANSI version
SqlDbx64U.exe - 64 bit UNICODE version

3. SqlDbx portable

To make SqlDbx portable create empty SqlDbx.ini file in the same directory where SqlDbx.exe located.
Restart SqlDbx.

4. Translations

Download language file from www.sqldbx.com/translations.htm
Copy language file to the same directory where SqlDbx.exe located.
Go to Options->General and select your language from Language combo box.
Restart SqlDbx

5. Support
email:   support@sqldbx.com
Support: www.sqldbx.com/forum