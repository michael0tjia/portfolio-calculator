package com.morganstanley.interviews.portfoliocalculator.marketdata.provider;

public interface PriceConsumer extends Runnable {

}
