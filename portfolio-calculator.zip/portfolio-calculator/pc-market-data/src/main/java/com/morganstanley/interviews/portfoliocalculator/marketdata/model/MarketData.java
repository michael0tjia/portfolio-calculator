package com.morganstanley.interviews.portfoliocalculator.marketdata.model;

public interface MarketData {
    public String getTicker();

    public double getPrice();

}
