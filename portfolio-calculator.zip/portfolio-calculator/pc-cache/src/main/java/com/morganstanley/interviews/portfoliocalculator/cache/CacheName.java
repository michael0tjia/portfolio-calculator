package com.morganstanley.interviews.portfoliocalculator.cache;

public enum CacheName {
    Instrument,
    CommonStock,
    Option,
    Position
}
