package com.morganstanley.interviews.portfoliocalculator.dataloader;

public interface DataLoaderManager {
    void doAllInitialLoads();
}
