package com.morganstanley.interviews.portfoliocalculator.service;

public interface PortfolioManager {
}
