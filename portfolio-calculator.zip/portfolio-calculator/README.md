Portfolio Calculator
==========================
To build the project, run gradlew build
To run the server, run java -jar pc-service-1.0.0-SNAPSHOT.jar [portflio csv file]
To run the real time nav reader, run java -jar pc-web-socket-client-1.0.0-SNAPSHOT.jar
To run the portolio printer, run java -jar java -jar pc-web-client-1.0.0-SNAPSHOT.jar

Notes: A sample portflio csv file (portfolio-calculator\data\Portfolio.csv) is provided