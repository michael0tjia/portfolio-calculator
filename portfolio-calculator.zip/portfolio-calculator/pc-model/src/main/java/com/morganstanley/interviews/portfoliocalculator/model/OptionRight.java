package com.morganstanley.interviews.portfoliocalculator.model;

public enum OptionRight {
    CALL,
    PUT
}
