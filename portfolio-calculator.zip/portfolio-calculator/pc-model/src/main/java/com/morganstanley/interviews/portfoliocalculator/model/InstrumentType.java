package com.morganstanley.interviews.portfoliocalculator.model;

public enum InstrumentType {
    COMMON_STOCK,
    OPTION,
}
