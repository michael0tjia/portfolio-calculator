package com.morganstanley.interviews.portfoliocalculator.model;

public interface Cacheable {
    Object getPrimaryKey();
}
