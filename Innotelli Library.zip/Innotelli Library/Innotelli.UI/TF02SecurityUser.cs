using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Innotelli.BO;
using DevExpress.XtraEditors;
using Innotelli.WinForm.Control;


namespace Innotelli.UI
{
    public partial class TF02SecurityUser : TForm02
    {
        #region Members

        #region Business Object Declarations
        TB01SecurityUser mB01SecurityUser = new TB01SecurityUser();
        TB01SecurityGroupAssign mB01SecurityGroupAssign = new TB01SecurityGroupAssign();
        #endregion

        #endregion

        #region Constructors
        public TF02SecurityUser()
        {
            InitializeComponent();
        }
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions

        #region Initializations
        public override void Init()
        {
            BdsMaster = bdsMaster;
            Lyt01Base = lyt01Base;
            base.Init();
        }

        protected override void InitTree()
        {
            BOT01 = mB01SecurityUser;
            BOT01.AddChild(mB01SecurityGroupAssign, TB01SecurityGroupAssign.Cols.slkUser);
        }

        protected override void AssignBOToGrids()
        {
            base.AssignBOToGrids();
            grd02SecurityUserAssign.BOT01 = mB01SecurityGroupAssign;
        }

        #endregion

        #region Form Reuse
        public override void InitForReuse()
        {
            base.InitForReuse();
        }
        #endregion

        #endregion
    }
}