using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Innotelli.WinForm.Control;
using Innotelli.BO;

namespace Innotelli.UI
{
    public partial class TF02SecurityGroup : TForm02
    {
        #region Members

        #region Business Object Declarations
        TB01SecurityGroup mB01SecurityGroup = new TB01SecurityGroup();
        TB01SecurityPermissionAssign mB01SecurityPermissionAssign = new TB01SecurityPermissionAssign();
        #endregion

        #endregion

        #region Constructors
        public TF02SecurityGroup()
        {
            InitializeComponent();
        }
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions

        #region Initializations
        public override void Init()
        {
            BdsMaster = bdsMaster;
            Lyt01Base = lyt01Base;
            base.Init();
        }

        protected override void InitTree()
        {
            BOT01 = mB01SecurityGroup;
            BOT01.AddChild(mB01SecurityPermissionAssign, TB01SecurityPermissionAssign.Cols.slkGroup);
            mB01SecurityPermissionAssign.BODataRight.AllowAdd = false;
        }

        protected override void AssignBOToGrids()
        {
            base.AssignBOToGrids();
            grd02SecurityPermissionAssign.BOT01 = mB01SecurityPermissionAssign;
        }

        #endregion

        #region Form Reuse
        public override void InitForReuse()
        {
            base.InitForReuse();
        }

        public override bool Save()
        {
            bool lIsInsert = (DsMode == DSFormMode.DSInsert);
            DataTable lDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("SecurityPermission").Tables[0];
            bool lRtrnVal = false;

            lRtrnVal = base.Save();
            if (lDt.Rows.Count != 0 && lRtrnVal && lIsInsert)
            {
                mB01SecurityPermissionAssign.LoadBlank();
                foreach (DataRow lDr in lDt.Rows)
                {
                    mB01SecurityPermissionAssign.AddNewRow();
                    mB01SecurityPermissionAssign.Cr.slkGroup = mB01SecurityGroup.Cr.prmykey;
                    mB01SecurityPermissionAssign.Cr.PermissionGUID = (Guid)lDr["SecurityRightGUID"];
                }
                lRtrnVal = base.Save();
            }

            return lRtrnVal;
        }
        #endregion

        #endregion
    }
}