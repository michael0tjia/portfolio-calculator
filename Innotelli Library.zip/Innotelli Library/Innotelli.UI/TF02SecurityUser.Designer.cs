namespace Innotelli.UI
{
    partial class TF02SecurityUser
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label valueLabel1;
            System.Windows.Forms.Label hasValueLabel1;
            System.Windows.Forms.Label valueLabel;
            System.Windows.Forms.Label hasValueLabel;
            System.Windows.Forms.Label slkGroupLabel;
            System.Windows.Forms.Label groupNameLabel;
            System.Windows.Forms.Label groupGUIDLabel;
            this.lyt01Base = new Innotelli.WinForm.Control.TLayoutControl01();
            this.descriptionTTextBox041 = new Innotelli.WinForm.Control.TTextBox04();
            this.bdsMaster = new System.Windows.Forms.BindingSource(this.components);
            this.initialTTextBox04 = new Innotelli.WinForm.Control.TTextBox04();
            this.grd02SecurityUserAssign = new Innotelli.WinForm.Control.TDataGrid02();
            this.tGridView021 = new Innotelli.WinForm.Control.TGridView02();
            this.colslkGroup = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colGroupName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDescription = new DevExpress.XtraGrid.Columns.GridColumn();
            this.userNameTTextBox06 = new Innotelli.WinForm.Control.TTextBox06();
            this.passwordTTextBox04 = new Innotelli.WinForm.Control.TTextBox04();
            this.layoutControlGroup011 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.layoutControlItem011 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlItem014 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlItem016 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem019 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlItem018 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem017 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.descriptionTTextBox04 = new Innotelli.WinForm.Control.TTextBox04();
            this.layoutControlItem013 = new Innotelli.WinForm.Control.LayoutControlItem01();
            valueLabel1 = new System.Windows.Forms.Label();
            hasValueLabel1 = new System.Windows.Forms.Label();
            valueLabel = new System.Windows.Forms.Label();
            hasValueLabel = new System.Windows.Forms.Label();
            slkGroupLabel = new System.Windows.Forms.Label();
            groupNameLabel = new System.Windows.Forms.Label();
            groupGUIDLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bmgBase)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lyt01Base)).BeginInit();
            this.lyt01Base.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.descriptionTTextBox041.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.initialTTextBox04.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd02SecurityUserAssign)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tGridView021)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.userNameTTextBox06.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordTTextBox04.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup011)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem011)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem014)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem016)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem019)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem018)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem017)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.descriptionTTextBox04.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem013)).BeginInit();
            this.SuspendLayout();
            // 
            // barStandard
            // 
            this.barStandard.OptionsBar.AllowQuickCustomization = false;
            this.barStandard.OptionsBar.DrawDragBorder = false;
            this.barStandard.OptionsBar.UseWholeRow = true;
            // 
            // barBaseStatus
            // 
            this.barBaseStatus.OptionsBar.AllowQuickCustomization = false;
            this.barBaseStatus.OptionsBar.DisableClose = true;
            this.barBaseStatus.OptionsBar.DrawDragBorder = false;
            this.barBaseStatus.OptionsBar.UseWholeRow = true;
            // 
            // valueLabel1
            // 
            valueLabel1.Location = new System.Drawing.Point(4, 475);
            valueLabel1.Name = "valueLabel1";
            valueLabel1.Size = new System.Drawing.Size(962, 177);
            valueLabel1.TabIndex = 21;
            // 
            // hasValueLabel1
            // 
            hasValueLabel1.Location = new System.Drawing.Point(4, 454);
            hasValueLabel1.Name = "hasValueLabel1";
            hasValueLabel1.Size = new System.Drawing.Size(962, 52);
            hasValueLabel1.TabIndex = 19;
            // 
            // valueLabel
            // 
            valueLabel.Location = new System.Drawing.Point(4, 433);
            valueLabel.Name = "valueLabel";
            valueLabel.Size = new System.Drawing.Size(962, 38);
            valueLabel.TabIndex = 17;
            // 
            // hasValueLabel
            // 
            hasValueLabel.Location = new System.Drawing.Point(4, 412);
            hasValueLabel.Name = "hasValueLabel";
            hasValueLabel.Size = new System.Drawing.Size(962, 32);
            hasValueLabel.TabIndex = 15;
            // 
            // slkGroupLabel
            // 
            slkGroupLabel.Location = new System.Drawing.Point(4, 392);
            slkGroupLabel.Name = "slkGroupLabel";
            slkGroupLabel.Size = new System.Drawing.Size(962, 28);
            slkGroupLabel.TabIndex = 13;
            // 
            // groupNameLabel
            // 
            groupNameLabel.Location = new System.Drawing.Point(4, 372);
            groupNameLabel.Name = "groupNameLabel";
            groupNameLabel.Size = new System.Drawing.Size(962, 24);
            groupNameLabel.TabIndex = 11;
            // 
            // groupGUIDLabel
            // 
            groupGUIDLabel.Location = new System.Drawing.Point(4, 352);
            groupGUIDLabel.Name = "groupGUIDLabel";
            groupGUIDLabel.Size = new System.Drawing.Size(962, 21);
            groupGUIDLabel.TabIndex = 9;
            // 
            // lyt01Base
            // 
            this.lyt01Base.Appearance.DisabledLayoutGroupCaption.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lyt01Base.Appearance.DisabledLayoutGroupCaption.Options.UseForeColor = true;
            this.lyt01Base.Appearance.DisabledLayoutItem.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lyt01Base.Appearance.DisabledLayoutItem.Options.UseForeColor = true;
            this.lyt01Base.Controls.Add(this.descriptionTTextBox041);
            this.lyt01Base.Controls.Add(this.initialTTextBox04);
            this.lyt01Base.Controls.Add(this.grd02SecurityUserAssign);
            this.lyt01Base.Controls.Add(this.userNameTTextBox06);
            this.lyt01Base.Controls.Add(this.passwordTTextBox04);
            this.lyt01Base.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lyt01Base.Location = new System.Drawing.Point(0, 26);
            this.lyt01Base.Name = "lyt01Base";
            this.lyt01Base.OptionsItemText.TextAlignMode = DevExpress.XtraLayout.TextAlignMode.AlignInGroups;
            this.lyt01Base.OptionsView.EnableIndentsInGroupsWithoutBorders = true;
            this.lyt01Base.Root = this.layoutControlGroup011;
            this.lyt01Base.Size = new System.Drawing.Size(692, 430);
            this.lyt01Base.TabIndex = 4;
            this.lyt01Base.Text = "tLayoutControl011";
            // 
            // descriptionTTextBox041
            // 
            this.descriptionTTextBox041.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.bdsMaster, "Description", true));
            this.descriptionTTextBox041.Location = new System.Drawing.Point(63, 43);
            this.descriptionTTextBox041.Margin = new System.Windows.Forms.Padding(0);
            this.descriptionTTextBox041.MenuManager = this.bmgBase;
            this.descriptionTTextBox041.Name = "descriptionTTextBox041";
            this.descriptionTTextBox041.Properties.BOT01 = null;
            this.descriptionTTextBox041.Properties.DSFormMode = Innotelli.WinForm.Control.DSFormMode.DSEditable;
            this.descriptionTTextBox041.Size = new System.Drawing.Size(351, 19);
            this.descriptionTTextBox041.StyleController = this.lyt01Base;
            this.descriptionTTextBox041.TabIndex = 13;
            // 
            // bdsMaster
            // 
            this.bdsMaster.DataSource = typeof(Innotelli.BO.TB01SecurityUserDr);
            // 
            // initialTTextBox04
            // 
            this.initialTTextBox04.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.bdsMaster, "Initial", true));
            this.initialTTextBox04.Location = new System.Drawing.Point(277, 23);
            this.initialTTextBox04.Margin = new System.Windows.Forms.Padding(0);
            this.initialTTextBox04.MenuManager = this.bmgBase;
            this.initialTTextBox04.Name = "initialTTextBox04";
            this.initialTTextBox04.Properties.BOT01 = null;
            this.initialTTextBox04.Properties.DSFormMode = Innotelli.WinForm.Control.DSFormMode.DSEditable;
            this.initialTTextBox04.Size = new System.Drawing.Size(137, 19);
            this.initialTTextBox04.StyleController = this.lyt01Base;
            this.initialTTextBox04.TabIndex = 12;
            // 
            // grd02SecurityUserAssign
            // 
            this.grd02SecurityUserAssign.AllowDrop = true;
            this.grd02SecurityUserAssign.Editable = true;
            this.grd02SecurityUserAssign.HasAddNewHdrBtn = false;
            this.grd02SecurityUserAssign.HasOpnDtlCol = false;
            this.grd02SecurityUserAssign.Location = new System.Drawing.Point(4, 63);
            this.grd02SecurityUserAssign.MainView = this.tGridView021;
            this.grd02SecurityUserAssign.MenuManager = this.bmgBase;
            this.grd02SecurityUserAssign.Name = "grd02SecurityUserAssign";
            this.grd02SecurityUserAssign.Size = new System.Drawing.Size(685, 365);
            this.grd02SecurityUserAssign.TabIndex = 8;
            this.grd02SecurityUserAssign.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.tGridView021});
            // 
            // tGridView021
            // 
            this.tGridView021.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colslkGroup,
            this.colGroupName,
            this.colDescription});
            this.tGridView021.GridControl = this.grd02SecurityUserAssign;
            this.tGridView021.Name = "tGridView021";
            // 
            // colslkGroup
            // 
            this.colslkGroup.Caption = "Group";
            this.colslkGroup.FieldName = "slkGroup";
            this.colslkGroup.Name = "colslkGroup";
            this.colslkGroup.Visible = true;
            this.colslkGroup.VisibleIndex = 0;
            // 
            // colGroupName
            // 
            this.colGroupName.Caption = "Group Name";
            this.colGroupName.FieldName = "GroupName";
            this.colGroupName.Name = "colGroupName";
            this.colGroupName.OptionsColumn.ReadOnly = true;
            this.colGroupName.Visible = true;
            this.colGroupName.VisibleIndex = 1;
            // 
            // colDescription
            // 
            this.colDescription.Caption = "Description";
            this.colDescription.FieldName = "GroupDescription";
            this.colDescription.Name = "colDescription";
            this.colDescription.OptionsColumn.ReadOnly = true;
            this.colDescription.Visible = true;
            this.colDescription.VisibleIndex = 2;
            // 
            // userNameTTextBox06
            // 
            this.userNameTTextBox06.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.bdsMaster, "UserName", true));
            this.userNameTTextBox06.Location = new System.Drawing.Point(63, 3);
            this.userNameTTextBox06.Margin = new System.Windows.Forms.Padding(0);
            this.userNameTTextBox06.MenuManager = this.bmgBase;
            this.userNameTTextBox06.Name = "userNameTTextBox06";
            this.userNameTTextBox06.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.userNameTTextBox06.Properties.Appearance.Options.UseBackColor = true;
            this.userNameTTextBox06.Properties.BOT01 = null;
            this.userNameTTextBox06.Properties.DSFormMode = Innotelli.WinForm.Control.DSFormMode.DSEditable;
            this.userNameTTextBox06.Properties.IsAutoNumber = true;
            this.userNameTTextBox06.Properties.ReadOnly = true;
            this.userNameTTextBox06.Size = new System.Drawing.Size(152, 19);
            this.userNameTTextBox06.StyleController = this.lyt01Base;
            this.userNameTTextBox06.TabIndex = 9;
            this.userNameTTextBox06.TabStop = false;
            // 
            // passwordTTextBox04
            // 
            this.passwordTTextBox04.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.bdsMaster, "Password", true));
            this.passwordTTextBox04.Location = new System.Drawing.Point(63, 23);
            this.passwordTTextBox04.Margin = new System.Windows.Forms.Padding(0);
            this.passwordTTextBox04.MenuManager = this.bmgBase;
            this.passwordTTextBox04.Name = "passwordTTextBox04";
            this.passwordTTextBox04.Properties.BOT01 = null;
            this.passwordTTextBox04.Properties.DSFormMode = Innotelli.WinForm.Control.DSFormMode.DSEditable;
            this.passwordTTextBox04.Size = new System.Drawing.Size(152, 19);
            this.passwordTTextBox04.StyleController = this.lyt01Base;
            this.passwordTTextBox04.TabIndex = 11;
            // 
            // layoutControlGroup011
            // 
            this.layoutControlGroup011.CustomizationFormText = "layoutControlGroup011";
            this.layoutControlGroup011.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem011,
            this.layoutControlItem014,
            this.layoutControlItem016,
            this.emptySpaceItem2,
            this.layoutControlItem019,
            this.layoutControlItem018,
            this.emptySpaceItem3,
            this.emptySpaceItem4});
            this.layoutControlGroup011.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup011.Name = "layoutControlGroup011";
            this.layoutControlGroup011.OptionsItemText.TextToControlDistance = 2;
            this.layoutControlGroup011.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup011.Size = new System.Drawing.Size(692, 430);
            this.layoutControlGroup011.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup011.Text = "layoutControlGroup011";
            this.layoutControlGroup011.TextVisible = false;
            // 
            // layoutControlItem011
            // 
            this.layoutControlItem011.Control = this.grd02SecurityUserAssign;
            this.layoutControlItem011.CustomizationFormText = "layoutControlItem011";
            this.layoutControlItem011.Location = new System.Drawing.Point(0, 60);
            this.layoutControlItem011.Name = "layoutControlItem011";
            this.layoutControlItem011.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem011.Size = new System.Drawing.Size(688, 366);
            this.layoutControlItem011.Text = "layoutControlItem011";
            this.layoutControlItem011.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem011.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem011.TextToControlDistance = 0;
            this.layoutControlItem011.TextVisible = false;
            // 
            // layoutControlItem014
            // 
            this.layoutControlItem014.Control = this.userNameTTextBox06;
            this.layoutControlItem014.CustomizationFormText = "User Name:";
            this.layoutControlItem014.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem014.Name = "layoutControlItem014";
            this.layoutControlItem014.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem014.Size = new System.Drawing.Size(214, 20);
            this.layoutControlItem014.Text = "User Name:";
            this.layoutControlItem014.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem014.TextSize = new System.Drawing.Size(57, 13);
            this.layoutControlItem014.TextToControlDistance = 2;
            // 
            // layoutControlItem016
            // 
            this.layoutControlItem016.Control = this.passwordTTextBox04;
            this.layoutControlItem016.CustomizationFormText = "Password:";
            this.layoutControlItem016.Location = new System.Drawing.Point(0, 20);
            this.layoutControlItem016.Name = "layoutControlItem016";
            this.layoutControlItem016.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem016.Size = new System.Drawing.Size(214, 20);
            this.layoutControlItem016.Text = "Password:";
            this.layoutControlItem016.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem016.TextSize = new System.Drawing.Size(57, 13);
            this.layoutControlItem016.TextToControlDistance = 2;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(214, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(474, 20);
            this.emptySpaceItem2.Text = "emptySpaceItem2";
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem019
            // 
            this.layoutControlItem019.Control = this.descriptionTTextBox041;
            this.layoutControlItem019.CustomizationFormText = "Description:";
            this.layoutControlItem019.Location = new System.Drawing.Point(0, 40);
            this.layoutControlItem019.Name = "layoutControlItem019";
            this.layoutControlItem019.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem019.Size = new System.Drawing.Size(413, 20);
            this.layoutControlItem019.Text = "Description:";
            this.layoutControlItem019.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem019.TextSize = new System.Drawing.Size(57, 13);
            this.layoutControlItem019.TextToControlDistance = 2;
            // 
            // layoutControlItem018
            // 
            this.layoutControlItem018.Control = this.initialTTextBox04;
            this.layoutControlItem018.CustomizationFormText = "Initial:";
            this.layoutControlItem018.Location = new System.Drawing.Point(214, 20);
            this.layoutControlItem018.Name = "layoutControlItem018";
            this.layoutControlItem018.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem018.Size = new System.Drawing.Size(199, 20);
            this.layoutControlItem018.Text = "Initial:";
            this.layoutControlItem018.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem018.TextSize = new System.Drawing.Size(57, 13);
            this.layoutControlItem018.TextToControlDistance = 2;
            // 
            // emptySpaceItem3
            // 
            this.emptySpaceItem3.CustomizationFormText = "emptySpaceItem3";
            this.emptySpaceItem3.Location = new System.Drawing.Point(413, 20);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(275, 20);
            this.emptySpaceItem3.Text = "emptySpaceItem3";
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem4
            // 
            this.emptySpaceItem4.CustomizationFormText = "emptySpaceItem4";
            this.emptySpaceItem4.Location = new System.Drawing.Point(413, 40);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(275, 20);
            this.emptySpaceItem4.Text = "emptySpaceItem4";
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem017
            // 
            this.layoutControlItem017.CustomizationFormText = "layoutControlItem017";
            this.layoutControlItem017.Location = new System.Drawing.Point(0, 695);
            this.layoutControlItem017.Name = "layoutControlItem017";
            this.layoutControlItem017.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem017.Size = new System.Drawing.Size(1073, 84);
            this.layoutControlItem017.Text = "layoutControlItem017";
            this.layoutControlItem017.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem017.TextSize = new System.Drawing.Size(56, 13);
            this.layoutControlItem017.TextToControlDistance = 2;
            // 
            // descriptionTTextBox04
            // 
            this.descriptionTTextBox04.Location = new System.Drawing.Point(149, 670);
            this.descriptionTTextBox04.Margin = new System.Windows.Forms.Padding(0);
            this.descriptionTTextBox04.MenuManager = this.bmgBase;
            this.descriptionTTextBox04.Name = "descriptionTTextBox04";
            this.descriptionTTextBox04.Properties.BOT01 = null;
            this.descriptionTTextBox04.Properties.DSFormMode = Innotelli.WinForm.Control.DSFormMode.DSEditable;
            this.descriptionTTextBox04.Size = new System.Drawing.Size(100, 19);
            this.descriptionTTextBox04.TabIndex = 11;
            // 
            // layoutControlItem013
            // 
            this.layoutControlItem013.CustomizationFormText = "layoutControlItem013";
            this.layoutControlItem013.Location = new System.Drawing.Point(0, 743);
            this.layoutControlItem013.Name = "layoutControlItem013";
            this.layoutControlItem013.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem013.Size = new System.Drawing.Size(1037, 25);
            this.layoutControlItem013.Text = "layoutControlItem013";
            this.layoutControlItem013.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem013.TextSize = new System.Drawing.Size(50, 20);
            // 
            // TF02SecurityUser
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(692, 482);
            this.Controls.Add(this.lyt01Base);
            this.Name = "TF02SecurityUser";
            this.Text = "TF02SecurityUser";
            this.Controls.SetChildIndex(this.barDockControlTop, 0);
            this.Controls.SetChildIndex(this.barDockControlBottom, 0);
            this.Controls.SetChildIndex(this.barDockControlRight, 0);
            this.Controls.SetChildIndex(this.barDockControlLeft, 0);
            this.Controls.SetChildIndex(this.lyt01Base, 0);
            ((System.ComponentModel.ISupportInitialize)(this.bmgBase)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lyt01Base)).EndInit();
            this.lyt01Base.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.descriptionTTextBox041.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.initialTTextBox04.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd02SecurityUserAssign)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tGridView021)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.userNameTTextBox06.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.passwordTTextBox04.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup011)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem011)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem014)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem016)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem019)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem018)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem017)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.descriptionTTextBox04.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem013)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Innotelli.WinForm.Control.TLayoutControl01 lyt01Base;
        private Innotelli.WinForm.Control.LayoutControlGroup01 layoutControlGroup011;
        private System.Windows.Forms.BindingSource bdsMaster;
        private Innotelli.WinForm.Control.TDataGrid02 grd02SecurityUserAssign;
        private Innotelli.WinForm.Control.TGridView02 tGridView021;
        private DevExpress.XtraGrid.Columns.GridColumn colGroupName;
        private DevExpress.XtraGrid.Columns.GridColumn colDescription;
        private Innotelli.WinForm.Control.LayoutControlItem01 layoutControlItem011;
        private Innotelli.WinForm.Control.LayoutControlItem01 layoutControlItem017;
        private Innotelli.WinForm.Control.TTextBox04 descriptionTTextBox04;
        private Innotelli.WinForm.Control.LayoutControlItem01 layoutControlItem013;
        private Innotelli.WinForm.Control.TTextBox06 userNameTTextBox06;
        private Innotelli.WinForm.Control.LayoutControlItem01 layoutControlItem014;
        private Innotelli.WinForm.Control.TTextBox04 initialTTextBox04;
        private Innotelli.WinForm.Control.TTextBox04 passwordTTextBox04;
        private Innotelli.WinForm.Control.LayoutControlItem01 layoutControlItem016;
        private Innotelli.WinForm.Control.LayoutControlItem01 layoutControlItem018;
        private Innotelli.WinForm.Control.TTextBox04 descriptionTTextBox041;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private Innotelli.WinForm.Control.LayoutControlItem01 layoutControlItem019;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private DevExpress.XtraGrid.Columns.GridColumn colslkGroup;
    }
}