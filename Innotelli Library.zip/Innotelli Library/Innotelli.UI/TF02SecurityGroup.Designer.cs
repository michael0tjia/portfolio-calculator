namespace Innotelli.UI
{
    partial class TF02SecurityGroup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lyt01Base = new Innotelli.WinForm.Control.TLayoutControl01();
            this.descriptionTTextBox04 = new Innotelli.WinForm.Control.TTextBox04();
            this.bdsMaster = new System.Windows.Forms.BindingSource(this.components);
            this.grd02SecurityPermissionAssign = new Innotelli.WinForm.Control.TDataGrid02();
            this.tGridView021 = new Innotelli.WinForm.Control.TGridView02();
            this.colDescription = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colPermissionAllow = new DevExpress.XtraGrid.Columns.GridColumn();
            this.groupNameTTextBox061 = new Innotelli.WinForm.Control.TTextBox06();
            this.layoutControlGroup011 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.layoutControlItem013 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlItem011 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlItem015 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lyt01Base)).BeginInit();
            this.lyt01Base.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.descriptionTTextBox04.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsMaster)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd02SecurityPermissionAssign)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tGridView021)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupNameTTextBox061.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup011)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem013)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem011)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem015)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            this.SuspendLayout();
            // 
            // lyt01Base
            // 
            this.lyt01Base.Controls.Add(this.descriptionTTextBox04);
            this.lyt01Base.Controls.Add(this.grd02SecurityPermissionAssign);
            this.lyt01Base.Controls.Add(this.groupNameTTextBox061);
            this.lyt01Base.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lyt01Base.Location = new System.Drawing.Point(0, 26);
            this.lyt01Base.Name = "lyt01Base";
            this.lyt01Base.OptionsItemText.TextAlignMode = DevExpress.XtraLayout.TextAlignMode.AlignInGroups;
            this.lyt01Base.OptionsView.EnableIndentsInGroupsWithoutBorders = true;
            this.lyt01Base.Root = this.layoutControlGroup011;
            this.lyt01Base.Size = new System.Drawing.Size(709, 544);
            this.lyt01Base.TabIndex = 0;
            this.lyt01Base.Text = "tLayoutControl011";
            // 
            // descriptionTTextBox04
            // 
            this.descriptionTTextBox04.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.bdsMaster, "Description", true));
            this.descriptionTTextBox04.Location = new System.Drawing.Point(68, 21);
            this.descriptionTTextBox04.Margin = new System.Windows.Forms.Padding(0);
            this.descriptionTTextBox04.MenuManager = this.bmgBase;
            this.descriptionTTextBox04.Name = "descriptionTTextBox04";
            this.descriptionTTextBox04.Properties.BOT01 = null;
            this.descriptionTTextBox04.Properties.DSFormMode = Innotelli.WinForm.Control.DSFormMode.DSEditable;
            this.descriptionTTextBox04.Size = new System.Drawing.Size(418, 19);
            this.descriptionTTextBox04.StyleController = this.lyt01Base;
            this.descriptionTTextBox04.TabIndex = 9;
            // 
            // bdsMaster
            // 
            this.bdsMaster.DataSource = typeof(Innotelli.BO.TB01SecurityGroupDr);
            // 
            // grd02SecurityPermissionAssign
            // 
            this.grd02SecurityPermissionAssign.AllowDrop = true;
            this.grd02SecurityPermissionAssign.Editable = true;
            this.grd02SecurityPermissionAssign.HasAddNewHdrBtn = false;
            this.grd02SecurityPermissionAssign.HasOpnDtlCol = false;
            this.grd02SecurityPermissionAssign.Location = new System.Drawing.Point(3, 40);
            this.grd02SecurityPermissionAssign.MainView = this.tGridView021;
            this.grd02SecurityPermissionAssign.MenuManager = this.bmgBase;
            this.grd02SecurityPermissionAssign.Name = "grd02SecurityPermissionAssign";
            this.grd02SecurityPermissionAssign.Size = new System.Drawing.Size(703, 502);
            this.grd02SecurityPermissionAssign.TabIndex = 8;
            this.grd02SecurityPermissionAssign.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.tGridView021});
            // 
            // tGridView021
            // 
            this.tGridView021.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colDescription,
            this.colPermissionAllow});
            this.tGridView021.GridControl = this.grd02SecurityPermissionAssign;
            this.tGridView021.Name = "tGridView021";
            // 
            // colDescription
            // 
            this.colDescription.Caption = "Description";
            this.colDescription.FieldName = "Description";
            this.colDescription.Name = "colDescription";
            this.colDescription.Visible = true;
            this.colDescription.VisibleIndex = 0;
            this.colDescription.Width = 300;
            // 
            // colPermissionAllow
            // 
            this.colPermissionAllow.FieldName = "PermissionAllow";
            this.colPermissionAllow.Name = "colPermissionAllow";
            this.colPermissionAllow.Visible = true;
            this.colPermissionAllow.VisibleIndex = 1;
            this.colPermissionAllow.Width = 150;
            // 
            // groupNameTTextBox061
            // 
            this.groupNameTTextBox061.DataBindings.Add(new System.Windows.Forms.Binding("EditValue", this.bdsMaster, "GroupName", true));
            this.groupNameTTextBox061.Location = new System.Drawing.Point(68, 2);
            this.groupNameTTextBox061.Margin = new System.Windows.Forms.Padding(0);
            this.groupNameTTextBox061.MenuManager = this.bmgBase;
            this.groupNameTTextBox061.Name = "groupNameTTextBox061";
            this.groupNameTTextBox061.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.groupNameTTextBox061.Properties.Appearance.Options.UseBackColor = true;
            this.groupNameTTextBox061.Properties.BOT01 = null;
            this.groupNameTTextBox061.Properties.DSFormMode = Innotelli.WinForm.Control.DSFormMode.DSEditable;
            this.groupNameTTextBox061.Properties.IsAutoNumber = true;
            this.groupNameTTextBox061.Properties.ReadOnly = true;
            this.groupNameTTextBox061.Size = new System.Drawing.Size(174, 19);
            this.groupNameTTextBox061.StyleController = this.lyt01Base;
            this.groupNameTTextBox061.TabIndex = 6;
            this.groupNameTTextBox061.TabStop = false;
            // 
            // layoutControlGroup011
            // 
            this.layoutControlGroup011.CustomizationFormText = "layoutControlGroup011";
            this.layoutControlGroup011.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem013,
            this.layoutControlItem011,
            this.layoutControlItem015,
            this.emptySpaceItem1,
            this.emptySpaceItem2});
            this.layoutControlGroup011.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup011.Name = "layoutControlGroup011";
            this.layoutControlGroup011.OptionsItemText.TextToControlDistance = 2;
            this.layoutControlGroup011.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup011.Size = new System.Drawing.Size(709, 544);
            this.layoutControlGroup011.Text = "layoutControlGroup011";
            this.layoutControlGroup011.TextVisible = false;
            // 
            // layoutControlItem013
            // 
            this.layoutControlItem013.Control = this.groupNameTTextBox061;
            this.layoutControlItem013.CustomizationFormText = "Group Name:";
            this.layoutControlItem013.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem013.Name = "layoutControlItem013";
            this.layoutControlItem013.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem013.Size = new System.Drawing.Size(241, 19);
            this.layoutControlItem013.Text = "Group Name:";
            this.layoutControlItem013.TextSize = new System.Drawing.Size(63, 13);
            this.layoutControlItem013.TextToControlDistance = 2;
            // 
            // layoutControlItem011
            // 
            this.layoutControlItem011.Control = this.grd02SecurityPermissionAssign;
            this.layoutControlItem011.CustomizationFormText = "layoutControlItem011";
            this.layoutControlItem011.Location = new System.Drawing.Point(0, 38);
            this.layoutControlItem011.Name = "layoutControlItem011";
            this.layoutControlItem011.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem011.Size = new System.Drawing.Size(705, 502);
            this.layoutControlItem011.Text = "layoutControlItem011";
            this.layoutControlItem011.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem011.TextToControlDistance = 0;
            this.layoutControlItem011.TextVisible = false;
            // 
            // layoutControlItem015
            // 
            this.layoutControlItem015.Control = this.descriptionTTextBox04;
            this.layoutControlItem015.CustomizationFormText = "Description:";
            this.layoutControlItem015.Location = new System.Drawing.Point(0, 19);
            this.layoutControlItem015.Name = "layoutControlItem015";
            this.layoutControlItem015.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem015.Size = new System.Drawing.Size(485, 19);
            this.layoutControlItem015.Text = "Description:";
            this.layoutControlItem015.TextSize = new System.Drawing.Size(63, 13);
            this.layoutControlItem015.TextToControlDistance = 2;
            // 
            // emptySpaceItem1
            // 
            this.emptySpaceItem1.CustomizationFormText = "emptySpaceItem1";
            this.emptySpaceItem1.Location = new System.Drawing.Point(241, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(464, 19);
            this.emptySpaceItem1.Text = "emptySpaceItem1";
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.CustomizationFormText = "emptySpaceItem2";
            this.emptySpaceItem2.Location = new System.Drawing.Point(485, 19);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(220, 19);
            this.emptySpaceItem2.Text = "emptySpaceItem2";
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // TF02SecurityGroup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(709, 596);
            this.Controls.Add(this.lyt01Base);
            this.Name = "TF02SecurityGroup";
            this.Text = "TF02SecurityGroup";
            this.Controls.SetChildIndex(this.lyt01Base, 0);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lyt01Base)).EndInit();
            this.lyt01Base.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.descriptionTTextBox04.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bdsMaster)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grd02SecurityPermissionAssign)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tGridView021)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupNameTTextBox061.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup011)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem013)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem011)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem015)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Innotelli.WinForm.Control.TLayoutControl01 lyt01Base;
        private Innotelli.WinForm.Control.LayoutControlGroup01 layoutControlGroup011;
        private System.Windows.Forms.BindingSource bdsMaster;
        private Innotelli.WinForm.Control.TTextBox06 groupNameTTextBox061;
        private Innotelli.WinForm.Control.LayoutControlItem01 layoutControlItem013;
        private Innotelli.WinForm.Control.TDataGrid02 grd02SecurityPermissionAssign;
        private Innotelli.WinForm.Control.TGridView02 tGridView021;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private Innotelli.WinForm.Control.LayoutControlItem01 layoutControlItem011;
        private Innotelli.WinForm.Control.TTextBox04 descriptionTTextBox04;
        private Innotelli.WinForm.Control.LayoutControlItem01 layoutControlItem015;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraGrid.Columns.GridColumn colPermissionAllow;
        private DevExpress.XtraGrid.Columns.GridColumn colDescription;
    }
}