using System;
using System.Collections.Generic;
using System.Text;
using C1.Win.C1Report;
using System.Drawing;
using System.Drawing.Imaging;

namespace Innotelli.Report
{
    public class TOMR
    {
        public TOMR()
        {
        }

        public int AddOMR(C1Report aC1Rpt, int aWAS)
        {
            int lRtrnVal = aWAS;
            Graphics lGrphcsRef;
            Graphics lGrphcs;
            Image lPgImg;
            IntPtr lHdc;
            Metafile lMetafile;
            Rectangle lRctngl;

            // render report as usual
            // aC1Rpt.Render();

            // get reference dc for new metafiles
            lGrphcsRef = Graphics.FromHwnd(IntPtr.Zero);
            lGrphcsRef.PageUnit = GraphicsUnit.Millimeter;
            lHdc = lGrphcsRef.GetHdc();

            // enumerate and modify pages
            for (int lPg = 0; lPg < aC1Rpt.PageImages.Count; lPg++)
            {
                // get page image
                lPgImg = (Image)aC1Rpt.PageImages[lPg];

                // create new image
                lRctngl = new Rectangle(0, 0, lPgImg.Width, lPgImg.Height);
                lMetafile = new Metafile(lHdc, lRctngl, MetafileFrameUnit.Pixel, EmfType.EmfOnly);
                lGrphcs = Graphics.FromImage(lMetafile);
                lGrphcs.PageUnit = GraphicsUnit.Pixel;

                // copy original page
                lGrphcs.DrawImage(lPgImg, lRctngl);

                // add OMR marks
                AddPgMarks(lGrphcs, lPgImg, lPg, aC1Rpt.PageImages.Count, lRtrnVal);

                // done with this page
                if (lGrphcs != null)
                {
                    lGrphcs.Dispose();
                    //lGrphcs = null;
                }
                //if (lMetafile != null)
                //{
                //    lMetafile.Dispose();
                //}

                // save new page
                aC1Rpt.PageImages[lPg] = lMetafile;

                lRtrnVal = ++lRtrnVal % 8;
            }

            // done with reference graphics
            lGrphcsRef.ReleaseHdc(lHdc);
            if (lGrphcsRef != null)
            {
                lGrphcsRef.Dispose();
            }

            return lRtrnVal;
        }

        public void AddPgMarks(Graphics aGrphcs, Image aPgImg, int aCurPgOfSet, int aTtlPgOfSet, int aWAS)
        {
            float lHorPPM = (float)(aPgImg.HorizontalResolution / 2.54 / 10);
            float lVerPPM = (float)(aPgImg.VerticalResolution / 2.54 / 10);

            float lThck = (float)0.525 * lVerPPM;
            float lLngth = (float)12 * lHorPPM;

            float lXStart = (float)aPgImg.Width - (17 * lHorPPM);
            float lYStart = (float)aPgImg.Height / 4 * 3;
            float lXEnd = lXStart + lLngth;
            float lSpc = (float)(2.54 * lVerPPM) + (lThck * 2);

            int lPrnted = 0;
            Pen lPen = new Pen(Color.Black, lThck);

            for (int lLine = 0; lLine < 8; lLine++)
            {
                switch (lLine)
                {
                    case 0: //BM
                        aGrphcs.DrawLine(lPen, lXStart, lYStart, lXEnd, lYStart);
                        break;
                    case 1: //EOC
                        if (aCurPgOfSet == 0)
                        {
                            aGrphcs.DrawLine(lPen, lXStart, lYStart, lXEnd, lYStart);
                            lPrnted++;
                        }
                        break;
                    case 2: //BOC
                        if (aCurPgOfSet == aTtlPgOfSet - 1)
                        {
                            aGrphcs.DrawLine(lPen, lXStart, lYStart, lXEnd, lYStart);
                            lPrnted++;
                        }
                        break;
                    case 3: //WAS1
                        if (aWAS % 2 == 1)
                        {
                            aGrphcs.DrawLine(lPen, lXStart, lYStart, lXEnd, lYStart);
                            lPrnted++;
                        }
                        break;
                    case 4: //WAS2
                        if (aWAS % 4 / 2 >= 1)
                        {
                            aGrphcs.DrawLine(lPen, lXStart, lYStart, lXEnd, lYStart);
                            lPrnted++;
                        }
                        break;
                    case 5: //WAS3
                        if (aWAS / 4 >= 1)
                        {
                            aGrphcs.DrawLine(lPen, lXStart, lYStart, lXEnd, lYStart);
                            lPrnted++;
                        }
                        break;
                    case 6: //PAR
                        if (lPrnted % 2 == 1)
                        {
                            aGrphcs.DrawLine(lPen, lXStart, lYStart, lXEnd, lYStart);
                        }
                        break;
                    case 7: //SAF
                        aGrphcs.DrawLine(lPen, lXStart, lYStart, lXEnd, lYStart);
                        break;
                }
                lYStart += lSpc;
            }
        }
    }
}
