using System;
using System.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Drawing.Printing;
using System.Reflection;
using System.Text;
using C1.Win.C1Report;
using Innotelli.BO;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.Report
{
    public class TRptEngine
    {
        #region Members
        private DBType mDBVndr = DBType.MsSQLSvr;

        private string mCriteria = string.Empty;
        private string mCriteriaFullTxt = string.Empty;
        private string mParamFullText = string.Empty;
        private string mOrderByFieldList = string.Empty;

        private string mRptFullText = string.Empty;
        private string mRptID = string.Empty;

        private TSPrpsRPT01 mSPrpsRPT01 = new TSPrpsRPT01();
        private TRptFltr mRptFltr = null;

        private TSysDataRdr mSysDataRdr = Innotelli.Utilities.TSingletons.SysData01Rdr;

        private TRptT01 mRptT01 = null;
        private C1Report mC1Rpt = new C1Report();

        private DataSet mRptMainDs = null;
        private DataSet mCmnMiscDs = null;
        private DataSet mRptMiscDs = null;

        #endregion

        #region Constructors
        public TRptEngine()
        {
        }
        #endregion

        #region Enums
        public enum DBType
        {
            MsAccess = 0,
            MsSQLSvr = 1
        }
        #endregion

        #region Properties
        private string DLLFolder
        {
            get
            {
                return Innotelli.Utilities.TGC.BaseDirectory;
            }
        }
        public string RptPackNameSpace
        {
            get
            {
                return "BackOffice.RptPack";
            }
        }
        public TRptT01 RptT01
        {
            get
            {
                return mRptT01;
            }
            set
            {
                mRptT01 = value;
            }
        }
        public DBType DBVndr
        {
            get
            {
                return mDBVndr;
            }
            set
            {
                mDBVndr = value;
            }
        }
        public string Criteria
        {
            get
            {
                return mCriteria;
            }
            set
            {
                mCriteria = value;
            }
        }
        public string CriteriaFullTxt
        {
            get
            {
                return mCriteriaFullTxt;
            }
            set
            {
                if (mCriteriaFullTxt == value)
                    return;
                mCriteriaFullTxt = value;
            }
        }
        public string ParamFullText
        {
            get
            {
                return mParamFullText;
            }
            set
            {
                if (mParamFullText == value)
                    return;
                mParamFullText = value;
            }
        }
        public string OrderByFieldList
        {
            get
            {
                return mOrderByFieldList;
            }
            set
            {
                if (mOrderByFieldList == value)
                    return;
                mOrderByFieldList = value;
            }
        }
        public string RptFullText
        {
            get
            {
                return mRptFullText;
            }
            set
            {
                if (mRptFullText == value)
                    return;
                mRptFullText = value;
            }
        }
        public string RptID
        {
            get
            {
                return mRptID;
            }
            set
            {
                if (mRptID == value)
                    return;
                mRptID = value;
                SPrpsRPT01.RptID = mRptID;
                mRptT01 = CreateRptT01Obj();
            }
        }
        //#check!
        public TSPrpsRPT01 SPrpsRPT01
        {
            get
            {
                return mSPrpsRPT01;
            }
            set
            {
                if (mSPrpsRPT01 == value)
                    return;
                mSPrpsRPT01 = value;
            }
        }
        public TRptFltr RptFltr
        {
            get
            {
                return mRptFltr;
            }
            set
            {
                if (mRptFltr == value)
                    return;
                mRptFltr = value;
            }
        }
        public C1Report C1Rpt
        {
            get
            {
                return mC1Rpt;
            }
            set
            {
                mC1Rpt = value;
            }
        }
        public DataSet RptMainDs
        {
            get
            {
                return mRptMainDs;
            }
            set
            {
                if (mRptMainDs == value)
                    return;
                mRptMainDs = value;
            }
        }
        public DataSet CmnMiscDs
        {
            get
            {
                return mCmnMiscDs;
            }
            set
            {
                if (mCmnMiscDs == value)
                    return;
                mCmnMiscDs = value;
            }
        }
        public DataSet RptMiscDs
        {
            get
            {
                return mRptMiscDs;
            }
            set
            {
                if (mRptMiscDs == value)
                    return;
                mRptMiscDs = value;
            }
        }
        private bool mUseRptExternalMainDs = false;
        public bool UseRptExternalMainDs
        {
            get
            {
                return mUseRptExternalMainDs;
            }
            set
            {
                mUseRptExternalMainDs = value;
            }
        }

        private DataSet mRptExternalMainDs = null;
        public DataSet RptExternalMainDs
        {
            get
            {
                return mRptExternalMainDs;
            }
            set
            {
                mUseRptExternalMainDs = (value != null);
                mRptExternalMainDs = value;
            }
        }
        #endregion

        #region Event Handlers

        #endregion

        #region Functions

        #region Flow
        public void ProcessPhase1()
        {
            InitCriteria();
            LoadDataSets();
            if (mRptT01 != null)
            {
                RptT01.MiscDs = RptMiscDs;
            }
            LoadRptTemplate();
            BindData();
        }
        public void ProcessPhase2()
        {
            BeforeRender();
            Render();
            AfterRender();
        }
        public void ProcessPhase2Export(FileFormats aFileFormat, string aFileName)
        {
            string lFlExt = "." + aFileFormat.ToString();
            FileFormatEnum lC1FileFormatEnum;
            BeforeRender();
            switch (aFileFormat)
            {
                case FileFormats.Rtf:
                    lC1FileFormatEnum = FileFormatEnum.RTF;
                    break;
                case FileFormats.Xls:
                    lC1FileFormatEnum = FileFormatEnum.Excel;
                    break;
                case FileFormats.Pdf:
                    lC1FileFormatEnum = FileFormatEnum.PDF;
                    break;
                default:
                    lC1FileFormatEnum = FileFormatEnum.Text;
                    break;
            }
            if (aFileName == string.Empty)
            {
                C1Rpt.RenderToFile("D:\\" + mSPrpsRPT01.RptAls + lFlExt, lC1FileFormatEnum);
            }
            else
            {
                C1Rpt.RenderToFile(aFileName, lC1FileFormatEnum);
            }
        }
        private TRptT01 CreateRptT01Obj()
        {
            TRptT01 lRtrnVal = null;
            Assembly lAssembly = null;
            Object[] lParm = null;
            //#check!
            // need to derive a better way to manage dll folder and namespace.
            string lDash = DLLFolder.EndsWith("\\") ? string.Empty : "\\";

            lAssembly = Assembly.Load("BackOffice.RptPack");
            lParm = new Object[0];
            lRtrnVal = (TRptT01)lAssembly.CreateInstance(RptPackNameSpace + "." + "T" + RptID, true, BindingFlags.Default | BindingFlags.InvokeMethod, null, lParm, null, null);
            return lRtrnVal;
        }
        private void PrepareTmpData()
        {
            if (DBVndr == DBType.MsAccess)
            {
                PrepareMSAccessData();
            }
        }
        private void ClearTmpData()
        {
            if (DBVndr == DBType.MsAccess)
            {
                ClearMSAccessData();
            }
        }
        private void LoadRptTemplate()
        {
            //if (TAppSettings.DefaultSysDataFormat == TSysDataRdr.Formats.EncryptedZippedXml)
            //{
            //    C1Rpt.Load(mSysDataRdr.GetSysDataXmlDoc(SPrpsRPT01.RptNm), SPrpsRPT01.RptNm);
            //}
            //else if (TAppSettings.DefaultSysDataFormat == TSysDataRdr.Formats.UnencryptedXml)
            //{
                C1Rpt.Load(Innotelli.Utilities.TGC.BaseDirectory + Innotelli.Utilities.TGC.SYSDATA02_FOLDER_NAME + @"\" + SPrpsRPT01.RptNm + ".xml", SPrpsRPT01.RptNm);
            //}
        }
        private void InitCriteria()
        {
            string lCriteriaFullText = string.Empty;
            string lParamFullText = string.Empty;
            if (RptFltr != null)
            {
                Criteria = RptFltr.GetCriteria(ref lCriteriaFullText, ref lParamFullText);
                CriteriaFullTxt = lCriteriaFullText;
                ParamFullText = lParamFullText;
                RptFullText = CriteriaFullTxt + "\r\n" + ParamFullText;
            }
        }
        private void LoadDataSets()
        {
            DataSet lRptMainDs = new DataSet();
            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                PrepareTmpData();
                if (!mUseRptExternalMainDs)
                {
                    if (DBVndr == DBType.MsAccess)
                    {
                        LoadDtFromMSAccess();
                    }
                    else if (DBVndr == DBType.MsSQLSvr)
                    {
                        LoadDtFromMSSQLSvr();
                    }
                }
                else
                {
                    mRptMainDs = mRptExternalMainDs;
                }
                LoadCmnMiscData();
                LoadRptMiscData();
                ClearTmpData();
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();

                lReflectionParams["aRptID"] = RptID;
                if (RptFltr != null)
                {
                    lReflectionParams["aRptFltrDs"] = RptFltr.CriteiraDs;
                }
                else
                {
                    lReflectionParams["aRptFltrDs"] = new DataSet();
                }
                lReflectionParams["aCriteria"] = Criteria;
                lReflectionParams["aOrderByFieldList"] = OrderByFieldList;
                lReflectionParams["aUseRptExternalMainDs"] = mUseRptExternalMainDs;
                lReflectionParams["aCmnMiscDs"] = new DataSet();
                lReflectionParams["aRptMiscDs"] = new DataSet();
                lRptMainDs = (DataSet)TReflectionClient.ExecuteMethod(this.GetType().FullName, "WSGetRptDataSets", lReflectionParams);
                if (!mUseRptExternalMainDs)
                {
                    mRptMainDs = (DataSet)lRptMainDs;
                }
                else
                {
                    mRptMainDs = mRptExternalMainDs;
                }
                mCmnMiscDs = (DataSet)lReflectionParams["aCmnMiscDs"];
                mRptMiscDs = (DataSet)lReflectionParams["aRptMiscDs"];
            }
        }
        public DataSet WSGetRptDataSets(string aRptID, DataSet aRptFltrDs, string aCriteria, string aOrderByFieldList, bool aUseRptExternalMainDs, ref DataSet aCmnMiscDs, ref DataSet aRptMiscDs)
        {
            DataSet lRtrnVal = null;
            RptID = aRptID;
            OrderByFieldList = aOrderByFieldList;
            Criteria = aCriteria;
            // Empty DataSet?
            if (aRptFltrDs.Tables.Count != 0)
            {
                RptFltr = new TRptFltr();
                RptFltr.CriteiraDs = aRptFltrDs;
                RptFltr.RptNm = aRptID;
            }
            mUseRptExternalMainDs = aUseRptExternalMainDs;
            LoadDataSets();
            lRtrnVal = RptMainDs;
            aCmnMiscDs = CmnMiscDs;
            aRptMiscDs = RptMiscDs;
            if (aCmnMiscDs == null)
            {
                aCmnMiscDs = new DataSet();
            }
            if (aRptMiscDs == null)
            {
                aRptMiscDs = new DataSet();
            }
            return lRtrnVal;
        }
        private void BindData()
        {
            C1Rpt.DataSource.Recordset = RptMainDs.Tables[0];
        }
        public void BeforeRender()
        {
            GenRptHeading();
            GenRptCmpyLogos();
            ExecRptBeforeRender();
        }
        public void Render()
        {
            //#check!
            C1Rpt.Layout.PaperSize = PaperKind.A4;
            C1Rpt.Render();
        }
        public void AfterRender()
        {
        }
        #endregion

        #region Others

        #region Load Data

        #region Access
        private void PrepareMSAccessData()
        {
            switch (SPrpsRPT01.DataPrepType)
            {
                case 1:
                    break;
                case 2:
                    ExecAccessSPrc();
                    break;
                case 3:
                    ExceRptPrepareData();
                    break;
            }
        }
        private void ClearMSAccessData()
        {
        }
        private void ExecAccessSPrc()
        {
            TAccessSPrc lAccessSPrc = null;
            long lDataPrepType = -1;
            string lAccessSPrcNm = string.Empty;
            lAccessSPrc = new TAccessSPrc();
            lDataPrepType = SPrpsRPT01.DataPrepType;
            lAccessSPrcNm = SPrpsRPT01.AccessSPrcNm;
            if ((lDataPrepType == 2) && (lAccessSPrcNm != string.Empty))
            {
                lAccessSPrc.Name = lAccessSPrcNm;
                for (int i = 0; i < RptFltr.CriteiraDv.Count; i++)
                {
                    if (bool.Parse(RptFltr.CriteiraDv[i]["IsParam"].ToString()))
                    {
                        lAccessSPrc.Params.AddWithValue("FldNm", RptFltr.CriteiraDv[i]["Value1"]);
                    }
                }
                lAccessSPrc.Process();
            }
        }
        private void ExceRptPrepareData()
        {
            if (RptT01 != null)
            {
                RptT01.RptFltr = RptFltr;
                RptT01.PrepareData();
            }
        }
        private void LoadDtFromMSAccess()
        {
            DataSet lRptMainDs = new DataSet();
            TDataObject lDao = new TDataObject();
            lDao.SQL.Stmt = "SELECT " + SPrpsRPT01.RrdSrc + ".* FROM " + SPrpsRPT01.RrdSrc;
            if (Criteria != string.Empty)
            {
                lDao.SQL.AddToWhereClause(Criteria);
            }
            lDao.OpenTable();
            lRptMainDs.Tables.Add(lDao.Dt);
            RptMainDs = lRptMainDs;
        }
        #endregion

        #region SQL Server
        private void LoadDtFromMSSQLSvr()
        {
            DataSet lRptMainDs = new DataSet();
            TDataObject lDao = null;
            int i = 0;
            string lValue1 = string.Empty;
            DateTime lDate;
            lDao = new TDataObject();
            lDao.SQL.Stmt = SPrpsRPT01.RrdSrc;
            lDao.CmdTimeOut = 600;
            lDao.CmdType = CommandType.StoredProcedure;

            if (Criteria != string.Empty)
            {
                lDao.Params.AddWithValue("@Where", "WHERE (" + Criteria + ")");
            }
            else
            {
                lDao.Params.AddWithValue("@Where", string.Empty);
            }
            if (OrderByFieldList != string.Empty)
            {
                lDao.Params.AddWithValue("@OrderBy", "ORDER BY (" + OrderByFieldList + ")");
            }
            else
            {
                lDao.Params.AddWithValue("@OrderBy", string.Empty);
            }

            if (RptFltr != null)
            {
                for (i = 0; i < RptFltr.CriteiraDv.Count; i++)
                {
                    if (bool.Parse(RptFltr.CriteiraDv[i]["IsParam"].ToString()))
                    {
                        if (RptFltr.CriteiraDv[i]["FldType"].ToString() == "DATETIME")
                        {
                            lValue1 = RptFltr.CriteiraDv[i]["Value1"].ToString();
                            lDate = DateTime.Parse(lValue1);
                            lDao.Params.AddWithValue("@" + RptFltr.CriteiraDv[i]["FldNm"].ToString().Substring(3), lDate);
                        }
                        else
                        {
                            lDao.Params.AddWithValue("@" + RptFltr.CriteiraDv[i]["FldNm"].ToString().Substring(3), RptFltr.CriteiraDv[i]["Value1"]);
                        }

                    }
                }
            }
            lDao.OpenTable();
            lRptMainDs.Tables.Add(lDao.Dt);
            RptMainDs = lRptMainDs;
        }
        private void LoadCmnMiscData()
        {
            DataTable lDt = null;
            DataRow lDr = null;
            lDt = new DataTable();
            lDt.TableName = "Cmpny";
            lDt.Columns.Add("Cmpny");
            lDr = lDt.NewRow();
            lDr["Cmpny"] = GetCmpny();
            lDt.Rows.Add(lDr);

            CmnMiscDs = new DataSet();
            CmnMiscDs.Tables.Add(lDt);
        }
        private void LoadRptMiscData()
        {
            if (RptT01 != null)
            {
                RptT01.RptFltr = RptFltr;
                RptMiscDs = RptT01.MiscDs;
            }
        }
        private string GetCmpny()
        {
            string lRtrnVal = string.Empty;

            TDomain.Lookup("Cmpny", "Cmpny", string.Empty, out lRtrnVal);
            return lRtrnVal;
        }
        #endregion
        #endregion

        #region BeforeRender
        private void GenRptHeading()
        {
            string lCmpny = string.Empty;

            if (mCmnMiscDs != null)
            {
                lCmpny = mCmnMiscDs.Tables["Cmpny"].Rows[0]["Cmpny"].ToString();
            }
            try
            {
                this.C1Rpt.Sections.PageHeader.Fields["lblTitle"].Text = SPrpsRPT01.RptAls;
            }
            catch
            {
            }
            try
            {
                this.C1Rpt.Sections.PageHeader.Fields["txtCriteriaFullText"].Text = RptFullText;
            }
            catch
            {
            }
            try
            {
                this.C1Rpt.Sections.PageHeader.Fields["lblCompanyNameHeader"].Text = lCmpny;
            }
            catch
            {
            }
        }
        private void GenRptCmpyLogos()
        {
            try
            {
                C1Rpt.Sections.PageHeader.Fields["imgLogo01"].Picture = Innotelli.Utilities.TGC.BaseDirectory + Innotelli.Utilities.TGC.SYSDATA04_FOLDER_NAME + @"\Logo01.jpg";
                C1Rpt.Sections.PageHeader.Fields["imgLogo01"].PictureScale = PictureScaleEnum.Scale;
                C1Rpt.Sections.PageFooter.Fields["imgLogo02"].Picture = Innotelli.Utilities.TGC.BaseDirectory + Innotelli.Utilities.TGC.SYSDATA04_FOLDER_NAME + @"\Logo02.jpg";
                C1Rpt.Sections.PageFooter.Fields["imgLogo02"].PictureScale = PictureScaleEnum.Scale;
            }
            catch (Exception ex)
            {
                TAppLog.LogException(ex);
            }
        }
        //use reflection to run report object's beforerender
        private void ExecRptBeforeRender()
        {
            if (RptT01 != null)
            {
                RptT01.C1Rpt = C1Rpt;
                RptT01.RptFltr = RptFltr;
                RptT01.BeforeRender();
                //#check!
                //C1Rpt = lRptT01.C1Rpt;
            }
        }
        #endregion

        #region AfterRender

        #endregion

        #endregion

        #endregion
    }
}
