using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Windows.Forms;
using System.Drawing.Printing;
using C1.Win.C1Report;
using Innotelli.BO;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.Report
{
    public enum OutputEnum
    {
        Preview,
        Print,
        Export,
    }
    public class TRptLaunch : TThreadWrapperBase
    {
        #region Members
        private string mRptNm;
        private TRptFltr mRptFltr = new TRptFltr();
        private string mFilePath;
        private FileFormats mFileFormat;
        private PrintDialog mPrintDialog = null;
        private PrintDocument mPrintDocument = null;
        #endregion

        #region Constructors
        public TRptLaunch(Control aInvokeContext)
        {
            InvokeContext = aInvokeContext;
            SupportsProgress = true;
            CancelWaitTime = TimeSpan.FromSeconds(0);
        }
        #endregion

        #region Enums
        #endregion

        #region Properties
        private TRptEngine mRptEngine = new TRptEngine();
        public TRptEngine RptEngine
        {
            set
            {
                mRptEngine = value;
            }
            get
            {
                return mRptEngine;
            }
        }
        private TRptPreview mRptPreview = null;
        public TRptPreview RptPreview
        {
            set
            {
                mRptPreview = value;
            }
            get
            {
                return mRptPreview;
            }
        }
        private OutputEnum mOutput;
        public OutputEnum Output
        {
            get
            {
                return mOutput;
            }
            set
            {
                mOutput = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void CopyRptFilter(TRptFltr aRptFltr)
        {
            DataTable lDt = aRptFltr.CriteiraDv.ToTable();
            DataSet lDs = new DataSet();
            lDs.Tables.Add(lDt);
            mRptFltr.CriteiraDs = lDs;
            mRptFltr.RptNm = aRptFltr.RptNm;
            mRptEngine.RptFltr = mRptFltr;
        }
        private void BeforePreveiew(string aRptNm)
        {
            mRptPreview = new TRptPreview(this);
            mRptEngine.SPrpsRPT01.RptID = aRptNm;
            mRptPreview.FormTitle = mRptEngine.SPrpsRPT01.RptAls;
            mRptPreview.Show();
        }
        public void ExportToFileAsync(string aRptNm, string aCriteria, string aFilePath, FileFormats aFileFormat)
        {
            mRptEngine.Criteria = aCriteria;
            mFilePath = aFilePath;
            mFileFormat = aFileFormat;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Export;
            Start();
        }

        public void ExportToFileAsync(string aRptNm, DataSet aRptExternalMainDs, string aFilePath, FileFormats aFileFormat)
        {
            mRptEngine.RptExternalMainDs = aRptExternalMainDs;
            mFilePath = aFilePath;
            mFileFormat = aFileFormat;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Export;
            Start();
        }

        public void ExportToFileAsync(string aRptNm, TRptFltr aRptFltr, string aFilePath, FileFormats aFileFormat)
        {
            CopyRptFilter(aRptFltr);
            mFilePath = aFilePath;
            mFileFormat = aFileFormat;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Export;
            Start();
        }

        public void PreviewAsync(string aRptNm, string aCriteria)
        {
            mRptEngine.Criteria = aCriteria;
            BeforePreveiew(aRptNm);
            mRptNm = aRptNm;
            mOutput = OutputEnum.Preview;
            Start();
        }

        public void PreviewAsync(string aRptNm, DataSet aRptExternalMainDs)
        {
            mRptEngine.RptExternalMainDs = aRptExternalMainDs;
            BeforePreveiew(aRptNm);
            mRptNm = aRptNm;
            mOutput = OutputEnum.Preview;
            Start();
        }

        public void PreviewAsync(string aRptNm, TRptFltr aRptFltr)
        {
            BeforePreveiew(aRptNm);
            CopyRptFilter(aRptFltr);
            mRptNm = aRptNm;
            mOutput = OutputEnum.Preview;
            Start();
        }

        public void PrintAsync(string aRptNm, string aCriteria)
        {
            mRptEngine.Criteria = aCriteria;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Print;
            Start();
        }

        public void PrintAsync(string aRptNm, DataSet aRptExternalMainDs)
        {
            mRptEngine.RptExternalMainDs = aRptExternalMainDs;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Print;
            Start();
        }

        public void PrintAsync(string aRptNm, TRptFltr aRptFltr)
        {
            CopyRptFilter(aRptFltr);
            mRptNm = aRptNm;
            mOutput = OutputEnum.Print;
            Start();
        }

        public static void ExportToFile(string aRptNm, TRptFltr aRptFltr,
            string aFilePath, FileFormats aFileFormat)
        {
            TRptEngine lRptEngine = new TRptEngine();
            lRptEngine.RptID = aRptNm;
            aRptFltr.CriteiraDs.AcceptChanges();
            lRptEngine.RptFltr = aRptFltr;
            lRptEngine.ProcessPhase1();
            lRptEngine.ProcessPhase2Export(aFileFormat, aFilePath);
        }
        public static void ExportToFile(string aRptNm, string aCriteria,
            string aFilePath, FileFormats aFileFormat)
        {
            TRptEngine lRptEngine = new TRptEngine();
            lRptEngine.RptID = aRptNm;
            lRptEngine.Criteria = aCriteria;
            lRptEngine.ProcessPhase1();
            lRptEngine.ProcessPhase2Export(aFileFormat, aFilePath);
        }
        public static void ExportToFile(string aRptNm, DataSet aRptExternalMainDs,
            string aFilePath, FileFormats aFileFormat)
        {
            TRptEngine lRptEngine = new TRptEngine();
            lRptEngine.RptID = aRptNm;
            lRptEngine.RptExternalMainDs = aRptExternalMainDs;
            lRptEngine.ProcessPhase1();
            lRptEngine.ProcessPhase2Export(aFileFormat, aFilePath);
        }
        public static void Preview(string aRptNm, TRptFltr aRptFltr)
        {
            Cursor.Current = Cursors.WaitCursor;
            TRptPreview lRptPreview = new TRptPreview();
            TRptEngine lRptEngine = new TRptEngine();
            lRptEngine.RptID = aRptNm;
            aRptFltr.CriteiraDs.AcceptChanges();
            lRptEngine.RptFltr = aRptFltr;
            lRptEngine.ProcessPhase1();
            lRptPreview.FormTitle = lRptEngine.SPrpsRPT01.RptAls;
            lRptPreview.Show();
            //The following 3 line equivalent to mRptEngine.ProcessPhase2();
            lRptEngine.BeforeRender();
            lRptPreview.C1Rpt = lRptEngine.C1Rpt; //Auto rendering when assign C1Rpt to from
            lRptEngine.AfterRender();
            Cursor.Current = Cursors.Default;
            lRptPreview.InProgress = false;
        }
        public static void Preview(string aRptNm, string aCriteria)
        {
            Cursor.Current = Cursors.WaitCursor;
            TRptPreview lRptPreview = new TRptPreview();
            TRptEngine lRptEngine = new TRptEngine();
            lRptEngine.RptID = aRptNm;
            lRptEngine.Criteria = aCriteria;
            lRptEngine.ProcessPhase1();
            lRptPreview.FormTitle = lRptEngine.SPrpsRPT01.RptAls;
            lRptPreview.Show();
            //The following 3 line equivalent to mRptEngine.ProcessPhase2();
            lRptEngine.BeforeRender();
            lRptPreview.C1Rpt = lRptEngine.C1Rpt; //Auto rendering when assign C1Rpt to from
            lRptEngine.AfterRender();
            Cursor.Current = Cursors.Default;
            lRptPreview.InProgress = false;
        }
        public static void Preview(string aRptNm, DataSet aRptExternalMainDs)
        {
            Cursor.Current = Cursors.WaitCursor;
            TRptPreview lRptPreview = new TRptPreview();
            TRptEngine lRptEngine = new TRptEngine();
            lRptEngine.RptID = aRptNm;
            lRptEngine.RptExternalMainDs = aRptExternalMainDs;
            lRptEngine.ProcessPhase1();
            lRptPreview.FormTitle = lRptEngine.SPrpsRPT01.RptAls;
            lRptPreview.Show();
            //The following 3 line equivalent to mRptEngine.ProcessPhase2();
            lRptEngine.BeforeRender();
            lRptPreview.C1Rpt = lRptEngine.C1Rpt; //Auto rendering when assign C1Rpt to from
            lRptEngine.AfterRender();
            Cursor.Current = Cursors.Default;
            lRptPreview.InProgress = false;
        }

        public static void Print(string aRptNm, TRptFltr aRptFltr)
        {
            Cursor.Current = Cursors.WaitCursor;
            TRptEngine lRptEngine = new TRptEngine();
            PrintDialog lPrintDialog = null;
            PrintDocument lPrintDocument = null;
            lRptEngine.RptID = aRptNm;
            aRptFltr.CriteiraDs.AcceptChanges();
            lRptEngine.RptFltr = aRptFltr;
            lRptEngine.ProcessPhase1();
            lPrintDialog = new PrintDialog();
            lRptEngine.ProcessPhase2();
            lPrintDocument = lRptEngine.C1Rpt.Document;
            lPrintDialog.PrinterSettings = lPrintDocument.PrinterSettings;
            Cursor.Current = Cursors.Default;
            if (lPrintDialog.ShowDialog() == DialogResult.OK)
            {
                lPrintDocument.Print();
            }
            lPrintDialog.Dispose();
        }
        public static void Print(string aRptNm, string aCriteria)
        {
            Cursor.Current = Cursors.WaitCursor;
            TRptEngine lRptEngine = new TRptEngine();
            PrintDialog lPrintDialog = null;
            PrintDocument lPrintDocument = null;
            lRptEngine.RptID = aRptNm;
            lRptEngine.Criteria = aCriteria;
            lRptEngine.ProcessPhase1();
            lPrintDialog = new PrintDialog();
            lRptEngine.ProcessPhase2();
            lPrintDocument = lRptEngine.C1Rpt.Document;
            lPrintDialog.PrinterSettings = lPrintDocument.PrinterSettings;
            Cursor.Current = Cursors.Default;
            if (lPrintDialog.ShowDialog() == DialogResult.OK)
            {
                lPrintDocument.Print();
            }
            lPrintDialog.Dispose();
        }

        public static void Print(string aRptNm, DataSet aRptExternalMainDs)
        {
            Cursor.Current = Cursors.WaitCursor;
            TRptEngine lRptEngine = new TRptEngine();
            PrintDialog lPrintDialog = null;
            PrintDocument lPrintDocument = null;
            lRptEngine.RptID = aRptNm;
            lRptEngine.RptExternalMainDs = aRptExternalMainDs;
            lRptEngine.ProcessPhase1();
            lPrintDialog = new PrintDialog();
            lRptEngine.ProcessPhase2();
            lPrintDocument = lRptEngine.C1Rpt.Document;
            lPrintDialog.PrinterSettings = lPrintDocument.PrinterSettings;
            Cursor.Current = Cursors.Default;
            if (lPrintDialog.ShowDialog() == DialogResult.OK)
            {
                lPrintDocument.Print();
            }
            lPrintDialog.Dispose();
        }
        public void UpdateRptPreview()
        {

        }

        public static C1Report GetC1RptWithData(string aRptID, string aCriteria)
        {
            TRptEngine lRptEngine = new TRptEngine();
            C1Report lC1Rpt = null;

            lRptEngine.RptID = aRptID;
            lRptEngine.Criteria = aCriteria;
            lRptEngine.ProcessPhase1();
            lC1Rpt = lRptEngine.C1Rpt;

            return lC1Rpt;
        }

        protected override void DoTask()
        {
            try
            {
                Progress = 1;//creat report object
                mRptEngine.RptID = mRptNm;
                Progress = 2; //process dataset
                mRptEngine.ProcessPhase1();
                Progress = 3; //gen before render data
            }
            catch (Exception ex)
            {
                TAppLog.LogException(ex);
                Progress = 77;
            }
        }
        public void CompleteTask()
        {
            switch (mOutput)
            {
                case OutputEnum.Export:
                    mRptEngine.ProcessPhase2Export(mFileFormat, mFilePath);
                    break;
                case OutputEnum.Preview:
                    //The following 3 line equivalent to mRptEngine.ProcessPhase2();
                    mRptEngine.BeforeRender();
                    mRptPreview.C1Rpt = mRptEngine.C1Rpt; //Auto rendering when assign C1Rpt to from
                    mRptEngine.AfterRender();

                    mRptPreview.InProgress = false;
                    break;
                case OutputEnum.Print:
                    mPrintDialog = new PrintDialog();
                    mRptEngine.ProcessPhase2();
                    mPrintDocument = mRptEngine.C1Rpt.Document;
                    mPrintDialog.PrinterSettings = mPrintDocument.PrinterSettings;
                    if (mPrintDialog.ShowDialog() == DialogResult.OK)
                    {
                        mPrintDocument.Print();
                    }
                    mPrintDialog.Dispose();
                    break;
                default:
                    break;
            }
        }
        #endregion
    }
}