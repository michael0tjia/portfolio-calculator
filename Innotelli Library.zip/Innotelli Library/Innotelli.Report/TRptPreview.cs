﻿using System;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using Innotelli.Db;
using Innotelli.Utilities;
using C1.Win.C1Report;
using C1.Win.C1Preview;
using System.IO;
using System.Threading;

namespace Innotelli.Report
{
    public partial class TRptPreview : Form
    {
        #region Members
        private TRptLaunch mRptLaunch = null;
        #endregion

        #region Constructors
        public TRptPreview(TRptLaunch aRptLaunch)
        {
            InitializeComponent();
            mRptLaunch = aRptLaunch;
        }
        public TRptPreview()
        {
            InitializeComponent();
        }
        #endregion

        #region Enums

        #endregion

        #region Properties
        private C1Report mC1Rpt = null;
        public C1Report C1Rpt
        {
            get
            {
                return mC1Rpt;
            }
            set
            {
                mC1Rpt = value;
                c1PrintPreviewControl1.PreviewPane.Document = mC1Rpt.Document;
            }
        }

        private string mFormTitle;
        public string FormTitle
        {
            set
            {
                mFormTitle = value;
                if (mInProgress)
                {
                    this.Text = mFormTitle + "   (Loading Report Data)......";
                    Cursor.Current = Cursors.WaitCursor;
                }
                else
                {
                    this.Text = mFormTitle;
                    Cursor.Current = Cursors.Default;
                }

            }
        }
        private bool mInProgress = true;
        public bool InProgress
        {
            set
            {
                mInProgress = value;
                if (mInProgress)
                {
                    this.Text = mFormTitle + " (Loading Report Data)......";
                }
                else
                {
                    this.Text = mFormTitle;
                }
            }
        }
        #endregion

        #region Event Handlers
        private void TRptPreview_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (mRptLaunch != null)
            {
                lock (mRptLaunch)
                {
                    if (mRptLaunch.Status != StatusState.Unstarted)
                    {
                        Visible = false;
                        e.Cancel = true;
                        timer1.Enabled = true;
                    }
                }
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            Close();
        }

        private void toolStripSplitButton1_ButtonClick(object sender, EventArgs e)
        {
            Email(FileFormats.Pdf);
        }
        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Email(FileFormats.Pdf);
        }
        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Email(FileFormats.Xls);
        }
        private void toolStripMenuItem3_Click(object sender, EventArgs e)
        {
            Email(FileFormats.Rtf);
        }
        #endregion

        #region Functions

        #endregion

        #region Others
        #endregion

        #region Misc
        private void Email(FileFormats aFileType)
        {
            string lFilePath = string.Empty;
            TMAPI lMAPI = null;

            lMAPI = new TMAPI();

            if (!Directory.Exists(AppDomain.CurrentDomain.BaseDirectory + "OutTemp"))
            {
                Directory.CreateDirectory(AppDomain.CurrentDomain.BaseDirectory + "OutTemp");
            }

            lFilePath = AppDomain.CurrentDomain.BaseDirectory + "OutTemp\\" + this.mFormTitle + "." + aFileType.ToString();
            switch (aFileType)
            {
                case FileFormats.Pdf:
                    C1Rpt.RenderToFile(lFilePath, FileFormatEnum.PDF);
                    break;
                case FileFormats.Xls:
                    C1Rpt.RenderToFile(lFilePath, FileFormatEnum.Excel);
                    break;
                case FileFormats.Rtf:
                    C1Rpt.RenderToFile(lFilePath, FileFormatEnum.RTF);
                    break;
            }

            lMAPI = new TMAPI();
            lMAPI.Send("", "", "", "", lFilePath);
        }
        public void Print()
        {
            //Document = C1Report.Document;
        }
        #endregion
    }
}