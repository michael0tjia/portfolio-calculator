using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using C1.Win.C1Report;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.Report
{
    abstract public class TRptT01
    {
        #region Enums
        #endregion

        #region Members
        #endregion
        
        #region Constructors
        public TRptT01()
        {

        }
        #endregion

        #region Properties
        private string mRptNm = "";
        public string RptNm
        {
            get
            {
                return mRptNm;
            }
            set
            {
                mRptNm = value;
            }
        }
        //private string mRptAls = "";
        //public string RptAls
        //{
        //    get
        //    {
        //        return mRptAls;
        //    }
        //    set
        //    {
        //        mRptAls = value;
        //    }
        //}
        private DataSet mMiscDs = null;
        public DataSet MiscDs
        {
            get 
            {
                if (mMiscDs == null)
                {
                    mMiscDs = GetMiscDs();
                }
                return mMiscDs; 
            }
            set 
            { 
                mMiscDs = value; 
            }
        }

        private TRptFltr mRptFltr = null;
        public TRptFltr RptFltr
        {
            get { return mRptFltr; }
            set { mRptFltr = value; }
        }

        private C1Report mC1Rpt = null;
        public C1Report C1Rpt
        {
            get { return mC1Rpt; }
            set { mC1Rpt = value; }
        }
        #endregion

        #region Event Handlers

        #endregion

        #region Functions
        //#check!
        // should rename to PrepareAccessData
        public abstract void PrepareData();
        public virtual void BeforeRender()
        {
        }
        public virtual void AfterRender()
        {
        }
        protected virtual DataSet GetMiscDs()
        {
            return null;
        }
        #endregion
    }
}
