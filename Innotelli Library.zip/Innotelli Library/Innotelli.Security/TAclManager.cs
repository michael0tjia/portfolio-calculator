using Innotelli.Security.Acl;

namespace Innotelli.Security
{
   
    public class TAclManager:Innotelli.Security.Acl.TAclManager
    {

    }
}
