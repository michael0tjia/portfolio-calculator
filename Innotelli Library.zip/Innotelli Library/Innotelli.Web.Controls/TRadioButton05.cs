﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TRadioButton05Designer))]
    public class TRadioButton05 : ASPxRadioButtonList
    {
        public TRadioButton05()
        {
            this.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            this.ReadOnlyStyle.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            this.ReadOnly = true;
        }
    }

    [ToolboxItem(true)]
    public class TRadioButton05Designer : ASPxListEditDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxRadioButtonList));
        }
    }
}
