﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxPopupControl;
using DevExpress.Web.ASPxPopupControl.Design;
using System.Web.UI;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TPopUp01Designer))]
    public class TPopUp01 : ASPxPopupControl
    {
        public TPopUp01()
        {

        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                this.Width = 400;
                this.Height = 400;
                this.Modal = true;
                this.CloseAction = DevExpress.Web.ASPxClasses.CloseAction.CloseButton;
                this.ClientInstanceName = this.ID;
                this.ClientSideEvents.PopUp = "function (s, e) { lucCallback.PerformCallback(mBOID); }";
            }
        }

    }

    [ToolboxItem(true)]
    public class TPopUp01Designer : ASPxPopupControlDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxPopupControl));
        }
    }
}
