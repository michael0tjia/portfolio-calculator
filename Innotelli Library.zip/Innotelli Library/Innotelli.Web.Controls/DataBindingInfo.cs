using System;
using System.ComponentModel;
using System.Web.UI;

namespace Innotelli.Web.Controls
{
	/// <summary>Class with information about a data binding</summary>
	[Serializable, TypeConverter(typeof(DataBindingInfoTypeConverter))]
	public class DataBindingInfo
	{
		#region Fields

		protected string _object;
		protected string _propObject;
		protected Control _control;
		protected string _propControl;
		protected bool _twoWay;
		
		#endregion
		
		#region Properties

		[DefaultValue(null)]
		public string Object {
			get { return _object; }
			set { _object = value; }
		}
		
		[DefaultValue(null)]
		public string PropObject {
			get { return _propObject; }
			set { _propObject = value; }
		}
		
		[DefaultValue(null)]
		public Control Control {
			get { return _control; }
			set { _control = value; }
		}
		
		public string PropControl {
			get { return _propControl; }
			set { _propControl = value; }
		}

		[DefaultValue(true)]		
		public bool TwoWay {
			get { return _twoWay; }
			set { _twoWay = value; }
		}
		
		#endregion

		public DataBindingInfo(){}

		public DataBindingInfo(Control ctrl, string propCtrl, string obj, string propObj)
		{
			_control = ctrl;
			_propControl = propCtrl;
			_object = obj;
			_propObject = propObj;
			_twoWay = true;
		}
		
		public DataBindingInfo(Control ctrl, string propCtrl, string obj, string propObj, bool twoWay) 
		{
			_control = ctrl;
			_propControl = propCtrl;
			_object = obj;
			_propObject = propObj;
			_twoWay = twoWay;
		}
	}
}
