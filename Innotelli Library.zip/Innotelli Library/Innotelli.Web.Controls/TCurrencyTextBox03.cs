﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TCurrencyTextBox03Designer))]
    public class TCurrencyTextBox03 : ASPxTextBox
    {
        public TCurrencyTextBox03()
        {
            //this.ReadOnly = true;  
        }
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                this.ValidationSettings.ValidateOnLeave = true;
                this.ValidationSettings.RegularExpression.ValidationExpression = @"\d+(\.\d{1,2})?";
                this.Properties.ValidationSettings.RequiredField.ErrorText = "Field is Required";
                this.ValidationSettings.SetFocusOnError = true;
                this.Properties.DisplayFormatString = "d2";
                this.MaxLength = 255;
                this.ClientSideEvents.TextChanged = "function(s,e){SetButtonsEnable(true);}";
            }
        }
    }

    [ToolboxItem(true)]
    public class TCurrencyTextBox03Designer : ASPxTextBoxDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxTextBox));
        }
    }
}