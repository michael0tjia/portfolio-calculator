﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TTextBox07Designer))]
    public class TTextBox07 : ASPxTextBox
    {
        public TTextBox07()
        {
            this.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            this.ReadOnlyStyle.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            this.ReadOnly = true;
        }
    }

    [ToolboxItem(true)]
    public class TTextBox07Designer : ASPxTextBoxDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxTextBox));
        }
    }
}
