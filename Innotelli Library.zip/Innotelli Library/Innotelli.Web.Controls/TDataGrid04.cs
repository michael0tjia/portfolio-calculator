﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;
using DevExpress.Web.ASPxGridView.Design;
using DevExpress.Web.ASPxGridView;
using Innotelli.BO;
using Innotelli.Db;
using System.Data;
using System.Web.UI;
using DevExpress.Data.Helpers;
using DevExpress.Data;
using DevExpress.Web.ASPxClasses;
using Innotelli.Utilities;
using System.Web;


namespace Innotelli.Web.Controls
{
    [Designer(typeof(TDataGrid04Designer))]
    public class TDataGrid04 : ASPxGridView
    {
        private static double cTwipsPerPixel = 15;

        public TDataGrid04()
        {

        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                GridViewDataHyperLinkColumn lGridViewDataHyperLinkColumn = null;
                lGridViewDataHyperLinkColumn = new GridViewDataHyperLinkColumn();
                lGridViewDataHyperLinkColumn.PropertiesHyperLinkEdit.NavigateUrlFormatString = mDetailURL + "?PK={0}&MODE=edit";
                lGridViewDataHyperLinkColumn.FieldName = "EncryptedPK";
                lGridViewDataHyperLinkColumn.PropertiesHyperLinkEdit.Text = "Edit";
                lGridViewDataHyperLinkColumn.Caption = "#";
                lGridViewDataHyperLinkColumn.VisibleIndex = 0;
                lGridViewDataHyperLinkColumn.UnboundType = UnboundColumnType.String;

                this.GenColumns();
                this.Columns.Insert(0, lGridViewDataHyperLinkColumn);

                this.AutoGenerateColumns = false;
                this.KeyFieldName = Innotelli.Utilities.TGC.PKeyName;
                this.ClientInstanceName = this.ID;
                this.EnableCallBacks = false;
                this.RowDeleting += new DevExpress.Web.Data.ASPxDataDeletingEventHandler(TDataGrid04_RowDeleting);
                this.CustomUnboundColumnData += new ASPxGridViewColumnDataEventHandler(TDataGrid04_CustomUnboundColumnData);
            
            }
        }


        private string mDetailURL;
        public string DetailURL
        {
            get
            {
                return mDetailURL;
            }
            set
            {
                mDetailURL = value;
            }
        }

        //private TBOT01 mBOT01 = null;
        //public TBOT01 BOT01
        //{
        //    get
        //    {
        //        return mBOT01;
        //    }
        //    set
        //    {
        //        mBOT01 = value;
        //        DataSource = value.Dt;
        //        DataBind();
        //    }
        //}

        private string mBOID = string.Empty;
        public string BOID
        {
            get
            {
                return "TB01" + mBOID;
            }
            set
            {
                mBOID = value;
            }
        }

        private void TDataGrid04_RowDeleting(object sender, DevExpress.Web.Data.ASPxDataDeletingEventArgs e)
        {
            TDataGrid04 lDataGrid04 = (TDataGrid04)sender;
            DataTable lDt = (DataTable)lDataGrid04.DataSource;
            lDt.PrimaryKey = new DataColumn[] { lDt.Columns[Innotelli.Utilities.TGC.PKeyName] };
            lDt.Rows.Find(e.Keys[0]).Delete();
            // TODO: find a better way
            lDt.PrimaryKey = null;
            
            lDataGrid04.DataBind();
            e.Cancel = true;
        }


        private void TDataGrid04_CustomUnboundColumnData(object sender, ASPxGridViewColumnDataEventArgs e)
        {
            if (e.Column.FieldName == "EncryptedPK")
            {
                string lPK = e.GetListSourceFieldValue(Innotelli.Utilities.TGC.PKeyName).ToString();
                e.Value = HttpUtility.UrlEncode((new TCryptography()).Encrypt(lPK));
            }

        }
        public void GenColumns()
        {
            //TDataGrid04 lGv = null;
            DataTable lDt = null;
            string lFormat = null;
            int lWidth = 0;
            TSPrpsBOT01FindCol lSPrpsBOT01FindCol = null;
            int lVisibleIndex = 0;

            lDt = Innotelli.BO.TSingletons.SPrpsBOT01s[BOID].SPrpsBOT01FindCols.Dt;
            //lGv = grdSearchResults;
            //lGv.OptionsView.ColumnAutoWidth = false;
            //grdSearchResults.DataSource = null;
            
            this.DataSource = null;
            for (int i = 0; i < Innotelli.BO.TSingletons.SPrpsBOT01s[BOID].SPrpsBOT01FindCols.Count; i++)
            {
                lSPrpsBOT01FindCol = Innotelli.BO.TSingletons.SPrpsBOT01s[BOID].SPrpsBOT01FindCols[i];
                if (lSPrpsBOT01FindCol.Visible)
                {
                    GridViewDataTextColumn lGc = new GridViewDataTextColumn();
                    lFormat = lSPrpsBOT01FindCol.Format;
                    lGc.Caption = lSPrpsBOT01FindCol.Caption;
                    lGc.FieldName = lSPrpsBOT01FindCol.FldNm;
                    lGc.Visible = lSPrpsBOT01FindCol.Visible;
                    lWidth = int.Parse(lDt.Rows[i]["Width"].ToString());
                    lGc.Width = (int)(lWidth / cTwipsPerPixel) + 26;
                    lGc.VisibleIndex = lVisibleIndex;
                    lGc.ReadOnly = true;
                    this.Columns.Add(lGc);
                    if (!string.IsNullOrEmpty(lFormat))
                    {
                        lGc.PropertiesTextEdit.DisplayFormatString = "{0:" + lSPrpsBOT01FindCol.Format + "}";
                    }
                    lVisibleIndex++;
                }
            }
            //Text = Innotelli.BO.TSingletons.SPrpsBOT01s[BOID].FindFormCaption;
        }

    }

    [ToolboxItem(true)]
    public class TDataGrid04Designer : GridViewDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxGridView));
        }
    }
}
