﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TTextBox05Designer))]
    public class TTextBox05 : ASPxTextBox
    {
        public TTextBox05()
        {
            this.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            this.ReadOnlyStyle.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            this.ReadOnly = true;
        }
    }

    [ToolboxItem(true)]
    public class TTextBox05Designer : ASPxTextBoxDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxTextBox));
        }
    }
}
