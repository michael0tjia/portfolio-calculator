using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Innotelli.Utilities;

namespace Innotelli.Web.Controls
{
    class itCultureImageButton : ImageButton
    {
        string mCulture = "";

        public itCultureImageButton()
        {

        }

        [Bindable(false)]
        [Category("Appearance")]
        [DefaultValue("0")]
        [Localizable(true)]
        public void Culture(string aCulture)
        {
            mCulture = aCulture;
        }

        protected override void OnClick(System.Web.UI.ImageClickEventArgs e)
        {
            base.OnClick(e);
            TCulture lCulture = new TCulture();
            lCulture.Set(this.Page, mCulture);
            Page.Response.Redirect(Page.Request.Url.ToString(), true);
        }
    }
}
