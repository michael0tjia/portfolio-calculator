﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;


namespace Innotelli.Web.Controls
{
    [Designer(typeof(TCheckBox05Designer))]
    public class TCheckBox05 : ASPxCheckBox
    {
        public TCheckBox05()
        {            
            
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                this.ReadOnlyStyle.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                this.Text = string.Empty;
            }
        }
    }

    [ToolboxItem(true)]
    public class TCheckBox05Designer : ASPxCheckBoxDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxCheckBox));
        }
    }
}