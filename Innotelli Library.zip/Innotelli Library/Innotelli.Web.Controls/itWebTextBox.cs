using System;
using System.Data;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ComponentModel;
using System.Reflection;
using System.Web;
using System.IO;	

namespace Innotelli.Web.Controls
{
	/// <summary>
	/// 
	/// </summary>	
	[ToolboxBitmap(typeof(TextBox)),DefaultProperty("Text"),
	ToolboxData("<{0}:itWebTextBox runat='server'></{0}:itWebTextBox>")]
    public class itWebTextBox : System.Web.UI.WebControls.TextBox
    {
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            BaseDataBoundControl lDataBoundCtrl = (BaseDataBoundControl)this.NamingContainer;
            string lFldNm = lDataBoundCtrl.DataSourceID + "." + this.ID.Substring(3) + ".FieldSize";
            this.MaxLength = GetFieldSize(GetPageName(), lFldNm);
        }

        //protected void SetMaxLength(object sender, EventArgs e)
        //{
        //    BaseDataBoundControl lDataBoundCtrl = (BaseDataBoundControl)this.NamingContainer;
        //    string lFldNm = lDataBoundCtrl.DataSourceID + "." + this.ID.Substring(3) + ".FieldSize";
        //    this.MaxLength = GetFieldSize(GetPageName(), lFldNm);
        //}

        protected int GetFieldSize(string aPgNm, string aFldNm)
        {
            //System.Web.UI.TemplateControl.GetGlobalResourceObject
            //protected object GetGlobalResourceObject(string className, string resourceKey);
            //return int.Parse(GetGlobalResourceObject(aPgNm, aFldNm).ToString());
            return 10;
        }

        protected string GetPageName()
        {
            string lFlNm = Path.GetFileName(HttpContext.Current.Request.Url.AbsolutePath);
            string lPgNm = lFlNm.Substring(0, lFlNm.LastIndexOf('.'));
            return lPgNm;
        }
    }
}
