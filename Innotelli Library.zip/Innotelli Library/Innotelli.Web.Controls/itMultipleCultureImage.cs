using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Innotelli.Web.Controls
{
    [System.Drawing.ToolboxBitmap(typeof(System.Web.UI.WebControls.Image)), DefaultProperty("ImageUrl"),
    ToolboxData("<{0}:itMultipleCultureImage runat='server'></{0}:itMultipleCultureImage>")]
    public class itMultipleCultureImage : Image
    {
        string mImagesLoc = "";
        string mCulture = "en-us";

        public itMultipleCultureImage()
        {

        }

        public void setCulture(string aCulture)
        {
            mCulture = aCulture;
        }

        public override string ImageUrl
        {
            get
            {
                return base.ImageUrl;
            }
            set
            {
                base.ImageUrl = value;
                mImagesLoc = base.ImageUrl;
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            int pst1 = mImagesLoc.LastIndexOf("/");
            int pst2 = mImagesLoc.LastIndexOf(".");
            string lFileExt = mImagesLoc.Substring(pst2);
            string lFileName = mImagesLoc.Substring(pst1 + 1, (pst2 - pst1) - 1);
            string lFilePath = mImagesLoc.Substring(0, pst1 + 1);
            if (mCulture == "en-us")
            {
                base.ImageUrl = mImagesLoc;
            }
            else
            {
                base.ImageUrl = lFilePath + lFileName + "." + mCulture + lFileExt;
            }
        }
    }
}
