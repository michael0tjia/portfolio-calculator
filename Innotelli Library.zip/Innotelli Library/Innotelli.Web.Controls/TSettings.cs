﻿using System;
using System.Collections.Generic;
using System.Text;
using Innotelli.Utilities;
using Innotelli.Db;

namespace Innotelli.WinForm.Control
{
    public enum DSFormMode
    {
        DSBrowse,
        DSEditable,
        DSInsert,
        DSUnknown,
    }

    public static class TSettings
    {
        private static string mCurFormat = "n2";
        private static string mDecFormat = "n";
        private static string mIntFormat = "n0";
        private static string mPerFormat = "P2";
        private static string mDateFormat = "yyyy/MM/dd";
        private static string mTimeFormat = "hh:mm tt";
        //private static string mTimeFormat01 = "hh:mm tt";
        //private static string mTimeFormat02 = "HH:mm tt";
        private static int mMaxWidth = 2048;

        public static string CurFormat
        {
            get
            {
                return mCurFormat;
            }
        }
        public static string DecFormat
        {
            get
            {
                return mDecFormat;
            }
        }
        public static string IntFormat
        {
            get
            {
                return mIntFormat;
            }
            set
            {
                mIntFormat = value;
            }
        }

        public static string PerFormat
        {
            get
            {
                return mPerFormat;
            }
            set
            {
                mPerFormat = value;
            }
        }

        public static string DateFormat
        {
            get
            {
                return mDateFormat;
            }
            set
            {
                mDateFormat = value;
            }
        }
        public static string TimeFormat
        {
            get
            {
                return mTimeFormat;
            }
            set
            {
                mTimeFormat = value;
            }
        }
        //public static string TimeFormat01
        //{
        //    get
        //    {
        //        return mTimeFormat01;
        //    }
        //    set
        //    {
        //        mTimeFormat01 = value;
        //    }
        //}

        //public static string TimeFormat02
        //{
        //    get
        //    {
        //        return mTimeFormat02;
        //    }
        //    set
        //    {
        //        mTimeFormat02 = value;
        //    }
        //}
        public static int MaxWidth
        {
            get
            {
                return mMaxWidth;
            }
            set
            {
                if (mMaxWidth == value)
                    return;
                mMaxWidth = value;
            }
        }
    }
}
