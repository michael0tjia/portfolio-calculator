﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TTextBox08Designer))]
    public class TTextBox08 : ASPxButtonEdit
    {
        public TTextBox08()
        {

        }
    }

    [ToolboxItem(true)]
    public class TTextBox08Designer : ASPxButtonEditDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxButtonEdit));
        }
    }
}
