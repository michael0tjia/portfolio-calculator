﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;
using System.Web.UI;


namespace Innotelli.Web.Controls
{
    [Designer(typeof(TButton03Designer))]
    public class TButton03 : ASPxButton
    {
        public TButton03()
        {

        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);

            this.ClientSideEvents.Click = "function(s,e){if(confirm ('Delete it?')){e.processOnServer=true;}else{e.processOnServer=false;}}";
        }
    }

    [ToolboxItem(true)]
    public class TButton03Designer : ASPxButtonDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxButton));
        }
    }
}