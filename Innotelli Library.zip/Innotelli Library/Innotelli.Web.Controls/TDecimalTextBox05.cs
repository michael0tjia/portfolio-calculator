﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TDecimalTextBox05Designer))]
    public class TDecimalTextBox05 : ASPxTextBox
    {
        public TDecimalTextBox05()
        {
            this.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            this.ReadOnlyStyle.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            this.ReadOnly = true;
            this.MaxLength = 255;
            this.MaskSettings.Mask = "";

        }
    }

    [ToolboxItem(true)]
    public class TDecimalTextBox05Designer : ASPxTextBoxDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxTextBox));
        }
    }
}
