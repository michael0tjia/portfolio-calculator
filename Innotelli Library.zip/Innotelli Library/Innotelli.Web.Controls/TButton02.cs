﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;
using System.Web.UI;


namespace Innotelli.Web.Controls
{
    [Designer(typeof(TButton02Designer))]
    public class TButton02 : ASPxButton
    {
        public TButton02()
        {

        }
    }

    [ToolboxItem(true)]
    public class TButton02Designer : ASPxButtonDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxButton));
        }
    }
}