using System;
using System.Collections;
using System.Data;
using System.ComponentModel;
using System.Reflection;
using System.Web;
using System.Web.UI;
using System.Drawing;
using System.Web.UI.WebControls;

namespace Innotelli.Web.Controls
{
    [System.Drawing.ToolboxBitmap(typeof(System.Web.UI.WebControls.Image)), DefaultProperty("ImageUrl"),
    ToolboxData("<{0}:itMultipleStatusImage runat='server'></{0}:itMultipleStatusImage>")]
    public class itMultipleStatusImage : System.Web.UI.WebControls.Image
    {

        Hashtable mImages = new Hashtable();
        int mStatus = 0;

        public itMultipleStatusImage()
        {
            mImages[0] = "";
        }

        public void setImagesLoc(int aKey, string aImageLoc)
        {
            if (!mImages.ContainsKey(aKey))
            {
                mImages.Add(aKey, aImageLoc);
            }
            else
            {
                mImages[aKey] = aImageLoc;
            }
        }

        [Bindable(true)]
        [Category("Appearance")]
        [DefaultValue("")]
        [Localizable(true)]
        public override string ImageUrl
        {
            get
            {
                return mImages[mStatus].ToString();
            }
            set
            {

            }
        }

        [Bindable(true)]
        [Category("Appearance")]
        [DefaultValue("0")]
        [Localizable(true)]
        public string Status
        {
            get
            {
                return mStatus.ToString();
            }
            set
            {
                mStatus = int.Parse(value);
            }
        }
    }
}
