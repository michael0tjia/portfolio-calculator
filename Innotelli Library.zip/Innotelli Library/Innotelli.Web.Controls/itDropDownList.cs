using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Infragistics.WebUI.WebCombo;
using Infragistics.WebUI.UltraWebGrid;
using Innotelli.Utilities;
using Innotelli.Db;
using Innotelli.BO;

namespace Innotelli.Web.Controls
{
    [System.Drawing.ToolboxBitmap(typeof(System.Web.UI.WebControls.DropDownList)), DefaultProperty(""),
    ToolboxData("<{0}:itDropDownList runat='server'></{0}:itDropDownList>")]
    public class itDropDownList : DropDownList
    {

        #region Members
        private string mBuObjID = "";
        #endregion

        #region Constructors
        public itDropDownList()
        {

        }
        #endregion

        #region Enums

        #endregion

        #region Properties
        public string BuObjID
        {
            get
            {
                return mBuObjID;
            }
            set
            {
                mBuObjID = value;
            }
        }
        #endregion

        #region Events
        protected override void OnPreRender(EventArgs e)
        {
            GenColumns();
            base.OnPreRender(e);
        }
        #endregion

        #region Functions
        private void GenColumns()
        {
            try
            {
                TSPrpsBOT01 lSPrpsBOT01 = Innotelli.BO.TSingletons.SPrpsBOT01s[BuObjID];
                DataTable lDt = lSPrpsBOT01.SPrpsBOT01FindCols.Dt;

                this.Items.Clear();

                for (int i = 0; i < lDt.Rows.Count; i++)
                {
                    string lCaption = lDt.Rows[i]["Caption"].ToString();
                    string lFldNm = lDt.Rows[i]["FldNm"].ToString();

                    ListItem lListItem = new ListItem(lCaption, lFldNm);
                    this.Items.Add(lListItem);
                }
            }
            catch
            {

            }
        }
        #endregion

    }
}
