﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TDateEditor03Designer))]
    public class TDateEditor03 : ASPxDateEdit
    {
        public TDateEditor03()
        {         
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                this.EditFormat = EditFormat.DateTime;
            }
        }
    }

    [ToolboxItem(true)]
    public class TDateEditor03Designer : ASPxDateEditDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxDateEdit));
        }
    }
}
