using System;
using System.Data;
using System.Configuration;
using System.IO;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Innotelli.Utilities;
using Innotelli.BO.Server;

namespace Innotelli.Web.Controls
{
    public partial class TPage004 : TPage001
    {

        #region Member
        private TServerBOT001 mLvl1Obj;
        #endregion

        #region Constructor
        public TPage004()
        {

        }
        #endregion

        #region Enum

        #endregion

        #region Properties
        public TServerBOT001 Lvl1Obj
        {
            get
            {
                return mLvl1Obj;
            }
            set
            {
                mLvl1Obj = value;
            }
        }
        #endregion

        #region Event
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            try
            {
                if (!IsPostBack)
                {
                    Bind();
                }
            }
            catch
            {

            }
        }
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            try
            {
                // Initial DB Load
                if (!IsPostBack)
                {
                    mLvl1Obj.LoadAll();
                }
                // PostBack DataTable Restore from Session
                else
                {
                    LoadDts();
                }
            }
            catch
            {

            }
        }
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            try
            {
                // Subsequent Binding
                if (IsPostBack)
                {
                    Bind();
                }
            }
            catch
            {

            }

        }
        protected override void OnUnload(EventArgs e)
        {
            base.OnUnload(e);
            try
            {
                UnloadDts();
            }
            catch
            {

            }
        }
        #endregion

        #region Function
        public virtual void Bind()
        {

        }
        public virtual void UnBind(DataListCommandEventArgs e)
        {

        }
        public virtual void UnBind2(Infragistics.WebUI.UltraWebGrid.RowEventArgs e)
        {

        }
        
        public virtual void LoadDts()
        {
            mLvl1Obj.Dt = ((DataTable)Session[mLvl1Obj.BOT001ID]);
        }
        public virtual void UnloadDts()
        {
            Session[mLvl1Obj.BOT001ID] = mLvl1Obj.Dt;
        }
        #endregion

    }
}
