using System;
using System.Web.UI;

namespace Innotelli.Web.Controls
{
	/// <summary>Exception thrown when there's an error in databinding</summary>
	public class DataBindingException : Exception
	{
		protected Control _control;
		
		public Control Control {
			get { return _control; }
		}
		
		public DataBindingException(string errorMsg) : base(errorMsg) 
		{
			_control = null;
		}

		public DataBindingException(string errorMsg, Control control) : base(errorMsg)
		{
			_control = control;
		}
		
		public DataBindingException(string errorMsg, Exception exc, Control control) : base(errorMsg, exc.InnerException) 
		{
			_control = control;
		}
	}
}
