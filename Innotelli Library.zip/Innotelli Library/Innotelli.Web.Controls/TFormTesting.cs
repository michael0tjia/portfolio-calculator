﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Text;
using DevExpress.Web.ASPxGridView;
using Innotelli.BO;

namespace Innotelli.Web.Controls
{
    public class TFormTesting : System.Web.UI.Page
    {
        private ASPxGridView mGrd02Test;
        public ASPxGridView Grd02Test
        {
            get
            {
                return mGrd02Test;
            }
            set
            {
                mGrd02Test = value;
            }
        }

        private TBOT01 mBOT01 = null;
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                if (Session[value.BOID] == null)
                {
                    mBOT01 = value;
                    mBOT01.LoadDataSet();
                    Session[mBOT01.BOID] = mBOT01;
                }
                else
                {
                    mBOT01 = (TBOT01)Session[value.BOID];
                }
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            mGrd02Test.KeyFieldName = Innotelli.Utilities.TGC.PKeyName;
            mGrd02Test.RowUpdating += new DevExpress.Web.Data.ASPxDataUpdatingEventHandler(mGrd02Test_RowUpdating);
            BindData();
        }

        private void mGrd02Test_RowUpdating(object sender, DevExpress.Web.Data.ASPxDataUpdatingEventArgs e)
        {
            mBOT01.Dt.PrimaryKey = new DataColumn[] { BOT01.Dt.Columns[Innotelli.Utilities.TGC.PKeyName] };
            BindToDt(e.Keys[0], e.NewValues);

            mGrd02Test.CancelEdit();
            e.Cancel = true;
        }

        private void BindToDt(object aPk, IDictionary aDictionary)
        {
            DataRow lDr = mBOT01.Dt.Rows.Find(aPk);
            foreach (string a in aDictionary.Keys)
            {
                lDr[a] = aDictionary[a];
            }
        }

        public virtual void LoadData()
        {
            mBOT01.LoadDataSet();
        }

        public virtual void BindData()
        {
            if (mBOT01 != null)
            {
                mGrd02Test.DataSource = mBOT01.Dao.DefaultView;
                mGrd02Test.DataBind();
            }
        }

        public virtual void Save()
        {
            mBOT01.Save();
        }
    }
}
