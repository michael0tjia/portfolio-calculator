﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TIntegerTextBox03Designer))]
    public class TIntegerTextBox03 : ASPxTextBox
    {
        public TIntegerTextBox03()
        {   
            this.MaxLength = 255;
            this.MaskSettings.Mask = "";
        }
    }

    [ToolboxItem(true)]
    public class TIntegerTextBox03Designer : ASPxTextBoxDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxTextBox));
        }
    }
}
