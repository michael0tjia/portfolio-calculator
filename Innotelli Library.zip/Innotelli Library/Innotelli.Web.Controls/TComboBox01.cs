﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;
using System.Web.UI;
using Innotelli.Db;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TComboBox01Designer))]
    public class TComboBox01 : ASPxComboBox
    {
        public TComboBox01()
        {

        }

        private string mBOID;
        [Bindable(true),
        Category("LookUp"),
        DefaultValue(""),
        Description("LookUp Table"),
        Localizable(false),
        PersistenceMode(PersistenceMode.Attribute)]
        public string BOID
        {
            get
            {
                return mBOID;
            }
            set
            {
                mBOID = value;
            }
        }
       
    }

    [ToolboxItem(true)]
    public class TComboBox01Designer : ASPxComboBoxDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxComboBox));
        }
    }
}