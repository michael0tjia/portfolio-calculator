using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Innotelli.Utilities;

namespace Innotelli.Web.Controls
{
    public class itSetCultureImageButton : ImageButton
    {
        string mCulture = "";

        public itSetCultureImageButton()
        {

        }

        [Bindable(false)]
        [Category("Appearance")]
        [DefaultValue("0")]
        [Localizable(false)]

        public string Culture
        {
            get
            {
                return mCulture;
            }
            set
            {
                mCulture = value ;
            }
        }

        protected override void OnClick(System.Web.UI.ImageClickEventArgs e)
        {
            base.OnClick(e);
            TCulture lCulture = new TCulture();
            lCulture.Set(this.Page, mCulture);
            //Page.Response.Redirect(Page.Request.Url.ToString(), true);
            Page.Response.Redirect(Page.Request.Url.AbsoluteUri.ToString(), true);       
        }
    }
}
