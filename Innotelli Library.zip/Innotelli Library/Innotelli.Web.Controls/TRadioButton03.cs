﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TRadioButton03Designer))]
    public class TRadioButton03 : ASPxRadioButtonList
    {
        public TRadioButton03()
        {
          
        }
    }

    [ToolboxItem(true)]
    public class TRadioButton03Designer : ASPxListEditDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxRadioButtonList));
        }
    }
}
