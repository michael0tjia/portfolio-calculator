﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TTextBox06Designer))]
    public class TTextBox06 : ASPxButtonEdit
    {
        public TTextBox06()
        {
            this.NullText = null;
                                                
        }
    }

    [ToolboxItem(true)]
    public class TTextBox06Designer : ASPxButtonEditDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxButtonEdit));
        }
    }
}
