﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;
using System.Web.UI;
using Innotelli.Db;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TLookupCombo02Designer))]
    public class TLookupCombo02 : ASPxComboBox
    {
        public TLookupCombo02()
        {

        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                Buttons.Add();
                DropDownButton.Visible = false;

                ClientInstanceName = this.ID;
                ClientSideEvents.ButtonClick = "function(s, e) {mLookupComboID = s.name; mBOID = '" + mBOID + "'; lucPopUp.Show(); ShowText = '" + mShowText + ";'; SaveValue='" + mSaveValue + ";'; }";
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                if (!string.IsNullOrEmpty(mBOID) && !string.IsNullOrEmpty(mSlkValue))
                {
                    TDataObject lDao = new TDataObject();
                    lDao.SQL.Stmt = "SELECT * FROM " + LookupViewName;
                    lDao.SQL.AddToWhereClause(mSaveValue + " = " + TSQL.SqlText(mSlkValue));
                    lDao.OpenTable();
                    if (!lDao.IsNoRow())
                    {
                        Items.Clear();
                        Items.Add(lDao.Dr[mShowText].ToString(), lDao.Dr[mSaveValue]);
                        SelectedIndex = 0;
                    }
                }
            }
        }

        private string mSlkValue;
        public string SlkValue
        {
            get
            {
                return mSlkValue;
            }
            set
            {
                mSlkValue = value;
            }
        }

        //public int StrValue
        //{
        //    get
        //    {
        //        return Convert.ToInt32(Value);
        //    }
        //    set
        //    {
        //        Value = value;
        //    }
        //}

        private string mBOID;
        [Bindable(true),
        Category("LookUp"),
        DefaultValue(""),
        Description("LookUp Table"),
        Localizable(false),
        PersistenceMode(PersistenceMode.Attribute)]
        public string BOID
        {
            get
            {
                return mBOID;
            }
            set
            {
                mBOID = value;
            }
        }

        public string LookupViewName
        {
            get
            {
                return "A_TB01" + mBOID + "_LookUpList";
            }
        }

        private string mShowText;
        public string ShowText
        {
            get
            {
                return mShowText;
            }
            set
            {
                mShowText = value;
            }
        }

        private string mSaveValue;
        public string SaveValue
        {
            get
            {
                return mSaveValue;
            }
            set
            {
                mSaveValue = value;
            }
        }
    }

    [ToolboxItem(true)]
    public class TLookupCombo02Designer : ASPxComboBoxDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxComboBox));
        }
    }
}