using System;
using System.Data;
using System.Configuration;
using System.IO;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Innotelli.Utilities;
using Innotelli.BO;

namespace Innotelli.Web.Controls
{
    public partial class TPage003 : TPage001
    {

        #region Members
        private TBOT01 mLvl1Obj;
        #endregion

        #region Constructors
        public TPage003()
        {

        }
        #endregion

        #region Enums

        #endregion

        #region Properties
        public TBOT01 Lvl1Obj
        {
            get
            {
                return mLvl1Obj;
            }
            set
            {
                mLvl1Obj = value;
            }
        }
        #endregion

        #region Events
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            try
            {
                if (!IsPostBack)
                {
                    Bind();
                }
            }
            catch
            {

            }
        }
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            try
            {
                // Initial DB Load
                if (!IsPostBack)
                {
                    //#check! - 2008/02/15
                    mLvl1Obj.LoadDataSet();
                }
                // PostBack DataTable Restore from Session
                else
                {
                    LoadDts();
                }
            }
            catch
            {

            }
        }
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            try
            {
                // Subsequent Binding
                if (IsPostBack)
                {
                    Bind();
                }
            }
            catch
            {

            }

        }
        protected override void OnUnload(EventArgs e)
        {
            base.OnUnload(e);
            try
            {
                UnloadDts();
            }
            catch
            {

            }
        }
        #endregion

        #region Function
        public virtual void Bind()
        {

        }
        public virtual void UnBind(DataListCommandEventArgs e)
        {

        }
        public virtual void UnBind2(Infragistics.WebUI.UltraWebGrid.RowEventArgs e)
        {

        }
        
        public virtual void LoadDts()
        {
            //#check!
            //mLvl1Obj.Dt = ((DataTable)Session[mLvl1Obj.BOID]);
        }
        public virtual void UnloadDts()
        {
            Session[mLvl1Obj.BOID] = mLvl1Obj.Dt;
        }
        #endregion
    }
}
