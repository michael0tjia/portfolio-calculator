using System;
using System.Collections;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.Web.UI;

namespace Innotelli.Web.Controls
{
	/// <summary>BindingManager Designer</summary>
	internal class BindingManagerDesigner : ComponentDesigner
	{
		#region Designer Stuff

		protected BindingManager bindingManager;
		protected DesignerVerbCollection verbs;

		BindingManagerDesigner() {}

		/// <summary>Method called when the framework is ready to use the designer</summary>
		/// <param name="component">component designed by this designer</param>
		public override void Initialize(IComponent component)
		{
			base.Initialize(component);

			// get's the component designed by this designer
			bindingManager = (BindingManager)component;

			// if its the first time the component is created, update data bindings
			IDesignerHost host = (IDesignerHost)Component.Site.Container;
			if (!host.Loading){
				UpdateDataBindings();
			}

			// suscribes to be notified of any component change
			IComponentChangeService iccs = (IComponentChangeService)GetService(typeof(IComponentChangeService));
			if (iccs != null) {
				iccs.ComponentAdded += new ComponentEventHandler(iccs_ComponentAddedRemoved);
				iccs.ComponentChanged += new ComponentChangedEventHandler(iccs_ComponentChanged);
				iccs.ComponentRemoved += new ComponentEventHandler(iccs_ComponentAddedRemoved);
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing){
				// cancel the subscriptions
				IComponentChangeService iccs = (IComponentChangeService)GetService(typeof(IComponentChangeService));
				if (iccs != null) {
					iccs.ComponentAdded -= new ComponentEventHandler(iccs_ComponentAddedRemoved);
					iccs.ComponentChanged -= new ComponentChangedEventHandler(iccs_ComponentChanged);
					iccs.ComponentRemoved -= new ComponentEventHandler(iccs_ComponentAddedRemoved);
				}
				
				if (verbs != null){
					verbs.Clear();
				}
			}

			base.Dispose(disposing);
		}

		/// <summary>Verbs supported by this designer</summary>
		public override DesignerVerbCollection Verbs 
		{
			get {
				// create the verb collection on demand
				if (verbs == null) {
					verbs = new DesignerVerbCollection();
					verbs.Add(new DesignerVerb("Regenera DataBindings", new EventHandler(OnUpdateDataBindings)));
				}
				return verbs;
			}
		}
		
		protected void OnUpdateDataBindings(object sender, EventArgs args) 
		{
			// update existing data bindings
			UpdateDataBindings();
		}
		
		#endregion

		#region IComponentChangeService Events

		/// <summary>Method called when a component is added to or removed from a web form</summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void iccs_ComponentAddedRemoved(object sender, ComponentEventArgs e)
		{
			// if a control is added or removed, update data bindings
			if (e.Component is Control){
				UpdateDataBindings();
			}
		}

		/// <summary>Method called when a component has changed</summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void iccs_ComponentChanged(object sender, ComponentChangedEventArgs e)
		{
			// if the change is not of a control, do not process it
			if (!(e.Component is Control)) return;

			// update data bindings
			UpdateDataBindings();
		}

		#endregion
		
		#region DataBinding Stuff

		/// <summary>Updates the BindingManager data bindings with the information provided by the design time infrastructure</summary>
		protected void UpdateDataBindings() 
		{
			// create a new collection to store the new bindings found
			DataBindingInfoCollection newBindings = new DataBindingInfoCollection();

			// gets all web controls from the form
			IReferenceService service = (IReferenceService)GetService(typeof(IReferenceService));
			object[] references = service.GetReferences(typeof(Control));

			foreach(Control control in references){
				// if the control isn't in the page but it's a naming container, skip it
				if ((control.NamingContainer == null) || (control.NamingContainer.GetType() != typeof(Page))) continue;
				
				// get the interface related to data binding
				IDataBindingsAccessor dba = (IDataBindingsAccessor)control;

				if (dba.HasDataBindings){
					foreach (DataBinding db in dba.DataBindings){
						// get the binding information for the control
						DataBindingInfo dbi = GetBindingInformation(db, control);

						// if the entry isn't new, set the old values
						UpdateDataBindingInfo(dbi, bindingManager.DataBindings);

						newBindings.Add(dbi);
					}
				}
			}

			// if the data bindings have changed
			if (CheckBindingChanges(bindingManager.DataBindings, newBindings)){
				// notify that the component is going to change
				RaiseComponentChanging(null);

				// update the bindings
				bindingManager.DataBindings.Clear();
				foreach(DataBindingInfo dbi in newBindings){
					bindingManager.DataBindings.Add(dbi);
				}

				// notify that the component has changed
				RaiseComponentChanged(null, null, null);
			}
		}

		/// <summary>Creates a DataBindingInfo item from a binding in a control</summary>
		/// <param name="db">data binding information</param>
		/// <param name="control">bound control</param>
		/// <returns>a new DataBindingInfo item</returns>
		protected DataBindingInfo GetBindingInformation(DataBinding db, Control control) 
		{
			DataBindingInfo dbi = new DataBindingInfo();

			// check if the binding expression uses the DataBinder class
			if (db.Expression.StartsWith("DataBinder.Eval")){
				// if it does, parse it
				string auxStr = db.Expression.Substring("DataBinder.Eval".Length);
				auxStr = auxStr.Remove(auxStr.IndexOf('('), 1);
				auxStr = auxStr.Remove(auxStr.LastIndexOf(')'), 1);
				string[] campos = auxStr.Split(',');

				dbi.Object = campos[0].Trim();
				dbi.PropObject = campos[1].Replace('"', ' ').Trim();
			} else {
				dbi.Object = db.Expression;
			}

			dbi.Control = control;
			dbi.PropControl = db.PropertyName;
			
			// set two way data binding depending of the property
			if (dbi.PropControl.EndsWith("DataSource") || dbi.PropControl.EndsWith("DataMember")){
				dbi.TwoWay = false;
			} else {
				dbi.TwoWay = true;
			}

			return dbi;
		}

		/// <summary>Update the DataBindingInfo with the values it had in the previous execution</summary>
		/// <param name="dbi">DataBindingInfo item to update</param>
		/// <param name="oldBindings">old data binding colleciton</param>
		protected void UpdateDataBindingInfo(DataBindingInfo dbi, DataBindingInfoCollection oldBindings)
		{
			// iterate through old entries searching the new one
			foreach(DataBindingInfo oldEntry in oldBindings){
				if ((oldEntry.Control == dbi.Control) && ((oldEntry.PropControl == dbi.PropControl))){
					dbi.TwoWay = oldEntry.TwoWay;

					return;
				}
			}
		}

		/// <summary>Check if the data bindings have changed</summary>
		/// <param name="col1">first collection of data bindings</param>
		/// <param name="col2">second collection of data bindings</param>
		/// <returns>false if the collections are the same, false otherwise</returns>
		protected bool CheckBindingChanges(DataBindingInfoCollection col1, DataBindingInfoCollection col2)
		{
			if (col1.Count != col2.Count) return true;

			// iterates through the collections, comparing the elements
			for (int i = 0; i < col1.Count; i++){
				DataBindingInfo dbi1 = col1[i];
				DataBindingInfo dbi2 = col2[i];

				if ((dbi1.Control != dbi2.Control) || (dbi1.PropControl != dbi2.PropControl) ||
					(dbi1.Object != dbi2.Object) || (dbi1.PropObject != dbi2.PropObject) || (dbi1.TwoWay != dbi2.TwoWay)){
					return true;
				}
			}

			// if the code reaches here, there hasn't been any change
			return false;
		}
		
		#endregion
	}
}
