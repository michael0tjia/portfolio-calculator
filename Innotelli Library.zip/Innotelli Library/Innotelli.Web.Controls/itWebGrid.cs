using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Infragistics.WebUI.WebCombo;
using Infragistics.WebUI.UltraWebGrid;
using Innotelli.Utilities;
using Innotelli.Db;
using Innotelli.BO;

namespace Innotelli.Web.Controls
{
    [System.Drawing.ToolboxBitmap(typeof(Infragistics.WebUI.UltraWebGrid.UltraWebGrid)), DefaultProperty(""),
    ToolboxData("<{0}:itWebGrid runat='server'></{0}:itWebGrid>")]
    public class itWebGrid : UltraWebGrid
    {

        #region Members
        //private DataTable mTmp;
        //private DataSet mDsExternal = null;
        private TSPrpsBOT01 lSPrpsBOT01 = null;
        //private TClntSelCboHndlr lClntSelCboHndlr = new TClntSelCboHndlr();
        //private TForm02Tree lClntSelCboHndlr = new TForm02Tree();

        private string mBuObjID = "";
        private const double mGgcTwipsPercm = 1440 / 2.54;
        private bool mAutoGetDataSource = true;
        #endregion

        #region Constructors
        public itWebGrid()
        {
            //lClntSelCboHndlr.SvrObjNm = "Innotelli.BO.Server.TSvrFndFrmHndlr";
        }
        #endregion

        #region Properties
        public string BuObjID
        {
            get
            {
                return mBuObjID;
            }
            set
            {
                mBuObjID = value;
                lSPrpsBOT01 = Innotelli.BO.TSingletons.SPrpsBOT01s[BuObjID];
            }
        }
        //public DataSet SetExternalDataSource
        //{
        //    get
        //    {
        //        return mDsExternal;
        //    }
        //    set
        //    {
        //        mDsExternal = value;
        //        AutoGetDataSource = false;
        //    }
        //}
        public bool AutoGetDataSource
        {
            get
            {
                return mAutoGetDataSource;
            }
            set
            {
                mAutoGetDataSource = value;
                //BindShowAllDataSource();
            }
        }
        #endregion

        #region Events
        protected override void OnLoad(EventArgs e)
        {
            if (this.DesignMode)
            {
                base.OnLoad(e);
            }
            else
            {
                try
                {
                    //if ((AutoGetDataSource) && (mDsExternal == null))
                    //{
                    //    BindShowAllDataSource();
                    //}
                    //else if (mDsExternal != null)
                    //{
                    //    BindExternalDataSource();
                    //}
                    if (AutoGetDataSource)
                    {
                        BindShowAllDataSource();
                    }
                    base.OnLoad(e);
                }
                catch
                {
                    throw new Exception();
                }
            }
        }
        public override void OnInitializeLayout(UltraGridLayout layout)
        {
            if (this.DesignMode)
            {
                base.OnInitializeLayout(layout);
            }
            else
            {
                RunSetting();
                base.OnInitializeLayout(layout);
            }

        }
        #endregion

        #region Method

        #region RunSetting
        private void RunSetting()
        {
            GridLayoutSetting();
            GenColumns();
        }
        private void GridLayoutSetting()
        {
            try
            {
                this.DisplayLayout.RowSelectorsDefault = Infragistics.WebUI.UltraWebGrid.RowSelectors.Yes;
                this.DisplayLayout.AutoGenerateColumns = false;
                this.DisplayLayout.FilterOptionsDefault.AllowRowFiltering = RowFiltering.OnClient;
                this.DisplayLayout.AllowSortingDefault = AllowSorting.OnClient;
                this.DisplayLayout.HeaderClickActionDefault = HeaderClickAction.SortMulti;
                this.DisplayLayout.AllowRowNumberingDefault = RowNumbering.Continuous;
                this.DisplayLayout.AllowColumnMovingDefault = AllowColumnMoving.OnServer;
            }
            catch
            {
                throw new Exception();
            }
        }
        private void GenColumns()
        {
            try
            {
                lSPrpsBOT01 = Innotelli.BO.TSingletons.SPrpsBOT01s[BuObjID];
                DataTable lDt = lSPrpsBOT01.SPrpsBOT01FindCols.Dt;

                this.Columns.Clear();

                UltraGridBand band = this.DisplayLayout.Bands[0];
                //Alex 02/05
                this.DisplayLayout.Bands[0].Columns.Add(Utilities.TGC.PKeyName, Utilities.TGC.PKeyName);
                this.DisplayLayout.Bands[0].Columns[0].Hidden = true;
                this.DisplayLayout.Bands[0].Columns[0].BaseColumnName = Utilities.TGC.PKeyName;
                this.DisplayLayout.Bands[0].Columns[0].Key = Utilities.TGC.PKeyName;

                for (int i = 0; i < lDt.Rows.Count; i++)
                {
                    string lCaption = lDt.Rows[i]["Caption"].ToString();
                    string lFldNm = lDt.Rows[i]["FldNm"].ToString();
                    bool lVisible = !(bool.Parse(lDt.Rows[i]["Visible"].ToString()));
                    string CanSrch = lDt.Rows[i]["CanSrch"].ToString();
                    int lColNo = int.Parse(lDt.Rows[i]["ColNo"].ToString());
                    int lWidth = int.Parse(lDt.Rows[i]["Width"].ToString());
                    string lFldType = lDt.Rows[i]["FldType"].ToString();

                    this.DisplayLayout.Bands[0].Columns.Add(lFldNm, lCaption);
                    this.DisplayLayout.Bands[0].Columns[i + 1].BaseColumnName = lFldNm;
                    this.DisplayLayout.Bands[0].Columns[i + 1].Key = lFldNm;
                    this.DisplayLayout.Bands[0].Columns[i + 1].Hidden = lVisible;
                    this.DisplayLayout.Bands[0].Columns[i + 1].Width = lWidth / 10;
                    SetColumnsType(lFldType, i);
                    this.DisplayLayout.Bands[0].Columns[i + 1].Move(lColNo);
                }
            }
            catch
            {
                throw new Exception();
            }
        }
        private void SetColumnsType(string aFldType, int aColumnIndex)
        {
            try
            {
                switch (aFldType)
                {
                    case "BIT":
                        this.DisplayLayout.Bands[0].Columns[aColumnIndex + 1].Type = ColumnType.CheckBox;
                        this.DisplayLayout.Bands[0].Columns[aColumnIndex + 1].CellStyle.HorizontalAlign = HorizontalAlign.Center;
                        break;
                    case "DateTime":
                        this.DisplayLayout.Bands[0].Columns[aColumnIndex + 1].Format = "MM/dd/yyyy";
                        break;
                }
            }
            catch
            {
                throw new Exception();
            }
        }
        #endregion

        #region Binding
        public void BindShowAllDataSource()
        {
            try
            {
                //#check!
                //mTmp = lClntSelCboHndlr.GetDataSource(lSPrpsBOT01.Dmn).Tables[0];
                //this.DataSource = lClntSelCboHndlr.GetDataSource(lSPrpsBOT01.Dmn).Tables[0];
                this.DataBind();
            }
            catch
            {
                throw new Exception();
            }
        }
        public void BindSearchDataSource(string aField, string aCondition, string aValue)
        {
            try
            {
                //#check!
                //this.DataSource = lClntSelCboHndlr.Search(lSPrpsBOT01.Dmn, WhereClause(aField, aCondition, aValue)).Tables[0];
                this.DataBind();
            }
            catch
            {
                throw new Exception();
            }
        }
        public void BindNoOfDayDataSource(string aField, int aNoOfDay)
        {
            try
            {
                string lWhereClause = aField + " >= #" + DateTime.Now.AddDays(aNoOfDay).ToShortDateString() + "#";
                //#check!
                //this.DataSource = lClntSelCboHndlr.Search(lSPrpsBOT01.Dmn, lWhereClause).Tables[0];
                this.DataBind();
            }
            catch
            {
                throw new Exception();
            }
        }
        //private void BindExternalDataSource()
        //{
        //    try
        //    {
        //        this.DataSource = SetExternalDataSource.Tables[0];
        //        this.DataBind();
        //    }
        //    catch
        //    {
        //        throw new Exception();
        //    }
        //}
        #endregion

        #region Misc
        private string WhereClause(string aField, string aCondition, string aValue)
        {
            string lSql = "";
            try
            {
                if (aCondition == "Contains")
                {
                    lSql = aField + " " + "like" + " '%" + aValue + "%'";
                }
                else if (aCondition == "Begins With")
                {
                    lSql = aField + " " + "like" + " '" + aValue + "%'";
                }
                else if (aCondition == "Ends With")
                {
                    lSql = aField + " " + "like" + " '%" + aValue + "'";
                }
                else
                {
                    lSql = aField + " " + "=" + " '" + aValue + "'";
                }
            }
            catch
            {
                throw new Exception();
            }
            return lSql;
        }
        #endregion

        #endregion

    }
}
