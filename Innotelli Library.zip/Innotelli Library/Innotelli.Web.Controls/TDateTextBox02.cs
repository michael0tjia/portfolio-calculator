﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TDateTextBox02Designer))]
    public class TDateTextBox02 : ASPxTextBox
    {
        public TDateTextBox02()
        {            
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                this.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                this.ReadOnlyStyle.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                this.ReadOnly = true;
                this.MaskSettings.Mask = "";
            }
        }
    }

    [ToolboxItem(true)]
    public class TDateTextBox02Designer : ASPxTextBoxDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxTextBox));
        }
    }
}