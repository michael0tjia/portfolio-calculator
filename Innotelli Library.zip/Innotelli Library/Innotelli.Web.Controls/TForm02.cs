﻿using System;
using System.Data;
using System.Web;
using System.Web.UI;
using DevExpress.Web.ASPxCallbackPanel;
using DevExpress.Web.ASPxClasses;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxGridView;
using DevExpress.Web.ASPxPopupControl;
using Innotelli.BO;
using Innotelli.Utilities;
using System.Web.UI.WebControls;

namespace Innotelli.Web.Controls
{
    public class TForm02 : TPage001
    {
        #region Properties

        public ContentPlaceHolder CPHolder
        {
            get
            {
                ContentPlaceHolder lRtrnVal = null;
                if (Page.Master != null)
                {
                    lRtrnVal = (ContentPlaceHolder)(Page.Master.FindControl("Bdy"));
                }
                return lRtrnVal;
            }
        }

        public TPopUp01 lucPopUp
        {
            get
            {
                TPopUp01 lRtrnVal = null;

                if (CPHolder != null)
                {
                    lRtrnVal = (TPopUp01)(CPHolder.FindControl("lucPopUp"));
                }
                else
                {
                    lRtrnVal = (TPopUp01)FindControl("lucPopUp");
                }
                return lRtrnVal;
            }
        }

        public TButton02 btnSave
        {
            get
            {
                TButton02 lRtrnVal = null;
                if (CPHolder != null)
                {
                    lRtrnVal = (TButton02)(CPHolder.FindControl("btnSave"));
                }
                else
                {
                    lRtrnVal = (TButton02)FindControl("btnSave");
                }
                return lRtrnVal;
            }

        }
        public TButton02 btnCancel
        {
            get
            {
                TButton02 lRtrnVal = null;
                if (CPHolder != null)
                {
                    lRtrnVal = (TButton02)(CPHolder.FindControl("btnCancel"));
                }
                else
                {
                    lRtrnVal = (TButton02)FindControl("btnCancel");
                }
                return lRtrnVal;
            }
        }
        public ASPxCallbackPanel lucCallback
        {
            get
            {
                return (ASPxCallbackPanel)lucPopUp.FindControl("lucCallback");
            }
        }
        public TDataGrid02 lucDataGrid
        {
            get
            {
                return (TDataGrid02)lucCallback.FindControl("lucDataGrid");
            }
        }

        public bool IsDirty
        {
            get
            {
                return (bool)ViewState["IsDirty"];
            }
            set
            {
                ViewState["IsDirty"] = value;
                if (btnSave != null)
                {
                    btnSave.ClientEnabled = value;
                }
                if (btnCancel != null)
                {
                    btnCancel.ClientEnabled = value;
                }
            }
        }

        private BindingManager mBindingManager = new BindingManager();
        public BindingManager BindingManager
        {
            get
            {
                return mBindingManager;
            }
        }

        private TBOT01 mBOT01 = null;
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
            }
        }
        #endregion
        #region Event Handlers
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                InitTree();
                InitControl();
                if (Session["FillLookUpGrid"] != null && Convert.ToBoolean(Session["FillLookUpGrid"]) == true)
                {
                    FillLookUpGrid();
                }
            }

        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if (ViewState[mBOT01.BOID] == null)
            {
                Reset();
            }
            else
            {
                RetrieveBOFromViewState();
                mBindingManager.BindFromWebForm(this);
                StoreBOToViewState();
            }
            SetControlsRequired();
            IsDirty = BOT01.IsDirty;
            AssignBOToGrids();
        }
        protected void mASPxCallbackPanel_Callback(object source, CallbackEventArgsBase e)
        {
            lucDataGrid.BOID = e.Parameter;
            FillLookUpGrid();
            Session["FillLookUpGrid"] = true;
        }
        #endregion
        #region Function
        private void InitControl()
        {
            string lScript = @"
                    <script>
                        var btnSave; var btnCancel;
                        function OnGetRowValues(values)
			            {  	if(eval(mLookupComboID + '.GetValue() != values[0]'))
                            {
                                SetButtonsEnable(true);		 									
                                eval(mLookupComboID + '.ClearItems()');
                                eval(mLookupComboID + '.InsertItem(0, values[1], values[0])');
                                eval(mLookupComboID + '.SetValue(values[0])');
                            }
                            lucPopUp.Hide();                
			            }
                        function SetButtonsEnable(aBool)
                        {
                            if (btnSave != null)
                            {
                                btnSave.SetEnabled(aBool);
                            }
                            if (btnCancel != null)
                            {
                                btnCancel.SetEnabled(aBool);
                            }
                        }
	                </script>";
            if (btnSave != null)
            {
                btnSave.ClientInstanceName = btnSave.ID;
            }
            if (btnCancel != null)
            {
                btnCancel.ClientInstanceName = btnCancel.ID;
            }
            Page.RegisterClientScriptBlock("Done", lScript);
            lucCallback.ClientInstanceName = lucCallback.ID;
            lucCallback.Callback += new CallbackEventHandlerBase(mASPxCallbackPanel_Callback);
        }
        private void SetControlsRequired()
        {
            foreach (DataBindingInfo lDataBindingInfo in mBindingManager.DataBindings)
            {
                if (lDataBindingInfo.Control is ASPxEdit)
                {
                    ((ASPxEdit)lDataBindingInfo.Control).ValidationSettings.RequiredField.IsRequired = BOT01.SPrps.SPrpsBOT01Flds[lDataBindingInfo.PropObject].Required;
                }
            }
        }
        private void StoreBOToViewState(TBOT01 aBOT01)
        {
            ViewState[aBOT01.BOID] = aBOT01.Dt;

            foreach (TBOT01 lBO01Child in aBOT01.Childern)
            {
                StoreBOToViewState(lBO01Child);
            }
        }
        protected virtual void StoreBOToViewState()
        {
            if (mBOT01 != null)
            {
                IsDirty = mBOT01.IsDirty;
                StoreBOToViewState(mBOT01);
            }
        }
        private void RetrieveBOToViewState(TBOT01 aBOT01)
        {
            aBOT01.Dt = (DataTable)ViewState[aBOT01.BOID];
            mBOT01.IsDirty = IsDirty;
            foreach (TBOT01 lBO01Child in aBOT01.Childern)
            {
                RetrieveBOToViewState(lBO01Child);
            }
        }
        protected virtual void RetrieveBOFromViewState()
        {
            if (mBOT01 != null)
            {
                RetrieveBOToViewState(mBOT01);
            }
        }

        protected virtual void AssignBOToGrids()
        {
        }
        protected virtual void InitTree()
        {
        }

        protected virtual void Reset()
        {
            string lMode = Request.QueryString["MODE"];
            string lPK = Request.QueryString["PK"];
            string lFK = Request.QueryString["FK"];

            lPK = GetPlainText(lPK);
            lFK = GetPlainText(lFK);

            if (lMode == "edit" && !string.IsNullOrEmpty(lPK))
            {
                mBOT01.PK = lPK;
                mBOT01.LoadDataSet();
                StoreBOToViewState();
                mBindingManager.BindToWebForm(this);
            }
            else if (lMode == "add" && !string.IsNullOrEmpty(lFK))
            {
                if (lFK != "0")
                {
                    mBOT01.FK = lFK;
                }
                mBOT01.AddNew();
                StoreBOToViewState();
            }
            else
            {
                Response.Redirect("http://www.google.com");
                //Response.Redirect("http://localhost:1176/Contribution_Voucher.aspx?PK=mV9hnDJkOBI%3d&MODE=edit");
            }
            AssignBOToGrids();
            IsDirty = false;
        }

        protected virtual void Save()
        {
            mBOT01.Save();
            IsDirty = false;
        }

        protected virtual void Delete()
        {
            string lPK = Request.QueryString["PK"];
            lPK = (new TCryptography()).Decrypt(lPK);
            mBOT01.DeleteByPK(lPK);
        }

        protected virtual void FillLookUpGrid()
        {
            if (lucDataGrid != null)
            {
                lucDataGrid.LoadData();
                // TODO: BUG of DevExpress???
                lucDataGrid.AutoGenerateColumns = true;
                lucDataGrid.DataBind();
                foreach (GridViewColumn lGvc in lucDataGrid.Columns)
                {
                    if (lGvc.ToString() == Innotelli.Utilities.TGC.PKeyName || lGvc.ToString() == "upsize_ts")
                    {
                        lGvc.Visible = false;
                    }
                }
            }
        }
        public string GetChipper(string aPlainText)
        {
            return HttpUtility.UrlEncode((new TCryptography()).Encrypt(aPlainText));
        }

        public string GetPlainText(string aChipper)
        {
            return (new TCryptography()).Decrypt(aChipper);
        }
        #endregion
    }
}
