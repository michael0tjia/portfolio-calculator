using System;
using System.Data;
using System.Configuration;
using System.IO;
using System.Web;
using System.Web.Configuration;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Innotelli.Utilities;

namespace Innotelli.Web.Controls
{
    public partial class TPage001 : System.Web.UI.Page
    {
        public string CurCulture
        {
            get
            {
                return this.Session["Culture"].ToString();
            }
        }

        protected virtual void GetCtrlPrp()
        {
        }

        protected virtual void SetCtrlPrp()
        {
        }

        //public string Get(Page aPage)
        //{
        //    return aPage.Session["Culture"].ToString();
        //}

        protected override void InitializeCulture()
        {
            TCulture lCulture = new TCulture();
            lCulture.LocalSetting(this);
            base.InitializeCulture();
        }

        //protected override void OnInit(EventArgs e)
        //{
        //    base.OnInit(e);
        //    if (Context.Session != null)
        //    {
        //        if (Context.Session.IsNewSession)
        //        {
        //            string lCookieHeader = this.Request.Headers["Cookies"];
        //            if ((lCookieHeader != null) && (lCookieHeader.IndexOf("ASP.NET_SessionId") >= 0))
        //            {
        //                if (this.Request.IsAuthenticated)
        //                {
        //                    FormsAuthentication.SignOut();
        //                    this.Response.Redirect("~/Login.aspx");
        //                }
        //            }
        //        }
        //    }
        //}
        protected void GoToDefaultPage()
        {
            if (Request.IsAuthenticated)
            {
                if (ConfigurationManager.AppSettings["PageAfterLogin"] != null)
                {
                    Response.Redirect(ConfigurationManager.AppSettings["PageAfterLogin"]);
                }
            }
            else
            {
                if (ConfigurationManager.AppSettings["PageBeforeLogin"] != null)
                {
                    Response.Redirect(ConfigurationManager.AppSettings["PageBeforeLogin"]);
                }
            }
        }
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Session["WebUsrID"] == null)
            {
                string lReqURL = string.Empty;
                if (Request.UrlReferrer != null)
                {
                    lReqURL = Request.UrlReferrer.AbsoluteUri.ToString();
                }
                else
                {
                    GoToDefaultPage();
                }
                if (Request.IsAuthenticated)
                {
                    Session["DestinationPageUrl"] = lReqURL;
                    Session["ExUsrID"] = User.Identity.Name;
                    FormsAuthentication.SignOut();
                }
                if (ConfigurationManager.AppSettings["PageAfterTimeout"] != null)
                {
                    Response.Redirect(ConfigurationManager.AppSettings["PageAfterTimeout"]);
                }
                else
                {
                    Response.Redirect("~/Login.aspx");
                }
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            SetCtrlPrp();
        }

        protected void SetMaxLength(object sender, EventArgs e)
        {
            TextBox lTxtBx = (TextBox)sender;
            BaseDataBoundControl lDataBoundCtrl = (BaseDataBoundControl)lTxtBx.NamingContainer;
            string lFldNm = lDataBoundCtrl.DataSourceID + "." + lTxtBx.ID.Substring(3) + ".FieldSize";
            lTxtBx.MaxLength = GetFieldSize(GetPageName(), lFldNm);
        }

        protected int GetFieldSize(string aPgNm, string aFldNm)
        {
            return int.Parse(GetGlobalResourceObject(aPgNm, aFldNm).ToString());
        }

        protected string GetPageName()
        {
            string lFlNm = Path.GetFileName(HttpContext.Current.Request.Url.AbsolutePath);
            string lPgNm = lFlNm.Substring(0, lFlNm.Length - 5);
            return lPgNm;
        }
    }
}
