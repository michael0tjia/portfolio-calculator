﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;
using System.Web.UI;

namespace Innotelli.Web.Controls
{

    [Designer(typeof(TButtonEdit01Designer))]
    public class TButtonEdit01 : ASPxButtonEdit
    {
        public TButtonEdit01()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                ClientInstanceName = this.ID;
                ClientSideEvents.ButtonClick = "function(s, e) {mButtonEditID = s.name; mBOID = '" + mBOID + "'; mPopUp01.Show(); ShowText = '" + mShowText + ";'; SaveValue='" + mSaveValue + ";'; }";
            }
        }

        private string mBOID;
        [Bindable(true),
        Category("Behavior"),
        DefaultValue(""),
        Description("LookUp Table"),
        Localizable(false),
        PersistenceMode(PersistenceMode.Attribute)]
        public string BOID
        {
            get
            {
                return mBOID;
            }
            set
            {
                mBOID = value;
            }
        }

        private string mShowText;
        [Bindable(true),
        Category("Behavior"),
        DefaultValue(""),
        Description("LookUp Table"),
        Localizable(false),
        PersistenceMode(PersistenceMode.Attribute)]
        public string ShowText
        {
            get
            {
                return mShowText;
            }
            set
            {
                mShowText = value;
            }
        }

        private string mSaveValue;
        [Bindable(true),
        Category("Behavior"),
        DefaultValue(""),
        Description("LookUp Table"),
        Localizable(false),
        PersistenceMode(PersistenceMode.Attribute)]
        public string SaveValue
        {
            get
            {
                return mSaveValue;
            }
            set
            {
                mSaveValue = value;
            }
        }

    }

    [ToolboxItem(true)]
    public class TButtonEdit01Designer : ASPxButtonEditDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxButtonEdit));
        }
    }
}
