﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TDecimalTextBox03Designer))]
    public class TDecimalTextBox03 : ASPxTextBox
    {
        public TDecimalTextBox03()
        {
            this.MaxLength = 255;
            this.MaskSettings.Mask = "";
        }
    }

    [ToolboxItem(true)]
    public class TDecimalTextBox03Designer : ASPxTextBoxDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxTextBox));
        }
    }
}