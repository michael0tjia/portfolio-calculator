﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;


namespace Innotelli.Web.Controls
{
    [Designer(typeof(TCheckBox03Designer))]
    public class TCheckBox03 : ASPxCheckBox
    {
        public TCheckBox03()
        {
            
        }
       
        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
               this.Text = string.Empty;
            }
        }
    }

    [ToolboxItem(true)]
    public class TCheckBox03Designer : ASPxCheckBoxDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxCheckBox));
        }
    }
}