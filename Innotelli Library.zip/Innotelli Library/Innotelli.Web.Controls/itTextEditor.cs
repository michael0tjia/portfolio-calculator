using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Infragistics.WebUI.WebCombo;
using Infragistics.WebUI.UltraWebGrid;
using Innotelli.Utilities;
using Innotelli.Db;
using Innotelli.BO;

namespace Innotelli.Web.Controls
{
    [System.Drawing.ToolboxBitmap(typeof(Infragistics.WebUI.WebDataInput.WebTextEdit)), DefaultProperty(""),
    ToolboxData("<{0}:itTextEditor runat='server'></{0}:itTextEditor>")]
    public class itTextEditor : Infragistics.WebUI.WebDataInput.WebTextEdit
    {

        #region Members
        private string mBuObjID = "";
        private string mPopupWidth = "100";
        private string mPopupHeight = "100";
        private string mURL = "FindForm.aspx";
        private string mTitle = "Find Form";
        private string mGridID = "";
        private Option mToolbar = Option.No;
        private Option mMenubar = Option.No;
        private Option mLocation = Option.No;
        private Option mResizable = Option.No;
        private Option mStatus = Option.No;
        private Option mScrollbars = Option.No;
        #endregion

        #region Constructors
        public itTextEditor()
        {

        }
        #endregion

        #region Enums
        public enum Option
        {
            Yes = 0,
            No = 1,
        }
        #endregion

        #region Properties
        public string URL
        {
            get { return mURL; }
            set { mURL = value; }
        }
        public string BuObjID
        {
            get { return mBuObjID; }
            set { mBuObjID = value; }
        }
        public string PopupWidth
        {
            get { return mPopupWidth; }
            set { mPopupWidth = value; }
        }
        public string PopupHeight
        {
            get { return mPopupHeight; }
            set { mPopupHeight = value; }
        }
        public string Title
        {
            get { return mTitle; }
            set { mTitle = value; }
        }
        public string GridID
        {
            get { return mGridID; }
            set { mGridID = value; }
        }
        public Option Toolbar
        {
            get { return mToolbar; }
            set { mToolbar = value; }
        }
        public Option Menubar
        {
            get { return mMenubar; }
            set { mMenubar = value; }
        }
        public Option Location
        {
            get { return mLocation; }
            set { mLocation = value; }
        }
        public Option Resizable
        {
            get { return mResizable; }
            set { mResizable = value; }
        }
        public Option Status
        {
            get { return mStatus; }
            set { mStatus = value; }
        }
        public Option Scrollbars
        {
            get { return mScrollbars; }
            set { mScrollbars = value; }
        }
        #endregion

        #region Events
        protected override void OnPreRender(EventArgs e)
        {
            GenJavaScript();
            base.OnPreRender(e);
        }
        #endregion

        #region Functions
        private void GenJavaScript()
        {
            string returnScript = "";
            try
            {
                returnScript = returnScript + "<script language=\"JavaScript\" type=\"text/javascript\">" + "\r";
                returnScript = returnScript + "function " + this.UniqueID + "(ControlID,BOID) {" + "\r";

                returnScript = returnScript + "" + "\r";
                returnScript = returnScript + "var x = (parseInt(window.screen.width)-" + PopupWidth + ") / 2;" + "\r";
                returnScript = returnScript + "var y = (parseInt(window.screen.height)-" + PopupHeight + ") / 2;" + "\r";
                returnScript = returnScript + "" + "\r";

                returnScript = returnScript + "CW=window.open('" + URL + "?CID='+ControlID+'&BID='+BOID+'&GH='+" + PopupHeight + "+'&Title=" + Title + "&GridID=" + GridID + "','NewWin','toolbar=" + Toolbar + ",menubar=" + Menubar + ",location=" + Location + ",resizable=" + Resizable + ",status=" + Status + ",width=" + PopupWidth + ",height=" + PopupHeight + ",scrollbars=" + Scrollbars + ", top='+x+',left='+y);" + "\r";
                returnScript = returnScript + "" + "\r";

                returnScript = returnScript + "}" + "\r";
                returnScript = returnScript + "</script>" + "\r";

                HttpContext.Current.Response.Write(returnScript);          

                this.ClientSideEvents.CustomButtonPress = this.UniqueID + "('" + this.UniqueID + "','" + BuObjID + "')";
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
        #endregion

    }
}
