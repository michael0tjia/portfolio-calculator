using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

namespace Innotelli.Web.Controls
{
    public class itWebDateChooser : Infragistics.WebUI.WebSchedule.WebDateChooser
    {
        #region Members

        #endregion

        #region Constructors
        public itWebDateChooser()
        {

        }
        #endregion

        #region Enums

        #endregion

        #region Properties
        #endregion

        #region Events
        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            CultureInfo ci = new CultureInfo("");
            ci.DateTimeFormat.ShortDatePattern = "yyyy/MM/dd";
            ci.DateTimeFormat.LongDatePattern = "yyyy/MM/dd, ddd";
            this.CalendarLayout.Culture = ci;
            this.CalendarLayout.FooterFormat = "Today: {0:yyyy/MM/dd}";
        }
        #endregion

        #region Functions
        #endregion



    }
}
