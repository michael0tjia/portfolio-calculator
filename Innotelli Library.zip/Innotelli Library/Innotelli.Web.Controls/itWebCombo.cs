using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Infragistics.WebUI.WebCombo;
using Infragistics.WebUI.UltraWebGrid;
using Innotelli.Utilities;
using Innotelli.Db;
using Innotelli.BO;

namespace Innotelli.Web.Controls
{
    [System.Drawing.ToolboxBitmap(typeof(Infragistics.WebUI.WebCombo.WebCombo)), DefaultProperty(""),
    ToolboxData("<{0}:itWebCombo runat='server'></{0}:itWebCombo>")]
    public class itWebCombo : Infragistics.WebUI.WebCombo.WebCombo
    {

        #region Members
        private string mBuObjID = "";
        private string mFilter = "";
        #endregion

        #region Constructors
        public itWebCombo()
        {
            this.DropDownLayout.AutoGenerateColumns = false;
        }
        #endregion

        #region Properties
        public string BuObjID
        {
            get
            {
                return mBuObjID;
            }
            set
            {
                mBuObjID = value;
            }
        }
        public string Filter
        {
            get
            {
                return mFilter;
            }
            set
            {
                mFilter = value;
            }
        }
        #endregion

        #region Events
        protected override void OnPreRender(EventArgs e)
        {
            try
            {
                GenColumns();
                base.OnPreRender(e);
            }
            catch
            {

            }            
        }
        #endregion

        #region Method
        private void GenColumns()
        {
            try
            {
                TSPrpsBOT01 lSPrpsBOT01 = Innotelli.BO.TSingletons.SPrpsBOT01s[BuObjID];

                //TForm02Tree lClntSelCboHndlr = new TForm02Tree();
                //#check!
                //DataSet lDs = lClntSelCboHndlr.GetDataSource(lSPrpsBOT01.RowSource, Filter);
                DataSet lDs = null;
                int lColumnsNo = lSPrpsBOT01.ColumnCount;
                double[] lColuWidth = new double[10];
                lColuWidth[0] = double.Parse(lSPrpsBOT01.ColumnWidth01);
                lColuWidth[1] = double.Parse(lSPrpsBOT01.ColumnWidth02);
                lColuWidth[2] = double.Parse(lSPrpsBOT01.ColumnWidth03);
                lColuWidth[3] = double.Parse(lSPrpsBOT01.ColumnWidth04);
                lColuWidth[4] = double.Parse(lSPrpsBOT01.ColumnWidth05);
                lColuWidth[5] = double.Parse(lSPrpsBOT01.ColumnWidth06);
                lColuWidth[6] = double.Parse(lSPrpsBOT01.ColumnWidth07);
                lColuWidth[7] = double.Parse(lSPrpsBOT01.ColumnWidth08);
                lColuWidth[8] = double.Parse(lSPrpsBOT01.ColumnWidth09);
                lColuWidth[9] = double.Parse(lSPrpsBOT01.ColumnWidth10);

                this.Columns.Clear();

                for (int i = 0; i < lColumnsNo; i++)
                {
                    UltraGridColumn lColu = new UltraGridColumn();
                    lColu.Key = lDs.Tables[0].Columns[i].ColumnName;
                    lColu.BaseColumnName = lDs.Tables[0].Columns[i].ColumnName;
                    lColu.Header.Caption = lDs.Tables[0].Columns[i].Caption;
                    lColu.Width = (int)lColuWidth[i] * 20;
                    //lColu.Width = 10 * 10;
                    this.Columns.Add(lColu);
                }
                this.DataValueField = lDs.Tables[0].Columns[0].ColumnName;
                this.DataTextField = lDs.Tables[0].Columns[1].ColumnName;
                this.Columns[0].Hidden = true;
                //TODO: check the dropdownwidth
                this.DropDownLayout.DropdownWidth = (int)(lSPrpsBOT01.ListWidth.Value * 40);

                this.DataSource = lDs.Tables[0];
                this.DataBind();
            }
            catch
            {

            }
        }
        #endregion

    }
}
