﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TDateEditor02Designer))]
    public class TDateEditor02 : ASPxDateEdit
    {
        public TDateEditor02()
        {      
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                this.EditFormat = EditFormat.Date;
                this.ClientSideEvents.ValueChanged = "function(s,e){SetButtonsEnable(true);}";
            }
        }
    }

    [ToolboxItem(true)]
    public class TDateEditor02Designer : ASPxDateEditDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxDateEdit));
        }
    }
}
