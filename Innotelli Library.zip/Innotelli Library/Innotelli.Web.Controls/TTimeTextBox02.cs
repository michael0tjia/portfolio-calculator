﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TTimeTextBox02Designer))]
    public class TTimeTextBox02 : ASPxTextBox
    {
        public TTimeTextBox02()
        {
            this.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            this.ReadOnlyStyle.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            this.ReadOnly = true;
            this.MaskSettings.Mask = "";
        }
    }

    [ToolboxItem(true)]
    public class TTimeTextBox02Designer : ASPxTextBoxDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxTextBox));
        }
    }
}
