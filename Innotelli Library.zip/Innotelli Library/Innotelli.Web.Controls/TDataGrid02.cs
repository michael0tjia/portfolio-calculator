﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;
using DevExpress.Web.ASPxGridView.Design;
using DevExpress.Web.ASPxGridView;
using Innotelli.BO;
using Innotelli.Db;
using System.Data;
using System.Web.UI;


namespace Innotelli.Web.Controls
{
    [Designer(typeof(TDataGrid02Designer))]
    public class TDataGrid02 : ASPxGridView
    {
        public TDataGrid02()
        {

        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                this.EnableCallBacks = true;
                this.ClientInstanceName = this.ID;
                this.ClientSideEvents.RowClick = "function(s,e){lucDataGrid.GetRowValues(e.visibleIndex, SaveValue + ShowText , OnGetRowValues)}";
                this.Settings.ShowFilterRow = true;
                this.AutoGenerateColumns = true;
            }
        }

        private string mBOID;
        public string BOID
        {
            get
            {
                return mBOID;
            }
            set
            {
                if (Innotelli.Utilities.TGC.IsRunTime)
                {
                    mBOID = value;
                }
            }
        }

        public string LookupViewName
        {
            get
            {
                return "A_TB01" + mBOID + "_LookUpList";
            }
        }

        public void LoadData()
        {
            if (!string.IsNullOrEmpty(mBOID))
            {
                TDataObject lDao = new TDataObject();
                lDao.SQL.Stmt = "SELECT * FROM " + LookupViewName;
                lDao.OpenTable();
                Columns.Clear();
                DataSource = lDao.Dt;
                Page.Session["LookupView"] = lDao.Dt;
            }
            else if (Page.Session["LookupView"] != null)
            {
                DataSource = (DataTable)Page.Session["LookupView"];

            }
        }
    }

    [ToolboxItem(true)]
    public class TDataGrid02Designer : GridViewDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxGridView));
        }
    }
}
