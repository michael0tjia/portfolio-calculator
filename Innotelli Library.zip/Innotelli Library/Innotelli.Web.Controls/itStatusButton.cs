using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

namespace Innotelli.Web.Controls
{
    [DefaultProperty("Text")]
    [ToolboxData("<{0}:itStatusButton runat=server></{0}:itStatusButton>")]
    public class itStatusButton : ImageButton
    {
        Hashtable mHT = new Hashtable();

        public itStatusButton()
        {
            mHT.Add(0, "~/Image/StatusButton/0.gif");
            mHT.Add(1, "~/Image/StatusButton/1.gif");
            mHT.Add(2, "~/Image/StatusButton/2.gif");
        }

        [Bindable(true)]
        [Category("Appearance")]
        [DefaultValue("")]
        [Localizable(true)]
        protected override string Text
        {
            get
            {
                String s = (String)ViewState["Text"];
                return ((s == null) ? String.Empty : s);
            }
            set
            {
                //ViewState["Text"] = value;
                this.ImageUrl = mHT[int.Parse(value)].ToString();
            }
        }

        protected override void RenderContents(HtmlTextWriter output)
        {
            output.Write(Text);
        }

        public int setStatus
        {
            set
            {
                this.ImageUrl = mHT[value].ToString();
            }
        }

        public void setImagesLoc(int status, string aURL)
        {
            if (!mHT.ContainsKey(status))
            {
                mHT.Add(status, aURL);
            }
            else
            {
                mHT[status] = aURL;
            }
        }
    }
}
