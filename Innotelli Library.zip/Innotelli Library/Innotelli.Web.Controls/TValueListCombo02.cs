﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TValueListCombo02Designer))]
    public class TValueListCombo02 : ASPxComboBox
    {
        public TValueListCombo02()
        {
        }
    }

    [ToolboxItem(true)]
    public class TValueListCombo02Designer : ASPxComboBoxDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxComboBox));
        }
    }
}