using System;
using System.ComponentModel;
using System.ComponentModel.Design.Serialization;
using System.Globalization;
using System.Reflection;
using System.Web.UI;

namespace Innotelli.Web.Controls
{
	/// <summary>Type converter to persist the data bindings to code</summary>
	public class DataBindingInfoTypeConverter : TypeConverter
	{
		/// <summary>Tells if the type converter can convert to a specific type</summary>
		/// <param name="context">context</param>
		/// <param name="destinationType">destination type for the conversion</param>
		/// <returns>true if the conversion can be made. false otherwise</returns>
		public override bool CanConvertTo(ITypeDescriptorContext context, Type destinationType) 
		{
			// this TypeConverter converts only to a InstanceDescriptor
			if (destinationType == typeof(InstanceDescriptor)){
				return true;
			}

			// otherwise, delegate to the base class
			return base.CanConvertTo(context, destinationType);
		}
		
		/// <summary>Converts the object to the specific type</summary>
		/// <param name="context">contexto de formato</param>
		/// <param name="culture">referencia cultural a usar</param>
		/// <param name="value">valor a convertir</param>
		/// <param name="destinationType">tipo de destino</param>
		/// <returns>Instance descriptor para la conversi�n</returns>
		public override object ConvertTo(ITypeDescriptorContext context, CultureInfo culture, object value, Type destinationType) 
		{
			// check for it's asking to convert a DataBindingInfo to a InstanceDescriptor
			if ((destinationType == typeof(InstanceDescriptor)) && (value is DataBindingInfo)) {
				DataBindingInfo item = (DataBindingInfo)value;

				// choose a constructor based on the TwoWay property (to avoid temporary objects)
				if (item.TwoWay){
					ConstructorInfo ctor = typeof(DataBindingInfo).GetConstructor(new Type[]{ typeof(Control), typeof(string), typeof(string), typeof(string) });
					if (ctor != null) {
						return new InstanceDescriptor(ctor, new object[] { item.Control, item.PropControl, item.Object, item.PropObject });
					}
				} else {
					ConstructorInfo ctor = typeof(DataBindingInfo).GetConstructor(new Type[]{ typeof(Control), typeof(string), typeof(string), typeof(string), typeof(bool) });
					if (ctor != null) {
						return new InstanceDescriptor(ctor, new object[] { item.Control, item.PropControl, item.Object, item.PropObject, item.TwoWay });
					}
				}
			}

			// otherwise, delegate to the base class
			return base.ConvertTo(context, culture, value, destinationType);
		}
	}
}
