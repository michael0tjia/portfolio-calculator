///////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	Binding Manager (c) 2004 Manuel Abadia 
//
//	You are allowed to use this component in your own projects as long as you don't remove this message.
//	If you find this component useful, please send me an email to dotnetmanu@yahoo.com
///////////////////////////////////////////////////////////////////////////////////////////////////////////////


using System;
using System.Collections.Specialized;
using System.ComponentModel;
using System.ComponentModel.Design;
using System.ComponentModel.Design.Serialization;
using System.Globalization;
using System.Reflection;
using System.Threading;
using System.Web.UI;
using Innotelli.Utilities;

namespace Innotelli.Web.Controls
{
    /// <summary>Component that gets the data bindings in design time persisting them code in order to provide 2 way data binding</summary>
    [Serializable()]
    [Designer(typeof(BindingManagerDesigner))]
    public class BindingManager : Component
    {
        protected DataBindingInfoCollection _dbic;
        protected CultureInfo _cultureInfo;

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        [Description("DataBindings managed by the binding manager")]
        public DataBindingInfoCollection DataBindings
        {
            get { return _dbic; }
        }

        [Description("CultureInfo used for type conversion")]
        [DefaultValue(null)]
        public CultureInfo Culture
        {
            get { return _cultureInfo; }
            set { _cultureInfo = value; }
        }

        public BindingManager()
        {
            _dbic = new DataBindingInfoCollection();
            _cultureInfo = null;
        }

        #region Binding Methods

        /// <summary>Populates the bound controls with data</summary>
        /// <param name="form">WebForm with bound controls</param>
        public void BindToWebForm(Page form)
        {
            StringCollection bindedControls = new StringCollection();

            // iterate through the data bindings
            foreach (DataBindingInfo dbi in _dbic)
            {
                // get the control to bind
                Control control = dbi.Control;

                // if it hasn't been bound yet
                if (!bindedControls.Contains(control.ID))
                {
                    control.DataBind();

                    // mark the control as bound
                    bindedControls.Add(control.ID);
                }
            }
        }

        /// <summary>Extracts data from the bound controls</summary>
        /// <param name="form">WebForm with bound controls</param>
        public void BindFromWebForm(Page form)
        {
            // iterate through the data bindings
            foreach (DataBindingInfo dbi in _dbic)
            {
                // if the binding isn't two way, exit
                if (!dbi.TwoWay) continue;

                // get property to bind from
                object sourceProp = GetPropertyOrFieldEx(dbi.Control, dbi.PropControl);

                if (sourceProp != null && sourceProp.GetType() == typeof(DateTime))
                {
                    if (((DateTime)sourceProp).Ticks == 0)
                    {
                        sourceProp = null;
                    }
                }

                // if we can't get the property, error
                if (sourceProp != null)
                {

                    // get the full property name
                    string fullPropObject = dbi.Object;
                    if (dbi.PropObject != null)
                    {
                        fullPropObject += "." + dbi.PropObject;
                    }

                    // check source and destination types
                    Type sourcePropType = sourceProp.GetType();
                    Type destPropType = GetPropertyOrFieldTypeEx(form, fullPropObject);

                    if (destPropType == null)
                    {
                        throw new DataBindingException("DataBinding error, can't find: " + fullPropObject, dbi.Control);
                    }

                    // if the types doesn't match try to make a conversion
                    if (!sourcePropType.Equals(destPropType))
                    {
                        try
                        {
                            sourceProp = ConvertTypes(sourceProp, destPropType);
                        }
                        catch
                        {
                            //Deleted By Lok
                            //throw new DataBindingException("DataBinding error, can't convert types: ", e, dbi.Control);
                        }

                        if (sourceProp == null)
                        {
                            //Deleted By Lok
                            //throw new DataBindingException("DataBinding error, can't convert bound property: " + dbi.PropControl + " for: " + fullPropObject, dbi.Control);
                        }
                    }

                    // do the data binding
                    if (!SetPropertyOrFieldEx(form, fullPropObject, sourceProp))
                    {
                        throw new DataBindingException("DataBinding error, can't set: " + fullPropObject, dbi.Control);
                    }
                }
            }
        }

        #endregion

        #region Type Conversion

        /// <summary>Converts the source object to an object of the destination type</summary>
        /// <param name="source">object to convert</param>
        /// <param name="destType">destination type for the conversion</param>
        /// <returns>the object converted or null if the conversion can't be done</returns>
        protected virtual object ConvertTypes(object source, Type destType)
        {
            #region Convert string to TDbRowID
            // TODO: better way to do it
            if (destType == typeof(TDbRowID))
            {
                int? lSourceValue = null;
                if (source.GetType() == typeof(string))
                {
                    try
                    {
                        lSourceValue = int.Parse(source.ToString());
                    }
                    catch
                    {
                    }
                    if (lSourceValue == null)
                    {
                        return TDbRowID.Null;
                    }
                    else
                    {
                        TDbRowID lDbRowID = new TDbRowID();
                        lDbRowID.Value = (int)lSourceValue;
                        return lDbRowID;
                    }
                }
            }
            #endregion

            if (source == null || source.ToString() == string.Empty)
            {
                return null;
            }
            Type sourceType = source.GetType();

            // get a type converter for the destination type
            TypeConverter converter = TypeDescriptor.GetConverter(destType);

            // try to make the conversion using the type converter
            try
            {
                if ((converter != null) && (converter.CanConvertFrom(null, sourceType)))
                {
                    CultureInfo ci = _cultureInfo;

                    // if the culture info is not set, use the one in current thread
                    if (ci == null)
                    {
                        ci = Thread.CurrentThread.CurrentCulture;
                    }
                    return converter.ConvertFrom(null, ci, source);
                }
            }
            catch
            {
            }

            // if there wasn't a type converter associated with the type, try another method

            // if source type is string, search an static method called "Parse" to make the conversion
            if (sourceType.Equals(typeof(string)))
            {
                MethodInfo method = destType.GetMethod("Parse", BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.Static, null, new Type[] { typeof(string) }, null);

                // if we've found the method, do the conversion
                if ((method != null) && (method.ReturnType.Equals(destType)))
                {
                    return method.Invoke(null, BindingFlags.InvokeMethod, null, new object[] { source }, CultureInfo.CurrentCulture);
                }
            }

            // if we've reached this point, we can't make the conversion
            return null;
        }

        #endregion

        #region Reflection Helpers

        protected const BindingFlags BINDING_FLAGS =
            BindingFlags.IgnoreCase | BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static;

        /// <summary>Get a property or a field (even a complex one using recursion)</summary>
        /// <param name="obj">source object</param>
        /// <param name="member">property or field to get</param>
        /// <returns>desired property or field (or null if it hasn't been found)</returns>
        protected object GetPropertyOrFieldEx(object obj, string member)
        {
            if (member == "") return obj;

            // search a dot to see if it's a complex property
            int dotIndex = member.IndexOf('.');

            // search a square bracket to see if it's an indexer property
            int braquetIndex = member.IndexOf('[');

            bool hasDotBeforeBraquet = ((dotIndex > 0) && (braquetIndex == -1)) || ((dotIndex < braquetIndex) && (dotIndex > -1));
            bool hasBraquetBeforeDot = ((braquetIndex > 0) && (dotIndex == -1)) || ((braquetIndex < dotIndex) && (braquetIndex > -1));

            // if the expression uses an indexer
            if (hasBraquetBeforeDot)
            {
                int braquetIndex2 = member.IndexOf(']');
                string index = member.Substring(braquetIndex + 1, braquetIndex2 - braquetIndex - 1);
                string indexerProp = member.Substring(0, braquetIndex);
                string newMember = member.Substring(braquetIndex2 + 1);

                // get indexer property and advance through the path
                object newObj = GetIndexerProperty(obj, indexerProp, index.Trim());

                if (newObj == null) return null;

                return GetPropertyOrFieldEx(newObj, newMember);
            }
            else if (hasDotBeforeBraquet)
            {
                // if it's a complex property, advances through the property path
                string newObjName = member.Substring(0, dotIndex);
                string newMember = member.Substring(dotIndex + 1);

                object newObj = GetPropertyOrFieldEx(obj, newObjName);

                if (newObj == null) return null;

                return GetPropertyOrFieldEx(newObj, newMember);

            }
            else
            {
                // if it's a simple one, get its value
                return GetPropertyOrField(obj, member);
            }
        }

        /// <summary>Get a simple property or field</summary>
        /// <param name="obj">source object</param>
        /// <param name="member">property or field to get</param>
        /// <returns>desired property or field (or null if it hasn't been found)</returns>
        protected object GetPropertyOrField(object obj, string member)
        {
            Type objType = obj.GetType();

            // search a property with that name
            PropertyInfo prop = objType.GetProperty(member, BINDING_FLAGS);

            if (prop != null)
            {
                return prop.GetValue(obj, null);
            }
            else
            {
                // if a property with that name wasn't found, try with a field
                FieldInfo field = objType.GetField(member, BINDING_FLAGS);

                return (field == null) ? null : field.GetValue(obj);
            }
        }

        /// <summary>Get an indexer property</summary>
        /// <param name="obj">source object</param>
        /// <param name="member">property to get</param>
        /// <param name="index">index to get</param>
        /// <returns>desired indexer property (or null if it hasn't been found)</returns>
        protected object GetIndexerProperty(object obj, string member, string index)
        {
            PropertyInfo prop = null;
            object indexVal = null;

            object aux = GetPropertyOrFieldEx(obj, member);

            try
            {
                // search for an indexer property of type int
                int num = Int32.Parse(index);
                prop = GetIndexer(aux.GetType(), typeof(int));
                indexVal = num;
            }
            catch
            {
                // if conversion to int failed, search for an indexer property of type string
                prop = GetIndexer(aux.GetType(), typeof(string));
                indexVal = index.Substring(1, index.Length - 2);
            }

            // if we found the indexer, get its value
            if (prop != null)
            {
                return prop.GetValue(aux, new object[1] { indexVal });
            }
            else
            {
                return null;
            }
        }

        /// <summary>Set a property or field(even a complex one using recursion)</summary>
        /// <param name="obj">source object</param>
        /// <param name="member">property or field to set</param>
        /// <param name="value">value of the property or field</param>
        /// <returns>true if success, otherwise false</returns>
        protected bool SetPropertyOrFieldEx(object obj, string member, object value)
        {
            if (member == "")
            {
                return false;
            }

            // search a dot to see if it's a complex property
            int dotIndex = member.IndexOf('.');

            // search a square bracket to see if it's an indexer property
            int braquetIndex = member.IndexOf('[');

            bool hasDotBeforeBraquet = ((dotIndex > 0) && (braquetIndex == -1)) || ((dotIndex < braquetIndex) && (dotIndex > -1));
            bool hasBraquetBeforeDot = ((braquetIndex > 0) && (dotIndex == -1)) || ((braquetIndex < dotIndex) && (braquetIndex > -1));

            // if the expression uses an indexer
            if (hasBraquetBeforeDot)
            {
                int braquetIndex2 = member.IndexOf(']');
                string index = member.Substring(braquetIndex + 1, braquetIndex2 - braquetIndex - 1);
                string indexerProp = member.Substring(0, braquetIndex);
                string newMember = member.Substring(braquetIndex2 + 1);

                // if the expression ends with the indexer set it's value
                if (newMember == "")
                {
                    return this.SetIndexerProperty(obj, indexerProp, value, index.Trim());
                }
                else
                {
                    // otherwise, get indexer property and advance through the path
                    object newObj = GetIndexerProperty(obj, indexerProp, index.Trim());

                    if (newObj == null) return false;

                    return SetPropertyOrFieldEx(newObj, newMember, value);
                }
            }
            else if (hasDotBeforeBraquet)
            {
                // if it's a complex property, advances through the property path
                string newObjName = member.Substring(0, dotIndex);
                string newMember = member.Substring(dotIndex + 1);

                object newObj = GetPropertyOrFieldEx(obj, newObjName);

                if (newObj == null) return false;

                return SetPropertyOrFieldEx(newObj, newMember, value);
            }
            else
            {
                // if it's a simple one, set its value
                return SetPropertyOrField(obj, member, value);
            }
        }

        /// <summary>Set a property or field</summary>
        /// <param name="obj">source object</param>
        /// <param name="member">property ro field to set</param>
        /// <param name="value">value of the property or field</param>
        /// <returns>true if success, otherwise false</returns>
        protected bool SetPropertyOrField(object obj, string member, object value)
        {
            // search a property with that name
            PropertyInfo prop = obj.GetType().GetProperty(member, BINDING_FLAGS);

            if (prop != null)
            {
                prop.SetValue(obj, value, null);

                return true;
            }
            else
            {
                // if a property with that name wasn't found, try with a field
                FieldInfo field = obj.GetType().GetField(member, BINDING_FLAGS);

                if (field != null)
                {
                    field.SetValue(obj, value);

                    return true;
                }
                else
                {
                    return false;
                }
            }
        }

        /// <summary>Set an indexer property</summary>
        /// <param name="obj">source object</param>
        /// <param name="member">property to set</param>
        /// <param name="value">value of the property</param>
        /// <param name="index">index to get</param>
        /// <returns>true if success, otherwise false</returns>
        protected bool SetIndexerProperty(object obj, string member, object value, string index)
        {
            PropertyInfo prop = null;
            object indexVal = null;

            object aux = GetPropertyOrFieldEx(obj, member);

            try
            {
                // search for an indexer property of type int
                int num = Int32.Parse(index);
                prop = GetIndexer(aux.GetType(), typeof(int));
                indexVal = num;
            }
            catch
            {
                // if conversion to int failed, search for an indexer property of type string
                prop = GetIndexer(aux.GetType(), typeof(string));
                indexVal = index.Substring(1, index.Length - 2);
            }

            // if we found the indexer, set its value
            if (prop != null)
            {
                prop.SetValue(aux, value, new object[1] { indexVal });

                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>Get a property or field type (even a complex one using recursion)</summary>
        /// <param name="obj">source object</param>
        /// <param name="member">property or field</param>
        /// <returns>type found or null</returns>
        protected Type GetPropertyOrFieldTypeEx(object obj, string member)
        {
            if (member == "") return obj.GetType();

            // search a dot to see if it's a complex property
            int dotIndex = member.IndexOf('.');

            // search a square bracket to see if it's an indexer property
            int braquetIndex = member.IndexOf('[');

            bool hasDotBeforeBraquet = ((dotIndex > 0) && (braquetIndex == -1)) || ((dotIndex < braquetIndex) && (dotIndex > -1));
            bool hasBraquetBeforeDot = ((braquetIndex > 0) && (dotIndex == -1)) || ((braquetIndex < dotIndex) && (braquetIndex > -1));

            // if the expression uses an indexer
            if (hasBraquetBeforeDot)
            {
                int braquetIndex2 = member.IndexOf(']');
                string index = member.Substring(braquetIndex + 1, braquetIndex2 - braquetIndex - 1);
                string indexerProp = member.Substring(0, braquetIndex);
                string newMember = member.Substring(braquetIndex2 + 1);

                // get indexer property and advance through the path
                object newObj = GetIndexerProperty(obj, indexerProp, index.Trim());

                if (newObj == null) return null;

                return GetPropertyOrFieldTypeEx(newObj, newMember);
            }
            else if (hasDotBeforeBraquet)
            {
                // if it's a complex property, advances through the property path
                string newObjName = member.Substring(0, dotIndex);
                string newMember = member.Substring(dotIndex + 1);

                object newObj = GetPropertyOrFieldEx(obj, newObjName);

                if (newObj == null) return null;

                return GetPropertyOrFieldTypeEx(newObj, newMember);
            }
            else
            {
                // if it's a simple one, get its type
                return GetPropertyOrFieldType(obj, member);
            }
        }

        /// <summary>Get a property type</summary>
        /// <param name="obj">source object</param>
        /// <param name="member">property</param>
        /// <returns>type found or null</returns>
        protected Type GetPropertyOrFieldType(object obj, string member)
        {
            Type objType = obj.GetType();

            // search a property with that name
            PropertyInfo prop = objType.GetProperty(member, BINDING_FLAGS);

            if (prop != null)
            {
                if (prop.PropertyType != typeof(object))
                {
                    return prop.PropertyType;
                }
                else
                {
                    // if it's a generic type, try to get the underlying type
                    return prop.GetValue(obj, null).GetType();
                }
            }
            else
            {
                // if a property with that name wasn't found, try with a field
                FieldInfo field = objType.GetField(member, BINDING_FLAGS);

                if (field == null)
                {
                    return null;
                }

                if (field.FieldType != typeof(object))
                {
                    return field.FieldType;
                }
                else
                {
                    // if it's a generic type, try to get the underlying type
                    return field.GetValue(obj).GetType();
                }

            }
        }

        /// <summary>Get an indexer property type</summary>
        /// <param name="obj">source object</param>
        /// <param name="member">property type to get</param>
        /// <param name="index">index to get</param>
        /// <returns>type found or null</returns>
        protected Type GetIndexerPropertyType(object obj, string member, string index)
        {
            PropertyInfo prop = null;
            object indexVal = null;

            object aux = GetPropertyOrFieldEx(obj, member);

            try
            {
                // search for an indexer property of type int
                int num = Int32.Parse(index);
                prop = GetIndexer(aux.GetType(), typeof(int));
                indexVal = num;
            }
            catch
            {
                // if conversion to int failed, search for an indexer property of type string
                prop = GetIndexer(aux.GetType(), typeof(string));
                indexVal = index.Substring(1, index.Length - 2);
            }

            // if we found the indexer, get its value
            if (prop != null)
            {
                if (prop.PropertyType != typeof(object))
                {
                    return prop.PropertyType;
                }
                else
                {
                    // if it's a generic type, try to get the underlying type
                    return prop.GetValue(aux, new object[1] { indexVal }).GetType();
                }
            }
            else
            {
                return null;
            }
        }

        /// <summary>Get info about an indexer</summary>
        /// <param name="type">source type</param>
        /// <returns>information about the default indexer or null if no indexer was found</returns>
        protected PropertyInfo GetIndexer(Type sourceType, Type paramType)
        {
            // search for the indexer
            MemberInfo[] defaultMembers = sourceType.GetDefaultMembers();
            foreach (MemberInfo member in defaultMembers)
            {
                if (member.MemberType == MemberTypes.Property)
                {
                    PropertyInfo indexer = (PropertyInfo)member;

                    ParameterInfo[] param = indexer.GetGetMethod().GetParameters();
                    if (indexer.CanRead && (param.Length == 1) && (param[0].ParameterType.IsAssignableFrom(paramType)))
                    {
                        return indexer;
                    }
                }
            }

            // no indexer found			
            return null;
        }

        #endregion
    }
}