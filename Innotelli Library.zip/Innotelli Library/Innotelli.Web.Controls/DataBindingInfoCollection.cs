using System;
using System.Collections;

namespace Innotelli.Web.Controls
{
	/// <summary>Class that models a collection of DataBindingInfo items</summary>
	public class DataBindingInfoCollection : CollectionBase
	{
		public DataBindingInfoCollection(){}
		
		public int Add(DataBindingInfo item) 
		{
			return List.Add(item);
		}

		public void AddRange(DataBindingInfo[] items)
		{
			for (int i = 0; i < items.Length; i++){
				List.Add(items[i]);
			}
		}

		public void Insert(int index, DataBindingInfo item) 
		{
			List.Insert(index, item);
		}

		public void Remove(DataBindingInfo item) 
		{
			List.Remove(item);
		} 

		public bool Contains(DataBindingInfo item)
		{
			return List.Contains(item);
		}

		public int IndexOf(DataBindingInfo item)
		{
			return List.IndexOf(item);
		}

		public void CopyTo(DataBindingInfo[] array, int index) 
		{
			List.CopyTo(array, index);
		}

		public DataBindingInfo this[int index] 
		{
			get { return (DataBindingInfo)List[index]; }
			set { List[index] = value; 	}
		}
	}
}
