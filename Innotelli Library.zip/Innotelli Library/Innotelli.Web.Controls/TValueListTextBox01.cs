﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TValueListTextBox01Designer))]
    public class TValueListTextBox01 : ASPxComboBox
    {
        public TValueListTextBox01()
        {
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ReadOnlyStyle.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            this.ReadOnly = true;
        }
    }

    [ToolboxItem(true)]
    public class TValueListTextBox01Designer : ASPxComboBoxDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxComboBox));
        }
    }
}