using System;
using System.Data;
using System.Configuration;
using System.IO;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using Innotelli.Utilities;

namespace Innotelli.Web.Controls
{
    public partial class TPage002 : System.Web.UI.Page
    {
        public string CurCulture
        {
            get
            {
                return this.Session["Culture"].ToString();
            }
        }

        public string GetCultureSuffix()
        {
            string lRtrnVal = "";

            if (CurCulture == "zh-tw")
            {
                lRtrnVal = "TCh";
            }
            else if (CurCulture == "zh-cn")
            {
                lRtrnVal = "SCh";
            }

            return lRtrnVal;
        }

        protected virtual void GetCtrlPrp()
        {

        }

        protected virtual void SetCtrlPrp()
        {

        }

        protected override void InitializeCulture()
        {
            TCulture lCulture = new TCulture();
            lCulture.LocalSetting(this);
            base.InitializeCulture();
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            SetCtrlPrp();
        }

        protected void SetMaxLength(object sender, EventArgs e)
        {
            TextBox lTxtBx = (TextBox)sender;
            BaseDataBoundControl lDataBoundCtrl = (BaseDataBoundControl)lTxtBx.NamingContainer;
            string lFldNm = lDataBoundCtrl.DataSourceID + "." + lTxtBx.ID.Substring(3) + ".FieldSize";
            lTxtBx.MaxLength = GetFieldSize(GetPageName(), lFldNm);
        }

        protected int GetFieldSize(string aPgNm, string aFldNm)
        {
            return int.Parse(GetGlobalResourceObject(aPgNm, aFldNm).ToString());
        }

        protected string GetPageName()
        {
            string lFlNm = Path.GetFileName(HttpContext.Current.Request.Url.AbsolutePath);
            string lPgNm = lFlNm.Substring(0, lFlNm.Length - 5);
            return lPgNm;
        }

    }
}
