﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TCurrencyTextBox04Designer))]
    public class TCurrencyTextBox04 : ASPxTextBox
    {
        public TCurrencyTextBox04()
        {
            
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                this.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                this.ReadOnlyStyle.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                this.ReadOnly = true;
                this.ValidationSettings.ValidateOnLeave = true;
                this.ValidationSettings.RegularExpression.ValidationExpression = @"-*\d+";
                this.MaxLength = 255;
            }
        }
    }

    [ToolboxItem(true)]
    public class TCurrencyTextBox04Designer : ASPxTextBoxDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxTextBox));
        }
    }
}