﻿using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using DevExpress.Web.ASPxEditors;
using DevExpress.Web.ASPxEditors.Design;

namespace Innotelli.Web.Controls
{
    [Designer(typeof(TMemoBox01Designer))]
    public class TMemoBox01 : ASPxMemo
    {
        public TMemoBox01()
        {
            
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                this.ClientSideEvents.TextChanged = "function(s,e){SetButtonsEnable(true);}";
            }
        }
    }

    [ToolboxItem(true)]
    public class TMemoBox01Designer : ASPxMemoDesigner
    {
        public override void Initialize(IComponent component)
        {
            base.Initialize(component);
            RegisterTagPrefix(typeof(ASPxMemo));
        }
    }
}
