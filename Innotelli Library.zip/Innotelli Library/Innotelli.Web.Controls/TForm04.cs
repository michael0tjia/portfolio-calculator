﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using DevExpress.Web.ASPxEditors;
using Innotelli.Utilities;
using Innotelli.BO;
using DevExpress.Web.ASPxGridView;
using Innotelli.Db;
using System.Web;

namespace Innotelli.Web.Controls
{
    public class TForm04 : TPage001
    {
        protected TSysDataRdr mSysDataRdr = Innotelli.Utilities.TSingletons.SysData01Rdr;

        public TComboBox01 cbSearchField
        {
            get
            {
                return (TComboBox01)FindControl("cbSearchField");
            }
        }

        public TComboBox01 cbSearchCondition
        {
            get
            {
                return (TComboBox01)FindControl("cbSearchCondition");
            }
        }

        public TDataGrid04 grdSearchResults
        {
            get
            {
                return (TDataGrid04)FindControl("grdSearchResults");
            }
        }

        public string BOID
        {
            get
            {
                return grdSearchResults.BOID;
            }
        }

        public TTextBox04 txtSearchValue1
        {
            get
            {
                return (TTextBox04)FindControl("txtSearchValue1");
            }
        }
        public TTextBox04 txtSearchValue2
        {
            get
            {
                return (TTextBox04)FindControl("txtSearchValue2");
            }
        }

        private DataView mOperatorDv = null;
        public DataView OperatorDv
        {
            get
            {
                DataTable lDt = null;
                if (mOperatorDv == null)
                {
                    mOperatorDv = new DataView();
                    lDt = mSysDataRdr.GetSysData("SrchCndtn").Tables[0];
                    mOperatorDv.Table = lDt;
                    mOperatorDv.Sort = "Sort";
                }
                return mOperatorDv;
            }
        }

        private DataView mFieldNameDv = null;
        public DataView FieldNameDv
        {
            get
            {
                DataTable lDt = null;
                if (mFieldNameDv == null)
                {
                    mFieldNameDv = new DataView();
                    lDt = Innotelli.BO.TSingletons.SPrpsBOT01s[BOID].SPrpsBOT01FindCols.Dt;
                    mFieldNameDv.Table = lDt;
                    mFieldNameDv.Sort = "Caption";
                    mFieldNameDv.RowFilter = "CanSrch = True";

                }
                return mFieldNameDv;
            }
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                cbSearchField.ClientInstanceName = cbSearchField.ID;
                cbSearchCondition.ClientInstanceName = cbSearchCondition.ID;
                txtSearchValue1.ClientInstanceName = txtSearchValue1.ID;
                txtSearchValue2.ClientInstanceName = txtSearchValue2.ID;
                cbSearchCondition.ClientSideEvents.SelectedIndexChanged = "function(s,e){txtSearchValue2.SetVisible(s.GetSelectedIndex() == 9);}";
                //cbSearchField.ClientSideEvents.SelectedIndexChanged = "function(s,e){txtSearchValue1.SetIsValid(mFieldIsValid[s.GetSelectedIndex()]);txtSearchValue2.SetIsValid(mFieldIsValid[s.GetSelectedIndex()]);}";
                cbSearchField.ClientSideEvents.SelectedIndexChanged = "function(s,e){if(mFieldIsValid[s.GetSelectedIndex()]){txtSearchValue1.RemoveItem(0);}}";
                //txtSearchValue1.ValidationSettings.ErrorText = "Format of Date yyyy/mm/dd";
                //txtSearchValue2.ValidationSettings.ErrorText = "Format of Date yyyy/mm/dd";
                //txtSearchValue1.ValidationSettings.RegularExpression.ErrorText = "Format of Date yyyy/mm/dd";
                //txtSearchValue2.ValidationSettings.RegularExpression.ErrorText = "Format of Date yyyy/mm/dd";

                //txtSearchValue1.ValidationSettings.RegularExpression.ValidationExpression = @"(19|20)\d\d[/](0[1-9]|1[012])[/](0[1-9]|[12][0-9]|3[01])";
                //txtSearchValue2.ValidationSettings.RegularExpression.ValidationExpression = @"(19|20)\d\d[/](0[1-9]|1[012])[/](0[1-9]|[12][0-9]|3[01])";

            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            PrepareDataViews();
        }

        protected virtual void PrepareDataViews()
        {
            cbSearchCondition.DataSource = OperatorDv;
            cbSearchCondition.TextField = "Cndtn";
            cbSearchCondition.DataBind();

            cbSearchField.DataSource = FieldNameDv;
            cbSearchField.TextField = "Caption";
            cbSearchField.ValueField = "FldNm";
            cbSearchField.DataBind();

            string lScript = @"<script>var mFieldIsValid = new Array();";
            for (int i = 0; i < FieldNameDv.Count; i++)
            {
                if (FieldNameDv[i]["FldType"].ToString() == "DATE")
                {
                    lScript += "mFieldIsValid[" + i + "] = true;";
                }
                else
                {
                    lScript += "mFieldIsValid[" + i + "] = false;";
                }
            }
            lScript += "</script>";


            Page.RegisterClientScriptBlock("Done", lScript);


            grdSearchResults.DataSource = ViewState[BOID];
            grdSearchResults.DataBind();

            if (!IsPostBack)
            {
                cbSearchCondition.SelectedIndex = 1;
                cbSearchField.SelectedIndex = 0;
            }
            txtSearchValue2.ClientVisible = (cbSearchCondition.SelectedIndex == 9);
        }

        public string GetCriteriaFromCriteriaRow()
        {
            string lRtrnVal = string.Empty;

            string lValue1 = txtSearchValue1.Text;
            string lValue2 = txtSearchValue2.Text;
            TSQL lSQL = new TSQL();
            string lSQLVal1 = string.Empty;
            string lSQLVal2 = string.Empty;

            string lBgnStr = string.Empty;
            string lEndStr = string.Empty;
            string lOptr = string.Empty;
            DataRow lOperatorDr;
            string lFldNm = cbSearchField.Value.ToString();
            string lFldType = FieldNameDv.Table.Select("FldNm = '" + lFldNm + "'")[0]["FldType"].ToString();
            string lOperator = cbSearchCondition.Text;

            lOperatorDr = Innotelli.Utilities.TSingletons.SrchCndtnDs.Tables[0].Select("Cndtn = " + TSQL.SqlText(lOperator))[0];
            lOptr = lOperatorDr["Optr"].ToString();
            lBgnStr = lOperatorDr["BgnStr"].ToString();
            lEndStr = lOperatorDr["EndStr"].ToString();

            if (lOperator == "Is between" && !TNull.IsValueNull(lValue1) && !string.IsNullOrEmpty(lValue1.ToString()) && !TNull.IsValueNull(lValue2) && !string.IsNullOrEmpty(lValue2.ToString()))
            {
                if (lFldType == "TEXT")
                {
                    lValue1 = lBgnStr + (string)lValue1 + lEndStr;
                    lValue2 = lBgnStr + (string)lValue2 + lEndStr;
                }
                if (lFldType == "DATE")
                {
                    lSQLVal1 = TSQL.SqlValStr(lValue1, "TEXT");
                    lSQLVal2 = TSQL.SqlValStr(lValue2, "TEXT");
                }
                else
                {
                    lSQLVal1 = TSQL.SqlValStr(lValue1, lFldType);
                    lSQLVal2 = TSQL.SqlValStr(lValue2, lFldType);
                }
                lRtrnVal = lFldNm + " " + lOptr + " " + lSQLVal1 + " AND " + lSQLVal2;
            }
            else if (lOperator != "Is between" && !TNull.IsValueNull(lValue1) && !string.IsNullOrEmpty(lValue1.ToString()))
            {
                if (lFldType == "TEXT")
                {
                    lValue1 = lBgnStr + (string)lValue1 + lEndStr;
                }
                if (lFldType == "DATE")
                {
                    lSQLVal1 = TSQL.SqlValStr(lValue1, "TEXT");
                }
                else
                {
                    lSQLVal1 = TSQL.SqlValStr(lValue1, lFldType);
                }
                lRtrnVal = lFldNm + " " + lOptr + " " + lSQLVal1;
            }

            return lRtrnVal;
        }

        protected virtual void Search()
        {
            string lCriteria = GetCriteriaFromCriteriaRow();
            TDataObject lDao = new TDataObject();
            lDao.SQL.Stmt = "SELECT * FROM A_" + BOID + "_GetSearchResult";
            if (!string.IsNullOrEmpty(lCriteria))
            {
                lDao.SQL.AddToWhereClause(lCriteria);
            }
            lDao.OpenTable();
            lDao.Dt.TableName = BOID;
            grdSearchResults.DataSource = lDao.Dt;
            grdSearchResults.DataBind();
            ViewState[BOID] = lDao.Dt;
        }
        public string GetChipper(string aPlainText)
        {
            return HttpUtility.UrlEncode((new TCryptography()).Encrypt(aPlainText));
        }

        public string GetPlainText(string aChipper)
        {
            return (new TCryptography()).Decrypt(aChipper);
        }



    }
}
