using System;
using System.Configuration;
using System.Web.SessionState;
using System.Web;
using System.Threading;

namespace Innotelli.Db
{
    public static class TSingletons
    {
        #region Properties
        private static bool mInitialized = false;
        public static bool Initialized
        {
            get
            {
                return mInitialized;
            }
            set
            {
                mInitialized = value;
            }
        }
        public static TDbObj mDbObj = null;
        public static TDbObj DbObj
        {
            get
            {
                return mDbObj;
            }
        }
        #endregion

        #region Functions
        public static void InitDbObj()
        {
            mInitialized = true;
            mDbObj = new TDbObj(ConfigurationManager.AppSettings["DftCnnStr"]);
            Thread.AllocateNamedDataSlot("DftCnnStr");
        }
        //#check! Web
        private static HttpSessionState GetCurrentSessionObject()
        {
            return HttpContext.Current.Session;
        }
        #endregion
    }
}
