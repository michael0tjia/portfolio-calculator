using System;
using System.Collections;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

namespace Innotelli.Db
{
    public class TAccessSPrc
    {
        #region Enums
        #endregion

        #region Members
        // For MS Access, always Singleton DbObj
        private TDbObj mDbObj = Innotelli.Db.TSingletons.DbObj;
        #endregion

        #region Constructors
        public TAccessSPrc()
        {
        }
        #endregion

        #region Properties
        private string mName = "";
        public string Name
        {
            get
            {
                return mName;
            }
            set
            {
                mName = value;
            }
        }
        private TParams mParams = new TParams();
        public TParams Params
        {
            get
            {
                return mParams;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public bool Process()
        {
            return PartialProcess(1, 99);
        }

        public bool PartialProcess(int aFrom, int aTo)
        {
            bool lReturnValue = false;
            int lRowAffected = 0;
            OleDbCommand lCmd = null;
            int i;

            mDbObj.OpenCnn();
            for (i = aFrom; i <= aTo; i++)
            {
                lCmd = (OleDbCommand)mDbObj.CreateDbCommand();
                lCmd.CommandType = CommandType.StoredProcedure;
                lCmd.CommandText = mName + String.Format("{0:00}", i);

                mParams.AddParamsToCmd(DatabaseType.Access, lCmd);
                lRowAffected = lCmd.ExecuteNonQuery();
            }
            mDbObj.CloseCnn();

            lReturnValue = true;
            return lReturnValue;
        }
        #endregion
    }
}