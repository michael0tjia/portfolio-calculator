using System;
using Innotelli.Utilities;

namespace Innotelli.Db
{
    public class TSQL
    {
        #region Constructors
        public TSQL()
        {
        }
        public TSQL(string aStmt)
        {
            mStmt = aStmt;
        }        
        #endregion

        #region Properties
        private string mStmt;
        public string Stmt
        {
            get
            {
                return mStmt;
            }
            set
            {

                mStmt = TStr.TrimExtraSpace(value);
            }
        }
        private string mMainTable;
        public string MainTable
        {
            get
            {
                return mMainTable;
            }
            set
            {
                mMainTable = value;
            }
        }
        #endregion

        //TODO: Oracle Case not yet ready
        #region Functions

        #region SQL Type
        public static string SqlBool(bool? aVal)
        {
            if (aVal == null)
                return "NULL";
            else
                return SqlBool((bool)aVal, TConnectionFactory.GetDbTypeFromConfigFile());
        }
        public static string SqlBool(bool aVal, DatabaseType aDbType)
        {
            if (aDbType == DatabaseType.Access)
            {
                if (aVal)
                    return "true";
                else
                    return "false";
            }
            else
            {
                if (aVal)
                    return "1";
                else
                    return "0";
            }
        }
        public static string SqlDate(DateTime? aVal)
        {
            if (aVal == null)
                return "NULL";
            else
                return SqlDate(aVal.Value, TConnectionFactory.GetDbTypeFromConfigFile());
        }
        public static string SqlDate(DateTime aVal, DatabaseType aDbType)
        {
            string result = "";

            if (aDbType == DatabaseType.Access)
                result = "#" + aVal.ToString("MM/dd/yyyy") + "#";

            else if (aDbType == DatabaseType.SqlServer)
                result = "'" + aVal.ToString("MM/dd/yyyy") + "'";
            else if (aDbType == DatabaseType.Oracle)
                result = "TO_DATE('" +
                        aVal.Month + "/" + aVal.Day + "/" + aVal.Year + "')";

            return result;
        }
        public static string SqlTime(DateTime? aVal)
        {
            if (aVal == null)
                return "NULL";
            else
                return SqlTime(aVal.Value, TConnectionFactory.GetDbTypeFromConfigFile());
        }
        public static string SqlTime(DateTime aVal, DatabaseType aDbType)
        {
            string result = "";

            if (aDbType == DatabaseType.Access)
                result = "#" + TGC.SpecialDate01 + " " + aVal.ToString("HH:mm:ss") + "#";

            else if (aDbType == DatabaseType.SqlServer)
                result = "'" + TGC.SpecialDate02 + " " + aVal.ToString("HH:mm:ss") + "'";

            else if (aDbType == DatabaseType.Oracle) //To Be Done
                result = "TO_DATE('" +
                        aVal.Hour + ":" + aVal.Minute + ":" + aVal.Second + "')";

            return result;
        }
        public static string SqlDateTime(DateTime? aVal)
        {
            if (aVal == null)
                return "NULL";
            else
                return SqlDateTime(aVal.Value, TConnectionFactory.GetDbTypeFromConfigFile());
        }
        public static string SqlDateTime(DateTime aVal, DatabaseType aDbType)
        {
            string result = "";

            if (aDbType == DatabaseType.Access)
                result = "#" + aVal.ToString("MM/dd/yyyy") + " " + aVal.ToString("HH:mm:ss") + "#";
            else if (aDbType == DatabaseType.SqlServer)
                result = "'" + aVal.ToString("MM/dd/yyyy") + " " + aVal.ToString("HH:mm:ss") + "'";
            else if (aDbType == DatabaseType.Oracle) //To Be Done
                result = "TO_DATE('" +
                        aVal.Hour + ":" + aVal.Minute + ":" + aVal.Second + "')";

            return result;
        }
        public static string SqlText(string aVal)
        {
            string result;

            if ((aVal == null) || (aVal == ""))
            {
                result = "NULL";
            }
            else
            {
                //result = "'" + aVal + "'"; 
                // prevent SQL injection
                result = "'" + aVal.Replace("\'", "\'\'") + "'";
            }

            return result;
        }
        public static string SqlValStr(object aVal, string aFieldType)
        {
            string lReturnValue = "";

            switch (aFieldType)
            {
                case "BIT":
                    lReturnValue = SqlBool((bool?)aVal);
                    break;
                case "TEXT":
                    lReturnValue = SqlText((string)aVal);
                    break;
                case "DATE":
                    lReturnValue = SqlDate((DateTime?)aVal);
                    break;
                default:
                    break;
            }

            return lReturnValue;

        }

        #endregion

        #region Set Statement
		public void SetStmtByTableAndPK(string aTable, string aPKey)
        {
            mStmt = "SELECT * FROM " + aTable + " WHERE " + Utilities.TGC.PKeyName + " = " + aPKey;
        }
        public void SetStmtByTableAndFK(string aTable, string aFKey)
        {
            mStmt = "SELECT * FROM " + aTable + " WHERE " + Utilities.TGC.FKeyName + " = " + aFKey;
        }
        public void SetAllStmtByTable(string aTable)
        {
            mStmt = "SELECT * FROM " + aTable;
        }
        public void SetEmptyStmtByTable(string aTable)
        {
            mStmt = "SELECT * FROM " + aTable + " WHERE " + Utilities.TGC.PKeyName + " IS Null";
        }
	    #endregion        

        #region Statement Construction
        public void AddToWhereClause(string aCriteria)
        {
            string lOrgSQL = mStmt;
            string lNewSQL;
            int lWherePos;
            int lOtherPos;
            int[] lOtherPoss = new int[5];

            if (aCriteria != "")
            {
                lWherePos = lOrgSQL.ToUpper().IndexOf(" WHERE ", 0);
                if (lWherePos != -1)
                {
                    lWherePos += 1;
                }
                lOtherPoss[0] = lOrgSQL.ToUpper().IndexOf("ORDER BY", 0);
                lOtherPoss[1] = lOrgSQL.ToUpper().IndexOf("GROUP BY", 0);
                lOtherPoss[2] = lOrgSQL.ToUpper().IndexOf(" HAVING ", 0);
                if (lOtherPoss[2] != -1)
                {
                    lOtherPoss[2] += 1;
                }
                lOtherPoss[3] = lOrgSQL.ToUpper().IndexOf("WITH OWNERACCESS OPTION", 0);
                lOtherPoss[4] = lOrgSQL.IndexOf(';', 0);

                Array.Sort(lOtherPoss);

                lOtherPos = -1;
                for (int i = 0; i <= 4; i++)
                {
                    if (lOtherPoss[i] != -1)
                    {
                        lOtherPos = lOtherPoss[i];
                        break;
                    }
                }
                //   WHERE XXXXXXXXXXXXXXXXXXXXXXXXXXXX ORDER BY
                //   |     |                            |
                //   n     n+6                          m


                //***** Add () to Criteria
                aCriteria = "(" + aCriteria + ")";

                if (lWherePos == -1)
                {
                    aCriteria = " WHERE " + aCriteria;
                    if (lOtherPos == -1)
                    {
                        lNewSQL = lOrgSQL + aCriteria;
                    }
                    else
                    {
                        lNewSQL = lOrgSQL.Substring(0, lOtherPos) + aCriteria + " " + lOrgSQL.Substring(lOtherPos);
                    }

                }
                else
                {
                    // aCriteria = ") AND " & aCriteria
                    if (lOtherPos == -1)
                    {
                        lNewSQL = lOrgSQL.Substring(0, lWherePos + 5 + 1) + "(" + lOrgSQL.Substring(lWherePos + 6) + ") AND " + aCriteria;
                    }
                    else
                    {
                        lNewSQL = lOrgSQL.Substring(0, lWherePos + 5 + 1) + "(" + lOrgSQL.Substring(lWherePos + 6, lOtherPos - (lWherePos + 6)) + ") AND " + aCriteria;
                        lNewSQL = lNewSQL + " " + lOrgSQL.Substring(lOtherPos);
                    }
                }
                mStmt = lNewSQL;
            }
        }

        public void AddToOrderByClause(string aCriteria)
        {
            string lOrgSQL = mStmt;
            string lNewSQL;
            int lOrderByPos;
            int lOtherPos;
            int[] lOtherPoss = new int[2];

            if (aCriteria != "")
            {
                lOrderByPos = lOrgSQL.ToUpper().IndexOf("ORDER BY", 0);
                lOtherPoss[0] = lOrgSQL.ToUpper().IndexOf("WITH OWNERACCESS OPTION", 0);
                lOtherPoss[1] = lOrgSQL.IndexOf(';', 0);

                Array.Sort(lOtherPoss);

                lOtherPos = -1;
                for (int i = 0; i <= 1; i++)
                {
                    if (lOtherPoss[i] != -1)
                    {
                        lOtherPos = lOtherPoss[i];
                        break;
                    }
                }

                if (lOrderByPos == -1)
                {
                    aCriteria = " ORDER BY " + aCriteria;
                    if (lOtherPos == -1)
                    {
                        lNewSQL = lOrgSQL + aCriteria;
                    }
                    else
                    {
                        lNewSQL = lOrgSQL.Substring(0, lOtherPos) + aCriteria + " " + lOrgSQL.Substring(lOtherPos);
                    }

                }
                else
                {
                    // aCriteria = "), " & aCriteria
                    if (lOtherPos == -1)
                    {
                        lNewSQL = lOrgSQL.Substring(0, lOrderByPos + 8 + 1) + "(" + lOrgSQL.Substring(lOrderByPos + 9) + "), " + aCriteria;
                    }
                    else
                    {
                        lNewSQL = lOrgSQL.Substring(0, lOrderByPos + 8 + 1) + "(" + lOrgSQL.Substring(lOrderByPos + 9, lOtherPos - (lOrderByPos + 9)) + "), " + aCriteria;
                        lNewSQL = lNewSQL + " " + lOrgSQL.Substring(lOtherPos);
                    }
                }
                mStmt = lNewSQL;
            }
        }
        #endregion        

        public string GetBetweenDatesStr(DateTime aFromDate, DateTime aToDate)
        {
            string lStartDate = SqlDate(aFromDate);
            string lEndDate = SqlDate(aToDate);
            return "BETWEEN " + lStartDate + " AND " + lEndDate;
        }
        
        #endregion

    }
}