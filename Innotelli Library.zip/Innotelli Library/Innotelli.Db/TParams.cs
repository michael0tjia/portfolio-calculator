using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using Innotelli.Utilities;

namespace Innotelli.Db
{
    public class TParams
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TParams()
        {
        }
        #endregion

        #region Properties
        private DataSet mDs = null;
        public DataSet Ds
        {
            get 
            {
                if (mDs == null)
                {
                    mDs = CreateDs();
                }
                return mDs; 
            }
            set
            {
                mDs = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private DataSet CreateDs()
        {
            DataSet lReturnValue = null;
            DataTable lDt = null;

            lDt = new DataTable();
            lDt.TableName = "Params";
            lDt.Columns.Add("Name", typeof(string));
            lDt.Columns.Add("Value", typeof(object));
            lReturnValue = new DataSet();
            lReturnValue.Tables.Add(lDt);

            return lReturnValue;
        }
        //TODO: Special Handle TDbRowID
        public void AddWithValue(string aName, object aValue)
        {
            DataTable lDt = null;

            lDt = Ds.Tables["Params"];

            //check if Name duplicate
            for (int i = 0; i < lDt.Rows.Count; i++)
            {
                if (lDt.Rows[i]["Name"].ToString() == aName)
                {
                    throw new TDbException("Parameter " + aName + " already exists!");
                }
            }
            if (aValue is TDbRowID)
            {
                if (((TDbRowID)aValue).HasValue)
                {
                    lDt.Rows.Add(aName, ((TDbRowID)aValue).Value);
                }
                else
                {
                    throw new TDbException("TDbRowID Parameter " + aName + " is null!");
                }
            }
            else
            {
                lDt.Rows.Add(aName, aValue);
            }
        }
        public void AddParamsToCmd(DatabaseType aDbType, DbCommand aCmd)
        {
            DataTable lDt = null;

            lDt = Ds.Tables["Params"];
            switch (aDbType)
            {
                case DatabaseType.SqlServer:
                    for (int i = 0; i < lDt.Rows.Count; i++)
                    {
                        ((SqlCommand)aCmd).Parameters.AddWithValue(lDt.Rows[i]["Name"].ToString(), lDt.Rows[i]["Value"]);
                    }
                    break;
                default:
                    for (int i = 0; i < lDt.Rows.Count; i++)
                    {
                        ((OleDbCommand)aCmd).Parameters.AddWithValue(lDt.Rows[i]["Name"].ToString(), lDt.Rows[i]["Value"]);
                    }
                    break;
            }

        }
        public void RemoveAll()
        {
            // Let GC to remove it
            mDs = null;
        }
        #endregion
    }
}

