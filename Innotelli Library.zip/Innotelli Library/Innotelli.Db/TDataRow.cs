﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Innotelli.Utilities;

namespace Innotelli.Db
{
    public class TDataRow
    {
        #region Enums
        #endregion

        #region Structures
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TDataRow(DataRow aDataRow)
        {
            mDataRow = aDataRow;
        }
        #endregion

        #region Properties
        private DataRow mDataRow;
        public DataRow Row
        {
            get 
            {
                return mDataRow;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public static implicit operator TDataRow(DataRow aDataRow)
        {
            return new TDataRow(aDataRow);

        }

        public static implicit operator DataRow(TDataRow aDataRow)
        {
            return aDataRow.mDataRow;
        }
        public object this[int aColumnIndex]
        {
            get
            {
                object lReturnValue = null;

                if (mDataRow[aColumnIndex] is string && mDataRow[aColumnIndex] == DBNull.Value)
                {
                    lReturnValue = string.Empty;
                }
                else if (!(mDataRow[aColumnIndex] is string) && mDataRow[aColumnIndex] == DBNull.Value)
                {
                    lReturnValue = null;
                }
                else
                {
                    lReturnValue = mDataRow[aColumnIndex];
                }

                return lReturnValue;
            }
            set
            {
                if (value == null)
                {
                    mDataRow[aColumnIndex] = DBNull.Value;
                }
                else if (value is string && (string)value == string.Empty)
                {
                    mDataRow[aColumnIndex] = DBNull.Value;
                }
                else if (value is TDbRowID)
                {
                    if (((TDbRowID)value).HasValue)
                    {
                        mDataRow[aColumnIndex] = ((TDbRowID)value).Value;
                    }
                    else
                    {
                        mDataRow[aColumnIndex] = DBNull.Value;                        
                    }
                }
                else
                {
                    mDataRow[aColumnIndex] = value;
                }
            }
        }
        public object this[string aColumnName]
        {
            get
            {
                object lReturnValue = null;

                if (mDataRow.Table.Columns[aColumnName].DataType == typeof(string) && mDataRow[aColumnName] == DBNull.Value)
                {
                    lReturnValue = string.Empty;
                }
                else if (!(mDataRow.Table.Columns[aColumnName].DataType == typeof(string)) && mDataRow[aColumnName] == DBNull.Value)
                {
                    lReturnValue = null;
                }
                else
                {
                    lReturnValue = mDataRow[aColumnName];
                }

                return lReturnValue;
            }
            set
            {
                if (value == null)
                {
                    mDataRow[aColumnName] = DBNull.Value;
                }
                else if (value is string && (string)value == string.Empty)
                {
                    mDataRow[aColumnName] = DBNull.Value;
                }
                else if (value is TDbRowID)
                {
                    if (((TDbRowID)value).HasValue)
                    {
                        mDataRow[aColumnName] = ((TDbRowID)value).Value;
                    }
                    else
                    {
                        mDataRow[aColumnName] = DBNull.Value;                       
                    }                    
                }
                else
                {
                    mDataRow[aColumnName] = value;
                }
            }
        }
        #endregion
    }
}
