using System;
using Innotelli.Utilities;

namespace Innotelli.Db
{
    public class TUtil
    {
        public static string GetNextAutoID(string aTable, string aFld)
        {
            TDataObject lDao = new TDataObject();
            string lNextAutoID;
            string lReturnValue = "<<ERROR>>";

            try
            {
                lDao.SQL.Stmt = "SELECT * FROM " + aTable;
                lDao.MainTable = aTable;
                lDao.OpenTable();
                if (!lDao.IsNoRow())
                {
                    lNextAutoID = lDao.Dr[aFld].ToString();
                    lDao.Dr[aFld] = TMisc.IncrementNumber(lNextAutoID);
                    lDao.UpdateRows();
                    lReturnValue = lNextAutoID;
                }

                return lReturnValue;
            }
            catch
            {
                return "<<ERROR>>";
            }
        }

    }
}
