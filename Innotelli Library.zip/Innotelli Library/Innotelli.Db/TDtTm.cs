using System;

namespace Innotelli.Db
{
    // This is ONLY used for assigning values to DataRow!
    public class TDtTm
    {
        public TDtTm()
        {
        }

        public static object Date(DateTime? aDateTime)
        {
            object lReturnValue = null;

            if (aDateTime == null)
            {
                lReturnValue = DBNull.Value;
            }
            else
            {
                lReturnValue = aDateTime.Value.Date.ToString("yyyy/MM/dd");
            }

            return lReturnValue;
        }

        public static object Time(DateTime? aDateTime)
        {
            object lReturnValue = null;

            if (aDateTime == null)
            {
                lReturnValue = DBNull.Value;
            }
            else
            {
                lReturnValue = SqlTime(aDateTime.Value, TConnectionFactory.GetDbTypeFromConfigFile());
            }

            return lReturnValue;
        }
        private static string SqlTime(DateTime aDateTime, DatabaseType aDBType)
        {
            string lReturnValue = "";

            if (aDBType == DatabaseType.Access)
            {
                lReturnValue = Utilities.TGC.SpecialDate01 + " " + aDateTime.ToString("HH:mm:ss");
            }
            else
            {
                if (aDBType == DatabaseType.SqlServer)
                {
                    lReturnValue = Utilities.TGC.SpecialDate02 + " " + aDateTime.ToString("HH:mm:ss");
                }
                else
                {
                    //To Be Done
                    if (aDBType == DatabaseType.Oracle)
                    {
                        lReturnValue = "TO_DATE('" +
                                aDateTime.Hour + ":" + aDateTime.Minute + ":" + aDateTime.Second + "')";
                    }
                }
            }

            return lReturnValue;
        }

        public static object DateTime(DateTime? aDateTime)
        {
            object lReturnValue = null;

            if (aDateTime == null)
            {
                lReturnValue = DBNull.Value;
            }
            else
            {
                lReturnValue = aDateTime.Value.ToString("yyyy/MM/dd HH:mm:ss");
            }

            return lReturnValue;
        }
    }
}