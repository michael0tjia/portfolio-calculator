using System;
using System.Data;
using System.Data.Common;
using Innotelli.Utilities;

namespace Innotelli.Db
{
    public class TSPrc
    {
        #region Enums
        #endregion

        #region Members
        private TDbObj mDbObj = null;        
        #endregion

        #region Constructors
        public TSPrc()
        {
            mDbObj = TDbObjFactory.CreateDftDbObj();

        }
        public TSPrc(TDbObj aDbObj)
        {
            mDbObj = aDbObj;
        }
        #endregion

        #region Properties
        public string ClassFullName
        {
            get
            {
                return this.GetType().Namespace + "." + this.GetType().Name;
            }
        }
        private string mCmdText = "";
        public string CmdText
        {
            get
            {
                return mCmdText;
            }
            set
            {
                mCmdText = value;
            }
        }
        private CommandType mCmdType = CommandType.StoredProcedure;
        public CommandType CmdType
        {
            get
            {
                return mCmdType;
            }
            set
            {
                mCmdType = value;
            }
        }
        private int mCmdTimeout = 30;
        public int CmdTimeout
        {
            get
            {
                return mCmdTimeout;
            }
            set
            {
                mCmdTimeout = value;
            }
        }
        private TParams mParams = new TParams();
        public TParams Params
        {
            get
            {
                return mParams;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public int ExecuteNonQuery()
        {
            int lReturnValue = 0;
            
            switch (TAppSettings.ClientMode)
            {
                case ClientModes.ThickClient:
                    mDbObj.OpenCnn();
                    DbCommand lCmd = null;
                    lCmd = mDbObj.CreateDbCommand();
                    lCmd.CommandType = mCmdType;
                    lCmd.CommandText = mCmdText;
                    lCmd.CommandTimeout = mCmdTimeout;
                    mParams.AddParamsToCmd(mDbObj.DbType, lCmd);
                    lReturnValue = lCmd.ExecuteNonQuery();
                    mDbObj.CloseCnn();
                    break;
                case ClientModes.ThinClient:
                    TReflectionParams lReflectionParams = new TReflectionParams();

                    lReflectionParams["aCmdText"] = mCmdText;
                    lReflectionParams["aCmdTypeInt"] = (int)mCmdType;
                    lReflectionParams["aCmdTimeout"] = mCmdTimeout;
                    lReflectionParams["aParamsDs"] = mParams.Ds;   //mParams.Ds will always != null
                    lReturnValue = (int)TReflectionClient.ExecuteMethod(ClassFullName, "WSExecuteNonQuery", lReflectionParams);
                    break;

            }
            return lReturnValue;
        }
        public int WSExecuteNonQuery(string aCmdText, int aCmdTypeInt, int aCmdTimeout, DataSet aParamsDs)
        {
            int lReturnValue = 0;

            mDbObj.OpenCnn();
            mCmdText = aCmdText;
            mCmdType = (CommandType)aCmdTypeInt;
            mCmdTimeout = aCmdTimeout;
            mParams.Ds = aParamsDs;
            lReturnValue = ExecuteNonQuery();
            mDbObj.CloseCnn();

            return lReturnValue;
        }
        public object ExecuteScalar()
        {
            object lReturnValue = null;

            switch (TAppSettings.ClientMode)
            {
                case ClientModes.ThickClient:
                    mDbObj.OpenCnn();
                    DbCommand lCmd = null;
                    lCmd = mDbObj.CreateDbCommand();
                    lCmd.CommandType = mCmdType;
                    lCmd.CommandText = mCmdText;
                    mParams.AddParamsToCmd(mDbObj.DbType, lCmd);
                    lReturnValue = lCmd.ExecuteScalar();
                    mDbObj.CloseCnn();
                    break;
                case ClientModes.ThinClient:
                    TReflectionParams lReflectionParams = new TReflectionParams();

                    lReflectionParams["aCmdText"] = mCmdText;
                    lReflectionParams["aCmdTypeInt"] = (int)mCmdType;
                    lReflectionParams["aParamsDs"] = mParams.Ds;   //mParams.Ds will always != null
                    lReturnValue = (int)TReflectionClient.ExecuteMethod(ClassFullName, "WSExecuteScalar", lReflectionParams);
                    break;

            }
            return lReturnValue;
        }
        public object WSExecuteScalar(string aCmdText, int aCmdTypeInt, DataSet aParamsDs)
        {
            object lReturnValue = null;

            mDbObj.OpenCnn();
            mCmdText = aCmdText;
            mCmdType = (CommandType)aCmdTypeInt;
            mParams.Ds = aParamsDs;
            lReturnValue = ExecuteScalar();
            mDbObj.CloseCnn();

            return lReturnValue;
        }
        public bool DeleteRowByPK(string aTable, string aPK)
        {
            bool lReturnValue = false;
            int lRecAffected = 0;

            mCmdType = CommandType.Text;
            mCmdText = "DELETE FROM [" + aTable + "] WHERE " + Utilities.TGC.PKeyName + " = " + aPK + ";";
            lRecAffected = ExecuteNonQuery();

            if (lRecAffected >= 1)
            {
                lReturnValue = true;
            }

            return lReturnValue;
        }
        public bool DeleteRowsByPKList(string aTable, string aPKLst)
        {
            bool lReturnValue = false;
            int lRecAffected = 0;

            mCmdType = CommandType.Text;
            //mCmdText = "DELETE FROM " + aTable + " WHERE " + Utilities.TGC.PKeyName + " = " + aPKLst + ";";
            mCmdText = "DELETE FROM " + aTable + " WHERE " + Utilities.TGC.PKeyName + " IN (" + aPKLst + ")";
            
            lRecAffected = ExecuteNonQuery();

            if (lRecAffected >= 1)
            {
                lReturnValue = true;
            }

            return lReturnValue;
        }
        /// <summary>
        ///  Don't use this, will be deleted
        /// </summary>
        /// <returns></returns>
        public DbDataReader ExecuteReader()
        {
            DbDataReader lReturnValue;
            DbCommand lCmd = null;

            lCmd = mDbObj.CreateDbCommand();
            lCmd.CommandType = mCmdType;
            lCmd.CommandText = mCmdText;
            mParams.AddParamsToCmd(mDbObj.DbType, lCmd);
            lReturnValue = lCmd.ExecuteReader();

            return lReturnValue;
        }
        #endregion
    }
}
