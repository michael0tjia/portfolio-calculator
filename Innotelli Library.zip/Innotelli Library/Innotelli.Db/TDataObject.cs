using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Text;
using Innotelli.Utilities;

namespace Innotelli.Db
{
    public class TDataObject
    {
        #region Enums

        #endregion

        #region Members
        public const string TIMESTAMP_FIELD_NAME = "upsize_ts";
        public const string DefaultMainTableName = "Table";
        public const int BOFRowIndex = -1;
        public const int EOFRowIndex = int.MinValue;
        public const int DetachedRowIndex = int.MinValue + 1;
        private DbCommandBuilder mCb;
        private DbCommand mUpdateCmd = null;
        private DbCommand mInsertCmd = null;
        private DbCommand mDeleteCmd = null;
        #endregion

        #region Constructors
        public TDataObject()
        {
            switch (TAppSettings.ClientMode)
            {
                case ClientModes.ObjectServer:
                case ClientModes.ThickClient:
                    mDbObj = TDbObjFactory.CreateDftDbObj();                    
                    break;
                case ClientModes.ThinClient:
                    break;
                default:
                    throw new Exception("Unknown client mode");
            }
        }
        public TDataObject(TDbObj aDbObj)
        {
            switch (TAppSettings.ClientMode)
            {
                case ClientModes.ObjectServer:
                case ClientModes.ThickClient:
                    mDbObj = aDbObj;
                    break;
                case ClientModes.ThinClient:
                    throw new Exception("ThinClient Mode cannot use this constructor");
                default:
                    throw new Exception("Unknown client mode");
            }
        }
        #endregion

        #region Properties
        public string ClassFullName
        {
            get
            {
                return this.GetType().FullName;
            }
        }
        private TDbObj mDbObj = null;
        public TDbObj DbObj
        {
            get
            {
                return mDbObj;
            }
            set
            {
                mDbObj = value;
            }
        }
        private TSQL mSQL = new TSQL();
        public TSQL SQL
        {
            get
            {
                return mSQL;
            }
        }
        private string mMainTable = DefaultMainTableName;
        public string MainTable
        {
            get
            {
                return mMainTable;
            }
            set
            {
                mMainTable = value;
            }
        }
        private DbDataAdapter mDa = null;
        public DbDataAdapter Da
        {
            get
            {
                if (mDa == null)
                {
                    mDa = mDbObj.CreateDbAdapter();
                }
                return mDa;
            }
        }
        private CommandType mCmdType = CommandType.Text;
        public CommandType CmdType
        {
            get
            {
                return mCmdType;
            }
            set
            {
                mCmdType = value;
            }
        }
        private int mCmdTimeOut = 30;
        public int CmdTimeOut
        {
            get
            {
                return mCmdTimeOut;
            }
            set
            {
                mCmdTimeOut = value;
            }
        }
        private TParams mParams = new TParams();
        public TParams Params
        {
            get
            {
                return mParams;
            }
        }
        private DataTable mDt = null;
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
            set
            {
                if (value == null)
                {
                    mDt = null;
                }
                else if (value.DataSet == null)
                {
                    if (mDt != value)
                    {
                        mDt = value;
                        AssignDataTableEvents();
                        DefaultView.RowStateFilter = DataViewRowState.CurrentRows;
                    }
                }
                else
                {
                    throw new Exception("DataTable must not belong to any DataSet.");
                }
            }
        }
        public DataView DefaultView
        {
            get
            {
                return mDt.DefaultView;
            }
        }
        public string RowFilter
        {
            get
            {
                return DefaultView.RowFilter;
            }
            set
            {
                DefaultView.RowFilter = value;
                MoveFirst();
            }
        }
        public string Sort
        {
            get
            {
                return DefaultView.Sort;
            }
            set
            {
                DefaultView.Sort = value;
                MoveFirst();
            }
        }
        private int mCurrentRowIndex = 0;
        public int CurrentRowIndex
        {
            get
            {
                return mCurrentRowIndex;
            }
            set
            {                
                mCurrentRowIndex = value;
            }
        }
        private TDataRow mDr;
        public TDataRow Dr
        {
            get
            {
                if (mCurrentRowIndex >= 0 && mCurrentRowIndex < DefaultView.Count)
                {
                    mDr = (TDataRow)DefaultView[mCurrentRowIndex].Row;
                    return mDr;
                }
                else
                {
                    return null;
                }
            }
            set
            {
                mDr = value;
            }
        }
        #endregion

        #region Event Handlers
        private void Da_RowUpdated(object sender, OleDbRowUpdatedEventArgs e)
        {
            string lPK = null;
            DbCommand lCmd = null;

            if (e.StatementType == StatementType.Insert)
            {
                lCmd = mDbObj.CreateDbCommand();
                lCmd.CommandText = "Select @@IDENTITY";
                lPK = lCmd.ExecuteScalar().ToString();
                e.Row[Utilities.TGC.PKeyName] = lPK;
            }

        }
        private void Da_RowUpdated(object sender, SqlRowUpdatedEventArgs e)
        {
            string lPK = null;
            DbCommand lCmd = null;

            if (e.StatementType == StatementType.Insert)
            {
                if (Dt.Columns.Contains(Innotelli.Utilities.TGC.PKeyName))
                {
                    lCmd = mDbObj.CreateDbCommand();
                    lCmd.CommandText = "Select @@IDENTITY";
                    lPK = lCmd.ExecuteScalar().ToString();
                    e.Row[Utilities.TGC.PKeyName] = lPK;
                }
            }
        }
        private void Dt_RowDeleted(object sender, DataRowChangeEventArgs e)
        {
            if (IsNoRow())
            {
                mCurrentRowIndex = 0;
            }
            else
            {
                mCurrentRowIndex--;
            }
        }
        #endregion

        #region Functions

        #region CRUD
        public void OpenTable()
        {
            OpenTable(mSQL.Stmt);
        }
        public void OpenTable(string aStmt)
        {
            DbCommand lCmd = null;

            switch (TAppSettings.ClientMode)
            {
                case ClientModes.ThickClient:
                    mDbObj.OpenCnn();

                    mSQL.Stmt = aStmt;

                    //Resetting Update, Insert and Delete Commands
                    mUpdateCmd = null;
                    mInsertCmd = null;
                    mDeleteCmd = null;

                    lCmd = mDbObj.CreateDbCommand();
                    lCmd.CommandText = aStmt;
                    lCmd.CommandType = mCmdType;
                    lCmd.CommandTimeout = mCmdTimeOut;
                    Da.SelectCommand = lCmd;
                    if (mMainTable == DefaultMainTableName)
                    {
                        PrepareCommandBuilder();
                    }

                    mParams.AddParamsToCmd(mDbObj.DbType, lCmd);

                    // Michael at 2007/2/22 for CRM -> SQL Testing
                    //Da.MissingSchemaAction = MissingSchemaAction.AddWithKey;
                    //Da.FillSchema(mDs, SchemaType.Mapped);
                    mDt = new DataTable();
                    try
                    {
                        Da.Fill(mDt);
                    }
                    catch (DbException ex)
                    {
                        TAppLog.LogException(ex);
                        mDbObj.CloseCnn();
                        mDbObj.OpenCnn();
                        Da.Fill(mDt);
                    }
                    finally
                    {
                        mDt.TableName = mMainTable;
                        AssignDataTableEvents();
                        mDt.DefaultView.RowStateFilter = DataViewRowState.CurrentRows;
                        MoveFirst();
                        mDbObj.CloseCnn();
                    }
                    break;
                case ClientModes.ThinClient:
                    DataSet lDs = null;
                    TReflectionParams lReflectionParams = new TReflectionParams();

                    lReflectionParams["aSQLStmt"] = aStmt;
                    lReflectionParams["aMainTable"] = mMainTable;
                    lReflectionParams["aCmdTypeInt"] = (int)mCmdType;
                    lReflectionParams["aParamsDs"] = mParams.Ds;   //mParams.Ds will always != null
                    lDs = (DataSet)TReflectionClient.ExecuteMethod(ClassFullName, "WSGetDataSet", lReflectionParams);
                    // check null
                    mDt = lDs.Tables[0];
                    lDs.Tables.Remove(mDt);
                    mDt.TableName = mMainTable;
                    AssignDataTableEvents();
                    mDt.DefaultView.RowStateFilter = DataViewRowState.CurrentRows;
                    MoveFirst();
                    break;
                default:
                    throw new Exception("Unknown client mode");
            }
            mParams.RemoveAll();
        }
        public DataSet WSGetDataSet(string aSQLStmt, string aMainTable, int aCmdTypeInt, DataSet aParamsDs)
        {
            DataSet lReturnValue = new DataSet();
            DbCommand lCmd = null;

            mDbObj.OpenCnn();
            mSQL.Stmt = aSQLStmt;
            mMainTable = aMainTable;
            mCmdType = (CommandType)aCmdTypeInt;
            mParams.Ds = aParamsDs;

            lCmd = mDbObj.CreateDbCommand();
            lCmd.CommandText = aSQLStmt;
            lCmd.CommandType = mCmdType;
            Da.SelectCommand = lCmd;

            mParams.AddParamsToCmd(mDbObj.DbType, lCmd);

            Da.Fill(lReturnValue);
            mDbObj.CloseCnn();

            return lReturnValue;
        }
        // TODO
        // Current Row Index Maintenance difficult to handle
        public void UpdateRows()
        {
            DataSet lDs = new DataSet();
            //DataSet lDsChanges = null;

            switch (TAppSettings.ClientMode)
            {
                case ClientModes.ThickClient:
                    mDbObj.OpenCnn();
                    AssignDataAdapterEvents();
                    if (mMainTable != DefaultMainTableName)
                    {
                        // Join Table with the same attribute name is not supported.
                        // Update Command will not be set again if original select statement is unchanged.
                        SetUpdateCmd();
                        SetInsertCmd();
                        SetDeleteCmd();
                        Da.UpdateCommand = mUpdateCmd;
                        Da.InsertCommand = mInsertCmd;
                        Da.DeleteCommand = mDeleteCmd;
                    }

                    Da.Update(mDt);
                    mDbObj.CloseCnn();
                    break;
                case ClientModes.ThinClient:
                    TReflectionParams lReflectionParams = new TReflectionParams();

                    lDs.Tables.Add(mDt);
                    //lDsChanges = lDs.GetChanges();
                    //if (lDsChanges != null)
                    //{
                        //lReflectionParams["aDs"] = lDs.GetChanges();
                        lReflectionParams["aDs"] = lDs;
                        lReflectionParams["aMainTable"] = mMainTable;
                        try
                        {
                            lDs = (DataSet)TReflectionClient.ExecuteMethod(ClassFullName, "WSGetUpdatedDataSet", lReflectionParams, 5 * 60 * 1000);
                            mDt = lDs.Tables[0];
                        }
                        finally
                        {
                            lDs.Tables.Remove(mDt);
                        }
                    //}
                    break;
                default:
                    throw new Exception("Unknown client mode");
            }
        }
        public DataSet WSGetUpdatedDataSet(DataSet aDs, string aMainTable)
        {
            DataSet lReturnValue = null;

            mDbObj.OpenCnn();
            AssignDataAdapterEvents();
            mMainTable = aMainTable;
            mDt = aDs.Tables[0];
            aDs.Tables.Remove(mDt);

            Da.TableMappings.Clear();
            Da.TableMappings.Add("Table", mDt.TableName);

            if (mMainTable != DefaultMainTableName)
            {
                // Join Table with the same attribute name is not supported.
                // Update Command will not be set again if original select statement is unchanged.
                SetUpdateCmd();
                SetInsertCmd();
                SetDeleteCmd();
                Da.UpdateCommand = mUpdateCmd;
                Da.InsertCommand = mInsertCmd;
                Da.DeleteCommand = mDeleteCmd;
            }
            Da.Update(mDt);
            mDbObj.CloseCnn();
            aDs.Tables.Add(mDt);
            lReturnValue = aDs;

            return lReturnValue;
        }
        // Both Client Modes
        public void AddNewRow()
        {
            DataRow lDr = null;

            lDr = mDt.NewRow();
            mDt.Rows.Add(lDr);
            mCurrentRowIndex = DefaultView.Count - 1;
        }
        #endregion

        #region Record Navigation
        public bool EOF()
        {
            return (mCurrentRowIndex == EOFRowIndex);
        }
        public bool BOF()
        {
            return (mCurrentRowIndex == BOFRowIndex);
        }
        public bool IsNoRow()
        {
            return (DefaultView.Count == 0);
        }
        public void MoveFirst()
        {
            mCurrentRowIndex = 0;
        }
        public void MovePrevious()
        {
            if (mCurrentRowIndex > 0)
            {
                mCurrentRowIndex--;
            }
            else
            {
                mCurrentRowIndex = BOFRowIndex;
            }
        }
        public void MoveNext()
        {
            if (mCurrentRowIndex < DefaultView.Count - 1)
            {
                mCurrentRowIndex++;
            }
            else
            {
                mCurrentRowIndex = EOFRowIndex;
            }
        }
        public void MoveLast()
        {
            mCurrentRowIndex = DefaultView.Count - 1;
        }

        #endregion

        #region Generate Update, Insert, Delete SQL Commands
        public bool IsVirtualColumn(DataColumn aDc)
        {
            bool lReturnValue = false;

            if (aDc.ExtendedProperties.Contains("ISVIRTUALKEY") && (bool)aDc.ExtendedProperties["ISVIRTUALKEY"])
            {
                lReturnValue = true;
            }

            return lReturnValue;
        }
        public void SetUpdateCmd()
        {
            TDbObj lDbObj = null;
            TDataObject lDao = null;
            IDbDataParameter lParam = null;
            DataColumn lDc = null;
            string lNameValuePairs = "";

            if (mUpdateCmd == null)
            {
                mUpdateCmd = mDbObj.CreateDbCommand();

                lDbObj = TDbObjFactory.CreateDbObj(mDbObj.CnnStr);                
                lDao = new TDataObject(lDbObj);
                lDao.SQL.Stmt = "SELECT * FROM [" + mMainTable + "] WHERE " + Utilities.TGC.PKeyName + " IS NULL";
                lDao.OpenTable();
                lDbObj.CloseCnn();

                for (int i = 0; i < lDao.Dt.Columns.Count; i++)
                {
                    lDc = lDao.Dt.Columns[i];
                    if (lDc.ColumnName != Utilities.TGC.PKeyName && lDc.ColumnName != Innotelli.Utilities.TGC.TIMESTAMP_FIELD_NAME && !IsVirtualColumn(lDc))
                    {
                        for (int j = 0; j < Dt.Columns.Count; j++)
                        {
                            if (lDc.ColumnName == Dt.Columns[j].ColumnName)
                            {
                                lNameValuePairs = lNameValuePairs + "[" + lDc.ColumnName + "] = @" + lDc.ColumnName + ", ";
                                lParam = mUpdateCmd.CreateParameter();
                                lParam.ParameterName = "@" + lDc.ColumnName;
                                lParam.SourceColumn = lDc.ColumnName;
                                mUpdateCmd.Parameters.Add(lParam);
                                break;
                            }
                        }
                    }
                }
                lNameValuePairs = lNameValuePairs.Substring(0, lNameValuePairs.Length - 2);
                lParam = mUpdateCmd.CreateParameter();
                lParam.ParameterName = "@" + Utilities.TGC.PKeyName;
                lParam.SourceColumn = Utilities.TGC.PKeyName;
                mUpdateCmd.Parameters.Add(lParam);
                mUpdateCmd.CommandText = "UPDATE [" + mMainTable + "] SET " + lNameValuePairs + " WHERE [" + Utilities.TGC.PKeyName + "] = @" + Utilities.TGC.PKeyName;                
            }
        }
        public void SetInsertCmd()
        {
            TDbObj lDbObj = null;
            TDataObject lDao = null;
            IDbDataParameter lParam = null;
            DataColumn lDc = null;
            string lFieldNames = "";
            string lFieldValues = "";

            if (mInsertCmd == null)
            {
                mInsertCmd = mDbObj.CreateDbCommand();

                lDbObj = TDbObjFactory.CreateDbObj(mDbObj.CnnStr);
                lDbObj.OpenCnn();
                lDao = new TDataObject(lDbObj);
                lDao.SQL.Stmt = "SELECT * FROM [" + mMainTable + "] WHERE " + Utilities.TGC.PKeyName + " IS NULL";
                lDao.OpenTable();
                lDbObj.CloseCnn();

                for (int i = 0; i < lDao.Dt.Columns.Count; i++)
                {
                    lDc = lDao.Dt.Columns[i];

                    if (lDc.ColumnName != Utilities.TGC.PKeyName && lDc.ColumnName != Innotelli.Utilities.TGC.TIMESTAMP_FIELD_NAME && !IsVirtualColumn(lDc))
                    {
                        for (int j = 0; j < Dt.Columns.Count; j++)
                        {
                            if (lDc.ColumnName == Dt.Columns[j].ColumnName)
                            {
                                lFieldNames = lFieldNames + "[" + lDao.Dt.Columns[i].ColumnName + "]" + ", ";
                                lFieldValues = lFieldValues + "@" + lDao.Dt.Columns[i].ColumnName + ", ";
                                lParam = mInsertCmd.CreateParameter();
                                lParam.ParameterName = "@" + lDc.ColumnName;
                                lParam.SourceColumn = lDc.ColumnName;
                                mInsertCmd.Parameters.Add(lParam);
                                break;
                            }
                        }
                    }
                }
                lFieldNames = lFieldNames.Substring(0, lFieldNames.Length - 2);
                lFieldValues = lFieldValues.Substring(0, lFieldValues.Length - 2);
                mInsertCmd.CommandText = "INSERT INTO [" + mMainTable + "] (" + lFieldNames + ")" + " VALUES (" + lFieldValues + ")";                
            }
        }
        public void SetDeleteCmd()
        {
            IDbDataParameter lParam = null;

            if (mDeleteCmd == null)
            {
                mDeleteCmd = mDbObj.CreateDbCommand();
                lParam = mDeleteCmd.CreateParameter();

                lParam.ParameterName = "@" + Utilities.TGC.PKeyName;
                lParam.SourceColumn = Utilities.TGC.PKeyName;
                mDeleteCmd.Parameters.Add(lParam);
                mDeleteCmd.CommandText = "DELETE FROM [" + mMainTable + "] WHERE " + Utilities.TGC.PKeyName + " = " + "@" + Utilities.TGC.PKeyName;
            }
        }
        #endregion

        #region Others
        private void AssignDataAdapterEvents()
        {
            switch (mDbObj.DbType)
            {
                case DatabaseType.Access:
                    ((OleDbDataAdapter)Da).RowUpdated += new OleDbRowUpdatedEventHandler(Da_RowUpdated);
                    break;
                case DatabaseType.SqlServer:
                    ((SqlDataAdapter)Da).RowUpdated += new SqlRowUpdatedEventHandler(Da_RowUpdated);
                    break;
            }
        }
        private void AssignDataTableEvents()
        {
            Dt.RowDeleted += new DataRowChangeEventHandler(Dt_RowDeleted);
        }
        public void PrepareCommandBuilder()
        {
            mCb = CreateCommandBuilder();
        }
        public DbCommandBuilder CreateCommandBuilder()
        {
            DbCommandBuilder lReturnValue;

            switch (mDbObj.DbType)
            {
                case DatabaseType.SqlServer:
                    lReturnValue = (DbCommandBuilder)new SqlCommandBuilder((SqlDataAdapter)Da);
                    break;
                default:
                    lReturnValue = (DbCommandBuilder)new OleDbCommandBuilder((OleDbDataAdapter)Da);
                    break;
            }

            return lReturnValue;
        }
        #endregion

        #region Backup
        #endregion

        #endregion
    }

}