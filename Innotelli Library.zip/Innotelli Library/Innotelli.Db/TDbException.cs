﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Db
{
    public class TDbException : Exception
    {
        public TDbException(string message) : base(message)
        {
        }
    }
}
