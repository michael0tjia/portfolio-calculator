using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Text;

namespace Innotelli.Db
{
    public class TDbObj
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TDbObj(string aCnnStr)
        {
            if (aCnnStr != null)
            {
                mCnnStr = aCnnStr;
            }
        }
        #endregion

        #region Properties
        private string mCnnStr = "";
        public string CnnStr
        {
            get
            {
                return mCnnStr;
            }
            set
            {
                mCnnStr = value;
            }
        }
        private DbConnection mCnn;
        public DbConnection Cnn
        {
            get
            {
                return mCnn;
            }
        }
        private DbTransaction mTrans;
        public DbTransaction Trans
        {
            get
            {
                return mTrans;
            }
            set
            {
                mTrans = value;
            }
        }
        public DatabaseType DbType
        {
            get
            {
                if (mCnn != null)
                {
                    return GetDbType(mCnn);
                }
                else
                {
                    return DatabaseType.Unknown;
                }
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions

        #region Database Type
        public DatabaseType GetDbType(DbConnection aCnn)
        {
            DatabaseType lReturnValue = DatabaseType.Unknown;
            string lCnnType = aCnn.GetType().ToString();
            
            switch (lCnnType)
            {
                case "System.Data.SqlClient.SqlConnection":
                    lReturnValue = DatabaseType.SqlServer;
                    break;
                case "System.Data.OleDb.OleDbConnection":
                    lReturnValue = DatabaseType.Access;
                    break;
            }            
            return lReturnValue;
        } 
        #endregion

        #region Create ADO.NET Objects
        public DbDataAdapter CreateDbAdapter()
        {
            DbDataAdapter lReturnValue = null;

            switch (DbType)
            {
                case DatabaseType.SqlServer:
                    lReturnValue = (DbDataAdapter)new SqlDataAdapter();
                    break;

                default:
                    lReturnValue = (DbDataAdapter)new OleDbDataAdapter();
                    break;
            }

            return lReturnValue;
        }
        public DbCommand CreateDbCommand()
        {
            DbCommand lReturnValue;

            switch (DbType)
            {
                case DatabaseType.SqlServer:
                    lReturnValue = (DbCommand)new SqlCommand();
                    break;

                default:
                    lReturnValue = (DbCommand)new OleDbCommand();
                    break;
            }

            lReturnValue.Connection = mCnn;
            lReturnValue.CommandType = CommandType.Text;
            if (Trans != null)
            {
                lReturnValue.Transaction = Trans;
            }

            return lReturnValue;
        }
        #endregion

        #region Connection
        public void OpenCnn()
        {
            if (mCnn == null)
            {
                mCnn = TConnectionFactory.CreateCnn(mCnnStr);
            }
            if (mCnn.State == ConnectionState.Closed)
            {
                mCnn.Open();
            }
        }
        public void CloseCnn()
        {
            // Close connection will not destroy the connection object            
            if ((mCnn != null) && (Innotelli.Utilities.TAppSettings.DftCnnMode == Innotelli.Utilities.DftCnnModes.OnePerDataObject))
            {
                if (mCnn.State == ConnectionState.Open)
                {
                    mCnn.Close();
                }
            }
        } 
        #endregion

        #region Transaction
        public void BeginTrans()
        {
            if (Trans == null)
            {
                Trans = Cnn.BeginTransaction();
            }
        }
        public void Commit()
        {
            if (Trans != null)
            {
                Trans.Commit();
                Trans = null;
            }
        }
        public void RollBack()
        {

            if (Trans != null)
            {
                Trans.Rollback();
                Trans = null;
            }
        }
        #endregion        

        #endregion
    }
}