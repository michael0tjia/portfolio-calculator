using System;
using Innotelli.Utilities;

namespace Innotelli.Db
{
    public static class TDbObjFactory
    {
        #region Enums
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public static TDbObj CreateDftDbObj()
        {
            TDbObj lReturnValue = null;

            if (TAppSettings.DftCnnMode == DftCnnModes.OnePerDataObject)
            {
                lReturnValue = new TDbObj(TAppSettings.DftCnnStr);
            }
            else
            {
                lReturnValue = TSingletons.DbObj;
            }

            return lReturnValue;
        }
        public static TDbObj CreateDbObj(string aCnnStr)
        {
            TDbObj lReturnValue = null;

            lReturnValue = new TDbObj(aCnnStr);

            return lReturnValue;
        }
        #endregion

    }
}
