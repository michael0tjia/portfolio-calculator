using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Text;

namespace Innotelli.Db
{
    public enum DatabaseType
    {
        Access,
        SqlServer,
        Oracle,
        Unknown,
    }

    public static class TConnectionFactory
    {
        #region Enums
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public static DbConnection CreateCnn(string aCnnStr)
        {
            DbConnection lReturnValue = null;
            DatabaseType lDbType = GetDbTypeFromConfigFile();

            if (string.IsNullOrEmpty(aCnnStr))
            {
                throw new Exception("Connection string cannot be null or empty!");
            }
            else
            {
                switch (lDbType)
                {
                    case DatabaseType.Access:
                        lReturnValue = (DbConnection)new OleDbConnection(aCnnStr);
                        break;
                    case DatabaseType.SqlServer:
                        lReturnValue = (DbConnection)new SqlConnection(aCnnStr);
                        break;
                }
            }

            return lReturnValue;
        }
        public static DatabaseType GetDbTypeFromConfigFile()
        {
            DatabaseType lReturnValue = DatabaseType.Access;
            string lDbTypeSetting = ConfigurationManager.AppSettings["DatabaseType"];

            if (lDbTypeSetting == null)
            {
                lReturnValue = DatabaseType.Access;
            }
            else
            {
                switch (lDbTypeSetting)
                {
                    case "1":
                        lReturnValue = DatabaseType.Access;
                        break;
                    case "2":
                        lReturnValue = DatabaseType.SqlServer;
                        break;
                    case "3":
                        lReturnValue = DatabaseType.Oracle;
                        break;
                    default:
                        lReturnValue = DatabaseType.Unknown;
                        break;
                }
            }

            return lReturnValue;
        }
        #endregion

    }
}
