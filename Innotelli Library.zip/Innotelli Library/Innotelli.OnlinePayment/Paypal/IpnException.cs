﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Innotelli.OnlinePayment.Paypal
{
    public class IpnException : Exception
    {
        public IpnException():base()
        {

        }

        public IpnException(string message)
            : base(message)
        {

        }
    }
}
