﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Innotelli.OnlinePayment.Paypal
{
    public static class IpnVariables
    {
        public static string FirstName = "first_name";
        public static string ItemName = "item_name";
        public static string ItemNumber = "item_number";
        public static string LastName = "last_name";
        public static string Currency = "mc_currency";
        public static string Gross = "mc_gross";
        public static string PayerEmail = "payer_email";
        public static string PayerId = "payer_id";
        public static string PayerStatus = "payer_status";
        public static string PaymentDate = "payment_date";
        public static string PaymentStatus = "payment_status";
        public static string PaymentType = "payment_type";
        public static string PendingReason = "pending_reason";
        public static string Quantity = "quantity";
        public static string ReceiverEmail = "receiver_email";
        public static string ReceiverId = "receiver_id";
        public static string TestIpn = "test_ipn";
        public static string TxnId = "txn_id";
        public static string TxnType = "txn_type";
        public static string TxnFee = "mc_fee";
    }
}
