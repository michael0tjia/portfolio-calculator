﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Services;
using System.Configuration;
using System.Web;
using System.Net;
using System.IO;
using System.Collections.Specialized;
using System.Data.Linq;
using System.Diagnostics;

namespace Innotelli.OnlinePayment.Paypal
{
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    public class IpnHandler : IHttpHandler
    {
        private readonly string mAuthorizeToken = ConfigurationManager.AppSettings["authToken"];
        private string txToken;

        
        public void ProcessRequest(HttpContext context)
        {
            HttpRequest request = context.Request;
            string lPaypalUrl = ConfigurationManager.AppSettings[ConfigurationManager.AppSettings["PaypalMode"]];
            PaypalDataContext lDb;
            HttpWebRequest req = (HttpWebRequest)WebRequest.Create(lPaypalUrl);

            //Set values for the request back
            req.Method = "POST";
            req.ContentType = "application/x-www-form-urlencoded";
            byte[] param = context.Request.BinaryRead(HttpContext.Current.Request.ContentLength);
            string strRequest = Encoding.ASCII.GetString(param);
            strRequest += "&cmd=_notify-validate";
            req.ContentLength = strRequest.Length;
            StreamWriter streamOut = new StreamWriter(req.GetRequestStream(), System.Text.Encoding.ASCII);
            streamOut.Write(strRequest);
            streamOut.Close();
            StreamReader streamIn = new StreamReader(req.GetResponse().GetResponseStream());
            string strResponse = streamIn.ReadToEnd();
            streamIn.Close();
            NameValueCollection lParams = request.Params;

            if (strResponse == "VERIFIED")
            {
                lDb = new PaypalDataContext();
                Payment payment = new Payment();
                payment.Amount = Convert.ToDecimal(lParams[IpnVariables.Gross]);
                payment.Currency = lDb.Currencies.Single(i=>i.Code == lParams[IpnVariables.Currency]);
                payment.IsValid = true;
                payment.NotifiedDate = DateTime.Now;
                payment.PayerEmail = lParams[IpnVariables.PayerEmail];
                payment.PaymentDate = Convert.ToDateTime(lParams[IpnVariables.PaymentDate]);
                payment.PaymentStatus = lDb.PaymentStatus.Single(i => i.Name == lParams[IpnVariables.PaymentStatus]);
                payment.PendingReason1 = lDb.PendingReasons.Single(i => i.Reason == lParams[IpnVariables.PendingReason]);
                payment.Product = lDb.Products.Single(i => i.ProductCode == lParams[IpnVariables.ItemNumber]);
                payment.ReceiverEmail = lParams[IpnVariables.ReceiverEmail];
                payment.TxnFee = Convert.ToDecimal(lParams[IpnVariables.TxnFee]);
                payment.TxnId = lParams[IpnVariables.TxnId];
                payment.TxnType = lDb.TxnTypes.Single(i => i.Name == lParams[IpnVariables.TxnType]);
                //check the payment_status is Completed
                if (payment.PaymentStatus.Name == "Completed")
                {
                    //check that txn_id has not been previously processed
                    if (!lDb.Payments.Any(i => i.TxnId == payment.TxnId))
                    {
                        //check that receiver_email is your Primary PayPal email
                        if (payment.ReceiverEmail == ConfigurationManager.AppSettings["PrimaryPaypalEmail"])
                        {
                            //check that payment_amount/payment_currency are correct
                            if (payment.Amount == payment.Product.Price && payment.Currency.Code == payment.Product.Currency)
                            {
                                
                            }
                        }
                        
                    }
                }
            }
            else if (strResponse == "INVALID")
            {
                Trace.Write("Invalid response found: " + strRequest + Environment.NewLine);
            }
            else
            {
                //log response/ipn data for manual investigation
                Trace.Write("Invalid data format: " + strRequest + Environment.NewLine);
            }
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}
