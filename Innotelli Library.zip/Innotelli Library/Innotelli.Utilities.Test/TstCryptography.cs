using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Innotelli.Utilities.Tester
{
    public partial class TstCryptography : Form
    {
        public TstCryptography()
        {
            InitializeComponent();
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            TCryptography lCryptography = new TCryptography();
            if (txtKEY64.Text != "")
            {
                lCryptography.RGBKey = txtKEY64.Text;
            }
            if (txtIV64.Text != "")
            {
                lCryptography.RGBIV = txtIV64.Text;
            }
            if (txtEncryptSource.Text != "")
            {
                txtEncryptResult.Text = lCryptography.Encrypt(txtEncryptSource.Text);
                txtDecryptResult.Text = lCryptography.Decrypt(txtEncryptResult.Text);
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtEncryptResult.Text = "";
            txtDecryptResult.Text = "";
            txtEncryptSource.Text = "";
            txtKEY64.Text = "";
            txtIV64.Text = "";
            txtEncryptResult.Focus();
        }
    }
}