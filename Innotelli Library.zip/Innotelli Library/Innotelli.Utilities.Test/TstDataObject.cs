using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.Utilities.Tester
{
    public partial class TstDataObject : Form
    {
        public TstDataObject()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TDataObject lDao = new TDataObject();

            //lDao.SQL.Stmt = "SELECT prmykey, TblNm, RowPK, TmStmp FROM RowLock";
            //for (int i = 0; i < 1000; i++)
            //{
                lDao.SQL.Stmt = "SELECT * FROM RowLock";
                lDao.OpenTable();
                lDao.MoveFirst();
                lDao.Dr["RowPK"] = 99;
                lDao.Dr["TmStmp"] = TDtTm.DateTime(DateTime.Now);
                lDao.AddNewRow();
                lDao.Dr["TblNm"] = "Test";
                lDao.Dr["RowPK"] = 1;
                lDao.Dr["TmStmp"] = TDtTm.DateTime(DateTime.Now);
                lDao.Dr["InEdit"] = false;
                lDao.AddNewRow();
                lDao.Dr["TblNm"] = "Test";
                lDao.Dr["RowPK"] = 2;
                lDao.Dr["TmStmp"] = TDtTm.DateTime(DateTime.Now);
                lDao.Dr["InEdit"] = false;
                lDao.AddNewRow();
                lDao.Dr["TblNm"] = "Test";
                lDao.Dr["RowPK"] = 3;
                lDao.Dr["TmStmp"] = TDtTm.DateTime(DateTime.Now);
                lDao.Dr["InEdit"] = false;
                lDao.UpdateRows();            

            //}
        }
    }
}