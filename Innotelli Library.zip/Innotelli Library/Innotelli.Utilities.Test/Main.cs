using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Innotelli.Utilities.Tester
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void btnTRoute_Click(object sender, EventArgs e)
        {
            TstRoute lTstRoute = new TstRoute();
            lTstRoute.Show();
        }

        private void btnTCryptography_Click(object sender, EventArgs e)
        {
            TstCryptography lTstCryptography = new TstCryptography();
            lTstCryptography.Show();
        }

        private void btnTDomain_Click(object sender, EventArgs e)
        {

        }
    }
}