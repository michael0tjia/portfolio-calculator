using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Configuration;

namespace Innotelli.Utilities.Tester
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Innotelli.Utilities.TGC.IsRunTime = true;
            if (ConfigurationManager.ConnectionStrings["abcDataConnectionString"] != null)
            {
                ConfigurationManager.AppSettings["DftCnnStr"] = ConfigurationManager.ConnectionStrings["abcDataConnectionString"].ConnectionString;
            }
            Innotelli.Db.TSingletons.InitDbObj();

            //Application.Run(new TstCustomControl());
            Application.Run(new TstDataObject());
        }
    }
}