using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Web;

namespace Innotelli.Utilities.Tester
{
    public partial class TstRoute : Form
    {

        public TstRoute()
        {
            InitializeComponent();
        }

        private void btnProcess_Click(object sender, EventArgs e)
        {
            TRoute lRoute = new TRoute();

            lRoute.Info = Decode(txtInfo.Text);
            txtBackwardUrl.Text = lRoute.BackwardUrl;
            lRoute.SetNewInfo(lRoute.BackwardUrl, lRoute.Info);

            txtUrlEncodedInfo.Text = lRoute.UrlEncodedInfo;
            txtDecryptUrlEncode.Text = DecodeWithDecrypt(txtUrlEncodedInfo.Text);
            txtDecryptInfo.Text = Decrypt(Decode(txtInfo.Text));
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtBackwardUrl.Text = "";
            txtUrlEncodedInfo.Text = "";
            txtDecryptUrlEncode.Text = "";
            txtDecryptInfo.Text = "";
            txtInfo.Text = "";
            txtInfo.Focus();
        }

        public string Decrypt(string aValue)
        {
            TCryptography lCryptography = new TCryptography();
            return lCryptography.Decrypt(aValue);
        }

        public string DecodeWithDecrypt(string aValue)
        {
            TCryptography lCryptography = new TCryptography();
            return lCryptography.Decrypt(HttpUtility.UrlDecode(aValue));
        }

        public string Decode(string aValue)
        {
            int lStart = (aValue.IndexOf("Route=")) + 6;
            string lStr = aValue.Substring(lStart);
            int lEnd = lStr.IndexOf("&");
            if (lEnd != -1)
            {
                aValue = aValue.Substring(lStart, lEnd);
            }
            else
            {
                aValue = aValue.Substring(lStart);
            }

            return HttpUtility.UrlDecode(aValue);
        }
    }
}