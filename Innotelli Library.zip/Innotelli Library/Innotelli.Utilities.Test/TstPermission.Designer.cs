namespace Innotelli.Utilities.Tester
{
    partial class TstPermission
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReport_AllowRead = new System.Windows.Forms.Button();
            this.btnBO_AllowRead = new System.Windows.Forms.Button();
            this.btnBO_AllowAdd = new System.Windows.Forms.Button();
            this.btnBO_AllowWrite = new System.Windows.Forms.Button();
            this.btnPerformSpecificAction = new System.Windows.Forms.Button();
            this.btnBO_AllowDelete = new System.Windows.Forms.Button();
            this.lblReport_AllowRead = new System.Windows.Forms.Label();
            this.lblBO_AllowRead = new System.Windows.Forms.Label();
            this.lblBO_AllowAdd = new System.Windows.Forms.Label();
            this.lblBO_AllowWrite = new System.Windows.Forms.Label();
            this.lblPerformSpecificAction = new System.Windows.Forms.Label();
            this.lblBO_AllowDelete = new System.Windows.Forms.Label();
            this.txtUsrID = new System.Windows.Forms.TextBox();
            this.lblUsrID = new System.Windows.Forms.Label();
            this.lblActnTrgt = new System.Windows.Forms.Label();
            this.txtActnTrgt = new System.Windows.Forms.TextBox();
            this.lblBO_AllowUnPost = new System.Windows.Forms.Label();
            this.lblBO_AllowPost = new System.Windows.Forms.Label();
            this.btnBO_AllowUnPost = new System.Windows.Forms.Button();
            this.btnBO_AllowPost = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnReport_AllowRead
            // 
            this.btnReport_AllowRead.Location = new System.Drawing.Point(15, 90);
            this.btnReport_AllowRead.Name = "btnReport_AllowRead";
            this.btnReport_AllowRead.Size = new System.Drawing.Size(150, 23);
            this.btnReport_AllowRead.TabIndex = 0;
            this.btnReport_AllowRead.Text = "Report_AllowRead";
            this.btnReport_AllowRead.UseVisualStyleBackColor = true;
            this.btnReport_AllowRead.Click += new System.EventHandler(this.btnReport_AllowRead_Click);
            // 
            // btnBO_AllowRead
            // 
            this.btnBO_AllowRead.Location = new System.Drawing.Point(15, 119);
            this.btnBO_AllowRead.Name = "btnBO_AllowRead";
            this.btnBO_AllowRead.Size = new System.Drawing.Size(150, 23);
            this.btnBO_AllowRead.TabIndex = 1;
            this.btnBO_AllowRead.Text = "BO_AllowRead";
            this.btnBO_AllowRead.UseVisualStyleBackColor = true;
            this.btnBO_AllowRead.Click += new System.EventHandler(this.btnBO_AllowRead_Click);
            // 
            // btnBO_AllowAdd
            // 
            this.btnBO_AllowAdd.Location = new System.Drawing.Point(15, 177);
            this.btnBO_AllowAdd.Name = "btnBO_AllowAdd";
            this.btnBO_AllowAdd.Size = new System.Drawing.Size(150, 23);
            this.btnBO_AllowAdd.TabIndex = 3;
            this.btnBO_AllowAdd.Text = "BO_AllowAdd";
            this.btnBO_AllowAdd.UseVisualStyleBackColor = true;
            this.btnBO_AllowAdd.Click += new System.EventHandler(this.btnBO_AllowAdd_Click);
            // 
            // btnBO_AllowWrite
            // 
            this.btnBO_AllowWrite.Location = new System.Drawing.Point(15, 148);
            this.btnBO_AllowWrite.Name = "btnBO_AllowWrite";
            this.btnBO_AllowWrite.Size = new System.Drawing.Size(150, 23);
            this.btnBO_AllowWrite.TabIndex = 2;
            this.btnBO_AllowWrite.Text = "BO_AllowWrite";
            this.btnBO_AllowWrite.UseVisualStyleBackColor = true;
            this.btnBO_AllowWrite.Click += new System.EventHandler(this.btnBO_AllowWrite_Click);
            // 
            // btnPerformSpecificAction
            // 
            this.btnPerformSpecificAction.Location = new System.Drawing.Point(14, 293);
            this.btnPerformSpecificAction.Name = "btnPerformSpecificAction";
            this.btnPerformSpecificAction.Size = new System.Drawing.Size(150, 23);
            this.btnPerformSpecificAction.TabIndex = 5;
            this.btnPerformSpecificAction.Text = "PerformSpecificAction";
            this.btnPerformSpecificAction.UseVisualStyleBackColor = true;
            this.btnPerformSpecificAction.Click += new System.EventHandler(this.btnPerformSpecificAction_Click);
            // 
            // btnBO_AllowDelete
            // 
            this.btnBO_AllowDelete.Location = new System.Drawing.Point(14, 206);
            this.btnBO_AllowDelete.Name = "btnBO_AllowDelete";
            this.btnBO_AllowDelete.Size = new System.Drawing.Size(150, 23);
            this.btnBO_AllowDelete.TabIndex = 4;
            this.btnBO_AllowDelete.Text = "BO_AllowDelete";
            this.btnBO_AllowDelete.UseVisualStyleBackColor = true;
            this.btnBO_AllowDelete.Click += new System.EventHandler(this.btnBO_AllowDelete_Click);
            // 
            // lblReport_AllowRead
            // 
            this.lblReport_AllowRead.AutoSize = true;
            this.lblReport_AllowRead.Location = new System.Drawing.Point(171, 95);
            this.lblReport_AllowRead.Name = "lblReport_AllowRead";
            this.lblReport_AllowRead.Size = new System.Drawing.Size(96, 13);
            this.lblReport_AllowRead.TabIndex = 6;
            this.lblReport_AllowRead.Text = "Report_AllowRead";
            // 
            // lblBO_AllowRead
            // 
            this.lblBO_AllowRead.AutoSize = true;
            this.lblBO_AllowRead.Location = new System.Drawing.Point(171, 124);
            this.lblBO_AllowRead.Name = "lblBO_AllowRead";
            this.lblBO_AllowRead.Size = new System.Drawing.Size(79, 13);
            this.lblBO_AllowRead.TabIndex = 7;
            this.lblBO_AllowRead.Text = "BO_AllowRead";
            // 
            // lblBO_AllowAdd
            // 
            this.lblBO_AllowAdd.AutoSize = true;
            this.lblBO_AllowAdd.Location = new System.Drawing.Point(171, 182);
            this.lblBO_AllowAdd.Name = "lblBO_AllowAdd";
            this.lblBO_AllowAdd.Size = new System.Drawing.Size(72, 13);
            this.lblBO_AllowAdd.TabIndex = 9;
            this.lblBO_AllowAdd.Text = "BO_AllowAdd";
            // 
            // lblBO_AllowWrite
            // 
            this.lblBO_AllowWrite.AutoSize = true;
            this.lblBO_AllowWrite.Location = new System.Drawing.Point(171, 153);
            this.lblBO_AllowWrite.Name = "lblBO_AllowWrite";
            this.lblBO_AllowWrite.Size = new System.Drawing.Size(78, 13);
            this.lblBO_AllowWrite.TabIndex = 8;
            this.lblBO_AllowWrite.Text = "BO_AllowWrite";
            // 
            // lblPerformSpecificAction
            // 
            this.lblPerformSpecificAction.AutoSize = true;
            this.lblPerformSpecificAction.Location = new System.Drawing.Point(171, 298);
            this.lblPerformSpecificAction.Name = "lblPerformSpecificAction";
            this.lblPerformSpecificAction.Size = new System.Drawing.Size(111, 13);
            this.lblPerformSpecificAction.TabIndex = 11;
            this.lblPerformSpecificAction.Text = "PerformSpecificAction";
            // 
            // lblBO_AllowDelete
            // 
            this.lblBO_AllowDelete.AutoSize = true;
            this.lblBO_AllowDelete.Location = new System.Drawing.Point(171, 211);
            this.lblBO_AllowDelete.Name = "lblBO_AllowDelete";
            this.lblBO_AllowDelete.Size = new System.Drawing.Size(84, 13);
            this.lblBO_AllowDelete.TabIndex = 10;
            this.lblBO_AllowDelete.Text = "BO_AllowDelete";
            // 
            // txtUsrID
            // 
            this.txtUsrID.Location = new System.Drawing.Point(15, 25);
            this.txtUsrID.Name = "txtUsrID";
            this.txtUsrID.Size = new System.Drawing.Size(314, 20);
            this.txtUsrID.TabIndex = 12;
            // 
            // lblUsrID
            // 
            this.lblUsrID.AutoSize = true;
            this.lblUsrID.Location = new System.Drawing.Point(12, 9);
            this.lblUsrID.Name = "lblUsrID";
            this.lblUsrID.Size = new System.Drawing.Size(46, 13);
            this.lblUsrID.TabIndex = 13;
            this.lblUsrID.Text = "User ID:";
            // 
            // lblActnTrgt
            // 
            this.lblActnTrgt.AutoSize = true;
            this.lblActnTrgt.Location = new System.Drawing.Point(12, 48);
            this.lblActnTrgt.Name = "lblActnTrgt";
            this.lblActnTrgt.Size = new System.Drawing.Size(168, 13);
            this.lblActnTrgt.TabIndex = 15;
            this.lblActnTrgt.Text = "Action ID / BO ID / Report Name:";
            // 
            // txtActnTrgt
            // 
            this.txtActnTrgt.Location = new System.Drawing.Point(15, 64);
            this.txtActnTrgt.Name = "txtActnTrgt";
            this.txtActnTrgt.Size = new System.Drawing.Size(314, 20);
            this.txtActnTrgt.TabIndex = 14;
            // 
            // lblBO_AllowUnPost
            // 
            this.lblBO_AllowUnPost.AutoSize = true;
            this.lblBO_AllowUnPost.Location = new System.Drawing.Point(171, 269);
            this.lblBO_AllowUnPost.Name = "lblBO_AllowUnPost";
            this.lblBO_AllowUnPost.Size = new System.Drawing.Size(88, 13);
            this.lblBO_AllowUnPost.TabIndex = 19;
            this.lblBO_AllowUnPost.Text = "BO_AllowUnPost";
            // 
            // lblBO_AllowPost
            // 
            this.lblBO_AllowPost.AutoSize = true;
            this.lblBO_AllowPost.Location = new System.Drawing.Point(171, 240);
            this.lblBO_AllowPost.Name = "lblBO_AllowPost";
            this.lblBO_AllowPost.Size = new System.Drawing.Size(74, 13);
            this.lblBO_AllowPost.TabIndex = 18;
            this.lblBO_AllowPost.Text = "BO_AllowPost";
            // 
            // btnBO_AllowUnPost
            // 
            this.btnBO_AllowUnPost.Location = new System.Drawing.Point(14, 264);
            this.btnBO_AllowUnPost.Name = "btnBO_AllowUnPost";
            this.btnBO_AllowUnPost.Size = new System.Drawing.Size(150, 23);
            this.btnBO_AllowUnPost.TabIndex = 17;
            this.btnBO_AllowUnPost.Text = "BO_AllowUnPost";
            this.btnBO_AllowUnPost.UseVisualStyleBackColor = true;
            this.btnBO_AllowUnPost.Click += new System.EventHandler(this.btnBO_AllowUnPost_Click);
            // 
            // btnBO_AllowPost
            // 
            this.btnBO_AllowPost.Location = new System.Drawing.Point(15, 235);
            this.btnBO_AllowPost.Name = "btnBO_AllowPost";
            this.btnBO_AllowPost.Size = new System.Drawing.Size(150, 23);
            this.btnBO_AllowPost.TabIndex = 16;
            this.btnBO_AllowPost.Text = "BO_AllowPost";
            this.btnBO_AllowPost.UseVisualStyleBackColor = true;
            this.btnBO_AllowPost.Click += new System.EventHandler(this.btnBO_AllowPost_Click);
            // 
            // TstPermission
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(342, 326);
            this.Controls.Add(this.lblBO_AllowUnPost);
            this.Controls.Add(this.lblBO_AllowPost);
            this.Controls.Add(this.btnBO_AllowUnPost);
            this.Controls.Add(this.btnBO_AllowPost);
            this.Controls.Add(this.lblActnTrgt);
            this.Controls.Add(this.txtActnTrgt);
            this.Controls.Add(this.lblUsrID);
            this.Controls.Add(this.txtUsrID);
            this.Controls.Add(this.lblPerformSpecificAction);
            this.Controls.Add(this.lblBO_AllowDelete);
            this.Controls.Add(this.lblBO_AllowAdd);
            this.Controls.Add(this.lblBO_AllowWrite);
            this.Controls.Add(this.lblBO_AllowRead);
            this.Controls.Add(this.lblReport_AllowRead);
            this.Controls.Add(this.btnPerformSpecificAction);
            this.Controls.Add(this.btnBO_AllowDelete);
            this.Controls.Add(this.btnBO_AllowAdd);
            this.Controls.Add(this.btnBO_AllowWrite);
            this.Controls.Add(this.btnBO_AllowRead);
            this.Controls.Add(this.btnReport_AllowRead);
            this.Name = "TstPermission";
            this.Text = "TstPermission";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReport_AllowRead;
        private System.Windows.Forms.Button btnBO_AllowRead;
        private System.Windows.Forms.Button btnBO_AllowAdd;
        private System.Windows.Forms.Button btnBO_AllowWrite;
        private System.Windows.Forms.Button btnPerformSpecificAction;
        private System.Windows.Forms.Button btnBO_AllowDelete;
        private System.Windows.Forms.Label lblReport_AllowRead;
        private System.Windows.Forms.Label lblBO_AllowRead;
        private System.Windows.Forms.Label lblBO_AllowAdd;
        private System.Windows.Forms.Label lblBO_AllowWrite;
        private System.Windows.Forms.Label lblPerformSpecificAction;
        private System.Windows.Forms.Label lblBO_AllowDelete;
        private System.Windows.Forms.TextBox txtUsrID;
        private System.Windows.Forms.Label lblUsrID;
        private System.Windows.Forms.Label lblActnTrgt;
        private System.Windows.Forms.TextBox txtActnTrgt;
        private System.Windows.Forms.Label lblBO_AllowUnPost;
        private System.Windows.Forms.Label lblBO_AllowPost;
        private System.Windows.Forms.Button btnBO_AllowUnPost;
        private System.Windows.Forms.Button btnBO_AllowPost;
    }
}