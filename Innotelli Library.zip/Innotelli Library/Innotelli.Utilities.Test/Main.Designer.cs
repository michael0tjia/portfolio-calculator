namespace Innotelli.Utilities.Tester
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnTRoute = new System.Windows.Forms.Button();
            this.btnTCryptography = new System.Windows.Forms.Button();
            this.btnTDomain = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnTRoute
            // 
            this.btnTRoute.Location = new System.Drawing.Point(12, 12);
            this.btnTRoute.Name = "btnTRoute";
            this.btnTRoute.Size = new System.Drawing.Size(75, 23);
            this.btnTRoute.TabIndex = 0;
            this.btnTRoute.Text = "TRoute";
            this.btnTRoute.UseVisualStyleBackColor = true;
            this.btnTRoute.Click += new System.EventHandler(this.btnTRoute_Click);
            // 
            // btnTCryptography
            // 
            this.btnTCryptography.Location = new System.Drawing.Point(93, 12);
            this.btnTCryptography.Name = "btnTCryptography";
            this.btnTCryptography.Size = new System.Drawing.Size(92, 23);
            this.btnTCryptography.TabIndex = 1;
            this.btnTCryptography.Text = "TCryptography";
            this.btnTCryptography.UseVisualStyleBackColor = true;
            this.btnTCryptography.Click += new System.EventHandler(this.btnTCryptography_Click);
            // 
            // btnTDomain
            // 
            this.btnTDomain.Location = new System.Drawing.Point(191, 12);
            this.btnTDomain.Name = "btnTDomain";
            this.btnTDomain.Size = new System.Drawing.Size(75, 23);
            this.btnTDomain.TabIndex = 2;
            this.btnTDomain.Text = "TDomain";
            this.btnTDomain.UseVisualStyleBackColor = true;
            this.btnTDomain.Click += new System.EventHandler(this.btnTDomain_Click);
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(823, 519);
            this.Controls.Add(this.btnTDomain);
            this.Controls.Add(this.btnTCryptography);
            this.Controls.Add(this.btnTRoute);
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tester";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnTRoute;
        private System.Windows.Forms.Button btnTCryptography;
        private System.Windows.Forms.Button btnTDomain;
    }
}

