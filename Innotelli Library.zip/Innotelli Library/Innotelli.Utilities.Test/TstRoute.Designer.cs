namespace Innotelli.Utilities.Tester
{
    partial class TstRoute
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtInfo = new System.Windows.Forms.TextBox();
            this.txtUrlEncodedInfo = new System.Windows.Forms.TextBox();
            this.btnProcess = new System.Windows.Forms.Button();
            this.lblInfo = new System.Windows.Forms.Label();
            this.lblUrlEncodedInfo = new System.Windows.Forms.Label();
            this.lblOutBackwardUrl = new System.Windows.Forms.Label();
            this.txtBackwardUrl = new System.Windows.Forms.TextBox();
            this.txtDecryptUrlEncode = new System.Windows.Forms.TextBox();
            this.txtDecryptInfo = new System.Windows.Forms.TextBox();
            this.btnReset = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtInfo
            // 
            this.txtInfo.Location = new System.Drawing.Point(105, 12);
            this.txtInfo.Name = "txtInfo";
            this.txtInfo.Size = new System.Drawing.Size(548, 20);
            this.txtInfo.TabIndex = 0;
            // 
            // txtUrlEncodedInfo
            // 
            this.txtUrlEncodedInfo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtUrlEncodedInfo.Location = new System.Drawing.Point(105, 90);
            this.txtUrlEncodedInfo.Name = "txtUrlEncodedInfo";
            this.txtUrlEncodedInfo.Size = new System.Drawing.Size(548, 20);
            this.txtUrlEncodedInfo.TabIndex = 2;
            // 
            // btnProcess
            // 
            this.btnProcess.Location = new System.Drawing.Point(105, 142);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(75, 23);
            this.btnProcess.TabIndex = 4;
            this.btnProcess.Text = "Process";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // lblInfo
            // 
            this.lblInfo.AutoSize = true;
            this.lblInfo.Location = new System.Drawing.Point(13, 15);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(25, 13);
            this.lblInfo.TabIndex = 5;
            this.lblInfo.Text = "Info";
            // 
            // lblUrlEncodedInfo
            // 
            this.lblUrlEncodedInfo.AutoSize = true;
            this.lblUrlEncodedInfo.Location = new System.Drawing.Point(13, 93);
            this.lblUrlEncodedInfo.Name = "lblUrlEncodedInfo";
            this.lblUrlEncodedInfo.Size = new System.Drawing.Size(81, 13);
            this.lblUrlEncodedInfo.TabIndex = 7;
            this.lblUrlEncodedInfo.Text = "UrlEncodedInfo";
            // 
            // lblOutBackwardUrl
            // 
            this.lblOutBackwardUrl.AutoSize = true;
            this.lblOutBackwardUrl.Location = new System.Drawing.Point(13, 67);
            this.lblOutBackwardUrl.Name = "lblOutBackwardUrl";
            this.lblOutBackwardUrl.Size = new System.Drawing.Size(68, 13);
            this.lblOutBackwardUrl.TabIndex = 13;
            this.lblOutBackwardUrl.Text = "BackwardUrl";
            // 
            // txtBackwardUrl
            // 
            this.txtBackwardUrl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtBackwardUrl.Location = new System.Drawing.Point(105, 64);
            this.txtBackwardUrl.Name = "txtBackwardUrl";
            this.txtBackwardUrl.Size = new System.Drawing.Size(548, 20);
            this.txtBackwardUrl.TabIndex = 14;
            // 
            // txtDecryptUrlEncode
            // 
            this.txtDecryptUrlEncode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.txtDecryptUrlEncode.Location = new System.Drawing.Point(105, 116);
            this.txtDecryptUrlEncode.Name = "txtDecryptUrlEncode";
            this.txtDecryptUrlEncode.Size = new System.Drawing.Size(548, 20);
            this.txtDecryptUrlEncode.TabIndex = 16;
            // 
            // txtDecryptInfo
            // 
            this.txtDecryptInfo.Location = new System.Drawing.Point(105, 38);
            this.txtDecryptInfo.Name = "txtDecryptInfo";
            this.txtDecryptInfo.Size = new System.Drawing.Size(548, 20);
            this.txtDecryptInfo.TabIndex = 17;
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(186, 142);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 18;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // TstRoute
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(665, 172);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.txtDecryptInfo);
            this.Controls.Add(this.txtDecryptUrlEncode);
            this.Controls.Add(this.txtBackwardUrl);
            this.Controls.Add(this.lblOutBackwardUrl);
            this.Controls.Add(this.lblUrlEncodedInfo);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.btnProcess);
            this.Controls.Add(this.txtUrlEncodedInfo);
            this.Controls.Add(this.txtInfo);
            this.Name = "TstRoute";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TstRoute";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtInfo;
        private System.Windows.Forms.TextBox txtUrlEncodedInfo;
        private System.Windows.Forms.Button btnProcess;
        private System.Windows.Forms.Label lblInfo;
        private System.Windows.Forms.Label lblUrlEncodedInfo;
        private System.Windows.Forms.Label lblOutBackwardUrl;
        private System.Windows.Forms.TextBox txtBackwardUrl;
        private System.Windows.Forms.TextBox txtDecryptUrlEncode;
        private System.Windows.Forms.TextBox txtDecryptInfo;
        private System.Windows.Forms.Button btnReset;
    }
}