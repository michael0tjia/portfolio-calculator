namespace Innotelli.Utilities.Tester
{
    partial class TstCryptography
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEncryptSource = new System.Windows.Forms.Label();
            this.txtEncryptSource = new System.Windows.Forms.TextBox();
            this.lbEncryptResult = new System.Windows.Forms.Label();
            this.txtEncryptResult = new System.Windows.Forms.TextBox();
            this.txtKEY64 = new System.Windows.Forms.TextBox();
            this.txtIV64 = new System.Windows.Forms.TextBox();
            this.btnProcess = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.lblKEY64 = new System.Windows.Forms.Label();
            this.lblIV64 = new System.Windows.Forms.Label();
            this.lblDecryptSource = new System.Windows.Forms.Label();
            this.txtDecryptResult = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // lblEncryptSource
            // 
            this.lblEncryptSource.AutoSize = true;
            this.lblEncryptSource.Location = new System.Drawing.Point(12, 9);
            this.lblEncryptSource.Name = "lblEncryptSource";
            this.lblEncryptSource.Size = new System.Drawing.Size(80, 13);
            this.lblEncryptSource.TabIndex = 0;
            this.lblEncryptSource.Text = "Encrypt Source";
            // 
            // txtEncryptSource
            // 
            this.txtEncryptSource.Location = new System.Drawing.Point(98, 6);
            this.txtEncryptSource.Name = "txtEncryptSource";
            this.txtEncryptSource.Size = new System.Drawing.Size(174, 20);
            this.txtEncryptSource.TabIndex = 1;
            // 
            // lbEncryptResult
            // 
            this.lbEncryptResult.AutoSize = true;
            this.lbEncryptResult.Location = new System.Drawing.Point(278, 22);
            this.lbEncryptResult.Name = "lbEncryptResult";
            this.lbEncryptResult.Size = new System.Drawing.Size(37, 13);
            this.lbEncryptResult.TabIndex = 2;
            this.lbEncryptResult.Text = "Result";
            // 
            // txtEncryptResult
            // 
            this.txtEncryptResult.Location = new System.Drawing.Point(321, 19);
            this.txtEncryptResult.Name = "txtEncryptResult";
            this.txtEncryptResult.Size = new System.Drawing.Size(174, 20);
            this.txtEncryptResult.TabIndex = 3;
            // 
            // txtKEY64
            // 
            this.txtKEY64.Location = new System.Drawing.Point(98, 58);
            this.txtKEY64.Name = "txtKEY64";
            this.txtKEY64.Size = new System.Drawing.Size(174, 20);
            this.txtKEY64.TabIndex = 4;
            // 
            // txtIV64
            // 
            this.txtIV64.Location = new System.Drawing.Point(98, 84);
            this.txtIV64.Name = "txtIV64";
            this.txtIV64.Size = new System.Drawing.Size(174, 20);
            this.txtIV64.TabIndex = 5;
            // 
            // btnProcess
            // 
            this.btnProcess.Location = new System.Drawing.Point(98, 110);
            this.btnProcess.Name = "btnProcess";
            this.btnProcess.Size = new System.Drawing.Size(75, 23);
            this.btnProcess.TabIndex = 6;
            this.btnProcess.Text = "Process";
            this.btnProcess.UseVisualStyleBackColor = true;
            this.btnProcess.Click += new System.EventHandler(this.btnProcess_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(179, 110);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 23);
            this.btnReset.TabIndex = 7;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = true;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // lblKEY64
            // 
            this.lblKEY64.AutoSize = true;
            this.lblKEY64.Location = new System.Drawing.Point(12, 61);
            this.lblKEY64.Name = "lblKEY64";
            this.lblKEY64.Size = new System.Drawing.Size(46, 13);
            this.lblKEY64.TabIndex = 8;
            this.lblKEY64.Text = "KEY_64";
            // 
            // lblIV64
            // 
            this.lblIV64.AutoSize = true;
            this.lblIV64.Location = new System.Drawing.Point(12, 87);
            this.lblIV64.Name = "lblIV64";
            this.lblIV64.Size = new System.Drawing.Size(35, 13);
            this.lblIV64.TabIndex = 9;
            this.lblIV64.Text = "IV_64";
            // 
            // lblDecryptSource
            // 
            this.lblDecryptSource.AutoSize = true;
            this.lblDecryptSource.Location = new System.Drawing.Point(12, 35);
            this.lblDecryptSource.Name = "lblDecryptSource";
            this.lblDecryptSource.Size = new System.Drawing.Size(81, 13);
            this.lblDecryptSource.TabIndex = 10;
            this.lblDecryptSource.Text = "Decrypt Source";
            // 
            // txtDecryptResult
            // 
            this.txtDecryptResult.Location = new System.Drawing.Point(98, 32);
            this.txtDecryptResult.Name = "txtDecryptResult";
            this.txtDecryptResult.Size = new System.Drawing.Size(174, 20);
            this.txtDecryptResult.TabIndex = 12;
            // 
            // TstCryptography
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(506, 141);
            this.Controls.Add(this.txtDecryptResult);
            this.Controls.Add(this.lblDecryptSource);
            this.Controls.Add(this.lblIV64);
            this.Controls.Add(this.lblKEY64);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnProcess);
            this.Controls.Add(this.txtIV64);
            this.Controls.Add(this.txtKEY64);
            this.Controls.Add(this.txtEncryptResult);
            this.Controls.Add(this.lbEncryptResult);
            this.Controls.Add(this.txtEncryptSource);
            this.Controls.Add(this.lblEncryptSource);
            this.Name = "TstCryptography";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "TstCryptography";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEncryptSource;
        private System.Windows.Forms.TextBox txtEncryptSource;
        private System.Windows.Forms.Label lbEncryptResult;
        private System.Windows.Forms.TextBox txtEncryptResult;
        private System.Windows.Forms.TextBox txtKEY64;
        private System.Windows.Forms.TextBox txtIV64;
        private System.Windows.Forms.Button btnProcess;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Label lblKEY64;
        private System.Windows.Forms.Label lblIV64;
        private System.Windows.Forms.Label lblDecryptSource;
        private System.Windows.Forms.TextBox txtDecryptResult;
    }
}