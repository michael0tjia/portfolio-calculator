using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Innotelli.Security;
using Innotelli.Db;
using System.Configuration;

namespace Innotelli.Utilities.Tester
{
    public partial class TstPermission : Form
    {
        public TPermission mPermission;

        public TstPermission()
        {
            InitializeComponent();
            Db.TSingletons.DbObj.CnnStr = ConfigurationManager.AppSettings["Connection"];
            mPermission = new TPermission();//salesManager.hk
        }

        private void btnReport_AllowRead_Click(object sender, EventArgs e)
        {
            string lErrMsg = "";
            if (ResetData(out lErrMsg))
            {
                this.lblReport_AllowRead.Text = mPermission.Report_AllowRead(this.txtActnTrgt.Text, out lErrMsg).ToString() + ". " + lErrMsg;
            }
            else
            {
                this.lblReport_AllowRead.Text = lErrMsg;
            }
        }

        private void btnBO_AllowRead_Click(object sender, EventArgs e)
        {
            string lErrMsg = "";
            if (ResetData(out lErrMsg))
            {
                //this.lblBO_AllowRead.Text = mPermission.BO_AllowRead(this.txtActnTrgt.Text, out lErrMsg).ToString() + ". " + lErrMsg;
                this.lblBO_AllowRead.Text = mPermission.BO_AllowAction(TPermission.ActionType.Read, this.txtActnTrgt.Text, out lErrMsg).ToString() + ". " + lErrMsg;
            }
            else
            {
                this.lblBO_AllowRead.Text = lErrMsg;
            }
        }

        private void btnBO_AllowWrite_Click(object sender, EventArgs e)
        {
            string lErrMsg = "";
            if (ResetData(out lErrMsg))
            {
                //this.lblBO_AllowWrite.Text = mPermission.BO_AllowWrite(this.txtActnTrgt.Text, out lErrMsg).ToString() + ". " + lErrMsg;
                this.lblBO_AllowWrite.Text = mPermission.BO_AllowAction(TPermission.ActionType.Write, this.txtActnTrgt.Text, out lErrMsg).ToString() + ". " + lErrMsg;
            }
            else
            {
                this.lblBO_AllowWrite.Text = lErrMsg;
            }
        }

        private void btnBO_AllowAdd_Click(object sender, EventArgs e)
        {
            string lErrMsg = "";
            if (ResetData(out lErrMsg))
            {
                //this.lblBO_AllowAdd.Text = mPermission.BO_AllowAdd(this.txtActnTrgt.Text, out lErrMsg).ToString() + ". " + lErrMsg;
                this.lblBO_AllowAdd.Text = mPermission.BO_AllowAction(TPermission.ActionType.Add, this.txtActnTrgt.Text, out lErrMsg).ToString() + ". " + lErrMsg;
            }
            else
            {
                this.lblBO_AllowAdd.Text = lErrMsg;
            }
        }

        private void btnBO_AllowDelete_Click(object sender, EventArgs e)
        {
            string lErrMsg = "";
            if (ResetData(out lErrMsg))
            {
                //this.lblBO_AllowDelete.Text = mPermission.BO_AllowDelete(this.txtActnTrgt.Text, out lErrMsg).ToString() + ". " + lErrMsg;
                this.lblBO_AllowDelete.Text = mPermission.BO_AllowAction(TPermission.ActionType.Delete, this.txtActnTrgt.Text, out lErrMsg).ToString() + ". " + lErrMsg;
            }
            else
            {
                this.lblBO_AllowDelete.Text = lErrMsg;
            }
        }

        private void btnBO_AllowPost_Click(object sender, EventArgs e)
        {
            string lErrMsg = "";
            if (ResetData(out lErrMsg))
            {
                //this.lblBO_AllowPost.Text = mPermission.BO_AllowPost(this.txtActnTrgt.Text, out lErrMsg).ToString() + ". " + lErrMsg;
                this.lblBO_AllowPost.Text = mPermission.BO_AllowAction(TPermission.ActionType.Post, this.txtActnTrgt.Text, out lErrMsg).ToString() + ". " + lErrMsg;
            }
            else
            {
                this.lblBO_AllowPost.Text = lErrMsg;
            }
        }

        private void btnBO_AllowUnPost_Click(object sender, EventArgs e)
        {
            string lErrMsg = "";
            if (ResetData(out lErrMsg))
            {
                //this.lblBO_AllowUnPost.Text = mPermission.BO_AllowUnPost(this.txtActnTrgt.Text, out lErrMsg).ToString() + ". " + lErrMsg;
                this.lblBO_AllowUnPost.Text = mPermission.BO_AllowAction(TPermission.ActionType.UnPost, this.txtActnTrgt.Text, out lErrMsg).ToString() + ". " + lErrMsg;
            }
            else
            {
                this.lblBO_AllowUnPost.Text = lErrMsg;
            }
        }

        private void btnPerformSpecificAction_Click(object sender, EventArgs e)
        {
            //Guid lGuid = Guid.NewGuid();
            //lGuid.ToByteArray();
            string lErrMsg = "";
            if (ResetData(out lErrMsg))
            {
                this.lblPerformSpecificAction.Text = mPermission.PerformSpecificAction(this.txtActnTrgt.Text, out lErrMsg).ToString() + ". " + lErrMsg;
            }
            else
            {
                this.lblPerformSpecificAction.Text = lErrMsg;
            }
        }

        private bool ResetData(out string aErrMsg)
        {
            aErrMsg = "";
            bool lRtrnVal = true;

            this.lblBO_AllowRead.Text = "";
            this.lblBO_AllowWrite.Text = "";
            this.lblBO_AllowAdd.Text = "";
            this.lblBO_AllowDelete.Text = "";
            this.lblBO_AllowPost.Text = "";
            this.lblBO_AllowUnPost.Text = "";
            this.lblPerformSpecificAction.Text = "";
            this.lblReport_AllowRead.Text = "";
            mPermission.UserID = this.txtUsrID.Text;
            if (mPermission.UserPK == "")
            {
                aErrMsg = "No such user.";
                lRtrnVal = false;
            }

            return lRtrnVal;
        }
    }
}