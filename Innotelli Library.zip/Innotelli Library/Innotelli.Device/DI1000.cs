﻿using System;
using System.Text;
using System.IO.Ports;
using System.IO;
using System.Threading;

namespace Innotelli.Device
{
    // Author: Victor Wong
    //
    // Step to use:
    // 1. Initialize with COM number
    // 2. Should close the COM port by DI1000.Close() in the Closing event of windows form
    //    But, the DI1000's destructor will auto Close if carelessly forgot to close.
    // Example: See A401/BackOffice/Test/DI1000Demo2

    public class DI1000
    {
        private SerialPort mPort;
        public string Unit;
        public bool IsStable = false;
        public double GrossWeight = 0.0;
        public double NetWeight = 0.0;
        public double TareWeight = 0.0;
        public double TotalWeight = 0.0;

        public void Reset()
        {
            GrossWeight = 0.0;
            NetWeight = 0.0;
            TareWeight = 0.0;
            TotalWeight = 0.0;
        }
        public void Open()
        {
            mPort.Open();
        }
        public void Close()
        {
            mPort.Close();
        }
        //Send { 0x02, 0x0d, 0x0a } to COM Port, the weight will echo back the weights data
        public bool GetData(int aMachineTimeout, int aPortReadTimeout)
        {
            bool lRtrnVal = true;
            byte[] lBuffer = new byte[64];

            Reset();
            mPort.ReadTimeout = aPortReadTimeout;
            mPort.Open();
            if (mPort.BytesToRead > 0)
            {
                mPort.ReadExisting();
            }
            mPort.Write(new byte[] { 0x02, 0x0d, 0x0a }, 0, 3);            
            try
            {
                Thread.Sleep(aMachineTimeout);
                mPort.Read(lBuffer, 0, 64);
                ParseData(lBuffer);
                lRtrnVal = true;
            }
            catch (TimeoutException)
            {
                lRtrnVal = false;
            }
            finally
            {
                mPort.Close();
            }            

            return lRtrnVal;

        }
        //Only one constructor to initialize, with specified COM port
        public DI1000(string aCom)
        {
            if (Array.IndexOf(SerialPort.GetPortNames(), aCom) < 0)
                throw new System.IO.IOException("Serial port '" + aCom + "' not found.");
            else
            {
                mPort = new SerialPort(aCom, 9600, Parity.None, 8, StopBits.One);
            }
        }
        public DI1000()
        {

        }
        private void ParseData(byte[] aBuffer)
        {
            byte[] lTmp = new byte[7];
            string lUnit = string.Empty;

            //validate format
            if (aBuffer[0] == 0x06)
            {
                if (aBuffer[1] == 0x6b && aBuffer[2] == 0x67)
                {
                    lUnit = "kg";
                }
                else if (aBuffer[1] == 0x6c && aBuffer[2] == 0x62)
                {
                    lUnit = "lb";
                }
                else
                {
                    throw new DI1000FormatException("Unknown data format 2");
                }
                if (aBuffer[4] == 0x0d)
                {

                    if (aBuffer[5] == 0x47 && aBuffer[13] == 0x0d && aBuffer[14] == 0x4c && aBuffer[22] == 0x0d && aBuffer[23] == 0x0a)
                    {
                        Unit = lUnit;
                        IsStable = (aBuffer[3] == 0x30);
                        Array.Copy(aBuffer, 6, lTmp, 0, 7);
                        GrossWeight = Convert.ToDouble(ASCIIEncoding.ASCII.GetString(lTmp));
                        Array.Copy(aBuffer, 15, lTmp, 0, 7);
                        TotalWeight = Convert.ToDouble(ASCIIEncoding.ASCII.GetString(lTmp));
                    }
                    else if (aBuffer[5] == 0x4e && aBuffer[13] == 0x0d && aBuffer[14] == 0x54 && aBuffer[22] == 0x0d && aBuffer[23] == 0x54 && aBuffer[31] == 0x0d && aBuffer[32] == 0x0a)
                    {
                        Unit = lUnit;
                        IsStable = (aBuffer[3] == 0x30);
                        Array.Copy(aBuffer, 6, lTmp, 0, 7);
                        NetWeight = Convert.ToDouble(ASCIIEncoding.ASCII.GetString(lTmp));
                        Array.Copy(aBuffer, 15, lTmp, 0, 7);
                        TareWeight = Convert.ToDouble(ASCIIEncoding.ASCII.GetString(lTmp));
                        Array.Copy(aBuffer, 24, lTmp, 0, 7);
                        TotalWeight = Convert.ToDouble(ASCIIEncoding.ASCII.GetString(lTmp));
                    }
                    else
                    {
                        throw new DI1000FormatException("Unknown data format 3");
                    }
                    
                }


            }
            else
            {
                throw new DI1000FormatException("Unknown data format 1");
            }
            

        }
        ~DI1000()
        {
            if (mPort != null && mPort.IsOpen)
            {
                mPort.Close();
            }
        }
    }
    public class DI1000FormatException : Exception
    {
        public DI1000FormatException(string aMessage)
            : base(aMessage)
        {

        }
    }
}
