using System;
using System.Collections.Generic;
using System.Text;
using Innotelli.Utilities;
using System.Text.RegularExpressions;

namespace Innotelli.Utilities
{
    public static class TUKDate
    {
        #region Functions
        public static bool IsValidShortDate(string aStr)
        {
            bool lReturnValue = false;
            int lYr = 0;
            int lMth = 0;
            int lDay = 0;
            DateTime lDateTime;
            string lStr = "";

            bool lDayTryParsed = false;
            bool lMthTryParsed = false;
            bool lYrTryParsed = false;

            if (aStr != null)
            {
                lStr = aStr.Trim();
                if (lStr.Length == 10)
                {
                    lDayTryParsed = int.TryParse(TStr.Left(lStr, 2), out lDay);
                    lMthTryParsed = int.TryParse(TStr.Mid(lStr, 3, 2),out lMth);
                    lYrTryParsed = int.TryParse(TStr.Right(lStr, 4),out lYr);

                    if (lDayTryParsed && (TStr.Mid(lStr, 2, 1) == "/") && lMthTryParsed && (TStr.Mid(lStr, 5, 1) == "/") && lYrTryParsed)
                    {
                        lReturnValue = DateTime.TryParse(lYr + "/" + lMth + "/" + lDay, out lDateTime);
                    }
                }
            }
            return lReturnValue;
        }
        public static bool IsValidShortDate(string aStr, ref DateTime aDate)
        {
            bool lReturnValue = false;
            int lYr = 0;
            int lMth = 0;
            int lDay = 0;
            string lStr = "";

            DateTime lDateTime;

            bool lDayTryParsed = false;
            bool lMthTryParsed = false;
            bool lYrTryParsed = false;

            aDate = DateTime.MinValue;

            if (aStr != null)
            {
                lStr = aStr.Trim();
                if (lStr.Length == 10)
                {
                    lDayTryParsed = int.TryParse(TStr.Left(lStr, 2), out lDay);
                    lMthTryParsed = int.TryParse(TStr.Mid(lStr, 3, 2), out lMth);
                    lYrTryParsed = int.TryParse(TStr.Right(lStr, 4), out lYr);

                    if (lDayTryParsed && 
                        (TStr.Mid(lStr, 2, 1) == "/") &&
                        lMthTryParsed && 
                        (TStr.Mid(lStr, 5, 1) == "/") &&
                        lYrTryParsed)
                    {
                        lReturnValue = DateTime.TryParse(lYr + "/" + lMth + "/" + lDay, out lDateTime);
                        if (lReturnValue)
                        {
                            aDate = lDateTime;
                        }
                    }
                }
            }

            return lReturnValue;
        }
        public static bool IsValidLongDate(string aStr)
        {
            bool lReturnValue = false;
            string lStr = aStr.Trim();

            DateTime lDateTime;

            int lYr = 0;
            int lMth = 0;
            int lDay = 0;

            if (DateTime.TryParse(lStr, out lDateTime))
            {
                string[] lDateStr = new string[3];
                lDateStr = Regex.Split(lStr, "\\s+");

                if ((int.TryParse(lDateStr[0], out lDay)) &&
                    (!int.TryParse(lDateStr[1],out lMth)) &&
                    (int.TryParse(lDateStr[2],out lYr)))
                {
                    if ((lDay <= 31) && (int.Parse(lDateStr[2]) >= 1900))
                    {
                        lReturnValue = true;
                    }
                }
            }
            return lReturnValue;
        }
        public static bool IsValidLongDate(string aStr, ref DateTime aDate)
        {
            bool lReturnValue = false;
            string lStr = aStr.Trim();

            DateTime lDateTime;

            int lYr = 0;
            int lMth = 0;
            int lDay = 0;

            if (DateTime.TryParse(lStr, out lDateTime))
            {
                string[] lDateStr = new string[3];
                lDateStr = Regex.Split(lStr, "\\s+");
                if ((int.TryParse(lDateStr[0], out lDay)) &&
                    (!int.TryParse(lDateStr[1], out lMth)) &&
                    (int.TryParse(lDateStr[2], out lYr)))
                {
                    if ((int.Parse(lDateStr[0]) <= 31) && (int.Parse(lDateStr[2]) >= 1900))
                    {
                        aDate = DateTime.Parse(lDateStr[2] + "/" + lDateStr[1] + "/" + lDateStr[0]);
                        lReturnValue = true;
                    }
                }
            }
            return lReturnValue;
        }
        public static DateTime ConvertShortDateStringToDateTime(string aStr)
        {
            DateTime lReturnValue = new DateTime();
            int lYr = 0;
            int lMth = 0;
            int lDay = 0;
            string lStr = string.Empty;
            bool lDayTryParsed = false;
            bool lMthTryParsed = false;
            bool lYrTryParsed = false;

            if (aStr != null)
            {
                lStr = aStr.Trim();
                if (lStr.Length == 10)
                {
                    lDayTryParsed = int.TryParse(TStr.Left(lStr, 2), out lDay);
                    lMthTryParsed = int.TryParse(TStr.Mid(lStr, 3, 2), out lMth);
                    lYrTryParsed = int.TryParse(TStr.Right(lStr, 4), out lYr);

                    if (lDayTryParsed && 
                        (TStr.Mid(lStr, 2, 1) == "/") &&
                        lMthTryParsed && 
                        (TStr.Mid(lStr, 5, 1) == "/") &&
                        lYrTryParsed)
                    {
                        DateTime.TryParse(lYr + "/" + lMth + "/" + lDay, out lReturnValue);
                    }
                }
            }
            return lReturnValue;
        }
        #endregion

    }
}
