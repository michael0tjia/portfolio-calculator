using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Collections;

namespace Innotelli.Utilities
{
    public class TLineReader : StreamReader
    {
        public struct CharDtls
        {
            public char Char1;
            public char Char2;
            public bool Bold;
        }

        public struct ComplexLine
        {
            public string Line1;
            public string Line2;
            public bool Bold;
        }

        public enum LastChar
        {
            Return = 0,
            NewLine = 1,
            PageBreak = 2,
            Others = 3
        }

        public TLineReader(string aPath)
            : base(aPath)
        {

        }

        public ComplexLine ReadComplexLine(out LastChar aLastChar)
        {
            ComplexLine lReturnValue;
            CharDtls lCharDtls;
            string lTmpStr = "";
            ArrayList lComplicatedLine = new ArrayList();
            int lPos = 0;

            aLastChar = LastChar.Others;
            lTmpStr = this.ReadLine(out aLastChar);
            if (aLastChar == LastChar.Return)
            {
                foreach (char lChar in lTmpStr)
                {
                    lCharDtls = new CharDtls();
                    lCharDtls.Bold = false;
                    if (lChar == '_')
                    {
                        lCharDtls.Char1 = ' ';
                        lCharDtls.Char2 = '_';
                    }
                    else
                    {
                        lCharDtls.Char1 = lChar;
                        lCharDtls.Char2 = ' ';
                    }
                    lComplicatedLine.Add(lCharDtls);
                }

                do
                {
                    lPos = 0;
                    lTmpStr = this.ReadLine(out aLastChar);
                    foreach (char lChar in lTmpStr)
                    {
                        if (lPos < lComplicatedLine.Count)
                        {
                            lCharDtls = (CharDtls)lComplicatedLine[lPos];

                            if (lChar == ' ')
                            {
                                // do nothing
                            }
                            else if (lChar == '_')
                            {
                                lCharDtls.Char2 = '_';
                            }
                            else if (lChar == lCharDtls.Char1) // not ' ' and not '_' but same as previous lChar0 
                            {
                                lCharDtls.Bold = true;
                            }
                            else
                            {
                                //data invalid
                                throw new Exception();
                            }
                            lComplicatedLine[lPos] = lCharDtls;
                        }
                        else
                        {
                            lCharDtls = new CharDtls();
                            lCharDtls.Bold = false;
                            if (lChar == '_')
                            {
                                lCharDtls.Char1 = ' ';
                                lCharDtls.Char2 = '_';
                            }
                            else
                            {
                                lCharDtls.Char1 = lChar;
                                lCharDtls.Char2 = ' ';
                            }
                            lComplicatedLine.Add(lCharDtls);
                        }
                        lPos++;
                    }
                } while (aLastChar == LastChar.Return);
                lReturnValue = GetFromArrayList(lComplicatedLine);
            }
            else
            {
                lReturnValue = new ComplexLine();
                lReturnValue.Line1 = lTmpStr;
                lReturnValue.Bold = false;
                lReturnValue.Line2 = "";
            }
            return lReturnValue;
        }

        public string ReadLine(out LastChar aLastChar)
        {
            string lReturnValue = "";
            aLastChar = LastChar.Others;
            int lCharCd = 0;
            char lChar = ' ';

            lCharCd = this.Read();
            lChar = Convert.ToChar(lCharCd);

            // identify three patterns
            // 1. \r
            // 2. \r\n
            // 3. \f

            // 4. \n

            // 5. \n\r

            // 6. \f\r
            // 7. \f\n

            while (lChar != '\n' && lChar != '\r' && lChar != '\f')
            {
                lReturnValue += lChar;
                lCharCd = this.Read();
                lChar = Convert.ToChar(lCharCd);
            }

            switch (lChar)
            {
                case '\f':
                    aLastChar = LastChar.PageBreak;
                    break;
                case '\n':
                    aLastChar = LastChar.NewLine;
                    break;
                case '\r':
                    do
                    {
                        lCharCd = this.Peek();
                        lChar = Convert.ToChar(lCharCd);
                    } while (lChar == 'r');

                    if (lChar == '\n') // Case 2
                    {
                        this.Read();
                        aLastChar = LastChar.NewLine;
                    }
                    else // Case 1
                    {
                        aLastChar = LastChar.Return;
                    }
                    break;
            }

            return lReturnValue;
        }

        private ComplexLine GetFromArrayList(ArrayList aComplicatedLine)
        {
            ComplexLine lReturnValue = new ComplexLine();
            CharDtls lCharDtls;

            lReturnValue.Bold = true;
            lReturnValue.Line1 = "";
            lReturnValue.Line2 = "";

            for (int i = 0; i < aComplicatedLine.Count; i++)
            {
                lCharDtls = (CharDtls)aComplicatedLine[i];
                lReturnValue.Line1 += lCharDtls.Char1;
                lReturnValue.Line2 += lCharDtls.Char2;

                // ignore ' '
                if ((lCharDtls.Char1 != ' ') && (!lCharDtls.Bold))
                {
                    lReturnValue.Bold = false;
                }
            }
            return lReturnValue;
        }
    }
}