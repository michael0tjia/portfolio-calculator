using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace Innotelli.Utilities
{
    public class TDataSetBuilder
    {
        #region Members Variable

        private DataSet mDs;
        private DataTable mDt;
        private DataRow mDr;

        #endregion

        #region Class Properties

        public DataSet Ds
        {
            get
            {
                return mDs;
            }
            set
            {
                mDs = value;
            }
        }
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
            set
            {
                mDt = value;
            }
        }

        #endregion

        #region Constructors

        public TDataSetBuilder() 
        {
            mDs = new DataSet();
        }
        
        #endregion

        #region Function

        public void AddNewTable(string aTableName)
        {
            mDt = new DataTable();
            mDt.TableName = aTableName;
            mDs.Tables.Add(mDt);
        }

        public void AddNewCol(string aColName)
        {
            mDt.Columns.Add(aColName);
        }

        public void AddNewRowWithValue(string aColName, string aValue)
        {
            mDr = mDt.NewRow();
            mDr[aColName] = aValue;
            mDt.Rows.Add(mDr);
        }

        public void AddRelation(string aParentCol, string aChildCol)
        {
            mDs.Relations.Add(mDs.Tables[aParentCol.Split(new char[] { '.' })[0]].Columns[aParentCol.Split(new char[] { '.' })[1]], mDs.Tables[aChildCol.Split(new char[] { '.' })[0]].Columns[aChildCol.Split(new char[] { '.' })[1]]);
        }

        public void AddRelation(string aRelationName, string aParentCol, string aChildCol)
        {
            mDs.Relations.Add(aRelationName, mDs.Tables[aParentCol.Split(new char[] { '.' })[0]].Columns[aParentCol.Split(new char[] { '.' })[1]], mDs.Tables[aChildCol.Split(new char[] { '.' })[0]].Columns[aChildCol.Split(new char[] { '.' })[1]]);
        }

        public void LoadTreeByPK(INode aRootNode, string aPK)
        {
            string lLnkKyToChld = "";
            string lPrntTblNm = "";
            string lLnkKyToPrnt = "";
            string lChldTblNm = "";

            lLnkKyToChld = ((Element)aRootNode.Data).LinkKeyToChild;
            lPrntTblNm = ((Element)aRootNode.Data).TableName;

            AddNewTable(lPrntTblNm);
            AddNewCol(lLnkKyToChld);
            AddNewRowWithValue(lLnkKyToChld, aPK);

            foreach (INode lChild in aRootNode.DirectChildren)
            {
                lLnkKyToPrnt = ((Element)lChild.Data).LinkKeyToParent;
                lChldTblNm = ((Element)lChild.Data).TableName;

                AddNewTable(lChldTblNm);
                AddNewCol(lLnkKyToChld);
                AddNewCol(lLnkKyToPrnt);
                AddRelation(lPrntTblNm + "." + lLnkKyToChld, lChldTblNm + "." + lLnkKyToPrnt);

                //LoadTreeByPK(lChild, aPK);
            }
        }

        #endregion
    }
}
