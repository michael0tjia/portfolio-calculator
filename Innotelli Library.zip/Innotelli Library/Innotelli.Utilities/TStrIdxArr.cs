using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;

namespace Innotelli.Utilities
{
    public class TStrIdxArr
    {
        //#check!
        public struct Param
        {
            public object Val;
            public Type Type;
        }

        #region Members
        private ArrayList mIdxArrLst;
        private ArrayList mValArrLst;
        private ArrayList mTypeArrLst;
        #endregion

        #region Properties
        public int Count
        {
            get { return mIdxArrLst.Count; }
        }
        public ArrayList IdxArrLst
        {
            get { return mIdxArrLst; }
            set { mIdxArrLst = value; }
        }
        public ArrayList ValArrLst
        {
            get { return mValArrLst; }
            set { mValArrLst = value; }
        }
        public ArrayList TypeArrLst
        {
            get { return mTypeArrLst; }
            set { mTypeArrLst = value; }
        }
        public object this[string aStrIdx]
        {
            get
            {
                if (aStrIdx.Length == 0)
                {
                    return null;
                }
                return GetValue(aStrIdx);
            }
            set
            {
                bool lIsFound = false;

                for (int i = 0; i < mIdxArrLst.Count; i++)
                {
                    if ((mIdxArrLst[i].ToString()).Equals(aStrIdx.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        lIsFound = true;
                        mValArrLst[i] = value;
                        break;
                    }
                }
                if (!lIsFound)
                {
                    mIdxArrLst.Add(aStrIdx);
                    mValArrLst.Add(value);
                }
            }
        }
        #endregion

        #region Constructors
        public TStrIdxArr()
        {
            mIdxArrLst = new ArrayList();
            mValArrLst = new ArrayList();
        }
        #endregion

        #region Functions
        private object GetValue(string aStrIdx)
        {
            for (int i = 0; i < mIdxArrLst.Count; i++)
            {
                if ((mIdxArrLst[i].ToString()).Equals(aStrIdx.ToString(), StringComparison.OrdinalIgnoreCase))
                {
                    return mValArrLst[i];
                }
            }
            return null;
        }
        public void GenArrays(ref string[] aIndexes, ref ArrayList aObjValues, ref DataSet[] aDSValues)
        {
            ArrayList lDSIdxArr = new ArrayList();
            ArrayList lDSValArr = new ArrayList();
            int lCount = 0;
            aIndexes = new string[Count];
            aObjValues = new ArrayList();
            aDSValues = null;

            for (int i = 0; i < Count; i++)
            {
                //if (mValArrLst[i].GetType() == typeof(DataSet))
                if (mValArrLst[i] is DataSet)
                {
                    lDSIdxArr.Add(mIdxArrLst[i].ToString());
                    lDSValArr.Add(mValArrLst[i]);
                }
                else
                {
                    aIndexes[lCount] = mIdxArrLst[i].ToString();
                    aObjValues.Add(mValArrLst[i]);
                    lCount++;
                }
            }

            if (lDSIdxArr.Count != 0)
            {
                aDSValues = new DataSet[lDSIdxArr.Count];
                for (int j = 0; j < lDSIdxArr.Count; j++)
                {
                    aIndexes[lCount] = lDSIdxArr[j].ToString();
                    aDSValues[j] = (DataSet)lDSValArr[j];
                    lCount++;
                }
            }
        }
        public void GenStrIdxArr(string[] aIndexes, ArrayList aObjValues, DataSet[] aDSValues)
        {
            int i = 0;
            int j = 0;

            if (Count == 0)
            {
                if (aObjValues != null)
                {
                    for (i = 0; i < aObjValues.Count; i++)
                    {
                        mIdxArrLst.Add(aIndexes[i]);
                        mValArrLst.Add(aObjValues[i]);
                    }
                }

                if (aDSValues != null)
                {
                    for (j = 0; j < aDSValues.Length; j++)
                    {
                        mIdxArrLst.Add(aIndexes[i + j]);
                        mValArrLst.Add(aDSValues[j]);
                    }
                }
            }
            else
            {
                if (aObjValues != null)
                {
                    for (i = 0; i < aObjValues.Count; i++)
                    {
                        mIdxArrLst[i] = aIndexes[i];
                        mValArrLst[i] = aObjValues[i];
                    }
                }

                if (aDSValues != null)
                {
                    for (j = 0; j < aDSValues.Length; j++)
                    {
                        mIdxArrLst[i + j] = aIndexes[i + j];
                        mValArrLst[i + j] = aDSValues[j];
                    }
                }
            }
        }
        #endregion
    }
}
