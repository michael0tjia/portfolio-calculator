﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
namespace Innotelli.Utilities
{
    //TODO: Here
    //TASK: A
    public abstract class TExceptionListener : System.Diagnostics.TraceListener
    {
        public abstract void Write(Exception e);
    }
}
