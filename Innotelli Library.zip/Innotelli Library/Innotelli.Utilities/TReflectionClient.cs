using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections;
using Innotelli.Utilities.ReflectionProxy;

namespace Innotelli.Utilities
{
    public static class TReflectionClient
    {
        #region Members
        private static int mDefaultTimeout = 300000;
        #endregion

        #region Properties
        private static Guid mBOServerID = new Guid("EB40CE04-64AE-417F-BDBD-9FE47DA49562");
        public static Guid BOServerID
        {
            get
            {
                return mBOServerID;
            }
            set
            {
                mBOServerID = value;
            }
        }
        #endregion

        #region Functions

        #region ExecuteMethod
        public static object ExecuteMethod(string aTypeName, string aMethod, TReflectionParams aParameters)
        {
            object lReturnValue = null;
            lReturnValue = ExecuteMethod(aTypeName, aMethod, aParameters, mDefaultTimeout);
            return lReturnValue;
        }
        public static object ExecuteMethod(string aTypeName, string aMethod, TReflectionParams aParameters, int aTimeout)
        {
            object lReturnValue = null;
            string[] lParamNames = null;
            int[] lParamTypes = null;
            object[] lObjectValues = null;
            DataSet[] lDataSetValues = null;

            ReflectionProxySvc lReflectionProxySvc = TReflectionClientFactory.GetDefaultReflectionClient();
            lReflectionProxySvc.Timeout = aTimeout;

            aParameters.GenArraysFromParams(out lParamNames, out lParamTypes, out lObjectValues, out lDataSetValues);
            lReflectionProxySvc.ExecuteMethod(BOServerID, aTypeName, aMethod, ref lParamNames, ref lParamTypes, ref lObjectValues, ref lDataSetValues);
            aParameters.GenParamsFromArrays(lParamNames, lParamTypes, lObjectValues, lDataSetValues);
            lReturnValue = aParameters["ReturnVal"];
           
            return lReturnValue;
        }   
        //WCF Version
        //public static object ExecuteMethod(string aTypeName, string aMethod, TReflectionParams aParameters, int aTimeout)
        //{
        //    object lReturnValue = null;
        //    string[] lParamNames = null;
        //    int[] lParamTypes = null;
        //    object[] lObjectValues = null;
        //    DataSet[] lDataSetValues = null;
        
        //    ReflectionClient lClient = TReflectionClientFactory.GetDefaultReflectionClient();
        //    aParameters.GenArraysFromParams(out lParamNames, out lParamTypes, out lObjectValues, out lDataSetValues);
        //    lClient.Endpoint.Binding.ReceiveTimeout = TimeSpan.FromMilliseconds(aTimeout);
        //    lClient.Open();            
        //    lClient.ExecuteMethod(BOServerID, aTypeName, aMethod, ref lParamNames, ref lParamTypes, ref lObjectValues, ref lDataSetValues);            
        //    lClient.Close();
        //    aParameters.GenParamsFromArrays(lParamNames, lParamTypes, lObjectValues, lDataSetValues);
        //    lReturnValue = aParameters["ReturnVal"];

        //    return lReturnValue;
        //}   
        #endregion

        #endregion
    }
}
