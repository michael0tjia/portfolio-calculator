﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    public class TReflectionException : Exception
    {
        public TReflectionException(string message)
            : base(message)
        {
        }
    }
}
