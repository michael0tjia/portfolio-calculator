using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    [Serializable]
    public class Element //: IDeepCopy
    {
        private object mBOT01 = null;
        private string mTableName = null;
        private string mLinkKeyToChild = null;
        private string mLinkKeyToParent = null;

        public object BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                if (mBOT01 == value)
                    return;
                mBOT01 = value;
            }
        }
        public string TableName
        {
            get
            {
                return mTableName;
            }
            set
            {
                if (mTableName == value)
                    return;
                mTableName = value;
            }
        }
        public string LinkKeyToChild
        {
            get
            {
                return mLinkKeyToChild;
            }
            set
            {
                if (mLinkKeyToChild == value)
                    return;
                mLinkKeyToChild = value;
            }
        }
        public string LinkKeyToParent
        {
            get
            {
                return mLinkKeyToParent;
            }
            set
            {
                if (mLinkKeyToParent == value)
                    return;
                mLinkKeyToParent = value;
            }
        }

#if SupportXmlSerialization
		public Element(){}
        public object BOT01 { get { return mBOT01; } set { mBOT01 = value; } }
		public string TableNm { get { return mTableNm; } set { mTableNm = value; } }
		public string LinkKeyToChild { get { return mLinkKeyToChild; } set { mLinkKeyToChild = value; } }
		public string LinkKeyToParent { get { return mLinkKeyToParent; } set { mLinkKeyToParent = value; } }
#endif

        public Element(object aBuObj, string aTblNm, string aLnkKyToChld)
        {
            mBOT01 = aBuObj;
            mTableName = aTblNm;
            mLinkKeyToChild = aLnkKyToChld;
        }

        public Element(object aBuObj, string aTblNm, string aLnkKyToPrnt, string aLnkKyToChld)
        {
            mBOT01 = aBuObj;
            mTableName = aTblNm;
            mLinkKeyToParent = aLnkKyToPrnt;
            mLinkKeyToChild = aLnkKyToChld;
        }

#if true
        //public Element(Element o)
        //{
        //    _data = o._data + " *COPYCTOR*";
        //}
#endif

        //public override string ToString()
        //{
        //    return _data;
        //}

        //public object CreateDeepCopy()
        //{
        //    return new Element(_data + " *DEEPCOPY*");
        //}
    }
}
