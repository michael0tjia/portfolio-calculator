using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    /// <summary>
    /// Summary description for TCsv
    /// </summary>
    public class TCsv
    {
        private const string cComma = "C0mm@";
        private const string cTerminator = ",";
        private string mIntChgStr;
        private string mLineStr;
        private string mDateFormatStr;
        private string mTimeFormatStr;

        public TCsv()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public string IntChgStr
        {
            get
            {
                return mIntChgStr;
            }
        }

        public string LineStr
        {
            get
            {
                return mLineStr;
            }
        }

        public string DateFormatStr
        {
            get
            {
                return mDateFormatStr;
            }
            set
            {
                mDateFormatStr = value;
            }
        }


        public string TimeFormatStr
        {
            get
            {
                return mTimeFormatStr;
            }
            set
            {
                mTimeFormatStr = value;
            }
        }

        public void AddLine()
        {
            if (mLineStr.Substring(mLineStr.Length - 1, 1) == ",")
            {
                mLineStr = mLineStr.Substring(0, mLineStr.Length - 1);
            }
            mLineStr = mLineStr.Trim();
            mIntChgStr = mIntChgStr + mLineStr + "\r\n";
        }

        //***** This type refers to XML Data Type
        public void AddTagParam(string aTagParam)
        {
            mLineStr = mLineStr + aTagParam + cTerminator;
        }

        public void AddDecimalParam(object aDecimalParam)
        {
            if (!TNull.IsValueNull(aDecimalParam))  //DBNull?
            {
                mLineStr = mLineStr + aDecimalParam.ToString() + cTerminator;
            }
            else
            {
                mLineStr = mLineStr + cTerminator;
            }
        }

        public void AddDateParam(object aDateParam)
        {
            if (!TNull.IsValueNull(aDateParam))  //DBNull?
            {
                mLineStr = mLineStr + ((DateTime)aDateParam).ToString(mDateFormatStr) + cTerminator;
            }
            else
            {
                mLineStr = mLineStr + cTerminator;
            }
        }

        public void AddTimeParam(object aTimeParam)
        {
            if (!TNull.IsValueNull(aTimeParam))
            {
                mLineStr = mLineStr + ((DateTime)aTimeParam).ToString(mTimeFormatStr) + cTerminator;
            }
            else
            {
                mLineStr = mLineStr + cTerminator;
            }
        }

        public void AddStrParam(object aStrParam)
        {
            if (!TNull.IsValueNull(aStrParam))  //DBNull?
            {
                mLineStr = mLineStr + "\"" + CorrectStr(aStrParam.ToString()) + "\"" + cTerminator;
            }
            else
            {
                mLineStr = mLineStr + cTerminator;
            }
        }

        public void IntChgInit()
        {
            mIntChgStr = "";
        }

        public void LineInit()
        {
            mLineStr = "";
        }

        private string CorrectStr(string aStr)
        {
            string returnValue;
            aStr = aStr.Replace("\"", "\'");
            aStr = aStr.Replace("\r\n", " ");
            aStr = aStr.Trim();
            returnValue = aStr;
            return returnValue;
        }

        public bool GetParams(string aInStr, ref string[] aParams, ref int aParamNo)
        {
            bool lReturnValue;
            int i;

            aInStr = ReplaceInBetweenComma(aInStr);
            aParams = aInStr.Split(',');

            for (i = 0; i <= (aParams.Length - 1); i++)
            {
                aParams[i] = aParams[i].Replace(cComma, ",");
                aParams[i] = aParams[i].Replace("\"", "");
                aParams[i] = aParams[i].Trim();
            }

            if ((aParams.Length) == aParamNo)
            {
                lReturnValue = true;
            }
            else
            {
                lReturnValue = false;
            }

            aParamNo = aParams.Length;
            return lReturnValue;
        }

        private string ReplaceInBetweenComma(string aInStr)
        {
            string lReturnValue;
            int i;
            bool lBeginQuote;

            lReturnValue = aInStr;
            lBeginQuote = false;
            for (i = 1; i <= lReturnValue.Length; i++)
            {
                if (lReturnValue.Substring(i - 1, 1) == "\"")
                {
                    if (!lBeginQuote)
                    {
                        lBeginQuote = true;
                    }
                    else
                    {
                        lBeginQuote = false;
                    }
                }
                else if (lReturnValue.Substring(i - 1, 1) == ",")
                {
                    if (lBeginQuote)
                    {
                        lReturnValue = lReturnValue.Substring(0, i - 2) + cComma + lReturnValue.Substring(i);
                    }
                }
            }

            return lReturnValue;
        }
    }
}
