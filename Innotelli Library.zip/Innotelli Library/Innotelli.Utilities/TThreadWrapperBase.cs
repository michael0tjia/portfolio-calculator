﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Innotelli.Utilities
{
    public enum StatusState
    {
        Unstarted, InProgress, Completed
    }
    public abstract class TThreadWrapperBase
    {
        #region Members
        private object mLocker = new object();

        // This is the thread where the task is carried out.
        private Thread mThread;
        #endregion

        #region Constructors
        public TThreadWrapperBase()
        {
        }
        #endregion

        #region Properties
        private Control mInvokeContext = null;
        public Control InvokeContext
        {
            get
            {
                return mInvokeContext;
            }
            set
            {
                mInvokeContext = value;
            }
        }
        // Track the status of the task.
        private StatusState mStatus = StatusState.Unstarted;
        public StatusState Status
        {
            get
            {
                return mStatus;
            }
        }
        // Use a unique ID to track the tasmk later, if needed.
        private Guid mID = Guid.NewGuid();
        public Guid ID
        {
            get
            {
                return mID;
            }
        }
        // Flag that indicates a stop is requested.
        private bool mRequestCancel = false;
        protected bool RequestCancel
        {
            get
            {
                return mRequestCancel;
            }
        }

        // How long the thread will wait (in total)
        // before aborting a thread that hasn't responded to
        // the cancellation message.
        // TimeSpan.Zero means polite stops are not enabled.
        private TimeSpan mCancelWaitTime = TimeSpan.Zero;
        protected TimeSpan CancelWaitTime
        {
            get
            {
                return mCancelWaitTime;
            }
            set
            {
                mCancelWaitTime = value;
            }
        }
        // How often the thread checks to see if a cancellation
        // message has been heeded.
        private int nCancelCheckInterval = 0;
        protected int CancelCheckInterval
        {
            get
            {
                return nCancelCheckInterval;
            }
            set
            {
                nCancelCheckInterval = value;
            }
        }
        // Add Pause and Resume methods here.
        private bool mSupportsProgress = false;
        public bool SupportsProgress
        {
            get
            {
                return mSupportsProgress;
            }
            set
            {
                mSupportsProgress = value;
            }
        }
        protected int mProgress;
        public int Progress
        {
            get
            {
                if (!mSupportsProgress)
                {
                    throw new InvalidOperationException("This worker does not report progess.");
                }
                else
                {
                    return mProgress;
                }
            }
            set
            {
                if (!mSupportsProgress)
                {
                    throw new InvalidOperationException("This worker does not report progess.");
                }
                else
                {
                    mProgress = value;
                    // Fire notification event.
                    if (mInvokeContext != null /*&& mInvokeContext.Created*/)
                    {
                        mInvokeContext.Invoke(new ReportWorkerProgressEventHandler(OnReportWorkerProgress),
                            new object[]{this, 
								new TReportWorkerProgressEventArgs(ID, mProgress, mPartialResult)});
                    }

                }
            }

        }
        // Use this to return result to outside
        private Object mResult;
        public Object Result
        {
            get
            {
                if (Status == StatusState.Completed)
                {
                    return mResult;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                mResult = value;
            }
        }

        private Object mPartialResult;
        public Object PartialResult
        {
            get
            {
                if (Status == StatusState.Completed)
                {
                    return mPartialResult;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                mPartialResult = value;
            }
        }
        #endregion

        #region Event Handlers
        public event ReportWorkerProgressEventHandler ReportWorkerProgress;
        private void OnReportWorkerProgress(object sender, TReportWorkerProgressEventArgs e)
        {
            if (ReportWorkerProgress != null)
            {
                ReportWorkerProgress(sender, e);
            }
        }

        public event WorkerCompletedEventHandler WorkerCompleted;
        private void OnWorkerCompleted(object sender, TWorkerCompletedEventArgs e)
        {
            if (WorkerCompleted != null)
            {
                WorkerCompleted(sender, e);
            }
        }
        #endregion

        #region Functions
        // Start the new operation.
        public void Start()
        {
            lock (mLocker)
            {
                if (mStatus == StatusState.InProgress)
                {
                    throw new InvalidOperationException("Already in progress.");
                }
                else
                {
                    // Initialize the new task.
                    mStatus = StatusState.InProgress;

                    // Create the thread and run it in the background,
                    // so it will terminate automatically if the application ends.
                    mThread = new Thread(StartTaskAsync);
                    mThread.IsBackground = true;
                    mThread.CurrentUICulture = TAppSettings.GetCultureInfoFromSystemLanguage(Innotelli.Utilities.TAppSettings.SystemLanguage);
                    // Start the thread.
                    mThread.Start();
                }
            }
        }

        //Thread Method
        private void StartTaskAsync()
        {
            DoTask();

            lock (mLocker)
            {
                mStatus = StatusState.Completed;
            }


            if (mInvokeContext != null /*&& mInvokeContext.Created*/)
            {
                // Fire notification event.
                mInvokeContext.Invoke(new WorkerCompletedEventHandler(OnWorkerCompleted),
                    new object[] { this, new TWorkerCompletedEventArgs(mID, mResult) });
            }

            mStatus = StatusState.Unstarted;
        }
        public virtual void StopTask()
        {
            // Perform no operation if task isn't running.

            lock (mLocker)
            {
                if (mStatus == StatusState.InProgress)
                {
                    //Try the polite approach.
                    if (mCancelWaitTime != TimeSpan.Zero)
                    {
                        DateTime lStartTime = DateTime.Now;
                        while (DateTime.Now.Subtract(lStartTime).TotalSeconds < mCancelWaitTime.TotalSeconds)
                        {
                            Thread.Sleep(nCancelCheckInterval);
                        }
                    }

                    // Use the forced approach.
                    mThread.Abort();

                    mStatus = StatusState.Unstarted;
                }
            }
        }
        // Override this class to supply the task logic.
        protected abstract void DoTask();
        #endregion
    }
}
