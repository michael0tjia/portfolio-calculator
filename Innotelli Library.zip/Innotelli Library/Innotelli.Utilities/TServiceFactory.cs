using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using System.IO;
using Innotelli.Utilities.ReflectionProxy;

namespace Innotelli.Utilities
{
    public static class TServiceFactory
    {
        #region Members
        private static string mServiceName = "ReflectionProxySvc.asmx";
        private static int mTimeOut = 300;
        private static string mUrl = @"http://localhost/BOServer/";
        #endregion

        #region Constructors

        #endregion

        #region Enums

        #endregion

        #region Properties
        public static string Url
        {
            get 
            {
                return mUrl; 
            }
            set
            {
                mUrl = value;
            }

        }
        public static int TimeOut
        {
            get 
            {
                mTimeOut = int.Parse(ConfigurationManager.AppSettings["TimeOut"].ToString());
                return mTimeOut; 
            }
        }
        public static string ServiceName
        {
            get 
            {
                return mServiceName; 
            }
        }
        #endregion

        #region Event Handlers

        #endregion

        #region Functions
        public static ReflectionProxySvc GetService()
        {
            return GetService(Url, ServiceName, TimeOut);
        }
        public static ReflectionProxySvc GetService(string aUrl, string aServiceName)
        {
            return GetService(aUrl, aServiceName, TimeOut);
        }
        public static ReflectionProxySvc GetService(string aUrl, string aServiceName, int aTimeOut)
        {
            ReflectionProxySvc lReflectionProxySvc = new ReflectionProxySvc();
            lReflectionProxySvc.Url = Path.Combine(aUrl, aServiceName);
            lReflectionProxySvc.Timeout = aTimeOut * 1000;
            return lReflectionProxySvc;
        }
        #endregion
    }
}
