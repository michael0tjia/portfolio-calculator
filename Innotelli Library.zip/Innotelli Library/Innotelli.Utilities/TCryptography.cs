using System;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Xml;
using System.Security.Cryptography.Xml;

namespace Innotelli.Utilities
{
    public class TCryptography
    {
        private Byte[] KEY_64 = { 1, 2, 3, 4, 5, 6, 7, 8 };
        private Byte[] IV_64 = { 8, 7, 6, 5, 4, 3, 2, 1 };
        private byte[] mXMLKey = { 110, 21, 145, 11, 5, 55, 98, 6, 111, 54, 235, 201, 5, 156, 236, 21, 56, 12, 29, 125, 45, 54, 82, 246 };

        // returns DES encrypted string
        public string Encrypt(string value)
        {
            DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, cryptoProvider.CreateEncryptor(KEY_64, IV_64), CryptoStreamMode.Write);
            StreamWriter sw = new StreamWriter(cs);

            sw.Write(value);
            sw.Flush();
            cs.FlushFinalBlock();
            ms.Flush();

            // convert back to a string
            return Convert.ToBase64String(ms.GetBuffer(), 0, Convert.ToInt32(ms.Length));
        }

        // returns DES decrypted string

        public string Decrypt(string value)
        {
            try
            {
                DESCryptoServiceProvider cryptoProvider = new DESCryptoServiceProvider();
                Byte[] buffer = Convert.FromBase64String(value);
                MemoryStream ms = new MemoryStream(buffer);
                CryptoStream cs = new CryptoStream(ms, cryptoProvider.CreateDecryptor(KEY_64, IV_64), CryptoStreamMode.Read);
                StreamReader sr = new StreamReader(cs);

                return sr.ReadToEnd();
            }
            catch
            {
                return "";
            }
        }

        //Set Encrypt & Decrypt Key
        public string RGBKey
        {
            set
            {

                string lLeadChar = "";
                if (value.Length > 8)
                {
                    KEY_64 = ASCIIEncoding.ASCII.GetBytes(TStr.Left(value, 8));
                }
                else if (value.Length < 8)
                {
                    for (int i = 1; i <= (8 - value.Length); i++)
                    {
                        lLeadChar = lLeadChar + "A";
                    }
                    KEY_64 = ASCIIEncoding.ASCII.GetBytes(lLeadChar + value);
                }
                else
                {
                    KEY_64 = ASCIIEncoding.ASCII.GetBytes(value);
                }
               
            }
        }
        public string RGBIV
        {
            set
            {
                string lLeadChar = "";
                if (value.Length > 8)
                {
                    IV_64 = ASCIIEncoding.ASCII.GetBytes(TStr.Left(value, 8));
                }
                else if (value.Length < 8)
                {
                    for (int i = 1; i <= (8 - value.Length); i++)
                    {
                        lLeadChar = lLeadChar + "A";
                    }
                    IV_64 = ASCIIEncoding.ASCII.GetBytes(lLeadChar + value);
                }
                else
                {
                    IV_64 = ASCIIEncoding.ASCII.GetBytes(value);
                }

            }
        }

        public bool EncryptXML(string aSrcFlPth, string aDstFlPth)
        {
            bool lReturnValue = false;
            XmlDocument lXMLDoc = new XmlDocument();
            lXMLDoc.Load(aSrcFlPth);
            lXMLDoc = EncryptXML(lXMLDoc);
            if (lXMLDoc != null)
            {
                lXMLDoc.Save(aDstFlPth);
                lReturnValue = true;
            }

            return lReturnValue;
        }
        public XmlDocument EncryptXML(XmlDocument aXmlDoc)
        {
            XmlDocument lReturnValue = null;

            lReturnValue = new XmlDocument();

            //Create an instance of the encryption algorithm provider
            TripleDESCryptoServiceProvider lTripleDES = new TripleDESCryptoServiceProvider();
            lTripleDES.Key = mXMLKey;

            //Select the XML element you need to encrypt 
            XmlElement lXmlElement = aXmlDoc.DocumentElement;

            //Create an EncryptedXML object 
            EncryptedXml lEncryptedXML = new EncryptedXml(aXmlDoc);

            //Encrypt the element using the encryption algorithm 
            byte[] lEncryptedXmlElement = lEncryptedXML.EncryptData(lXmlElement, lTripleDES, false);

            //Create an encrypted data object and specify its properties
            EncryptedData lEncryptedData = new EncryptedData();
            lEncryptedData.Type = EncryptedXml.XmlEncElementUrl;
            lEncryptedData.EncryptionMethod = new EncryptionMethod(EncryptedXml.XmlEncTripleDESUrl);
            lEncryptedData.CipherData = new CipherData();

            //Assign the encrypted data to the encrypted data object's cipher value
            lEncryptedData.CipherData.CipherValue = lEncryptedXmlElement;

            //Replace the plain text XML element with the encrypted data object 
            EncryptedXml.ReplaceElement(lXmlElement, lEncryptedData, false);

            lReturnValue = aXmlDoc;
            return lReturnValue;
        }

        public bool DecryptXML(string aSrcFlPth, string aDstFlPth)
        {
            bool lReturnValue = false;
            XmlDocument lXMLDoc = new XmlDocument();
            lXMLDoc.Load(aSrcFlPth);
            lXMLDoc = DecryptXML(lXMLDoc);
            if (lXMLDoc != null)
            {
                lXMLDoc.Save(aDstFlPth);
                lReturnValue = true;
            }
            return lReturnValue;
        }
        public XmlDocument DecryptXML(XmlDocument aXmlDoc)
        {
            XmlDocument lReturnValue = null;
            lReturnValue = new XmlDocument();

            //Retrieve the encrypted XML element 
            //#check! 2008/01/23 - carol amended
            //XmlElement lEncryptedXmlElement = (XmlElement)aXmlDoc.GetElementsByTagName("EncryptedData")[0];
            XmlElement lEncryptedXmlElement = (XmlElement)aXmlDoc.GetElementsByTagName("*")[0];

            //Create an encrypted data object 
            EncryptedData lEncryptedData = new EncryptedData();

            //Load the encrypted element into the encrypted data object 
            lEncryptedData.LoadXml(lEncryptedXmlElement);

            //Create an encrypted XML object 
            EncryptedXml lEncryptedXML = new EncryptedXml();

            //Decrypt the element using the key 
            TripleDESCryptoServiceProvider lTripleDES = new TripleDESCryptoServiceProvider();
            lTripleDES.Key = mXMLKey;
            byte[] lDecryptedXmlElement = lEncryptedXML.DecryptData(lEncryptedData, lTripleDES);

            //Replace the encrypted element with the plain-text XML element 
            lEncryptedXML.ReplaceData(lEncryptedXmlElement, lDecryptedXmlElement);

            lReturnValue = aXmlDoc;
            return lReturnValue;
        }
    }
}