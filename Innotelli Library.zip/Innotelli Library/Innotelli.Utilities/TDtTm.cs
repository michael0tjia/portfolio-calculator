﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{

    public class TDtTm
    {
        
        public TDtTm()
        {

        }

        public static string Date(DateTime aDateTime)
        {
            string lRtrnVal = "";

            lRtrnVal = aDateTime.Date.ToString("yyyy/MM/dd");
            
            return lRtrnVal;
        }

        public static string Time(DateTime aDateTime)
        {
            string lRtrnVal = "";

            lRtrnVal = TGC.SpecialDate01 + " " + aDateTime.ToString("HH:mm:ss");
            
            return lRtrnVal;
        }

        public static string DateTime(DateTime aDateTime)
        {
            string lRtrnVal = "";
            
            lRtrnVal = aDateTime.ToString("yyyy/MM/dd HH:mm:ss");
            
            return lRtrnVal;
        }

    }
}
