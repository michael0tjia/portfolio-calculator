using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.UI;

namespace Innotelli.Utilities
{
    public class TCookies
    {
        public TCookies()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        public bool Set(Page aPage, string aCookieName, string aCookieValue, int aDaysToExpire)
        {
            try
            {
                HttpCookie lHttpCookie = new HttpCookie(aCookieName);
                aPage.Response.Cookies.Clear();
                aPage.Response.Cookies.Add(lHttpCookie);
                lHttpCookie.Value = aCookieValue;
                DateTime lExpiryDate = DateTime.Now.AddDays(aDaysToExpire);
                aPage.Response.Cookies[aCookieName].Expires = lExpiryDate;
                return true;
            }
            catch
            {
                return false;
            }
        }
        public string Get(Page aPage, string aCookieName)
        {
            string lCookieValue = "";
            if (aPage.Request.Cookies[aCookieName] != null)
            {
                lCookieValue = aPage.Request.Cookies[aCookieName].Value;
            }
            return lCookieValue;
        }
        public bool Set(MasterPage aPage, string aCookieName, string aCookieValue, int aDaysToExpire)
        {
            try
            {
                HttpCookie lHttpCookie = new HttpCookie(aCookieName);
                aPage.Response.Cookies.Clear();
                aPage.Response.Cookies.Add(lHttpCookie);
                lHttpCookie.Value = aCookieValue;
                DateTime lExpiryDate = DateTime.Now.AddDays(aDaysToExpire);
                aPage.Response.Cookies[aCookieName].Expires = lExpiryDate;
                return true;
            }
            catch
            {
                return false;
            }
        }
        public string Get(MasterPage aPage, string aCookieName)
        {
            string lCookieValue = "";
            if (aPage.Request.Cookies[aCookieName] != null)
            {
                lCookieValue = aPage.Request.Cookies[aCookieName].Value;
            }

            return lCookieValue;
        }
    }
}