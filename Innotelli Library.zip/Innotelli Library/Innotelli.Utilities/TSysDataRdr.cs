using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Text;
using System.IO;
using System.Xml;
using Ionic.Zip;
using System.Reflection;

namespace Innotelli.Utilities
{
    public class TSysDataRdr
    {
        #region Enums
        public enum Formats
        {
            UnencryptedXml,
            EncryptedXml,
            UnencryptedZippedXml,
            EncryptedZippedXml,
        }
        #endregion

        #region Members
        private const string cZipPassword = "P@ssw0rd";
        private Formats mFormat = Formats.UnencryptedXml;
        private bool mIsEncrypted = false;
        #endregion

        #region Constructors

        #endregion

        #region Properties
        private string BaseDirectory
        {
            get
            {
                return Innotelli.Utilities.TGC.BaseDirectory;
            }
        }
        private string mDataFolder = "";
        public string DataFolder
        {
            get
            {
                return mDataFolder;
            }
            set
            {
                mDataFolder = value;
            }
        }
        public Formats Format
        {
            get
            {
                return mFormat;
            }
            set
            {
                mFormat = value;
            }
        }
        private string mFileExtension = "xml";
        public string FileExtension
        {
            get
            {
                return mFileExtension;
            }
            set
            {
                mFileExtension = value;
            }
        }
        public bool IsEncrypted
        {
            get
            {
                return mIsEncrypted;
            }
            set
            {
                mIsEncrypted = value;
            }
        }
        #endregion

        #region Event Handlers

        #endregion

        #region Functions
        public DataSet GetSysData(string aXmlFileName)
        {
            DataSet lReturnValue = null;

            switch (Format)
            {
                case Formats.UnencryptedXml:
                    lReturnValue = GetSysDataByFolder(aXmlFileName);
                    break;
                case Formats.EncryptedZippedXml:
                    lReturnValue = GetSysDataDsByZip(aXmlFileName);
                    break;
            }

            return lReturnValue;
        }
        public XmlDocument GetSysDataXmlDoc(string aXmlFileName)
        {
            XmlDocument lReturnValue = null;

            switch (Format)
            {
                case Formats.UnencryptedXml:
                    //lReturnValue = GetSysDataByFolder(aXmlFileName);
                    break;
                case Formats.EncryptedZippedXml:
                    lReturnValue = GetSysDataXmlDocByZip(aXmlFileName);
                    break;
            }

            return lReturnValue;
        }
        public bool SetSysData(string aXmlFileName, DataSet aDs)
        {
            bool lReturnValue = false;

            if (aDs != null)
            {
                switch (Format)
                {
                    case Formats.UnencryptedXml:
                        lReturnValue = SetSysDataByFolder(aXmlFileName, aDs);
                        break;
                    case Formats.EncryptedZippedXml:
                        //lReturnValue = SetSysDataByZip(aXmlFileName, aDs);
                        break;
                }
            }

            return lReturnValue;
        }
        public MemoryStream GetSysDataMemoryStreamByZip(string aRepxName)
        {
            ZipFile lZipFl = null;
            XmlDocument lXmlDocument = new XmlDocument();
            MemoryStream lMemoryStream = null;
            TCryptography lCryptography = new TCryptography();
            Assembly lAssembly = null;

            aRepxName = aRepxName + ".repx";
            lAssembly = Assembly.Load(Innotelli.Utilities.TGC.SysDataNamespace);
            lZipFl = ZipFile.Read(lAssembly.GetManifestResourceStream(Innotelli.Utilities.TGC.SysDataNamespace + "." + DataFolder + ".zip"));
            if (lZipFl[aRepxName] != null)
            {
                lMemoryStream = new MemoryStream();
                lZipFl[aRepxName].ExtractWithPassword(lMemoryStream, cZipPassword);
            }

            return lMemoryStream;
        }
        private DataSet GetSysDataByFolder(string aXmlFileName)
        {
            DataSet lReturnValue = null;
            string lFullPath = null;

            lFullPath = BaseDirectory + DataFolder + @"\" + aXmlFileName + "." + mFileExtension;
            if (File.Exists(lFullPath))
            {
                lReturnValue = new DataSet();
                lReturnValue.ReadXml(lFullPath, XmlReadMode.ReadSchema);
            }

            return lReturnValue;
        }
        private bool SetSysDataByFolder(string aXmlFileName, DataSet aDs)
        {
            bool lReturnValue = false;
            string lFullPath = null;
            //XmlWriterSettings lXmlWriterSettings = null;
            //XmlWriter lXmlWriter = null;

            lFullPath = BaseDirectory + DataFolder + @"\" + aXmlFileName + "." + mFileExtension;

            //lXmlWriterSettings = new XmlWriterSettings();
            //lXmlWriterSettings.CloseOutput = true;
            //lXmlWriterSettings.Encoding = Encoding.UTF8;
            //lXmlWriterSettings.Indent = true;
            //lXmlWriterSettings.IndentChars = "  ";
            //lXmlWriterSettings.NewLineChars = "\r\n";

            //lXmlWriter = XmlWriter.Create(lFullPath, lXmlWriterSettings);
            //aDs.WriteXml(lXmlWriter, XmlWriteMode.WriteSchema);
            //lXmlWriter.Close();
            //lXmlWriter.Flush();

            aDs.WriteXml(lFullPath, XmlWriteMode.WriteSchema);

            lReturnValue = true;

            return lReturnValue;
        }
        //private XmlDocument GetSysDataXmlDocByZip(string aXmlFileName)
        //{
        //    XmlDocument lReturnValue = null;
        //    ZipFile lZipFl = null;
        //    XmlDocument lXmlDocument = new XmlDocument();
        //    MemoryStream lMemoryStream = null;
        //    TCryptography lCryptography = new TCryptography();
        //    string lZipFileFullPath = null;

        //    aXmlFileName = aXmlFileName + "." + mFileExtension;
        //    lZipFileFullPath = DataFolder + ".zip";
        //    lZipFl = new ZipFile(lZipFileFullPath);

        //    if (lZipFl[aXmlFileName] != null)
        //    {
        //        lMemoryStream = new MemoryStream();
        //        lZipFl[aXmlFileName].ExtractWithPassword(lMemoryStream, cZipPassword);
        //        lMemoryStream.Position = 0;
        //        lXmlDocument.Load(lMemoryStream);
        //        lMemoryStream.Close();
        //        lReturnValue = lCryptography.DecryptXML(lXmlDocument);
        //    }

        //    return lReturnValue;
        //}        
        private XmlDocument GetSysDataXmlDocByZip(string aXmlFileName)
        {
            XmlDocument lReturnValue = null;
            ZipFile lZipFl = null;
            XmlDocument lXmlDocument = new XmlDocument();
            MemoryStream lMemoryStream = null;
            TCryptography lCryptography = new TCryptography();
            Assembly lAssembly = null;

            aXmlFileName = aXmlFileName + "." + mFileExtension;
            lAssembly = Assembly.Load(Innotelli.Utilities.TGC.SysDataNamespace);
            lZipFl = ZipFile.Read(lAssembly.GetManifestResourceStream(Innotelli.Utilities.TGC.SysDataNamespace + "." + DataFolder + ".zip"));
            if (lZipFl[aXmlFileName] != null)
            {
                lMemoryStream = new MemoryStream();
                lZipFl[aXmlFileName].ExtractWithPassword(lMemoryStream, cZipPassword);
                lMemoryStream.Position = 0;
                lXmlDocument.Load(lMemoryStream);
                lMemoryStream.Close();
                lReturnValue = lCryptography.DecryptXML(lXmlDocument);
            }

            return lReturnValue;
        }
        private DataSet GetSysDataDsByZip(string aXmlFileName)
        {
            DataSet lReturnValue = null;
            MemoryStream lMemoryStream = null;
            XmlDocument lXmlDocument = null;

            lXmlDocument = GetSysDataXmlDocByZip(aXmlFileName);
            if (lXmlDocument != null)
            {
                lMemoryStream = new MemoryStream();
                lXmlDocument.Save(lMemoryStream);
                lMemoryStream.Position = 0;
                lReturnValue = new DataSet();
                lReturnValue.ReadXml(lMemoryStream, XmlReadMode.ReadSchema);
                lMemoryStream.Close();
            }
            return lReturnValue;
        }
        #endregion
    }
}
