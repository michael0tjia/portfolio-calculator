using System;
using System.Reflection;
using System.Globalization;
using System.Collections;

namespace Innotelli.Utilities
{
    public class TBinder : Binder
    {
        private MethodBase mMatch = null;
        private string[] mParamName = null;
        private object[] mParamValue = null;
        private Type[] mParamType = null;
        private int mNoOfInputParams = 0;

        public MethodBase Match
        {
            get { return mMatch; }
            set { mMatch = value; }
        }

        public string[] ParamName
        {
            get { return mParamName; }
            set { mParamName = value; }
        }

        public object[] ParamValue
        {
            get { return mParamValue; }
            set { mParamValue = value; }
        }

        public Type[] ParamType
        {
            get { return mParamType; }
            set { mParamType = value; }
        }

        public int NoOfInputParams
        {
            get { return mNoOfInputParams; }
            set { mNoOfInputParams = value; }
        }

        public TBinder() : base()
        {
        }

        private class BinderState
        {
            public object[] args;
            //public Type[] types;
        }

        public override FieldInfo BindToField(
                                                BindingFlags bindingAttr,
                                                FieldInfo[] match,
                                                object value,
                                                CultureInfo culture
                                             )
        {
            if (match == null)
                throw new ArgumentNullException("match");
            // Get a field for which the value parameter can be converted to the specified field type.
            for (int i = 0; i < match.Length; i++)
                if (ChangeType(value, match[i].FieldType, culture) != null)
                    return match[i];
            return null;
        }

        public override MethodBase BindToMethod(
            BindingFlags bindingAttr,
            MethodBase[] match,
            ref object[] lInputArgs,
            ParameterModifier[] modifiers,
            CultureInfo culture,
            string[] lInputNames,
            out object state
            )
        {
            // Store the arguments to the method in a state object.
            BinderState lBinderState = new BinderState();
            object[] lTmpArgs = new Object[lInputArgs.Length];
            lInputArgs.CopyTo(lTmpArgs, 0);
            lBinderState.args = lTmpArgs;
            state = lBinderState;

            //if (Match == null)
            //{
            //    throw new ArgumentNullException();
            //}
            //// Find a method that has the same parameters as those of the InputArgs parameter.
            //for (int i = 0; i < match.Length; i++)
            //{
                // Count the number of parameters that match.
                int count = 0;
                //ParameterInfo[] lMatchedParams = Match.GetParameters();
                //// Go on to the next method if the number of parameters do not match.
                //if (lInputArgs.Length == lMatchedParams.Length)
                //{
                    // Match each of the MatchedParams that the user expects the method to have.
                    for (int j = 0; j < lInputArgs.Length; j++)
                    {
                        //// If the lInputNames parameter is not null, then reorder lInputArgs.
                        //if (lInputNames != null)
                        //{
                        //    if (lInputNames.Length != lInputArgs.Length)
                        //    {
                        //        throw new ArgumentException("InputNames and InputArgs must have the same number of elements.");
                        //    }
                        //    for (int k = 0; k < lInputNames.Length; k++)
                        //    {
                        //        if (String.Compare(lMatchedParams[j].Name, lInputNames[k].ToString()) == 0)
                        //        {
                        //            lInputArgs[k] = lBinderState.args[j];
                        //        }
                        //    }
                        //}
                        //if (lMatchedParams[j].ParameterType == lInputArgs[j].GetType())
                        if (ParamType[j] == lInputArgs[j].GetType())
                        {
                            count++;
                        }
                        else
                        {
                            // Determine whether the lInputTypes specified by the user can be converted to the parameter type.
                            if (Convert.ChangeType(lInputArgs[j], ParamType[j]) != null)
                            {
                                count++;
                            }
                            else
                            {
                                break;
                            }
                        }
                    }
                    // Determine whether the method has been found.
                    if (count == lInputArgs.Length)
                    {
                        //return match[i];
                        return Match;
                    }
                //}
            //}
            return null;
        }

        //public override object ChangeType(
        //    object value,
        //    Type myChangeType,
        //    CultureInfo culture
        //    )
        //{
        //    // Determine whether the value parameter can be converted to a value of type myType.
        //    if (CanConvertFrom(value.GetType(), myChangeType))
        //    {
        //        // Return the converted object.
        //        return Convert.ChangeType(value, myChangeType);
        //    }
        //    else
        //    {
        //        // Return null.
        //        return null;
        //    }
        //}
        public override object ChangeType(
            object value,
            Type myChangeType,
            CultureInfo culture
            )
        {
            object lReturnValue = null;

            // Return the converted object.
            lReturnValue = Convert.ChangeType(value, myChangeType);

            return lReturnValue;
        }

        public override void ReorderArgumentArray(
            ref object[] aArgs,
            object aState
            )
        {
            // Return the args that had been reordered by BindToMethod.
            ((BinderState)aState).args.CopyTo(aArgs, 0);
        }

        public override MethodBase SelectMethod(
            BindingFlags bindingAttr,
            MethodBase[] match,
            Type[] lInputTypes,
            ParameterModifier[] modifiers
            )
        {
            // Store the lInputTypes to the method in a state object.
            //BinderState lBinderState = new BinderState();
            Type lTmpType = null;
            string lTmpName = null;
            object lTmpValue = null;
            Type[] lTmpArgsTypes = new Type[NoOfInputParams];
            string[] lTmpArgsNames = new string[NoOfInputParams];
            object[] lTmpArgsValues = new object[NoOfInputParams];
            //lInputTypes.CopyTo(lTmpArgsTypes, 0);
            //lBinderState.types = lTmpArgsTypes;
            ArrayList lMatchIdx = new ArrayList();
            Type lResultantType = null;

            if (match == null)
            {
                throw new ArgumentNullException("match");
            }
            for (int i = 0; i < match.Length; i++)
            {
                // Count the number of parameters that match.
                int count = 0;
                ParameterInfo[] lMatchedParams = match[i].GetParameters();
                // Go on to the next method if the number of parameters do not match.
                if (NoOfInputParams != lMatchedParams.Length)
                {
                    continue;
                }
                // Match each of the MatchedParams that the user expects the method to have.
                lInputTypes.CopyTo(lTmpArgsTypes, 0);
                ParamName.CopyTo(lTmpArgsNames, 0);
                ParamValue.CopyTo(lTmpArgsValues, 0);
                for (int j = 0; j < lMatchedParams.Length; j++)
                {
                    for (int k = 0; k < NoOfInputParams - j; k++)
                    {
                        if (lTmpArgsNames[k + j] == lMatchedParams[j].Name)
                        {
                            if ((lTmpArgsTypes[k + j] == lMatchedParams[j].ParameterType) || (lMatchedParams[j].ParameterType.IsByRef && lTmpArgsTypes[k + j].FullName == TStr.Left(lMatchedParams[j].ParameterType.FullName, lMatchedParams[j].ParameterType.FullName.Length - 1)))
                            {
                                lTmpType = lTmpArgsTypes[k + j];
                                lTmpArgsTypes[k + j] = lTmpArgsTypes[j];
                                lTmpArgsTypes[j] = lTmpType;

                                lTmpName = lTmpArgsNames[k + j];
                                lTmpArgsNames[k + j] = lTmpArgsNames[j];
                                lTmpArgsNames[j] = lTmpName;

                                lTmpValue = lTmpArgsValues[k + j];
                                lTmpArgsValues[k + j] = lTmpArgsValues[j];
                                lTmpArgsValues[j] = lTmpValue;

                                count++;
                                break;
                            }
                            else
                            {
                                // Determine whether the InputTypes specified by the user can be converted to parameter type.
                                if (CanConvertFrom(lTmpArgsTypes[k + j], lMatchedParams[j].ParameterType, out lResultantType))
                                {
                                    //lInputTypes[j] = lBinderState.types[k];

                                    lTmpArgsTypes[k + j] = lTmpArgsTypes[j];
                                    lTmpArgsTypes[j] = lResultantType;

                                    lTmpName = lTmpArgsNames[k + j];
                                    lTmpArgsNames[k + j] = lTmpArgsNames[j];
                                    lTmpArgsNames[j] = lTmpName;

                                    lTmpValue = Convert.ChangeType(lTmpArgsValues[k + j], lResultantType);
                                    lTmpArgsValues[k + j] = lTmpArgsValues[j];
                                    lTmpArgsValues[j] = lTmpValue;

                                    count++;
                                    break;
                                }
                            }
                        }
                    }
                }
                // Determine whether the method has been found.
                if (count == NoOfInputParams)
                {
                    lTmpArgsTypes.CopyTo(ParamType, 0);
                    lTmpArgsNames.CopyTo(ParamName, 0);
                    lTmpArgsValues.CopyTo(ParamValue, 0);
                    return match[i];
                }
            }

            return null;
        }

        public override PropertyInfo SelectProperty(
            BindingFlags bindingAttr,
            PropertyInfo[] match,
            Type returnType,
            Type[] indexes,
            ParameterModifier[] modifiers
            )
        {
            if (match == null)
                throw new ArgumentNullException("match");
            for (int i = 0; i < match.Length; i++)
            {
                // Count the number of indexes that match.
                int count = 0;
                ParameterInfo[] parameters = match[i].GetIndexParameters();
                // Go on to the next property if the number of indexes do not match.
                if (indexes.Length != parameters.Length)
                    continue;
                // Match each of the indexes that the user expects the property to have.
                for (int j = 0; j < indexes.Length; j++)
                    // Determine whether the lInputTypes specified by the user can be converted to index type.
                    if (CanConvertFrom(indexes[j], parameters[j].ParameterType))
                        count++;
                    else
                        break;
                // Determine whether the property has been found.
                if (count == indexes.Length)
                    // Determine whether the return type can be converted to the properties type.
                    if (CanConvertFrom(returnType, match[i].GetType()))
                        return match[i];
                    else
                        continue;
            }
            return null;
        }

        // Determines whether type1 can be converted to type2. Check only for primitive types.
        private bool CanConvertFrom(Type type1, Type type2)
        {
            if (type1.IsPrimitive && type2.IsPrimitive)
            {
                TypeCode typeCode1 = Type.GetTypeCode(type1);
                TypeCode typeCode2 = Type.GetTypeCode(type2);
                // If both type1 and type2 have the same type, return true.
                if (typeCode1 == typeCode2)
                {
                    return true;
                }
                // Possible conversions from Char follow.
                if (typeCode1 == TypeCode.Char)
                {
                    switch (typeCode2)
                    {
                        case TypeCode.UInt16: return true;
                        case TypeCode.UInt32: return true;
                        case TypeCode.Int32: return true;
                        case TypeCode.UInt64: return true;
                        case TypeCode.Int64: return true;
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from Byte follow.
                if (typeCode1 == TypeCode.Byte)
                {
                    switch (typeCode2)
                    {
                        case TypeCode.Char: return true;
                        case TypeCode.UInt16: return true;
                        case TypeCode.Int16: return true;
                        case TypeCode.UInt32: return true;
                        case TypeCode.Int32: return true;
                        case TypeCode.UInt64: return true;
                        case TypeCode.Int64: return true;
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from SByte follow.
                if (typeCode1 == TypeCode.SByte)
                {
                    switch (typeCode2)
                    {
                        case TypeCode.Int16: return true;
                        case TypeCode.Int32: return true;
                        case TypeCode.Int64: return true;
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from UInt16 follow.
                if (typeCode1 == TypeCode.UInt16)
                {
                    switch (typeCode2)
                    {
                        case TypeCode.UInt32: return true;
                        case TypeCode.Int32: return true;
                        case TypeCode.UInt64: return true;
                        case TypeCode.Int64: return true;
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from Int16 follow.
                if (typeCode1 == TypeCode.Int16)
                {
                    switch (typeCode2)
                    {
                        case TypeCode.Int32: return true;
                        case TypeCode.Int64: return true;
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from UInt32 follow.
                if (typeCode1 == TypeCode.UInt32)
                {
                    switch (typeCode2)
                    {
                        case TypeCode.UInt64: return true;
                        case TypeCode.Int64: return true;
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from Int32 follow.
                if (typeCode1 == TypeCode.Int32)
                {
                    switch (typeCode2)
                    {
                        case TypeCode.Int64: return true;
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from UInt64 follow.
                if (typeCode1 == TypeCode.UInt64)
                {
                    switch (typeCode2)
                    {
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from Int64 follow.
                if (typeCode1 == TypeCode.Int64)
                {
                    switch (typeCode2)
                    {
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from Single follow.
                if (typeCode1 == TypeCode.Single)
                {
                    switch (typeCode2)
                    {
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
            }
            return false;
        }
        private bool CanConvertFrom(Type aTypeFrom, Type aTypeTo, out Type aResultantType)
        {
            aResultantType = aTypeTo;

            if (aTypeFrom.IsPrimitive && aTypeTo.IsPrimitive || aTypeFrom.IsPrimitive && aTypeTo.IsByRef)
            {
                TypeCode lTypeCodeFrom = Type.GetTypeCode(aTypeFrom);
                TypeCode lTypeCodeTo = Type.GetTypeCode(aTypeTo);
                
                if (aTypeTo.IsByRef)
                {
                    aResultantType = Type.GetType(TStr.Left(aTypeTo.FullName, aTypeTo.FullName.Length - 1));
                    lTypeCodeTo = Type.GetTypeCode(aResultantType);
                }

                // If both aTypeFrom and aTypeTo have the same type, return true.
                if (lTypeCodeFrom == lTypeCodeTo)
                {
                    return true;
                }
                // Possible conversions from Char follow.
                if (lTypeCodeFrom == TypeCode.Char)
                {
                    switch (lTypeCodeTo)
                    {
                        case TypeCode.UInt16: return true;
                        case TypeCode.UInt32: return true;
                        case TypeCode.Int32: return true;
                        case TypeCode.UInt64: return true;
                        case TypeCode.Int64: return true;
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from Byte follow.
                if (lTypeCodeFrom == TypeCode.Byte)
                {
                    switch (lTypeCodeTo)
                    {
                        case TypeCode.Char: return true;
                        case TypeCode.UInt16: return true;
                        case TypeCode.Int16: return true;
                        case TypeCode.UInt32: return true;
                        case TypeCode.Int32: return true;
                        case TypeCode.UInt64: return true;
                        case TypeCode.Int64: return true;
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from SByte follow.
                if (lTypeCodeFrom == TypeCode.SByte)
                {
                    switch (lTypeCodeTo)
                    {
                        case TypeCode.Int16: return true;
                        case TypeCode.Int32: return true;
                        case TypeCode.Int64: return true;
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from UInt16 follow.
                if (lTypeCodeFrom == TypeCode.UInt16)
                {
                    switch (lTypeCodeTo)
                    {
                        case TypeCode.UInt32: return true;
                        case TypeCode.Int32: return true;
                        case TypeCode.UInt64: return true;
                        case TypeCode.Int64: return true;
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from Int16 follow.
                if (lTypeCodeFrom == TypeCode.Int16)
                {
                    switch (lTypeCodeTo)
                    {
                        case TypeCode.Int32: return true;
                        case TypeCode.Int64: return true;
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from UInt32 follow.
                if (lTypeCodeFrom == TypeCode.UInt32)
                {
                    switch (lTypeCodeTo)
                    {
                        case TypeCode.UInt64: return true;
                        case TypeCode.Int64: return true;
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from Int32 follow.
                if (lTypeCodeFrom == TypeCode.Int32)
                {
                    switch (lTypeCodeTo)
                    {
                        case TypeCode.Int64: return true;
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from UInt64 follow.
                if (lTypeCodeFrom == TypeCode.UInt64)
                {
                    switch (lTypeCodeTo)
                    {
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from Int64 follow.
                if (lTypeCodeFrom == TypeCode.Int64)
                {
                    switch (lTypeCodeTo)
                    {
                        case TypeCode.Single: return true;
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
                // Possible conversions from Single follow.
                if (lTypeCodeFrom == TypeCode.Single)
                {
                    switch (lTypeCodeTo)
                    {
                        case TypeCode.Double: return true;
                        default: return false;
                    }
                }
            }
            return false;
        }
    }
}
