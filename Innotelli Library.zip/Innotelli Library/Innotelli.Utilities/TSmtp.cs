using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Net.Mail;
using System.Collections;
using System.Text.RegularExpressions;
using System.Diagnostics;

namespace Innotelli.Utilities
{
    /// <summary>
    /// Summary description for TSmtp
    /// </summary>
    public class TSmtp
    {
        public TSmtp()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        // Public Sub Send(ByVal aProfile As String, ByVal aSMTPEmail As String, ByVal aText As String, ByVal aSubject As String, ByVal aAttachFilePath As String)
        public bool SendMail(string aSmtpSvr, string aFromName, string aFromSMTPEmail, string aToSMTPEmail, string aText, string aSubject, out string aErrMsg)
        {
            bool lReturnValue = false;
            aErrMsg = "";
            lReturnValue = SendMail(aSmtpSvr, aFromName, aFromSMTPEmail, aToSMTPEmail, "", "", aText, aSubject, null, out aErrMsg);
            return lReturnValue;
        }
        public bool SendMail(string aSmtpSvr, string aFromName, string aFromSMTPEmail, string aToSMTPEmail, string aText, string aSubject, ArrayList aAttchmntPth, out string aErrMsg)
        {
            bool lReturnValue = false;
            aErrMsg = "";
            lReturnValue = SendMail(aSmtpSvr, aFromName, aFromSMTPEmail, aToSMTPEmail, "", "", aText, aSubject, aAttchmntPth, out aErrMsg);
            return lReturnValue;
        }
        public bool SendMail(string aSmtpSvr, string aFromName, string aFromSMTPEmail, string aToSMTPEmail, string aCcSMTPEmail, string aBccSMTPEmail, string aText, string aSubject, out string aErrMsg)
        {
            bool lReturnValue = false;
            aErrMsg = "";
            lReturnValue = SendMail(aSmtpSvr, aFromName, aFromSMTPEmail, aToSMTPEmail, aCcSMTPEmail, aBccSMTPEmail, aText, aSubject, null, out aErrMsg);
            return lReturnValue;
        }
        public bool SendMail(string aSmtpSvr, string aFromName, string aFromSMTPEmail, string aToSMTPEmail, string aCcSMTPEmail, string aBccSMTPEmail, string aText, string aSubject, ArrayList aAttchmntPth, out string aErrMsg)
        {
            bool lReturnValue = false;
            aErrMsg = "";

            try
            {
                if (IsValidEmailAddr(aFromSMTPEmail))
                {
                    bool lIsRcpntAddrValid = true;
                    SmtpClient lSmtpClient = new SmtpClient();
                    MailMessage lMailMessage = new MailMessage();
                    MailAddress lFromMailAddress = new MailAddress(aFromSMTPEmail, aFromName);
                    string[] lToEmails = new string[10];
                    string[] lCcEmails = new string[10];
                    string[] lBccEmails = new string[10];
                    char[] lSplitter = { ';' };

                    lMailMessage.From = lFromMailAddress;
                    lMailMessage.Subject = aSubject;
                    lMailMessage.IsBodyHtml = false;
                    lMailMessage.Body = aText;
                    if (aAttchmntPth != null)
                    {
                        for (int i = 0; i < aAttchmntPth.Count; i++)
                        {
                            lMailMessage.Attachments.Add(new Attachment(aAttchmntPth[i].ToString()));

                        }
                    }

                    if (aToSMTPEmail != "")
                    {
                        lToEmails = aToSMTPEmail.Split(lSplitter, 10);
                        for (int i = 0; i < lToEmails.Length; i++)
                        {
                            if (IsValidEmailAddr(lToEmails[i]))
                            {
                                lMailMessage.To.Add(lToEmails[i]);
                            }
                            else
                            {
                                lIsRcpntAddrValid = false;
                            }
                        }
                    }

                    if (aCcSMTPEmail != "")
                    {
                        lCcEmails = aCcSMTPEmail.Split(lSplitter, 10);
                        for (int i = 0; i < lCcEmails.Length; i++)
                        {
                            if (IsValidEmailAddr(lCcEmails[i]))
                            {
                                lMailMessage.CC.Add(lCcEmails[i]);
                            }
                            else
                            {
                                lIsRcpntAddrValid = false;
                            }
                        }
                    }

                    if (aBccSMTPEmail != "")
                    {
                        lBccEmails = aBccSMTPEmail.Split(lSplitter, 10);
                        for (int i = 0; i < lBccEmails.Length; i++)
                        {
                            if (IsValidEmailAddr(lBccEmails[i]))
                            {
                                lMailMessage.Bcc.Add(lBccEmails[i]);
                            }
                            else
                            {
                                lIsRcpntAddrValid = false;
                            }
                        }
                    }

                    if (lIsRcpntAddrValid)
                    {
                        lSmtpClient.Host = aSmtpSvr;
                        lSmtpClient.Send(lMailMessage);

                        lReturnValue = true;
                    }
                    else
                    {
                        aErrMsg = "Invalid Email Address";
                    }
                }
            }
            catch (Exception aException)
            {
                EventLog lAppLog = new EventLog();
                lAppLog.Source = "TSMTP";
                lAppLog.WriteEntry("Message : " + aException.Message + "\r\n\r\n" + "StackTrace : " + aException.StackTrace);
            }
            return lReturnValue;
        }
        public bool SendMail(string aSmtpSvr, string aFromDisplayName, string aFromEmail, string aToEmail, string aCcEmail, string aBccEmail, string aText, string aSubject, ArrayList aAttachmentFullPaths, ArrayList aAttachmentFileNames, out string aErrMsg)
        {
            bool lReturnValue = false;
            aErrMsg = "";

            try
            {
                if (IsValidEmailAddr(aFromEmail))
                {
                    bool lIsRcpntAddrValid = true;
                    SmtpClient lSmtpClient = new SmtpClient();
                    MailMessage lMailMessage = new MailMessage();
                    MailAddress lFromMailAddress = new MailAddress(aFromEmail, aFromDisplayName);
                    string[] lToEmails = new string[10];
                    string[] lCcEmails = new string[10];
                    string[] lBccEmails = new string[10];
                    char[] lSplitter = { ';' };
                    Attachment lAttachment = null;

                    lMailMessage.From = lFromMailAddress;
                    lMailMessage.Subject = aSubject;
                    lMailMessage.IsBodyHtml = false;
                    lMailMessage.Body = aText;
                    if (aAttachmentFullPaths != null)
                    {
                        for (int i = 0; i < aAttachmentFullPaths.Count; i++)
                        {
                            lAttachment = new Attachment(aAttachmentFullPaths[i].ToString());
                            lAttachment.Name = aAttachmentFileNames[i].ToString();
                            lMailMessage.Attachments.Add(lAttachment);
                        }
                    }

                    if (aToEmail != "")
                    {
                        lToEmails = aToEmail.Split(lSplitter, 10);
                        for (int i = 0; i < lToEmails.Length; i++)
                        {
                            if (IsValidEmailAddr(lToEmails[i]))
                            {
                                lMailMessage.To.Add(lToEmails[i]);
                            }
                            else
                            {
                                lIsRcpntAddrValid = false;
                            }
                        }
                    }

                    if (aCcEmail != "")
                    {
                        lCcEmails = aCcEmail.Split(lSplitter, 10);
                        for (int i = 0; i < lCcEmails.Length; i++)
                        {
                            if (IsValidEmailAddr(lCcEmails[i]))
                            {
                                lMailMessage.CC.Add(lCcEmails[i]);
                            }
                            else
                            {
                                lIsRcpntAddrValid = false;
                            }
                        }
                    }

                    if (aBccEmail != "")
                    {
                        lBccEmails = aBccEmail.Split(lSplitter, 10);
                        for (int i = 0; i < lBccEmails.Length; i++)
                        {
                            if (IsValidEmailAddr(lBccEmails[i]))
                            {
                                lMailMessage.Bcc.Add(lBccEmails[i]);
                            }
                            else
                            {
                                lIsRcpntAddrValid = false;
                            }
                        }
                    }

                    if (lIsRcpntAddrValid)
                    {
                        lSmtpClient.Host = aSmtpSvr;
                        lSmtpClient.Send(lMailMessage);

                        lReturnValue = true;
                    }
                    else
                    {
                        aErrMsg = "Invalid Email Address";
                    }
                }
            }
            catch (Exception ex)
            {
                TAppLog.LogException(ex);
                EventLog lAppLog = new EventLog();
                lAppLog.Source = "TSMTP";
                lAppLog.WriteEntry("Message : " + ex.Message + "\r\n\r\n" + "StackTrace : " + ex.StackTrace);
            }
            return lReturnValue;
        }

        public static bool IsValidEmailAddr(string aEmailAddr)
        {
            bool lReturnValue = false;
            string lEmlRegex = @"^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}" +
                @"\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\" +
                @".)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$";
            Regex lRegex = new Regex(lEmlRegex);

            if (lRegex.IsMatch(aEmailAddr))
            {
                lReturnValue = true;
            }
            else
            {
                lReturnValue = false;
            }

            return lReturnValue;
        }
    }
}