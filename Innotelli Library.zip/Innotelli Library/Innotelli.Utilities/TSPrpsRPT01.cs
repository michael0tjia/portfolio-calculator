using System.Diagnostics;
using System;
using System.Collections;
using System.Data;
using System.Configuration;

namespace Innotelli.Utilities
{
    public class TSPrpsRPT01
    {
        private string mRptID;
        private TSysDataRdr mSysDataRdr = Innotelli.Utilities.TSingletons.SysData01Rdr;
        
        private const string mSysData = "RPT01";

        public TSPrpsRPT01()
        {
        }

        public TSPrpsRPT01(string aRptID)
        {
            mRptID = aRptID;
        }

        public string RptID
        {
            get
            {
                return mRptID;
            }
            set
            {
                mRptID = value;
            }
        }

        public string RptNm
        {
            get
            {
                return GetSPrps("RptNm", RptID).ToString();
            }
        }

        public long DataPrepType
        {
            get
            {
                return long.Parse(GetSPrps("DataPrepType", RptID).ToString());
            }
        }

        public string AccessSPrcNm
        {
            get
            {
                return GetSPrps("AccessSPrcNm", RptID).ToString();
            }
        }

        public string RrdSrc
        {
            get
            {
                return GetSPrps("RrdSrc", RptID).ToString();
            }
        }

        public string RptAls
        {
            get
            {
                string lReturnValue = string.Empty;

                switch (Innotelli.Utilities.TAppSettings.SystemLanguage)
                {
                    case SystemLanguages.English:
                        lReturnValue = GetSPrps("RptAls", RptID).ToString();
                        break;
                    case SystemLanguages.SimplifiedChinese:
                        lReturnValue = GetSPrps("ReportNameSCh", RptID).ToString();
                        break;
                    case SystemLanguages.TraditionalChinese:
                        lReturnValue = GetSPrps("ReportNameTCh", RptID).ToString();
                        break;
                }

                return lReturnValue;
                
            }
        }
        public string ReportNameTCh
        {
            get
            {

                return GetSPrps("ReportNameTCh", RptID).ToString();
            }
        }
        public string ReportNameSCh
        {
            get
            {

                return GetSPrps("ReportNameSCh", RptID).ToString();
            }
        }
        public string AccssCtlNm
        {
            get
            {
                return GetSPrps("AccssCtlNm", RptID).ToString();
            }
        }
        public string RptNameSpace
        {
            get
            {

                return GetSPrps("RptNameSpace", RptID).ToString();
            }
        }

        public long GetDataPrepType(string aRPT01ID)
        {
            long lReturnValue = 0;
            lReturnValue = long.Parse(GetSPrps("DataPrepType", aRPT01ID).ToString());
            return lReturnValue;
        }

        public string GetAccessSPrcNm(string aRPT01ID)
        {
            string lReturnValue = "";
            lReturnValue = GetSPrps("AccessSPrcNm", aRPT01ID).ToString();
            return lReturnValue;
        }

        public string GetRrdSrc(string aRPT01ID)
        {
            string lReturnValue = "";
            lReturnValue = GetSPrps("RrdSrc", aRPT01ID).ToString();
            return lReturnValue;
        }

        public string GetRptAls(string aRPT01ID)
        {
            string lReturnValue = "";
            lReturnValue = GetSPrps("RptAls", aRPT01ID).ToString();
            return lReturnValue;
        }

        public string GetAccssCtlNm(string aRPT01ID)
        {
            string lReturnValue = "";
            lReturnValue = GetSPrps("AccssCtlNm", aRPT01ID).ToString();
            return lReturnValue;
        }

        private object GetSPrps(string aPrpNm, string aRPT01ID)
        {
            DataSet dsBuObj = new DataSet();
            DataTable dtBuObj = new DataTable();
            DataRow[] foundRow;
            object lPrpVal = null;
            string lExp = "RptNm = '" + aRPT01ID + "'";

            dsBuObj = mSysDataRdr.GetSysData(mSysData);

            foundRow = dsBuObj.Tables[0].Select(lExp);
            lPrpVal = foundRow[0][aPrpNm];

            return lPrpVal;

        }
    }
}


       



