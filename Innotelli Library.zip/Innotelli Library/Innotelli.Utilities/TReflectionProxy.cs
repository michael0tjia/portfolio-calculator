using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;

namespace Innotelli.Utilities
{
    public static class TReflectionProxy
    {        
        #region ExecuteMethod
        public static string GetBOServerConnectionString(Guid aBOServerID)
        {
            string lReturnValue = string.Empty;
            DataTable lDt = null;
            DataView lDv = new DataView();

            TSysDataRdr lSysDataRdr03 = new TSysDataRdr();
            lSysDataRdr03.DataFolder = Innotelli.Utilities.TGC.SYSDATA03_FOLDER_NAME;
            lSysDataRdr03.Format  = TSysDataRdr.Formats.UnencryptedXml;
            lSysDataRdr03.FileExtension = "config";
            lDt = lSysDataRdr03.GetSysData("Sites").Tables[0];
            lDv.Table = lDt;
            lDv.RowFilter = "BOServerID = '" + aBOServerID.ToString() + "'";
            if (lDv.Count == 1)
            {
                lReturnValue = (string)lDv[0]["ConnectionString"];
            }

            return lReturnValue;
        }
        public static void ExecuteMethod(Guid aBOServerID, string aTypeName, string aMethod, ref string[] aParamNames, ref int[] aParamTypes, ref object[] aObjectValues, ref DataSet[] aDataSetValues)
        {   
            TReflection lReflection = new TReflection();
            TReflectionParams lArguments = null;

            Innotelli.Utilities.TAppSettings.DftCnnStr = GetBOServerConnectionString(aBOServerID);
            lArguments = new TReflectionParams();
            lArguments.GenParamsFromArrays(aParamNames, aParamTypes, aObjectValues, aDataSetValues);

            lReflection.ExecuteMethod(aTypeName, aMethod, lArguments);

            lArguments.GenArraysFromParams(out aParamNames, out aParamTypes, out aObjectValues, out aDataSetValues);
            
        }
        #endregion
    }
}
