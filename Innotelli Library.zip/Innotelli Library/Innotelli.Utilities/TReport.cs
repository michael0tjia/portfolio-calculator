using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Xml;
using C1.C1Zip;

namespace Innotelli.Utilities
{
    public class TReport
    {
        public TReport()
        {
        }

        public XmlDocument ExtractXmlDoc(string aZipFlPth, string aRptNm)
        {
            XmlDocument lRtrnVal = new XmlDocument();

            C1ZipFile lZipFl = new C1ZipFile();
            Stream lStrm;
            TCryptography lCrypt = new TCryptography();

            lZipFl.Open(aZipFlPth);
            lZipFl.Password = "P@ssw0rd";
            lStrm = lZipFl.Entries[aRptNm].OpenReader();
            lZipFl.Close();
            lRtrnVal.Load(lStrm);
            lStrm.Close();
            lRtrnVal = lCrypt.DecryptXML(lRtrnVal);

            return lRtrnVal;
        }

        public bool ExtractXmlFile(string aZipFlPth, string aRptNm, string aDstFlPth)
        {
            bool lRtrnVal = false;

            try
            {
                C1ZipFile lZipFl = new C1ZipFile();
                Stream lStrm;
                TCryptography lCrypt = new TCryptography();
                XmlDocument lXmlDoc = new XmlDocument();

                lZipFl.Open(aZipFlPth);
                lZipFl.Password = "P@ssw0rd";
                lStrm = lZipFl.Entries[aRptNm].OpenReader();
                lZipFl.Close();
                lXmlDoc.Load(lStrm);
                lStrm.Close();
                lXmlDoc = lCrypt.DecryptXML(lXmlDoc);
                lXmlDoc.Save(aDstFlPth);

                lRtrnVal = true;
            }
            catch (Exception)
            {
            }

            return lRtrnVal;
        }
    }
}
