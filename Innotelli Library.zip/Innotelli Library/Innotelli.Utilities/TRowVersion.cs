using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    public class TRowVersion
    {
        ulong mVal = 0;

        public TRowVersion()
        {
        }
        public TRowVersion(ulong aVal)
        {
            mVal = aVal;
        }
        public ulong Val
        {
            get
            {
                return mVal;
            }
            set
            {
                mVal = value;
            }
        }
        public void SetValByObj(object aObj)
        {
            byte[] lTmp = { 0, 0, 0, 0, 0, 0, 0, 0 };
            lTmp = (byte[])aObj;
            if (lTmp.Length == 8)
            {
                mVal = ByteArrayTolong(lTmp);
            }
        }
        private string ByteArrayToHexString(byte[] b)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("0x");

            foreach (byte val in b)
            {
                sb.Append(val.ToString("X2"));
            }

            return sb.ToString();
        }
        private ulong ByteArrayTolong(byte[] b)
        {
            ulong lReturnValue = 0;
            string lHexVal = ByteArrayToHexString(b);

            lReturnValue = Convert.ToUInt64(lHexVal, 16);
            return lReturnValue;
        }
    }
}
