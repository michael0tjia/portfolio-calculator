using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    public static class TNull
    {
        public static object Nz(object aVal, object aValIfNull)
        {
            object lReturnValue = null;

            if (aVal == null || aVal == DBNull.Value)
            {
                lReturnValue = aValIfNull;
            }
            else
            {
                lReturnValue = aVal;
            }
            return lReturnValue;
        }
        public static object Nz(object aVal)
        {
            return Nz(aVal, 0);
        }
        
        public static bool IsValueNull(object aVal)
        {
            bool lReturnValue = false;

            if (aVal == null || aVal == DBNull.Value)
            {
                lReturnValue = true;
            }
            else if (aVal is TDbRowID && !((TDbRowID)aVal).HasValue)
            {
                lReturnValue = true;
            }
            else
            {
                lReturnValue = false;
            }
            return lReturnValue;
        }
        // TODO
        // Check if empty case can be removed. Michael
        public static bool IsValueNullOrEmpty(object aVal)
        {
            bool lReturnValue = false;

            if (aVal != null && aVal != DBNull.Value && !string.IsNullOrEmpty(aVal.ToString()))
            {
                lReturnValue = false;
            }
            else
            {
                lReturnValue = true;
            }
            return lReturnValue;
        }
    }

}


