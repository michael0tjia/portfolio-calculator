using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    public enum SystemLanguages
    {
        English,
        TraditionalChinese,
        SimplifiedChinese
    }

    public static class TGC
    {
        public const string PKeyName = "prmykey";
        public const string FKeyName = "prntkey";
        private static string cSpecialDate01 = "1899/12/30"; //Access
        private static string cSpecialDate02 = "1900/1/1"; //T-SQL
        private static string cSpecialTime01 = "HH:mm:ss"; //Access
        private static string cSpecialTime02 = "HH:mm:ss"; //T-SQL
        private static bool mIsRunTime = false;
        private static string mCurrentUserPK = "1";
        private static string mCurrentUserName = "Admin";
        public const string TIMESTAMP_FIELD_NAME = "upsize_ts";
        public const string PROJECT_NAME_SPACE = "BackOffice";
        public const string BO_NAMESPACE_PART = "BO";
        public const string UI_NAMESPACE_PART = "UI";
        public const string REPORT_NAMESPACE_PART = "RptPack";
        public const string SYSDATA_NAMESPACE_PART = "SysData";
        public const string TEST_NAMESPACE_PART = "Test";
        public const string SYSDATA01_FOLDER_NAME = "SysData01";
        public const string SYSDATA02_FOLDER_NAME = "SysData02";
        public const string SYSDATA03_FOLDER_NAME = "SysData03";
        public const string SYSDATA04_FOLDER_NAME = "SysData04";

        //Access
        public static string SpecialDate01
        {
            get
            {
                return cSpecialDate01;
            }
        }
        //T-SQL
        public static string SpecialDate02
        {
            get
            {
                return cSpecialDate02;
            }
        }
        //Access
        public static string SpecialTime01
        {
            get
            {
                return cSpecialTime01;
            }
        }
        //T-SQL
        public static string SpecialTime02
        {
            get
            {
                return cSpecialTime02;
            }
        }
        public static bool IsRunTime
        {
            get
            {
                return mIsRunTime;
            }
            set
            {
                mIsRunTime = value;
            }
        }
        public static string CurrentUserPK
        {
            get
            {
                return mCurrentUserPK;
            }
            set
            {
                mCurrentUserPK = value;
            }
        }
        public static string CurrentUserName
        {
            get
            {
                return mCurrentUserName;
            }
            set
            {
                mCurrentUserName = value;
            }
        }
        public static string SysDataNamespace
        {
            get
            {
                return PROJECT_NAME_SPACE + "." + SYSDATA_NAMESPACE_PART;
            }
        }
        private static string mProjectID;
        public static string ProjectID
        {
            get 
            {
                return mProjectID; 
            }
            set 
            {
                mProjectID = value;
            }
        }

        private static string mBaseDirectory;
        public static string BaseDirectory
        {
            get 
            {
                return mBaseDirectory; 
            }
            set 
            {
                mBaseDirectory = value;
            }
        }
        public static string GetFormNameSpace(string aFormName)
        {
            return aFormName.Substring(0, aFormName.LastIndexOf('.'));
        }
    }
}
