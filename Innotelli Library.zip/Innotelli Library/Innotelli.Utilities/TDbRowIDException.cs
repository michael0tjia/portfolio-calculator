﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    public class TDbRowIDException : Exception
    {
        public TDbRowIDException(string message)
            : base(message)
        {
        }
    }
}
