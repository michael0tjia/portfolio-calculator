using System;
using System.Diagnostics;
using System.IO;
using System.Xml;
using System.Xml.Schema;

namespace Innotelli.Utilities
{
    /// <summary>
    /// Summary description for TXMLSchemaValidtor.
    /// </summary>
    public class TXMLSchemaValidtor
    {
        private string mUrl;
        //private XmlSchemaCollection mXsc;
        private XmlSchemaSet mXss;
        private bool mIsValidXml = true;
        private string mErrMsg = "";

        private void ValidationCallBack(object sender, ValidationEventArgs args)
        {
            mIsValidXml = false;
            mErrMsg = args.Message;
        }
        public TXMLSchemaValidtor(string aNs, string aUrl)
        {
            mUrl = aUrl;
            //mXsc = new XmlSchemaCollection();
            mXss = new XmlSchemaSet();
            mXss.Add(aNs, aUrl);
        }
        public string ErrMsg
        {
            get
            {
                return mErrMsg;
            }
        }
        public bool IsValidXml(string aXmlStr)
        {
            try
            {
                if (aXmlStr == null)
                {
                    mIsValidXml = false;
                }
                else
                {
                    StringReader lSr = new StringReader(aXmlStr);
                    mIsValidXml = IsValidXml(lSr);
                }
            }
            catch (Exception ex)
            {
                mErrMsg = ex.Message;
                mIsValidXml = false;
            }
            finally
            {
            }
            return mIsValidXml;
        }
        public bool IsValidXml(XmlDocument aXmlDoc)
        {
            try
            {
                if (aXmlDoc == null)
                {
                    mIsValidXml = false;
                }
                else
                {
                    StringWriter lSw = new StringWriter();
                    XmlTextWriter lXw = new XmlTextWriter(lSw);
                    aXmlDoc.WriteTo(lXw);
                    string lXmlStr = lSw.ToString();
                    StringReader lSr = new StringReader(lXmlStr);
                    mIsValidXml = IsValidXml(lSr);
                }
            }
            catch (Exception ex)
            {
                mErrMsg = ex.Message;
                mIsValidXml = false;
            }
            finally
            {
            }
            return mIsValidXml;
        }
        public bool IsValidXml(StringReader aXmlSr)
        {
            //carol
            //XmlValidatingReader lXvr = null;
            XmlReader lXmlRdr = null;
            XmlReaderSettings lXmlRdrSttngs = null;
            XmlTextReader lXtr = null;
            
            try
            {
                if (aXmlSr == null)
                {
                    mIsValidXml = false;
                }
                else
                {
                    lXtr = new XmlTextReader(aXmlSr);
                    //carol
                    //lXvr = new XmlValidatingReader(lXtr);
                    //lXvr.ValidationType = ValidationType.Schema;
                    //lXvr.Schemas.Add(mXsc);
                    //lXvr.ValidationEventHandler += new ValidationEventHandler(ValidationCallBack);
                    //while (lXvr.Read()) ;
                    lXmlRdrSttngs = new XmlReaderSettings();
                    lXmlRdrSttngs.Schemas.Add(mXss);
                    lXmlRdrSttngs.ValidationType = ValidationType.Schema;
                    lXmlRdrSttngs.ValidationEventHandler += new ValidationEventHandler(ValidationCallBack);
                    lXmlRdr = XmlReader.Create(lXtr, lXmlRdrSttngs);
                    while (lXmlRdr.Read()) ;
                }
            }
            catch (Exception ex)
            {
                mErrMsg = ex.Message;
                mIsValidXml = false;
            }
            finally
            {
                //#check! - 20080516 - to be modified
                lXtr.Close();
                //lXvr.Close();
                lXmlRdr.Close();
            }
            return mIsValidXml;
        }
    }
}
