﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    public struct TDbRowID
    {
        #region Members
        #endregion

        #region Constructors
        private TDbRowID(int aValue, bool aHasValue)
        {
            mValue = aValue;
            mHasValue = aHasValue;
        }
        #endregion

        #region Properties
        private int mValue;
        public int Value
        {
            get
            {
                if (mHasValue)
                {
                    return mValue;
                }
                else
                {
                    throw new TDbRowIDException("Row ID Value is null!");
                }
            }
            set
            {
                mValue = value;
                mHasValue = true;
            }
        }
        private bool mHasValue;
        public bool HasValue
        {
            get
            {
                return mHasValue;
            }
            set
            {
                mHasValue = value;
            }
        }
        #endregion

        #region Functions
        public override string ToString()
        {
            string lReturnValue = string.Empty;

            if (mHasValue)
            {
                lReturnValue = string.Format("{0}", mValue);
            }

            return lReturnValue;
        }
        public override bool Equals(object obj)
        {
            bool lReturnValue = false;

            if (obj is TDbRowID)
            {
                lReturnValue = ((TDbRowID)obj == this);
            }

            return lReturnValue;
        }

        // TODO: TDbRowID.Value cannot be 0
        public override int GetHashCode()
        {
            int lReturnValue = 0;

            if (mHasValue)
            {
                lReturnValue = mValue;
            }

            return mValue;
        }

        #region Operator Overloading
        public static bool operator ==(TDbRowID aDbRowID1, TDbRowID aDbRowID2)
        {
            bool lReturnValue = false;

            if (aDbRowID1.HasValue && aDbRowID2.HasValue)
            {
                lReturnValue = (aDbRowID1.Value == aDbRowID2.Value);
            }
            else if (!aDbRowID1.HasValue && !aDbRowID2.HasValue)
            {
                lReturnValue = true;
            }

            return lReturnValue;
        }
        public static bool operator !=(TDbRowID aDbRowID1, TDbRowID aDbRowID2)
        {
            bool lReturnValue = false;

            lReturnValue = !(aDbRowID1 == aDbRowID2);

            return lReturnValue;
        }
        public static string operator +(TDbRowID aDbRowID, string aStr)
        {
            string lReturnValue = string.Empty;

            if (aDbRowID.HasValue)
            {
                lReturnValue = aDbRowID.ToString() + aStr;
            }
            else
            {
                throw new TDbRowIDException("Row ID Value is null!");
            }

            return lReturnValue;
        }
        public static string operator +(string aStr, TDbRowID aDbRowID)
        {
            string lReturnValue = string.Empty;

            if (aDbRowID.HasValue)
            {
                lReturnValue = aStr + aDbRowID.ToString();
            }
            else
            {
                throw new TDbRowIDException("Row ID Value is null!");
            }

            return lReturnValue;
        }
        //TODO: To be used later
        public static implicit operator int(TDbRowID aDbRowID)
        {
            int lReturnValue = 0;

            if (aDbRowID.HasValue)
            {
                lReturnValue = aDbRowID.Value;
            }
            else
            {
                throw new TDbRowIDException("Row ID Value is null!");
            }

            return lReturnValue;
        }
        public static implicit operator TDbRowID(int aInt)
        {
            TDbRowID lReturnValue = new TDbRowID(aInt, true);

            return lReturnValue;
        }
        public static implicit operator TDbRowID(int? aInt)
        {
            TDbRowID lReturnValue;

            if (aInt == null)
            {
                lReturnValue = TDbRowID.Null;
            }
            else
            {
                lReturnValue = new TDbRowID(aInt.Value, true);
            }            
            return lReturnValue;
        }
        public static implicit operator string(TDbRowID aDbRowID)
        {
            string lReturnValue = null;

            if (aDbRowID.HasValue)
            {
                lReturnValue = aDbRowID.ToString();
            }

            return lReturnValue;
        }
        public static implicit operator TDbRowID(string aStr)
        {
            TDbRowID lReturnValue;
            int lNumericVal = 0;

            if (!string.IsNullOrEmpty(aStr))
            {
                if (int.TryParse(aStr, out lNumericVal))
                {
                    lReturnValue = new TDbRowID(lNumericVal, true);
                }
                else
                {
                    throw new TDbRowIDException("Invalid Row ID value!");
                }
            }
            else
            {
                lReturnValue = TDbRowID.Null;
            }

            return lReturnValue;
        }
	    #endregion        

        #region Row ID Value is null Representation
        public static TDbRowID Null
        {
            get
            {
                TDbRowID lReturnValue = new TDbRowID(0, false);

                return lReturnValue;
            }
        }        
        #endregion        
        
        #endregion
    }   

}
