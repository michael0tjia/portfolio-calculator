﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    //Numeric Value = Primary Key
    public enum SimpleDataType
    {
        Bool = 98,
        Byte = 99,
        Currency = 103,
        Date = 218,
        DateTime = 104,
        Decimal = 216,
        Double = 106,
        Guid = 220,
        Image = 113,
        Int = 109,
        ItemNumber = 108,
        Long = 227,
        NText = 111,
        NVarChar = 122,
        PercentInteger = 241,
        RowID = 212,
        Short = 117,
        Single = 118,
        Time = 219,
        ValueList = 217
    }
   
    public static class TSimpleDataType
    {
        public static SimpleDataType GetSimpleDataType(Type aType)
        {
            SimpleDataType lReturnValue;

            if (aType == typeof(bool))
            {
                lReturnValue = SimpleDataType.Bool;
            }
            else if (aType == typeof(byte))
            {
                lReturnValue = SimpleDataType.Byte;
            }
            else if (aType == typeof(short))
            {
                lReturnValue = SimpleDataType.Short;
            }
            else if (aType == typeof(int))
            {
                lReturnValue = SimpleDataType.Int;
            }
            else if (aType == typeof(long))
            {
                lReturnValue = SimpleDataType.Long;
            }
            else if (aType == typeof(float))
            {
                lReturnValue = SimpleDataType.Single;
            }
            else if (aType == typeof(double))
            {
                lReturnValue = SimpleDataType.Double;
            }
            else if (aType == typeof(decimal))
            {
                lReturnValue = SimpleDataType.Decimal;
            }
            else if (aType == typeof(string))
            {
                lReturnValue = SimpleDataType.NVarChar;
            }
            else if (aType == typeof(Guid))
            {
                lReturnValue = SimpleDataType.Guid;
            }
            else if (aType == typeof(DateTime))
            {
                lReturnValue = SimpleDataType.DateTime;
            }
            else
            {
                throw new TReflectionException("Data Type " + aType.FullName + " is not supported!");
            }

            return lReturnValue;
        }
        public static SimpleDataTypeCat1s GetCat1(SimpleDataType aSimpleDataType)
        {
            SimpleDataTypeCat1s lReturnValue;

            switch (aSimpleDataType)
            {
                case SimpleDataType.Image:
                    lReturnValue = SimpleDataTypeCat1s.Binary;
                    break;
                case SimpleDataType.Bool:
                    lReturnValue = SimpleDataTypeCat1s.Boolean;
                    break;
                case SimpleDataType.DateTime:
                case SimpleDataType.Date:
                case SimpleDataType.Time:
                    lReturnValue = SimpleDataTypeCat1s.DateTime;
                    break;
                case SimpleDataType.Guid:
                    lReturnValue = SimpleDataTypeCat1s.Guid;
                    break;
                case SimpleDataType.Long:
                case SimpleDataType.ValueList:
                case SimpleDataType.Byte:
                case SimpleDataType.Short:
                case SimpleDataType.Int:
                    lReturnValue = SimpleDataTypeCat1s.Integer;
                    break;
                case SimpleDataType.Currency:
                case SimpleDataType.Decimal:
                    lReturnValue = SimpleDataTypeCat1s.PreciseReal;
                    break;
                case SimpleDataType.NVarChar:
                case SimpleDataType.NText:
                    lReturnValue = SimpleDataTypeCat1s.UnicodeText;
                    break;
                default:
                    lReturnValue = SimpleDataTypeCat1s.Unknown;
                    break;
            }

            return lReturnValue;
        }
    }
}
