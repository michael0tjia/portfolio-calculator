using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    class Template01
    {
        #region Enums
        #endregion

        #region Structures
        #endregion

        #region Members
        #endregion

        #region Constructors
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}
