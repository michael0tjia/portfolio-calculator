using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using System.IO;
using System.Drawing.Imaging;
using System.Drawing;

namespace Innotelli.Utilities
{
    public static class TStr
    {
        public static string RemoveSquareBracket(string aStr)
        {
            string lReturnValue = string.Empty;

            if (aStr.Length > 2 && aStr[0] == '[' && aStr[aStr.Length - 1] == ']')
            {
                lReturnValue = aStr.Substring(1, aStr.Length - 2);
            }
            else
            {
                lReturnValue = aStr;
            }

            return lReturnValue;
        }
        public static string ReplaceInvalidFileNameCharWithMinus(string aInStr)
        {
            aInStr = aInStr.Replace('\\', '-');
            aInStr = aInStr.Replace('/', '-');
            //..... :?"

            return aInStr;
        }
        public static string RemoveLastCharacter(string aInString, string aRemoveCharacter)
        {
            string lReturnValue = string.Empty;

            if (!(string.IsNullOrEmpty(aInString) || string.IsNullOrEmpty(aRemoveCharacter)))
            {
                if (aInString.Substring(aInString.Length - 1) == aRemoveCharacter)
                {
                    lReturnValue = aInString.Substring(0, aInString.LastIndexOf(aRemoveCharacter));
                }
            }
            return lReturnValue;
        }
        public static string Left(string aStr, int aLen)
        {
            string lReturnValue = string.Empty;
            if (aStr.Length <= aLen || aLen < 0)
            {
                lReturnValue = aStr;
            }
            else
            {
                lReturnValue = aStr.Substring(0, aLen);
            }
            return lReturnValue;
        }
        public static string Right(string aStr, int aLen)
        {
            string lReturnValue = string.Empty;
            if (aStr.Length <= aLen || aLen < 0)
            {
                lReturnValue = aStr;
            }
            else
            {
                lReturnValue = aStr.Substring(aStr.Length - aLen, aLen);
            }
            return lReturnValue;
        }
        public static string Mid(string aStr, int aStartIdx, int aLen)
        {
            string lReturnValue = string.Empty;
            if (!string.IsNullOrEmpty(aStr))
            //if (aStr != null && aStr != string.Empty)
            {
                if (aLen >= 0)
                {
                    if (aStartIdx <= aStr.Length - 1)
                    {
                        if (aLen == 0)
                        {
                            lReturnValue = aStr.Substring(aStartIdx, aStr.Length - aStartIdx);
                        }
                        else
                        {
                            if (aStartIdx + aLen > aStr.Length)
                            {
                                aLen = aStr.Length - aStartIdx;
                            }
                            lReturnValue = aStr.Substring(aStartIdx, aLen);
                        }
                    }
                }
            }
            return lReturnValue;
        }
        public static string ReplaceFirstOccurrenceCaseInsensitive(string aStr, string aOldValue, string aNewValue)
        {
            string lReturnValue = aStr;
            int lIndex = -1;

            lIndex = aStr.IndexOf(aOldValue, StringComparison.OrdinalIgnoreCase);
            if (lIndex >= 0)
            {
                lReturnValue = aStr.Substring(0, lIndex) + aNewValue + aStr.Substring(lIndex + aOldValue.Length);
            }

            return lReturnValue;
        }
        public static string TrimExtraSpace(string aStr)
        {
            return Regex.Replace(aStr.Trim(), @"\s+", " ");
        }
        public static string ReplaceWithWordBoundary(string aStr, string aOldValue, string aNewValue)
        {
            return Regex.Replace(aStr, string.Format("{1}{0}{1}|{1}{0}$|^{0}{1}|^{0}$", aOldValue, @"\b"), aNewValue);
        }
        // replace the use of "new string(' ', aNoOfSpace)"
        public static string Space(int aNoOfSpace)
        {
            return new string(' ', aNoOfSpace);
        }

        public static bool IsNumeric(string aSource)
        {
            long lDummy;
            return long.TryParse(aSource, out lDummy);
        }
        public static bool IsDecmial(string aSource)
        {
            decimal lDummy;
            return decimal.TryParse(aSource, out lDummy);
        }
        public static bool IsDateTime(string aSource)
        {
            DateTime lDummy;
            return DateTime.TryParse(aSource, out lDummy);
        }
        public static bool IsNotNullOrEmpty(string aSource)
        {
            return string.IsNullOrEmpty(aSource);
        }
        public static string PascalNamingToPhase(string aSource)
        {
            string lReturnValue = string.Empty;
            StringBuilder lStringBuilder = new StringBuilder(aSource.Length + 12);
            for (int i = 0; i < aSource.Length; i++)
            {
                if (i > 0 && i < aSource.Length - 1 && (
                        Char.IsUpper(aSource[i]) && Char.IsLower(aSource[i + 1]) ||
                        Char.IsUpper(aSource[i]) && Char.IsLower(aSource[i - 1]))
                    )
                {
                    lStringBuilder.Append(" ");
                }
                lStringBuilder.Append(aSource[i]);
            }
            lReturnValue = lStringBuilder.ToString();
            return lReturnValue;
        }
        public static string ImageToBase64(Image aImage)
        {
            using (MemoryStream lMemoryStream = new MemoryStream())
            {
                aImage.Save(lMemoryStream, ImageFormat.Png);
                byte[] imageBytes = lMemoryStream.ToArray();

                return Convert.ToBase64String(imageBytes);
            }
        }
        public static Image Base64ToImage(string aBase64String)
        {
            byte[] lImageBytes = Convert.FromBase64String(aBase64String);
            MemoryStream lMemoryStream = new MemoryStream(lImageBytes, 0, lImageBytes.Length);

            lMemoryStream.Write(lImageBytes, 0, lImageBytes.Length);
            return Image.FromStream(lMemoryStream, true);
        }
    }
}
