﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    //Numeric Value = Primary Key
    public enum BasicDataTypeCat1s
    {
        Boolean	= 1,
        Integer	= 2,
        PreciseReal = 3,
        DateTime = 4,
        Binary = 5,
        Guid = 6,
        UnpreciseReal = 7,
        NonUnicodeText = 8,
        UnicodeText = 9,
        Unknown = 999
    }
    public class TBasicDataTypeCat1
    {

    }
}
