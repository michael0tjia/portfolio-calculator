using System;
using System.Collections;
using System.Data;
using System.Data.OleDb;
using System.Configuration;
using System.IO;
using System.Web;


namespace Innotelli.Utilities
{
    public class TMisc
    {
        public TMisc()
        {
        }
        public static void WriteLog(string aStrLogHeading)
        {
            FileStream lFs = new FileStream(@"C:\" + "Log.txt", FileMode.OpenOrCreate, FileAccess.Write);
            StreamWriter lStreamWriter = new StreamWriter(lFs);

            lStreamWriter.BaseStream.Seek(0, SeekOrigin.End);
            lStreamWriter.WriteLine(aStrLogHeading + System.DateTime.Now.ToString() + " \n");
            lStreamWriter.Flush();
            lStreamWriter.Close();
        }
        public static string IncrementNumber(string aStr)
        {
            string lReturnValue = "";
            string lNumStr = "";
            int lLenA = 0;	//lLenA = lLenB (Left) + lLenC (Right)
            int lLenB = 0;
            int lLenC = 0;
            int I = 0;
            char[] lTmpChrs = aStr.ToCharArray();

            lLenA = aStr.Length;

            for (I = lLenA; I >= 1; I -= 1)
            {
                if (!char.IsNumber(lTmpChrs[I - 1]))
                {
                    break;
                }
            }

            lLenB = I;
            lLenC = lLenA - lLenB;

            lNumStr = aStr.Substring(lLenB, lLenC);
            // use long to handle long string
            lNumStr = (long.Parse(lNumStr) + 1).ToString();

            lReturnValue = aStr.Substring(0, lLenB) + lNumStr.PadLeft(lLenC, '0');
            return lReturnValue;
        }

        public static string DateRangeCriteria(string aDateField, int aSelectedValue)
        {
            string lCriteria;

            switch (aSelectedValue)
            {
                case 0:
                    lCriteria = "";
                    break;
                case 1:
                    lCriteria = " WHERE " + aDateField + " BETWEEN  date() and date() ";
                    break;
                case 2:
                    lCriteria = " WHERE " + aDateField + " BETWEEN  date()-7 and date() ";
                    break;
                case 3:
                    lCriteria = " WHERE " + aDateField + " BETWEEN  date()-14 and date() ";
                    break;
                case 4:
                    lCriteria = " WHERE " + aDateField + " BETWEEN  date()-31 and date() ";
                    break;
                case 5:
                    lCriteria = " WHERE " + aDateField + " BETWEEN  date()-93 and date() ";
                    break;
                case 6:
                    lCriteria = " WHERE " + aDateField + " BETWEEN  date()-365 and date() ";
                    break;
                default:
                    lCriteria = "";
                    break;
            }
            return lCriteria;
        }

        //public static int AddUserRole(string aUserName, string aPassword, string aEmail, string aQuest, string aAnswer, string aRole)
        //{
        //    int lReturnValue = -1;
        //    MembershipCreateStatus lResult;
        //    Membership.CreateUser(aUserName, aPassword, aEmail, aQuest, aAnswer, true, out lResult);
        //    Roles.AddUserToRole(aUserName, aRole);
        //    return lReturnValue;
        //}
        public string GenPassword()
        {
            char[] arrChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+-!@#$%^&()".ToCharArray();
            int lPWLength = 8;
            string stringPassword = null;
            System.Random random = new Random();
            for (int i = 0; i < lPWLength; i++)
            {
                int intRandom = random.Next(arrChars.Length);
                stringPassword += arrChars[intRandom].ToString();
            }
            return stringPassword;
        }
        public static void OpenFileByDftApp(string aFileFullPath) 
        {
            System.Diagnostics.Process lProcess = new System.Diagnostics.Process();
            lProcess.StartInfo.FileName = aFileFullPath;
            lProcess.Start();
        }

    }
}

    


    