using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Data;

namespace Innotelli.Utilities
{
    public enum ReflectionParamTypes
    {
        Bool,
        SByte,
        Byte,
        Short,
        UShort,
        Int,
        UInt,
        Long,
        ULong,
        Char,
        Float,
        Double,
        Decimal,
        String,
        Object,
        Guid,
        DateTime,
        DataSet,
        ByteArray,
        TDbRowID
    }

    public class TReflectionParams
    {
        #region Structures
		public struct Param
        {
            public object Val;
            public Type Type;
        }
	    #endregion

        #region Enums
        #endregion

        #region Members
        private Dictionary<string, object> mValues = new Dictionary<string, object>();
        private Dictionary<string, ReflectionParamTypes> mTypes = new Dictionary<string,ReflectionParamTypes>();
        #endregion

        #region Properties
        public int Count
        {
            get 
            {
                return mValues.Count;
            }
        }
        public Dictionary<string, object> Values
        {
            get 
            {
                return mValues; 
            }
            set 
            {
                mValues = value;
            }
        }
        public Dictionary<string, ReflectionParamTypes> Types
        {
            get 
            {
                return mTypes; 
            }
            set 
            {
                mTypes = value;
            }
        }
        public object this[string aParamName]
        {
            get
            {
                object lReturnValue = null;
                TDbRowID lDbRowID = TDbRowID.Null;
                string[] lStrs = null;

                if (mTypes.ContainsKey(aParamName))
                {
                    if (mTypes[aParamName] == ReflectionParamTypes.TDbRowID)
                    {
                        lStrs = ((string)mValues[aParamName]).Split(':');
                        lDbRowID.Value = int.Parse(lStrs[0]);
                        lDbRowID.HasValue = bool.Parse(lStrs[1]);
                        lReturnValue = lDbRowID;
                    }
                    else
                    {
                        lReturnValue = mValues[aParamName];
                    }
                }
                else
                {
                    throw new TReflectionException("Parameter value cannot be null if parameter type is not yet set!");
                }

                return lReturnValue;
            }
            set
            {
                if (!mTypes.ContainsKey(aParamName) && (value != null))
                {
                    mTypes[aParamName] = GetParamType(value.GetType());
                }
                if (mTypes.ContainsKey(aParamName))
                {
                    if (mTypes[aParamName] == ReflectionParamTypes.TDbRowID)
                    {
                        mValues[aParamName] = ((TDbRowID)value).Value + ":" + ((TDbRowID)value).HasValue.ToString();
                    }
                    else
                    {
                        mValues[aParamName] = value;
                    }
                }
                else
                {
                    throw new TReflectionException("Parameter value cannot be null if parameter type is not yet set!");
                }                                
            }
        }
        #endregion

        #region Constructors
        public TReflectionParams()
        {
        }
        #endregion

        #region Functions
        //New objects created are passed out.
        public void GenArraysFromParams(out string[] aParamNames, out int[] aParamTypes, out object[] aObjectValues, out DataSet[] aDataSetValues)
        {
            ArrayList lDataSetParamNames = new ArrayList();
            ArrayList lDataSetParamValues = new ArrayList();
            ArrayList lObjectValues = new ArrayList();
            int lParamIndex = 0;

            aParamNames = new string[Count];
            aParamTypes = new int[Count];

            foreach(string lParamName in mValues.Keys)
            {
                if (mTypes[lParamName] == ReflectionParamTypes.DataSet)
                {
                    lDataSetParamNames.Add(lParamName);
                    lDataSetParamValues.Add(mValues[lParamName]);
                }
                else
                {
                    aParamNames[lParamIndex] = lParamName;
                    aParamTypes[lParamIndex] = (int)mTypes[lParamName];
                    lObjectValues.Add((mValues[lParamName]));
                    lParamIndex++;
                }
            }
            aObjectValues = lObjectValues.ToArray();

            aDataSetValues = new DataSet[lDataSetParamNames.Count];            

            for (int j = 0; j < lDataSetParamNames.Count; j++)
            {
                aParamNames[lParamIndex] = (string)lDataSetParamNames[j];
                aParamTypes[lParamIndex] = (int)ReflectionParamTypes.DataSet;
                aDataSetValues[j] = (DataSet)lDataSetParamValues[j];
                lParamIndex++;
            }
        }
        public void GenParamsFromArrays(string[] aParamNames, int[] aParamTypes, object[] aObjectValues, DataSet[] aDataSetValues)
        {
            int i = 0;
            int j = 0;

            for (i = 0; i < aObjectValues.Length; i++)
            {
                mTypes[aParamNames[i]] = (ReflectionParamTypes)aParamTypes[i];
                mValues[aParamNames[i]] = aObjectValues[i];
            }
            for (j = 0; j < aDataSetValues.Length; j++)
            {
                mTypes[aParamNames[i + j]] = (ReflectionParamTypes)aParamTypes[i + j];
                mValues[aParamNames[i + j]] = aDataSetValues[j];
            }
        }
        public static Type GetType(ReflectionParamTypes aParmaType)
        {
            Type lReturnValue = null;

            switch (aParmaType)
            {
                case ReflectionParamTypes.Bool:
                    lReturnValue = typeof(bool);
                    break;
                case ReflectionParamTypes.SByte:
                    lReturnValue = typeof(sbyte);
                    break;
                case ReflectionParamTypes.Byte:
                    lReturnValue = typeof(byte);
                    break;
                case ReflectionParamTypes.Short:
                    lReturnValue = typeof(short);
                    break;
                case ReflectionParamTypes.UShort:
                    lReturnValue = typeof(ushort);
                    break;
                case ReflectionParamTypes.Int:
                    lReturnValue = typeof(int);
                    break;
                case ReflectionParamTypes.UInt:
                    lReturnValue = typeof(uint);
                    break;
                case ReflectionParamTypes.Long:
                    lReturnValue = typeof(long);
                    break;
                case ReflectionParamTypes.ULong:
                    lReturnValue = typeof(ulong);
                    break;
                case ReflectionParamTypes.Char:
                    lReturnValue = typeof(char);
                    break;
                case ReflectionParamTypes.Float:
                    lReturnValue = typeof(float);
                    break;
                case ReflectionParamTypes.Double:
                    lReturnValue = typeof(double);
                    break;
                case ReflectionParamTypes.Decimal:
                    lReturnValue = typeof(decimal);
                    break;
                case ReflectionParamTypes.String:
                    lReturnValue = typeof(string);
                    break;
                case ReflectionParamTypes.Object:
                    lReturnValue = typeof(object);
                    break;
                case ReflectionParamTypes.Guid:
                    lReturnValue = typeof(Guid);
                    break;
                case ReflectionParamTypes.DateTime:
                    lReturnValue = typeof(DateTime);
                    break;
                case ReflectionParamTypes.DataSet:
                    lReturnValue = typeof(DataSet);
                    break;
                case ReflectionParamTypes.ByteArray:
                    lReturnValue = typeof(byte[]);
                    break;
                case ReflectionParamTypes.TDbRowID:
                    lReturnValue = typeof(TDbRowID);
                    break;
            }

            return lReturnValue;
        }
        public static ReflectionParamTypes GetParamType(Type aType)
        {
            ReflectionParamTypes lReturnValue;

            if (aType == typeof(bool))
            {
                lReturnValue = ReflectionParamTypes.Bool;
            }
            else if (aType == typeof(sbyte))
            {
                lReturnValue = ReflectionParamTypes.SByte;
            }
            else if (aType == typeof(byte))
            {
                lReturnValue = ReflectionParamTypes.Byte;
            }
            else if (aType == typeof(short))
            {
                lReturnValue = ReflectionParamTypes.Short;
            }
            else if (aType == typeof(ushort))
            {
                lReturnValue = ReflectionParamTypes.UShort;
            }
            else if (aType == typeof(int))
            {
                lReturnValue = ReflectionParamTypes.Int;
            }
            else if (aType == typeof(uint))
            {
                lReturnValue = ReflectionParamTypes.UInt;
            }
            else if (aType == typeof(long))
            {
                lReturnValue = ReflectionParamTypes.Long;
            }
            else if (aType == typeof(ulong))
            {
                lReturnValue = ReflectionParamTypes.ULong;
            }
            else if (aType == typeof(char))
            {
                lReturnValue = ReflectionParamTypes.Char;
            }
            else if (aType == typeof(float))
            {
                lReturnValue = ReflectionParamTypes.Float;
            }
            else if (aType == typeof(double))
            {
                lReturnValue = ReflectionParamTypes.Double;
            }
            else if (aType == typeof(decimal))
            {
                lReturnValue = ReflectionParamTypes.Decimal;
            }
            else if (aType == typeof(string))
            {
                lReturnValue = ReflectionParamTypes.String;
            }
            else if (aType == typeof(object))
            {
                lReturnValue = ReflectionParamTypes.Object;
            }
            else if (aType == typeof(Guid))
            {
                lReturnValue = ReflectionParamTypes.Guid;
            }
            else if (aType == typeof(DateTime))
            {
                lReturnValue = ReflectionParamTypes.DateTime;
            }
            else if (aType == typeof(DataSet))
            {
                lReturnValue = ReflectionParamTypes.DataSet;
            }
            else if (aType == typeof(byte[]))
            {
                lReturnValue = ReflectionParamTypes.ByteArray;
            }
            else if (aType == typeof(TDbRowID))
            {
                lReturnValue = ReflectionParamTypes.TDbRowID;
            }
            else
            {
                throw new TReflectionException("Parameter Type " + aType.FullName + " is not supported!");
            }

            return lReturnValue;
        }
        #endregion
    }
}
