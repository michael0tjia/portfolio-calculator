using System;
using System.Collections;
using System.IO;
using System.Windows.Forms;
//using Innotelli.Utilities.ReflectionService;

namespace Innotelli.Utilities
{
    public class TFileAndDirectory
    {
        public TFileAndDirectory()
        {
        }
        public static void ChkAndCreateDir(string aPath)
        {
            if (!Directory.Exists(aPath))
            {
                Directory.CreateDirectory(aPath);
            }
        }
        public static bool IsFileHiddenOrUsing(string aFlPth)
        {
            bool lReturnValue = true;
            FileInfo lFileInfo = new FileInfo(aFlPth);
            StreamReader lStrmInput;

            if (!lFileInfo.Attributes.ToString().ToLower().Contains("hidden"))
            {
                lStrmInput = new StreamReader(lFileInfo.FullName);
                lReturnValue = false;
            }
            return lReturnValue;
        }

        public static bool IsFileUsing(string aFlPth)
        {
            bool lReturnValue = true;
            StreamReader lStrmInput;

            lStrmInput = new StreamReader(aFlPth);
            lReturnValue = false;
            return lReturnValue;
        }
        public static bool FileUploadCompleted(string filename)
        {
            //
            // If the file can be opened for exclusive access it means that the file
            // is no longer locked by the FTP server program and has completed uploading.
            //
            try
            {
                using (FileStream inputStream = File.Open(filename, FileMode.Open, FileAccess.ReadWrite, FileShare.None))
                {
                    return true;
                }
            }
            catch (IOException)
            {
                return false;
            }
        }
        public static bool WaitForFileToBeReady(string aFullFilePath, int aWaitSeconds)
        {
            bool lReturnValue = false;
            TimeSpan lTimeSpan = new TimeSpan(0);
            DateTime lBegin = DateTime.Now;

            while (!FileUploadCompleted(aFullFilePath))
            {
                lTimeSpan = DateTime.Now.Subtract(lBegin);
                if (lTimeSpan.Seconds > aWaitSeconds)
                {
                    break;
                }
                else
                {
                    Application.DoEvents();
                }
            }
            lReturnValue = !(lTimeSpan.Seconds > aWaitSeconds);

            return lReturnValue;
        }

        public static string CopyFile2(string aSrcFlPth, string aDstFlPth)
        {
            //This method performs to copy a specified file
            //to a specified destination. If the destination
            //have existed the same file name of copied file,
            //this method may rename the copied file name repeatly
            //untill there is an available filename for saving the
            //copied file in the destination.
            //
            //This method will return a new saved file name

            //The parameter aSrcFlPth represents the fullname of original file
            //The parameter aDstFlPth represents ths fullname of copied file

            //The designer: Kenny Cheung
            //Date:         June 13, 2008

            string lReturnValue = null;

            if (aSrcFlPth == "" || aDstFlPth == "")
            {
                return "";
            }

            string lSrcFlPath = aSrcFlPth;
            string lDesFlPath = aDstFlPth;

            //to count how many times the copied filename has existed in the destination
            int lnExisted = 0;

            string ltmpFlPth = lDesFlPath;

            //To divide the fullname structure into two fixed
            //components, including file stored directory component 
            //and file extension component,and one variable component
            //
            //the lDirPth represents the directory element
            //the lFlExt represents the file extension element
            //the ltmpSrcFlName represents the filename element without extension
            string lDirPth = Path.GetDirectoryName(lDesFlPath);
            string lFlExt = Path.GetExtension(lDesFlPath);

            string ltmpFlName = Path.GetFileNameWithoutExtension(ltmpFlPth);
            string ltmpDesFlName = "";

            while (File.Exists(lDesFlPath))
            {
                ltmpDesFlName = "";
                lnExisted++;

                //to create the new filename from three updated elements
                ltmpDesFlName = ltmpFlName + "." + lnExisted.ToString() + lFlExt;
                lDesFlPath = lDirPth + "\\" + ltmpDesFlName;
            }

            File.Copy(lSrcFlPath, lDesFlPath);
            lReturnValue = ltmpFlPth;

            return lReturnValue;
        }

        public static string CopyFile3(string aSrcFlPth, string aDstFlPth)
        {
            //This method performs to copy a specified file
            //to a specified destination. If the destination
            //have existed the same file name of copied file,
            //this method may rename the copied file name repeatly
            //untill there is an available filename for saving the
            //copied file in the destination.
            //
            //This method will return a new saved file name

            //The parameter aSrcFlPth represents the fullname of original file
            //The parameter aDstFlPth represents ths fullname of copied file

            //The designer: Kenny Cheung
            //Date:         June 13, 2008

            string lReturnValue = null;

            if (aSrcFlPth == "" || aDstFlPth == "")
            {
                return "";
            }

            string lSrcFlPath = aSrcFlPth;
            string lDesFlPath = aDstFlPth;

            //to count how many times the copied filename has existed in the destination
            int lnExisted = 0;

            string ltmpFlPth = lDesFlPath;

            //To divide the fullname structure into two fixed
            //components, including file stored directory component 
            //and file extension component,and one variable component
            //
            //the lDirPth represents the directory element
            //the lFlExt represents the file extension element
            //the ltmpSrcFlName represents the filename element without extension
            string lDirPth = Path.GetDirectoryName(lDesFlPath);
            string lFlExt = Path.GetExtension(lDesFlPath);

            string ltmpFlName = Path.GetFileNameWithoutExtension(ltmpFlPth);
            string ltmpDesFlName = "";

            while (File.Exists(lDesFlPath))
            {
                ltmpDesFlName = "";
                lnExisted++;

                //to create the new filename from three updated elements
                ltmpDesFlName = ltmpFlName + "(" + lnExisted.ToString() + ")" + lFlExt;
                lDesFlPath = lDirPth + "\\" + ltmpDesFlName;
            }

            File.Copy(lSrcFlPath, lDesFlPath);
            lReturnValue = ltmpFlPth;

            return lReturnValue;
        }

        // This method accepts two strings the represent two files to 
        // compare. A return value of 0 indicates that the contents of the files
        // are the same. A return value of any other value indicates that the 
        // files are not the same.
        public static bool IsSameFile(string aFile1, string aFile2)
        {
            int lFile1Byte;
            int lFile2Byte;
            FileStream lFileStream1;
            FileStream lFileStream2;

            // Determine if the same file was referenced two times.
            if (aFile1 == aFile2)
            {
                // Return true to indicate that the files are the same.
                return true;
            }

            if (!File.Exists(aFile1) || !File.Exists(aFile2))
            {
                return false;
            }
            // Open the two files.
            lFileStream1 = new FileStream(aFile1, FileMode.Open);
            lFileStream2 = new FileStream(aFile2, FileMode.Open);

            // Check the file sizes. If they are not the same, the files 
            // are not the same.
            if (lFileStream1.Length != lFileStream2.Length)
            {
                // Close the file
                lFileStream1.Close();
                lFileStream2.Close();

                // Return false to indicate files are different
                return false;
            }

            // Read and compare a byte from each file until either a
            // non-matching set of bytes is found or until the end of
            // aFile1 is reached.
            do
            {
                // Read one byte from each file.
                lFile1Byte = lFileStream1.ReadByte();
                lFile2Byte = lFileStream2.ReadByte();
            }
            while ((lFile1Byte == lFile2Byte) && (lFile1Byte != -1));

            // Close the files.
            lFileStream1.Close();
            lFileStream2.Close();

            // Return the success of the comparison. "lFile1Byte" is 
            // equal to "lFile2Byte" at this point only if the files are 
            // the same.
            return ((lFile1Byte - lFile2Byte) == 0);
        }

        public static bool UploadFile(byte[] aFileContent, string aDstFilePath)
        {
            // the byte array argument contains the content of the file
            // the string argument contains the name and extension
            // of the file passed in the byte array
            bool lReturnValue = false;

            // instance a memory stream and pass the
            // byte array to its constructor
            MemoryStream lMemoryStream = new MemoryStream(aFileContent);

            // instance a filestream pointing to the 
            // storage folder, use the original file name
            // to name the resulting file
            //FileStream lFileStream = new FileStream(System.Web.Hosting.HostingEnvironment.MapPath("~/TransientStorage/") + aFileName, FileMode.Create);
            FileStream lFileStream = new FileStream(aDstFilePath, FileMode.Create);

            // write the memory stream containing the original
            // file as a byte array to the filestream
            lMemoryStream.WriteTo(lFileStream);

            // clean up
            lMemoryStream.Close();
            lFileStream.Close();
            lFileStream.Dispose();

            lReturnValue = true;
            return lReturnValue;
        }

        /// <summary>
        /// Upload any file to the web service; this function may be
        /// used in any application where it is necessary to upload
        /// a file through a web service
        /// </summary>
        /// <param name="filename">Pass the file path to upload</param>
        //public static bool SendFileViaWebService(IReflection aReflectionProxySvc,string aSrcFilePath, string aDstFilePath)
        //{
        //    bool lReturnValue = false;
        //    //string[] lIndexes = null;
        //    ArrayList lObjValues = null;
        //    //DataSet[] lDSValues = null;
        //    TReflectionParams lReflectionParams = new TReflectionParams();

        //    // create an instance fo the web service
        //    //ReflectionProxySvc lReflectionProxySvc = TServiceFactory.GetService(aUrl, aServiceName, aTimeOut);

        //    // get the file information form the selected file
        //    FileInfo lFileInfo = new FileInfo(aSrcFilePath);

        //    // get the length of the file to see if it is possible
        //    // to upload it (with the standard 4 MB limit)
        //    long lNumofBytes = lFileInfo.Length;
        //    double lFileSizeInMB = Convert.ToDouble(lFileInfo.Length / 1000000);

        //    // Default limit of 4 MB on web server
        //    // have to change the web.config to if
        //    // you want to allow larger uploads
        //    if (lFileSizeInMB < 4)
        //    {
        //        // set up a file stream and binary reader for the 
        //        // selected file
        //        FileStream lFileStream = new FileStream(aSrcFilePath, FileMode.Open, FileAccess.Read);
        //        BinaryReader lBinaryReader = new BinaryReader(lFileStream);

        //        // convert the file to a byte array
        //        byte[] lData = lBinaryReader.ReadBytes((int)lNumofBytes);
        //        lBinaryReader.Close();

        //        // pass the byte array (file) and file name to the web service
        //        lReflectionParams["aFileContent"] = lData;
        //        lReflectionParams["aDstFilePath"] = aDstFilePath;
        //        //lReflectionParams.GenArrays(ref lIndexes, ref lObjValues, ref lDSValues);
        //        object[] lObjValuesArr = lObjValues.ToArray();
        //        //TReflectionClient.ExecuteMethod("Innotelli.Utilities.TFileAndDirectory", "UploadFile", ref lIndexes, ref lObjValuesArr, ref lDSValues, ref lReturnValue);
        //        //for (int i = 0; i < lObjValuesArr.Length; i++)
        //        //{
        //        //    lObjValues[i] = lObjValuesArr[i];
        //        //}
        //        //lReflectionParams.GenStrIdxArr(lIndexes, lObjValues, lDSValues);

        //        // clean up
        //        lFileStream.Close();
        //        lFileStream.Dispose();
        //    }
        //    return lReturnValue;
        //}

        public static byte[] GetContentFromFile(string aFilePath)
        {
            //This method will be used to get any specified file
            //from the server through web service

            byte[] lReturnValue = null;

            if (File.Exists(aFilePath))
            {
                FileStream lFileStream = null;
                BinaryReader lBinaryReader = null;

                try
                {
                    lFileStream = new FileStream(aFilePath, FileMode.Open, FileAccess.Read);
                    lBinaryReader = new BinaryReader(lFileStream);

                    FileInfo lFileInfo = new FileInfo(aFilePath);

                    // get the length of the file to see if it is possible
                    // to upload it (with the standard 4 MB limit)
                    long lNumofBytes = lFileInfo.Length;

                    // convert the file to a byte array
                    byte[] lData = lBinaryReader.ReadBytes((int)lNumofBytes);

                    lReturnValue = lData;
                }
                finally
                {
                    if (lFileStream != null)
                    {
                        if (lBinaryReader != null)
                        {
                            lBinaryReader.Close();
                        }

                        // clean up
                        lFileStream.Close();
                        lFileStream.Dispose();
                    }   
                }
            }
            
            return lReturnValue;
        }
        public static string SaveContentToFileInTempFolder(byte[] aContent, string aFileName)
        {
            string lReturnValue = string.Empty;
            string lDstFilePath = Path.GetTempPath();

            // instance a memory stream and pass the
            // byte array to its constructor

            MemoryStream lMemoryStream = null;
            FileStream lFileStream = null;
            Guid lDstFilePathGuid = Guid.NewGuid();

            try
            {
                lMemoryStream = new MemoryStream(aContent);

                // instance a filestream pointing to the 
                // storage folder, use the original file name
                // to name the resulting file
                //FileStream lFileStream = new FileStream(System.Web.Hosting.HostingEnvironment.MapPath("~/TransientStorage/") + aFileName, FileMode.Create);

                lDstFilePath += aFileName;
                lFileStream = new FileStream(lDstFilePath, FileMode.Create);

                // write the memory stream containing the original
                // file as a byte array to the filestream
                lMemoryStream.WriteTo(lFileStream);

                lReturnValue = lDstFilePath;
            }
            finally
            {
                // clean up
                if (lMemoryStream != null)
                {
                    if (lFileStream != null)
                    {
                        lFileStream.Close();
                        lFileStream.Dispose();
                    }

                    lMemoryStream.Close();
                    lMemoryStream.Dispose();
                }
            }

            return lReturnValue;
        }
    }
}
