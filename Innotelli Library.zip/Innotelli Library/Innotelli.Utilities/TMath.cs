using System;
using System.Collections.Generic;
using System.Text;
using System.Globalization;

namespace Innotelli.Utilities
{
    public static class TMath
    {
        public static double Round(double aNumToRound)
        {
            return Math.Round(aNumToRound, MidpointRounding.AwayFromZero);
        }

        public static decimal Round(decimal aNumToRound)
        {
            return Math.Round(aNumToRound, MidpointRounding.AwayFromZero);
        }

        public static double Round(double aNumToRound, int aNumOfDec)
        {
            return Math.Round(aNumToRound, aNumOfDec, MidpointRounding.AwayFromZero);
        }

        public static decimal Round(decimal aNumToRound, int aNumOfDec)
        {
            return Math.Round(aNumToRound, aNumOfDec, MidpointRounding.AwayFromZero);
        }
        public static string ConvertCurrencyToText(decimal aAmount)
        {
            string lReturnValue = string.Empty;
            string lText = string.Empty;
            string lCurrFormat = string.Empty;
            int lLowDigit = 0;
            string lCents = string.Empty;
            string lDollars = string.Empty;
            int lDigit1 = 0;
            int lDigit2 = 0;
            int lDigit3 = 0;
            int lDigitCents = 0;
            int lDigitDollars = 0;
            string lSubText = string.Empty;
            int lArrGroupIdx = 0;

            string[] lArrOnes = new string[20];
            string[] lArrTens = new string[10];
            string[] lArrGroup = new string[4];
            string[] lArrSign = new string[2];

            lArrOnes[1] = "ONE";
            lArrOnes[2] = "TWO";
            lArrOnes[3] = "THREE";
            lArrOnes[4] = "FOUR";
            lArrOnes[5] = "FIVE";
            lArrOnes[6] = "SIX";
            lArrOnes[7] = "SEVEN";
            lArrOnes[8] = "EIGHT";
            lArrOnes[9] = "NINE";
            lArrOnes[10] = "TEN";
            lArrOnes[11] = "ELEVEN";
            lArrOnes[12] = "TWELVE";
            lArrOnes[13] = "THIRTEEN";
            lArrOnes[14] = "FOURTEEN";
            lArrOnes[15] = "FIFTEEN";
            lArrOnes[16] = "SIXTEEN";
            lArrOnes[17] = "SEVENTEEN";
            lArrOnes[18] = "EIGHTTEEN";
            lArrOnes[19] = "NINETEEN";
            lArrTens[1] = "TEN";
            lArrTens[2] = "TWENTY";
            lArrTens[3] = "THIRTY";
            lArrTens[4] = "FORTY";
            lArrTens[5] = "FIFTY";
            lArrTens[6] = "SIXTY";
            lArrTens[7] = "SEVENTY";
            lArrTens[8] = "EIGHTY";
            lArrTens[9] = "NINETY";
            lArrGroup[0] = "HUNDRED";
            lArrGroup[1] = "THOUSAND";
            lArrGroup[2] = "MILLION";
            lArrGroup[3] = "BILLION";
            lArrSign[0] = "CENTS";
            lArrSign[1] = "DOLLARS";

            if (aAmount > 0)
            {
                // TODO: Please help OK or not
                //lCurrFormat = VB6.Format(aAmount, "#,###.00")
                lCurrFormat = string.Format("{0:#,##0.00}", aAmount);

                // TODO: Please help OK or not  - has problem
                //lLowDigit  InStr(lCurrFormat, ".") - 1
                lLowDigit = lCurrFormat.IndexOf(".") - 1;
                lDollars = TStr.Left(lCurrFormat, lLowDigit + 1);
                lDigitDollars = int.Parse(lDollars, NumberStyles.AllowThousands);
                lCents = TStr.Mid(lCurrFormat, lLowDigit + 2, 2);
                lDigitCents = int.Parse(lCents);

                while (lLowDigit >= 0)
                {
                    // TODO: Please help OK or not
                    //lDigit3 = CShort(Mid(lCurrFormat, lLowDigit, 1))
                    lDigit3 = int.Parse(TStr.Mid(lCurrFormat, lLowDigit, 1));
                    if (lLowDigit >= 1)
                    {
                        lDigit2 = int.Parse(TStr.Mid(lCurrFormat, lLowDigit - 1, 1));
                    }
                    else
                    {
                        lDigit2 = 0;
                    }
                    if (lLowDigit >= 2)
                    {
                        lDigit1 = int.Parse(TStr.Mid(lCurrFormat, lLowDigit - 2, 1));
                    }
                    else
                    {
                        lDigit1 = 0;
                    }
                    lSubText = "";
                    if (lDigit1 > 0)
                    {
                        lSubText = lArrOnes[lDigit1] + " " + lArrGroup[0] + " ";
                    }
                    if (lDigit2 > 0)
                    {
                        if (lDigit2 == 1)
                        {
                            lSubText = lSubText + lArrOnes[lDigit3 + 10] + " ";
                        }
                        else
                        {
                            lSubText = lSubText + lArrTens[lDigit2];
                            if (lDigit3 > 0)
                            {
                                lSubText = lSubText + "-" + lArrOnes[lDigit3];
                            }

                            lSubText = lSubText + " ";
                        }
                    }
                    else
                    {
                        if (lDigit3 > 0)
                        {
                            lSubText = lSubText + lArrOnes[lDigit3] + " ";
                        }
                    }
                    if ((lSubText != "") && (lArrGroupIdx != 0))
                    {
                        lSubText = lSubText + lArrGroup[lArrGroupIdx] + " ";
                    }
                    lText = lSubText + lText;
                    lLowDigit = lLowDigit - 4;
                    lArrGroupIdx = lArrGroupIdx + 1;
                }
                if (lDigitDollars != 0)
                {
                    lText += lArrSign[1];
                }

                if (lDigitCents != 0)
                {
                    if (lDigitDollars != 0)
                    {
                        lText += " AND";
                    }
                    if (lDigitCents < 20)
                    {
                        lText += " " + lArrOnes[lDigitCents];
                    }
                    else
                    {
                        lText += " " + lArrTens[lDigitCents / 10];
                        if (lDigitCents % 10 != 0)
                        {
                            lText += "-" + lArrOnes[lDigitCents % 10];
                        }
                    }
                    lText += " " + lArrSign[0];
                }
            }
            lText += " " + "ONLY";
            lReturnValue = lText;
            return lReturnValue;

        }
        public static string ConvertCurrencyToText(decimal aAmount, int aLength)
        {
            string lReturnValue = ConvertCurrencyToText(aAmount);

            if (aLength > 0)
            {
                if (lReturnValue.Length <= aLength)
                {
                    for (int i = 1; i <= (aLength - lReturnValue.Length); i++)
                    {
                        lReturnValue += "*";
                    }
                }
            }
            return lReturnValue;
        }
    }
}
