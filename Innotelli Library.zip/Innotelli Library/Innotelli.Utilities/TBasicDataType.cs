﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    //Numeric Value = Primary Key
    public enum BasicDataTypes
    {
        Bool = 1,
        Byte = 2,
        Currency = 4,
        DateTime = 5,
        Double = 6,
        Int = 7,
        Image = 9,
        NText = 8,
        NVarChar = 12,
        Short = 10,
        Single = 11,        
        Decimal = 13,
        Guid = 15,
        Long = 16,
        Date = 17,
        ItemNumber = 18,
        RowID = 19,
        Time = 21,
        ValueList = 22
    }
    
    public static class TBasicDataType
    {
        public static BasicDataTypeCat1s GetCat1(BasicDataTypes aBasicDataTypes)
        {
            BasicDataTypeCat1s lRtrnVal;

            switch (aBasicDataTypes)
            {
                case BasicDataTypes.Image:
                    lRtrnVal = BasicDataTypeCat1s.Binary;
                    break;
                case BasicDataTypes.Bool:
                    lRtrnVal = BasicDataTypeCat1s.Boolean;
                    break;
                case BasicDataTypes.DateTime:
                case BasicDataTypes.Date:
                case BasicDataTypes.Time:
                    lRtrnVal = BasicDataTypeCat1s.DateTime;
                    break;
                case BasicDataTypes.Guid:
                    lRtrnVal = BasicDataTypeCat1s.Guid;
                    break;
                case BasicDataTypes.Long:
                case BasicDataTypes.ValueList:
                case BasicDataTypes.ItemNumber:
                case BasicDataTypes.RowID:
                case BasicDataTypes.Byte:
                case BasicDataTypes.Short:
                case BasicDataTypes.Int:
                    lRtrnVal = BasicDataTypeCat1s.Integer;
                    break;
                case BasicDataTypes.Currency:
                case BasicDataTypes.Decimal:
                    lRtrnVal = BasicDataTypeCat1s.PreciseReal;
                    break;
                case BasicDataTypes.NVarChar:
                case BasicDataTypes.NText:
                    lRtrnVal = BasicDataTypeCat1s.PreciseReal;
                    break;
                default:
                    lRtrnVal = BasicDataTypeCat1s.Unknown;
                    break;
            }

            return lRtrnVal;
        }
    }
}
