using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Reflection;

namespace Innotelli.Utilities
{    
    public class TSqlTraceListener : TraceListener
    {
        private static string mProjectID = string.Empty;
        public static string ProjectID
        {
            get 
            {
                Assembly lAssembly = null;
                Type lType = null;

                if (string.IsNullOrEmpty(mProjectID))
                {
                    if (string.IsNullOrEmpty(mProjectID))
                    {
                        lAssembly = Assembly.Load(TGC.SysDataNamespace);
                        lType = lAssembly.GetType(TGC.SysDataNamespace + "." + "TGC");
                        mProjectID = (string)lType.InvokeMember("PROJECT_ID", BindingFlags.GetField | BindingFlags.Static | BindingFlags.Public, null, null, null);
                    }
                }
                return mProjectID; 
            }
        }
        private string mConnectionString = @"Data Source=mentor\SQL2005;Initial Catalog=K606Db01;Persist Security Info=True;User ID=sa;Password=P@ssw0rd";
        private Exception mException;
        private string mSeverity;
        public TSqlTraceListener()
        {
            InitializeListener();
        }

        public TSqlTraceListener(string name)
            : base(name)
        {
            InitializeListener();
        }

        private void InitializeListener()
        {            
            //mMaxRequest = 5;
        }

        [Conditional("DEBUG")]
        private void SaveErrors()
        {
            SqlConnection objConnection = new SqlConnection(mConnectionString);
            SqlCommand objCommand = new SqlCommand();
            SqlParameterCollection objParameters = objCommand.Parameters;
            objCommand.Connection = objConnection;
            objCommand.CommandText = "AddTrace";
            objCommand.CommandType = CommandType.StoredProcedure;

            objParameters.Add(new SqlParameter("@Computer", SqlDbType.VarChar, 63));
            objParameters[0].Direction = ParameterDirection.Input;
            objParameters[0].Value = Environment.MachineName;

            objParameters.Add(new SqlParameter("@WindowsAccount", SqlDbType.VarChar, 63));
            objParameters[1].Direction = ParameterDirection.Input;
            objParameters[1].Value = System.Security.Principal.WindowsIdentity.GetCurrent().Name;

            objParameters.Add(new SqlParameter("@Source", SqlDbType.VarChar, 127));
            objParameters[2].Direction = ParameterDirection.Input;
            objParameters[2].Value = ProjectID;

            objParameters.Add(new SqlParameter("@Severity", SqlDbType.VarChar, 31));
            objParameters[3].Direction = ParameterDirection.Input;
            objParameters[3].Value = mSeverity;

            objParameters.Add(new SqlParameter("@ProcessName", SqlDbType.VarChar, 63));
            objParameters[4].Direction = ParameterDirection.Input;
            objParameters[4].Value = Process.GetCurrentProcess().ProcessName;

            objParameters.Add(new SqlParameter("@AppDomain", SqlDbType.VarChar, 127));
            objParameters[5].Direction = ParameterDirection.Input;
            objParameters[5].Value = AppDomain.CurrentDomain.FriendlyName;

            objParameters.Add(new SqlParameter("@ExceptionType", SqlDbType.VarChar, 63));
            objParameters[6].Direction = ParameterDirection.Input;
            objParameters[6].Value = mException.GetType().FullName;

            objParameters.Add(new SqlParameter("@Description", SqlDbType.VarChar, 1023));
            objParameters[7].Direction = ParameterDirection.Input;

            objParameters[7].Value = mException.Message;

            objParameters.Add(new SqlParameter("@StackTrace", SqlDbType.VarChar, 2047));
            objParameters[8].Direction = ParameterDirection.Input;
            objParameters[8].Value = mException.ToString();
            try
            {
                objConnection.Open();
                objCommand.ExecuteNonQuery();
            }
            catch
            {
                //throw;
            }
            finally
            {
                if (objConnection != null)
                {
                    if (objConnection.State == ConnectionState.Open)
                        objConnection.Close();
                }
                objConnection = null;
                objCommand = null;
            }
        }

        public override void Write(string aMessage)
        {
            //StackTrace objTrace = new StackTrace(true);
            //AddToCollection(DateTime.Now.ToString(), "", message, objTrace.ToString(), "");
        }

        public override void Write(object o)
        {
            if (o is Exception)
            {
                mException = o as Exception;
            }
        }
        public override void Write(string message, string aCategory)
        {
            //StackTrace objTrace = new StackTrace(true);
            //AddToCollection(DateTime.Now.ToString(), category, message, objTrace.ToString(), "");
        }
        public override void Write(object o, string aSeverity)
        {
            mSeverity = aSeverity;
            if (o is Exception)
            {
                mException = o as Exception;
                //StackTrace objTrace = new StackTrace(true);
                //AddToCollection(DateTime.Now.ToString(), Severity, o.ToString(), objTrace.ToString(), "");
            }
            else
            {

            }
        }
        public override void WriteLine(string aMessage)
        {
            Write(aMessage + "\n");
        }

        public override void WriteLine(object o)
        {
            Write(o.ToString() + "\n");
        }

        public override void WriteLine(string message, string aCategory)
        {
            Write((message + "\n"), aCategory);
        }

        public override void WriteLine(object o, string aCategory)
        {
            Write((o.ToString() + "\n"), aCategory);
        }


        public override void Fail(string aMessage)
        {
            //StackTrace objTrace = new StackTrace(true);
            //AddToCollection(DateTime.Now.ToString(), "Fail", message, objTrace.ToString(), "");
        }

        public override void Fail(string aMessage, string aDetailMessage)
        {
            //StackTrace objTrace = new StackTrace(true);
            //AddToCollection(DateTime.Now.ToString(), "Fail", message, objTrace.ToString(), detailMessage);
        }

        public override void Close()
        {
            SaveErrors();
        }

        public override void Flush()
        {
            SaveErrors();
        }

    }
}
