﻿using System;

namespace Innotelli.Utilities
{
    public enum FileFormats
    {
        Csv,
        Config,        
        Html,
        Mht,
        Pdf,
        Rtf,
        Text,
        Xls,
        Bmp,
        Emf,
        Exif,
        Gif,
        Icon,
        Jpeg,
        MemoryBmp,
        Png,
        Tif,
        Tiff,
        Wmf,

    }
}
