using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.SessionState;

namespace Innotelli.Utilities
{
    public class TCulture
    {
        public TCulture()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public string Get(Page aPage)
        {
            if (aPage.Session["Culture"] == null)
            {
                LocalSetting(aPage);
            }
            return aPage.Session["Culture"].ToString();
        }

        public string Get(MasterPage aPage)
        {
            if (aPage.Session["Culture"] == null)
            {
                LocalSetting(aPage.Page);
            }
            return aPage.Session["Culture"].ToString();
        }

        public void Set(Page aPage, string aCulture)
        {
            TCookies lCookies = new TCookies();

            aPage.Session["Culture"] = aCulture;
            lCookies.Set(aPage, "cookieCulture", aCulture, 100);

            //System.Globalization.CultureInfo ci = new System.Globalization.CultureInfo(aCulture);
            //System.Threading.Thread.CurrentThread.CurrentCulture = ci;
            //System.Threading.Thread.CurrentThread.CurrentUICulture = ci;
        }

        public void Set(MasterPage aPage, string aCulture)
        {
            TCookies lCookies = new TCookies();

            aPage.Session["Culture"] = aCulture;
            lCookies.Set(aPage, "cookieCulture", aCulture, 100);

            //System.Globalization.CultureInfo ci = new System.Globalization.CultureInfo(aCulture);
            //System.Threading.Thread.CurrentThread.CurrentCulture = ci;
            //System.Threading.Thread.CurrentThread.CurrentUICulture = ci;
        }

        public void LocalSetting(Page aPage)
        {
            TCookies lCookies = new TCookies();
            string lCulture = string.Empty;
            if (aPage.Session["Culture"] != null)
            {
                lCulture = aPage.Session["Culture"].ToString();
            }

            if (lCulture == string.Empty)
            {
                lCulture = lCookies.Get(aPage, "cookieCulture");

                if (lCulture == string.Empty)
                {
                    if (aPage.Request.ServerVariables["HTTP_ACCEPT_LANGUAGE"] != null)
                    {
                        lCulture = aPage.Request.ServerVariables["HTTP_ACCEPT_LANGUAGE"];
                        int lEnd = lCulture.IndexOf(';');
                        if (lEnd != -1)
                        {
                            lCulture = lCulture.Substring(0, lEnd);

                            if (lEnd != -1)
                            {
                                lCulture = lCulture.Substring(0, lEnd);
                            }

                            lEnd = lCulture.IndexOf(',');
                            if (lEnd != -1)
                            {
                                lCulture = lCulture.Substring(0, lEnd);
                            }
                        }
                    }

                    if (lCulture != "zh-cn" && lCulture != "zh-tw")
                    {
                        lCulture = "en-us";
                    }
                    lCookies.Set(aPage, "cookieCulture", lCulture, 100);

                }
                aPage.Session["Culture"] = lCulture;
            }

            System.Globalization.CultureInfo ci = new System.Globalization.CultureInfo(lCulture);
            System.Threading.Thread.CurrentThread.CurrentCulture = ci;
            System.Threading.Thread.CurrentThread.CurrentUICulture = ci;
        }
    }
}