﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Reflection;

namespace Innotelli.Utilities
{
    public class TStrResx
    {
        #region Members
        private DataTable mDt = null;
        #endregion

        #region Constructors
        public TStrResx()
        {
            mDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("StrResx").Tables[0];
            mDt.PrimaryKey = new DataColumn[] { mDt.Columns[Utilities.TGC.PKeyName] };
        }
        #endregion

        #region Properties
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }        
        #endregion

        #region Functions
        public string GetStr(int aStrResxPK)
        {
            string lReturnValue = string.Empty;
            DataRow lDr = null;

            try
            {
                if (Innotelli.Utilities.TGC.IsRunTime)
                lDr = mDt.Rows.Find(aStrResxPK);
                switch (Innotelli.Utilities.TAppSettings.SystemLanguage)
                {
                    case SystemLanguages.English:
                        lReturnValue = (string)lDr["Eng"];
                        break;
                    case SystemLanguages.TraditionalChinese:
                        lReturnValue = (string)lDr["TCh"];
                        break;
                    case SystemLanguages.SimplifiedChinese:
                        lReturnValue = (string)lDr["SCh"];
                        break;
                    default:
                        throw new Exception("Invalid Resource String ID: " + aStrResxPK + " used in " + Assembly.GetCallingAssembly().FullName + ".");
                }
            }
            catch
            {
            }
            return lReturnValue;
        }
        #endregion
    }
}
