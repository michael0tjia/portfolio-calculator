﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    public static class TCurrency
    {

    }
}
