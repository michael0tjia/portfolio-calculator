using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    public class TNumberToWord
    {
        public TNumberToWord()
        {
        }
        public string ChangeCurrencyToWords(decimal aVal)
        {
            string lReturnValue = "";
            if ((aVal > 0) && (aVal < 9999999999999))
            {
                lReturnValue = ChangeCurrencyToWords(aVal.ToString());
            }
            else if ((aVal) == 0)
            {
                lReturnValue = "Zero Only***";
            }

            return lReturnValue;
        }
        private string ChangeCurrencyToWords(string lNumStr)
        {
            string lReturnValue = "";
            int intDecPlace;
            int intTotSets;
            int intCntr;
            int intLDollHold;
            int intLDoll;
            string strNumToWd;
            string strNText;
            string strDollars;
            string strCents;
            string strNWord;
            string strTotCents = "";
            string[] strNumParts = new string[10]; //***** Array for curAmount (sets of three)
            string[] strPlace = new string[10]; //***** Array containing place holders

            strPlace[2] = " Thousand ";
            strPlace[3] = " Million ";
            strPlace[4] = " Billion ";
            strPlace[5] = " Trillion ";

            strNumToWd = "";
            strNText = lNumStr.ToString().Trim();
            intDecPlace = strNText.Trim().IndexOf(".", 0); //***** Position of decimal 0 if none
            //strDollars = strNText.Substring(0, (intDecPlace == -1 ? strNumVal.Length : intDecPlace)).Trim();

            strDollars = (TStr.Left(strNText, (intDecPlace == -1 ? lNumStr.Length : intDecPlace))).Trim();
            intLDoll = strDollars.Length;
            strCents = TStr.Right(strNText, (intDecPlace == -1 ? 0 : Math.Abs(intDecPlace - strNText.Length) - 1)).Trim();


            if (strCents.Length == 1)
            {
                strCents = strCents + "0";
            }
            if ((intLDoll % 3) == 0)
            {
                intTotSets = (intLDoll / 3);
            }
            else
            {
                intTotSets = (intLDoll / 3) + 1;
            }
            intCntr = 1;
            intLDollHold = intLDoll;
            while (intLDoll > 0)
            {
                strNumParts[intCntr] = (intLDoll > 3 ? strDollars.Substring(strDollars.Length - 3, 3) : strDollars.Trim());
                strDollars = (intLDoll > 3 ? strDollars.Substring(0, ((intLDoll < 3 ? 3 : intLDoll)) - 3) : "");
                intLDoll = strDollars.Length;
                intCntr = intCntr + 1;
            }
            //for (intCntr = intTotSets; intCntr <= 1; intCntr += -1)
            intCntr = intTotSets;
            while (intCntr >= 1)
            {
                strNWord = GetWord(ref strNumParts[intCntr]); //***** convert 1 element of strNumParts
                strNumToWd = strNumToWd + strNWord; //***** concatenate it to temp variable
                if (strNWord != "")
                {
                    strNumToWd = strNumToWd + strPlace[intCntr];
                }
                intCntr--;
            }
            if (intLDollHold > 0)
            {
                strNumToWd = strNumToWd + " and "; //***** concatenate text
            }
            else
            {
                strNumToWd = strNumToWd + " Zero and "; //***** concatenate text
            }
            if (strCents != "")
            {
                if (strCents.Length > 2)
                {
                    strCents = TStr.Left(strCents, 2);
                }
                strTotCents = GetTens(ref strCents); //***** Convert cents part to word
            }

            if (strTotCents == "")
            {
                strNumToWd = TStr.Left(strNumToWd, strNumToWd.Length - 4) + " Only ***"; //Concat strDollars and strCents
            }
            else
            {

                strNumToWd = strNumToWd + "Cents " + strTotCents + " Only***"; //Concat strDollars and strCents
            }
            lReturnValue = strNumToWd; //***** Assign word strValue to function

            return lReturnValue;
        }
        private string GetDigit(ref string strDigit)
        {
            string lReturnValue = "";

            //***** The following function converts a number from 1 to 9 to text

            switch (int.Parse(strDigit))
            {
                case 1:
                    lReturnValue = "One";
                    break;
                case 2:
                    lReturnValue = "Two";
                    break;
                case 3:
                    lReturnValue = "Three";
                    break;
                case 4:
                    lReturnValue = "Four";
                    break;
                case 5:
                    lReturnValue = "Five";
                    break;
                case 6:
                    lReturnValue = "Six";
                    break;
                case 7:
                    lReturnValue = "Seven";
                    break;
                case 8:
                    lReturnValue = "Eight";
                    break;
                case 9:
                    lReturnValue = "Nine";
                    break;
                default:
                    lReturnValue = "";
                    break;
            }
            return lReturnValue;
        }
        private string GetTens(ref string strTensText)
        {
            string lReturnValue = "";
            //***** The following function converts a number between 10 and 99 to text
            string strTen = "";
            if (int.Parse(strTensText.Substring(0, 1)) == 1) //***** If strTensText between 10-19
            {
                switch (int.Parse(strTensText))
                {
                    case 10:
                        strTen = "Ten";
                        break;
                    case 11:
                        strTen = "Eleven";
                        break;
                    case 12:
                        strTen = "Twelve";
                        break;
                    case 13:
                        strTen = "Thirteen";
                        break;
                    case 14:
                        strTen = "Fourteen";
                        break;
                    case 15:
                        strTen = "Fifteen";
                        break;
                    case 16:
                        strTen = "Sixteen";
                        break;
                    case 17:
                        strTen = "Seventeen";
                        break;
                    case 18:
                        strTen = "Eighteen";
                        break;
                    case 19:
                        strTen = "Nineteen";
                        break;
                    default:
                        break;
                }
            }
            else //***** If strTensText between 20-99
            {
                switch (int.Parse(strTensText.Substring(0, 1)))
                {
                    case 2:
                        strTen = "Twenty ";
                        break;
                    case 3:
                        strTen = "Thirty ";
                        break;
                    case 4:
                        strTen = "Forty ";
                        break;
                    case 5:
                        strTen = "Fifty ";
                        break;
                    case 6:
                        strTen = "Sixty ";
                        break;
                    case 7:
                        strTen = "Seventy ";
                        break;
                    case 8:
                        strTen = "Eighty ";
                        break;
                    case 9:
                        strTen = "Ninety ";
                        break;
                    default:
                        break;
                }
                string lTemp = strTensText.Substring(strTensText.Length - 1, 1);
                strTen = strTen + GetDigit(ref lTemp);
            }
            lReturnValue = strTen;
            return lReturnValue;
        }
        private string GetWord(ref string strNumText)
        {
            string lReturnValue = "";

            short intLen;
            string strWord;

            strWord = "";
            if (strNumText != null)
            {
                if (int.Parse(strNumText) > 0)
                {
                    //***** loop the length of strNumText times
                    for (intLen = 1; intLen <= strNumText.Length; intLen++)
                    {
                        switch (strNumText.Length)
                        {
                            case 3:

                                if (int.Parse(strNumText) > 99)
                                {
                                    string lTemp = strNumText.Substring(0, 1);
                                    strWord = GetDigit(ref lTemp) + " Hundred ";
                                }
                                strNumText = strNumText.Substring(strNumText.Length - 2, 2);
                                break;
                            case 2:

                                strWord = strWord + GetTens(ref strNumText);
                                strNumText = "";
                                break;
                            case 1:

                                strWord = GetDigit(ref strNumText);
                                break;
                            default:

                                break;
                        }
                    }
                }
            }
            lReturnValue = strWord;
            return lReturnValue;
        }
    }
}


