﻿using System;

public static class TDataType
{
    
}