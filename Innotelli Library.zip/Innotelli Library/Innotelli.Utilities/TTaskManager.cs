using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Innotelli.Utilities
{
    public delegate void ReportWorkerProgressEventHandler(object sender, TReportWorkerProgressEventArgs e);
    public delegate void WorkerCompletedEventHandler(object sender, TWorkerCompletedEventArgs e);

    public class TReportWorkerProgressEventArgs : EventArgs
    {
        private object mPartialResult;
        public object PartialResult
        {
            get 
            {
                return mPartialResult; 
            }
            set 
            {
                mPartialResult = value; 
            }
        }

        private int mProgress;
        public int Progress
        {
            get 
            { 
                return mProgress; 
            }
            set
            {
                mProgress = value;
            }
        }
        private Guid mID;
        public Guid ID
        {
            get
            { 
                return mID; 
            }
            set
            {
                mID = value;
            }
        }
        public TReportWorkerProgressEventArgs(Guid aID, int aProgress, object aPartialResult)
        {
            Progress = aProgress;
            PartialResult = aPartialResult;
            ID = aID;
        }
    }
    public class TWorkerCompletedEventArgs : EventArgs
    {
        private object mResult;
        public object Result
        {
            get
            {
                return mResult;
            }
            set
            {
                mResult = value;
            }
        }
        private Guid mID;
        public Guid ID
        {
            get
            {
                return mID;
            }
            set
            {
                mID = value;
            }
        }
        public TWorkerCompletedEventArgs(Guid aID, object aResult)
        {
            Result = aResult;
            mID = aID;
        }
    }	
	public class TTaskManager
    {
        #region Enums
        #endregion

        #region Members
        // Track ongoing workers.
        List<TThreadWrapperBase> mWorkers = new List<TThreadWrapperBase>();

        // Track queued requests.
        List<TThreadWrapperBase> mWorkersQueued = new List<TThreadWrapperBase>();

        // Task completed requests.
        List<TThreadWrapperBase> mWorkersCompleted = new List<TThreadWrapperBase>();
        private Thread mAllocateWork;
        private bool mWorking = false;
        private Control mInvokeContext;
        #endregion

        #region Constructors
        #endregion

        #region Properties
        private int mMaxThreads = 2;
        public int MaxThreads
        {
            get
            {
                return mMaxThreads;
            }
            set
            {
                mMaxThreads = value;
            }
        }
        private int mMonitoringInterval = 500;
        public int MonitoringInterval
        {
            get 
            {
                return mMonitoringInterval; 
            }
            set
            {
                mMonitoringInterval = value;
            }
        }
        #endregion

        #region Event Handlers
        public event ReportWorkerProgressEventHandler ReportWorkerProgress;
        private void OnReportWorkerProgress(object sender, TReportWorkerProgressEventArgs e)
        {
            if (ReportWorkerProgress != null)
            {
                ReportWorkerProgress(sender, e);
            }
        }

        public event WorkerCompletedEventHandler WorkerCompleted;
        private void OnWorkerCompleted(object sender, TWorkerCompletedEventArgs e)
        {
            if (WorkerCompleted != null)
            {
                WorkerCompleted(sender, e);
            }
        }
        #endregion

        #region Functions
        public TThreadWrapperBase[] CompletedTasks
        {
            get
            {
                // To avoid synchronization issues, make a copy of this
                // information.
                TThreadWrapperBase[] taskArray;
                lock (mWorkersCompleted)
                {
                    taskArray = new TThreadWrapperBase[mWorkersCompleted.Count];
                    mWorkersCompleted.CopyTo(taskArray);
                }
                return taskArray;
            }
        }
        public void EnqueueTask(TThreadWrapperBase aTask)
        {
            lock (mWorkersQueued)
            {
                mWorkersQueued.Add(aTask);
            }
        }
        public void StartAllocatingWork(Control aInvokeContext)
        {
            if (mWorking == false)
            {
                mInvokeContext = aInvokeContext;
                mAllocateWork = new Thread(new ThreadStart(AllocateWork));
                mAllocateWork.IsBackground = true;
                //allocateWork.Priority = ThreadPriority.BelowNormal;
                mWorking = true;
                mAllocateWork.Start();
            }
        }
        private void AllocateWork()
        {
            while (true)
            {
                // Remove completed tasks.
                // Because we are not using foreach, the collection
                // doesn't need to be locked. It could grow while this
                // method is working, but that would only result in a
                // slot being missed until the next pass, which is acceptable.
                // It can't shrink, because no other methods remove work.
                // We count in reverse order so a single pass can 
                // remove multiple entries without rearranging the items
                // that haven't been scanned.
                // Deferring the locking improves performance.
                for (int i = mWorkers.Count - 1; i >= 0; i--)
                {
                    if (mWorkers[i].Status == StatusState.Completed)
                    {
                        TThreadWrapperBase worker = mWorkers[i];
                        lock (mWorkersCompleted)
                        {
                            mWorkersCompleted.Add(worker);
                        }
                        lock (mWorkers)
                        {
                            mWorkers.Remove(worker);
                        }
                        // Fire notification event.
                        mInvokeContext.Invoke(new WorkerCompletedEventHandler(OnWorkerCompleted),
                            new object[] { this, new TWorkerCompletedEventArgs(worker.ID, worker.Result) });
                    }
                }

                // Allocate new work while threads are available.
                while (mWorkersQueued.Count > 0 &&
                    mWorkers.Count < mMaxThreads)
                {
                    TThreadWrapperBase task = mWorkersQueued[0];

                    // Some exception handling code here would be useful
                    // to prevent performing one part of this sequence
                    // (starting the task), without the other (removing it
                    // from the queue).
                    lock (mWorkers)
                    {
                        mWorkers.Add(task);
                    }
                    lock (mWorkersQueued)
                    {
                        mWorkersQueued.RemoveAt(0);
                    }
                    task.Start();
                }

                // Report progress.
                for (int i = mWorkers.Count - 1; i >= 0; i--)
                {
                    TThreadWrapperBase worker = mWorkers[i];
                    if (worker.SupportsProgress && worker.Status == StatusState.InProgress)
                    {
                        // Fire notification event.
                        if (mInvokeContext.Created)
                        {
                            mInvokeContext.Invoke(new ReportWorkerProgressEventHandler(OnReportWorkerProgress),
                                new object[]{this, 
								new TReportWorkerProgressEventArgs(worker.ID, worker.Progress, null)});
                        }
                    }
                }

                // Pause 2 seconds before the next pass.
                // You could make this variable configurable.

                Thread.Sleep(TimeSpan.FromMilliseconds(mMonitoringInterval));
            }
        }
        public void StopAllTasks()
        {
            // Stop the work allocator.
            mAllocateWork.Abort();
            // Make sure it's finished.
            mAllocateWork.Join();

            // Stop the tasks.
            foreach (TThreadWrapperBase worker in mWorkers)
            {
                worker.StopTask();
            }
        }
        #endregion
	}
}