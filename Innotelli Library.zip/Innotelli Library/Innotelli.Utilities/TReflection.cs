using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Globalization;
using Innotelli.Utilities;


namespace Innotelli.Utilities
{
    public class TReflection
    {
        #region Constructors
        public TReflection()
        {
        }
        #endregion

        #region Properties
        private string DLLFolder
        {
            get
            {
                return Innotelli.Utilities.TGC.BaseDirectory;
            }
        }
        #endregion

        #region Functions
        private string GetDLLFileNameFromTypeName(string aTypeName)
        {
            //#assume! one dll file, one namespace
            string lReturnValue = aTypeName.Substring(0, aTypeName.LastIndexOf(".")) + ".dll";
            return lReturnValue;
        }        
        private Assembly GetAssemblyByTypeName(string aTypeName)
        {
            Assembly lReturnValue;
            string lLocation = "";

            lLocation = DLLFolder + "\\" + GetDLLFileNameFromTypeName(aTypeName);
            lReturnValue = Assembly.LoadFrom(lLocation);
            if (lReturnValue == null)
            {
                throw new Exception("Could not find assembly");
            }
            return lReturnValue;
        }
        public Type GetType(Assembly aAssembly, string aTypeName)
        {
            Type lReturnValue = null;
            lReturnValue = aAssembly.GetType(aTypeName);
            if (lReturnValue == null)
            {
                throw new Exception("Could not find type!");
            }
            return lReturnValue;
        }
        private object CreateInstance(Assembly aAssembly, string aTypeName)
        {
            object lReturnValue = null;

            lReturnValue = aAssembly.CreateInstance(aTypeName);
            if (lReturnValue == null)
                throw new Exception("Could not create object instance");

            return lReturnValue;
        }
        public object CreateInstance(string aTypeName)
        {
            object lReturnValue = null;
            Assembly lAssembly = GetAssemblyByTypeName(aTypeName);

            lReturnValue = lAssembly.CreateInstance(aTypeName);

            return lReturnValue;
        }
        public void ExecuteMethod(string aTypeName, string aMethod, TReflectionParams aReflectionParameters)
        {
            object lReturnValue = null;

            int lNoOfInptArgs = aReflectionParameters.Count;
            MethodInfo lMethodInfo;
            Type[] lArgsTpLst;
            TBinder lBinder = new TBinder();
            Assembly lAssembly = GetAssemblyByTypeName(aTypeName);
            Type lType = GetType(lAssembly, aTypeName);
            object lInstance = null;
            int i = 0;

            lBinder.NoOfInputParams = lNoOfInptArgs;
            lBinder.ParamName = new string[lNoOfInptArgs];
            lBinder.ParamType = new Type[lNoOfInptArgs];
            lBinder.ParamValue = new object[lNoOfInptArgs];
            lArgsTpLst = new Type[lNoOfInptArgs];

            i = 0;
            foreach (string lParamName in aReflectionParameters.Values.Keys)
            {
                lBinder.ParamName[i] = lParamName;
                lBinder.ParamType[i] = TReflectionParams.GetType(aReflectionParameters.Types[lParamName]);
                lArgsTpLst[i] = lBinder.ParamType[i];
                lBinder.ParamValue[i] = aReflectionParameters[lParamName];
                i++;
            }
            lMethodInfo = lType.GetMethod(aMethod, BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.FlattenHierarchy, lBinder, CallingConventions.Any | CallingConventions.ExplicitThis | CallingConventions.HasThis, lArgsTpLst, null);

            if (!lMethodInfo.IsStatic)
            {
                lInstance = CreateInstance(lAssembly, aTypeName);
            }
            lReturnValue = lType.InvokeMember(aMethod, BindingFlags.InvokeMethod | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.ExactBinding | BindingFlags.FlattenHierarchy, null, lInstance, lBinder.ParamValue);

            for (i = 0; i < lNoOfInptArgs; i++)
            {
                aReflectionParameters[lBinder.ParamName[i]] = lBinder.ParamValue[i];
            }

            if (lReturnValue != null)
            {
                aReflectionParameters["ReturnVal"] = lReturnValue;
            }
            else
            {
                aReflectionParameters.Types["ReturnVal"] = ReflectionParamTypes.Object;
                aReflectionParameters["ReturnVal"] = null;
            }
        }
        #endregion
    }
}
