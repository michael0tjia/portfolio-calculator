using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Globalization;
using System.Threading;
using System.Web;

namespace Innotelli.Utilities
{
    public enum DftCnnModes
    {
        OnePerDataObject,
        OnePerApplication,
    }
    public enum ClientModes
    {
        ThickClient,
        ThinClient,
        ObjectServer,
        Unknown
    }
    public static class TAppSettings
    {
        #region Enums
        #endregion

        #region Properties
        private static TSysDataRdr.Formats mDefaultSysDataFormat = TSysDataRdr.Formats.EncryptedZippedXml;
        public static TSysDataRdr.Formats DefaultSysDataFormat
        {
            get
            {
                return mDefaultSysDataFormat;
            }
            set
            {
                mDefaultSysDataFormat = value;
            }
        }
        private static bool mPreloadForm02sBeforeLogin = false;
        public static bool PreloadForm02sBeforeLogin
        {
            get
            {
                return mPreloadForm02sBeforeLogin;
            }
            set
            {
                mPreloadForm02sBeforeLogin = value;
            }
        }
        public static DftCnnModes DftCnnMode
        {
            get
            {
                DftCnnModes lReturnValue = DftCnnModes.OnePerDataObject;

                if (ConfigurationManager.AppSettings["CnnMode"] != null && ConfigurationManager.AppSettings["CnnMode"] == "1")
                {
                    lReturnValue = DftCnnModes.OnePerDataObject;
                }
                else
                {
                    lReturnValue = DftCnnModes.OnePerApplication;
                }
                return lReturnValue;
            }
        }
        public static string DftCnnStr
        {
            get
            {                
                string lDftCnnStr = string.Empty;

                if (ConfigurationManager.AppSettings["ConnectionStringMode"] != null && ConfigurationManager.AppSettings["ConnectionStringMode"] == "Session")
                {
                    if (HttpContext.Current != null && HttpContext.Current.Session != null && HttpContext.Current.Session["DftCnnStr"] != null)
                    {
                        lDftCnnStr = HttpContext.Current.Session["DftCnnStr"].ToString();
                    }
                    if (string.IsNullOrEmpty(lDftCnnStr))
                    {
                        if (ConfigurationManager.AppSettings["DftCnnStr"] != null)
                        {
                            lDftCnnStr = ConfigurationManager.AppSettings["DftCnnStr"];
                        }
                    }
                }
                else
                {
                    object lCurrentThreadData = Thread.GetData(Thread.GetNamedDataSlot("DftCnnStr"));

                    if (lCurrentThreadData == null)
                    {
                        lDftCnnStr = ConfigurationManager.AppSettings["DftCnnStr"];
                    }
                    else
                    {
                        lDftCnnStr = lCurrentThreadData.ToString();
                    }
                }

                return lDftCnnStr;
            }
            set
            {
                if (ConfigurationManager.AppSettings["ConnectionStringMode"] != null && ConfigurationManager.AppSettings["ConnectionStringMode"] == "Session")
                {
                    if (HttpContext.Current != null && HttpContext.Current.Session != null)
                    {
                        HttpContext.Current.Session["DftCnnStr"] = value;
                    }
                }
                else
                {
                    Thread.SetData(Thread.GetNamedDataSlot("DftCnnStr"), value);
                }
            }

        }
        public static ClientModes ClientMode
        {
            get
            {
                ClientModes lReturnValue = ClientModes.ThickClient;

                //TODO : Improvement
                //string lCase = string.IsNullOrEmpty(ConfigurationManager.AppSettings["ClientMode"]) ? string.Empty : ConfigurationManager.AppSettings["ClientMode"];
                //switch (lCase)
                //{
                //    case "":
                //    case "1":

                //        lReturnValue = ClientModes.ThickClient;
                //        break;

                //    case "2":

                //        lReturnValue = ClientModes.ThinClient;
                //        break;

                //    case "3":

                //        lReturnValue = ClientModes.ObjectServer;
                //        break;

                //    default:

                //        lReturnValue = ClientModes.Unknown;
                //        break;
                //}

                if (ConfigurationManager.AppSettings["ClientMode"] == null || ConfigurationManager.AppSettings["ClientMode"] == "1")
                {
                    lReturnValue = ClientModes.ThickClient;
                }
                else if (ConfigurationManager.AppSettings["ClientMode"] == "2")
                {
                    lReturnValue = ClientModes.ThinClient;
                }
                else if (ConfigurationManager.AppSettings["ClientMode"] == "3")
                {
                    lReturnValue = ClientModes.ObjectServer;
                }
                else
                {
                    lReturnValue = ClientModes.Unknown;
                }
                return lReturnValue;
            }
        }
        public static bool IsFatClientOrObjSvrMode
        {
            get
            {
                return (ClientMode == ClientModes.ThickClient || ClientMode == ClientModes.ObjectServer);
            }
        }
        public static bool IsObjSvrMode
        {
            get
            {
                //return (ClientMode == ClientModes.ObjectServer);
                return (ClientMode == ClientModes.ThickClient);
            }
        }
        public static int RowLockTimeOutMin
        {
            get
            {
                int lReturnValue = 5;

                if (ConfigurationManager.AppSettings["RowLockTimeOutMin"] != null)
                {
                    lReturnValue = int.Parse(ConfigurationManager.AppSettings["RowLockTimeOutMin"]);
                }
                return lReturnValue;
            }
        }
        private static string mApplicationTitle = "";
        public static string ApplicationTitle
        {
            get
            {
                return mApplicationTitle;
            }
            set
            {
                mApplicationTitle = value;
            }
        }
        #region Logging
        private static bool mLogToDB = false;
        public static bool LogToDB
        {
            get
            {
                return TAppSettings.mLogToDB;
            }
            set
            {
                TAppSettings.mLogToDB = value;
            }
        }
        private static bool mLogToFile = false;
        public static bool LogToFile
        {
            get
            {
                return TAppSettings.mLogToFile;
            }
            set
            {
                TAppSettings.mLogToFile = value;
            }
        }
        #endregion

        public static CultureInfo GetCultureInfoFromSystemLanguage(SystemLanguages aSystemLanguage)
        {
            CultureInfo lReturnValue = null;

            switch (aSystemLanguage)
            {
                case SystemLanguages.English:
                    lReturnValue = new System.Globalization.CultureInfo("en-US");
                    break;
                case SystemLanguages.TraditionalChinese:
                    lReturnValue = new System.Globalization.CultureInfo("zh-CHT");
                    break;
                case SystemLanguages.SimplifiedChinese:
                    lReturnValue = new System.Globalization.CultureInfo("zh-CHS");
                    break;
            }

            return lReturnValue;

        }
        private static SystemLanguages mSystemLanguage = SystemLanguages.English;
        public static SystemLanguages SystemLanguage
        {
            get
            {
                return mSystemLanguage;
            }
            set
            {
                mSystemLanguage = value;
                System.Threading.Thread.CurrentThread.CurrentUICulture = GetCultureInfoFromSystemLanguage(value);
            }
        }
        #endregion

        #region Functions
        #endregion
    }
}
