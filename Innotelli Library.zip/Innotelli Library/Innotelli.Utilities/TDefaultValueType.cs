﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    public enum DefaultValueTypes
    {
        Const =	2,
        CurUserPK = 12,
        DocNxNoT01 = 4,
        DocNxNoT02 = 13,
        DocNxNoT03 = 14,
        DocNxNoT04 = 15,
        DocNxNoT05 = 16,
        SysDate = 7,
        SysDT = 8,
        SysTime = 9
    }
    public static class TDefaultValueType
    {
    }
}
