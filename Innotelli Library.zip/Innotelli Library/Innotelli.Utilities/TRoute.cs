using System;
using System.Data;
using System.Collections;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Text.RegularExpressions;
using Innotelli.Utilities;

namespace Innotelli.Utilities
{
    public class TRoute
    {
        string mInfo = "";
        string mBackwardUrl = "";
        Hashtable lLink = new Hashtable();
        

        public TRoute()
        {

        }

        public void SetNewInfo(string aDstPage, string aOrgInfo)
        {
            string lNewInfo = "";
            TCryptography lCryptography = new TCryptography();
            string[] lLinkList;
            bool lExist = false;

            if (aDstPage == "")
            {
                mInfo = aOrgInfo;
            }
            else
            {
                if (aOrgInfo == "")
                {
                    lNewInfo = aDstPage;
                }
                else
                {
                    aDstPage = aDstPage.Substring(0, aDstPage.IndexOf(".aspx") + 5);
                    aOrgInfo = lCryptography.Decrypt(aOrgInfo);

                    lLinkList = Regex.Split(aOrgInfo, ";");
                    for (int i = 0; i < lLinkList.Length; i++)
                    {
                        if (aDstPage == lLinkList[i])
                        {
                            lExist = true;
                            break;
                        }
                        else
                        {
                            lNewInfo += lLinkList[i] + ";";
                        }
                    }

                    if (!lExist)
                    {
                        lNewInfo += aDstPage + ";";
                    }

                    // remove the last ;
                    if (lNewInfo != "")
                    {
                        lNewInfo = lNewInfo.Substring(0, lNewInfo.Length - 1);
                    }
                }

                mInfo = lCryptography.Encrypt(lNewInfo);
            }
        }

        public string BackwardUrl
        {
            get
            {
                TCryptography lCryDecryp = new TCryptography();
                string lLink = lCryDecryp.Decrypt(mInfo);
                string[] lPostBackLink = Regex.Split(lLink, ";");

                if (lPostBackLink.Length != 0)
                {

                    mBackwardUrl = lPostBackLink[lPostBackLink.Length - 1];
                }
                else
                {
                    mBackwardUrl = "";
                }

                return mBackwardUrl;
            }
        }

        public string Info
        {
            get
            {
                return mInfo;
            }
            set
            {
                mInfo = value;
            }
        }

        public string UrlEncodedInfo
        {
            get
            {
                return HttpUtility.UrlEncode(mInfo);
            }
        }
    }

}
