using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    public class TPasswd
    {
        public TPasswd()
        {

        }

        public string GetNew()
        {
            char[] arrChars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+-!@#$%^&()".ToCharArray();
            int lPWLength = 8;
            string stringPassword = null;
            System.Random random = new Random();
            for (int i = 0; i < lPWLength; i++)
            {
                int intRandom = random.Next(arrChars.Length);
                stringPassword += arrChars[intRandom].ToString();
            }
            return stringPassword;
        }
    }
}
