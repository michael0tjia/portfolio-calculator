using System;
using System.Data;
using System.Configuration;
using System.Web;


/// <summary>
/// Summary description for TSingletons
/// </summary>
/// 
namespace Innotelli.Utilities
{
    public static class TSingletons
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        #endregion

        #region Properties
        private static TSysDataRdr mSysData01Rdr = null;
        public static TSysDataRdr SysData01Rdr
        {
            get
            {
                return mSysData01Rdr;
            }
        }
        private static TSysDataRdr mSysData02Rdr = null;
        public static TSysDataRdr SysData02Rdr
        {
            get
            {
                return mSysData02Rdr;
            }
        }
        private static TSysDataRdr mSysData03Rdr = null;
        public static TSysDataRdr SysData03Rdr
        {
            get
            {
                return mSysData03Rdr;
            }
        }
        private static TStrResx mStrResx = null;
        public static TStrResx StrResx
        {
            get
            {
                return mStrResx;
            }
        }
        //TODO: add support to read logo
        //private static TSysDataRdr mSysData04Rdr = null;
        //public static TSysDataRdr SysData04Rdr
        //{
        //    get
        //    {
        //        return mSysData04Rdr;
        //    }
        //}
        private static DataSet mRptT01Ds = null;
        public static DataSet RptT01Ds
        {
            get
            {
                if (mRptT01Ds == null)
                {
                    mRptT01Ds = SysData01Rdr.GetSysData("RPT01");
                }
                return mRptT01Ds;
            }
        }
        private static DataSet mRpt01SubRptDs = null;
        public static DataSet Rpt01SubRptDs
        {
            get
            {
                if (mRpt01SubRptDs == null)
                {
                    mRpt01SubRptDs = SysData01Rdr.GetSysData("RPT01SubRpt");
                }
                return mRpt01SubRptDs;
            }
        }
        private static DataSet mSrchCndtnDs = null;
        public static DataSet SrchCndtnDs
        {
            get
            {
                if (mSrchCndtnDs == null)
                {
                    mSrchCndtnDs = SysData01Rdr.GetSysData("SrchCndtn");
                }
                return mSrchCndtnDs;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public static void Init()
        {
            mSysData01Rdr = new TSysDataRdr();
            mSysData01Rdr.DataFolder = Innotelli.Utilities.TGC.SYSDATA01_FOLDER_NAME;
            mSysData01Rdr.Format = TAppSettings.DefaultSysDataFormat;

            mSysData02Rdr = new TSysDataRdr();
            mSysData02Rdr.DataFolder = Innotelli.Utilities.TGC.SYSDATA02_FOLDER_NAME;
            mSysData02Rdr.Format = TAppSettings.DefaultSysDataFormat;

            mSysData03Rdr = new TSysDataRdr();
            mSysData03Rdr.DataFolder = Innotelli.Utilities.TGC.SYSDATA03_FOLDER_NAME;
            mSysData03Rdr.Format  = TSysDataRdr.Formats.UnencryptedXml;

            mStrResx = new TStrResx();
            //TODO: add support to read logo
            //mSysData04Rdr = new TSysDataRdr();
            //mSysData04Rdr.DataFolder = Innotelli.Utilities.TGC.SYSDATA04_FOLDER_NAME;
            //mSysData04Rdr.Format = TSysDataRdr.Formats.UnencryptedXml;
        }
        #endregion
    }
}