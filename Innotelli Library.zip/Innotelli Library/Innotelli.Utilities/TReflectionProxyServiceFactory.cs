using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using System.IO;
//using Innotelli.Utilities.ReflectionService;
using Innotelli.Utilities.ReflectionProxy;

namespace Innotelli.Utilities
{
    public static class TReflectionClientFactory
    {
        #region Members
        private static string mDefaultServiceName = "ReflectionProxySvc.asmx";
        private static string mEndpointAddress = string.Empty;
        #endregion

        #region Constructors
        #endregion

        #region Enums

        #endregion

        #region Properties
        public static string EndpointAddress
        {
            get 
            {
                return mEndpointAddress; 
            }
            set
            {
                mEndpointAddress = value;
            }

        }
        #endregion

        #region Event Handlers

        #endregion

        #region Functions

        public static ReflectionProxySvc GetDefaultReflectionClient()
        {
            ReflectionProxySvc lReflectionProxySvc = new ReflectionProxySvc();
            lReflectionProxySvc.Url = Path.Combine(EndpointAddress, mDefaultServiceName);            
            return lReflectionProxySvc;
        }
        //WCF
        //public static ReflectionClient GetDefaultReflectionClient()
        //{
        //    ReflectionClient lClient = new ReflectionClient("WSHttpBinding_IReflection");
        //    lClient.Endpoint.Address = new System.ServiceModel.EndpointAddress(mEndpointAddress);
        //    return lClient;
        //}
        #endregion
    }
}
