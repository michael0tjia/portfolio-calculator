using System;
using System.Diagnostics;

namespace Innotelli.Utilities
{
    public class TAppLog //Singleton Pattern
    {
        //1.	Must exist ProjectId in <appSettings>?/appSettings>       
        //2.	ProjectId must exist in Prjct in Mentor.
        //3.	Database Logging only works in debug mode
        //4.	File Logging always works in all mode.
        //5.	Logging files are managed as <base path>\log\<short date>.log

        #region Enums
        #endregion

        #region Members
        //private static TAppLog mAppLog = null;
        //private static string mConfigFileName = "exception.config";
        //private static FileConfigurationSource mFileConfigurationSource;
        //private static ExceptionPolicyFactory mExceptionPolicyFactory;
        #endregion

        #region Constructors
        public TAppLog()
        {
            //CreateEnterpriseConfig();
            //mFileConfigurationSource = new FileConfigurationSource(mConfigFileName);
            //mExceptionPolicyFactory = new ExceptionPolicyFactory(mFileConfigurationSource);
        }
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public static void LogException(Exception aException)
        {
            //LogToFile(aException);
            //LogToDb(aException);
            Trace.Write(aException, TraceEventType.Error.ToString());
        }
        public static void LogValue(long aLong)
        {
            //Trace.Write(aException, TraceEventType.Information.ToString());
        }
        //private static void LogToFile(Exception aException)
        //{
        //    try
        //    {
        //        ExceptionPolicy.HandleException(aException, "Release");
        //        ExceptionPolicy.HandleException(aException, "ServerSide");
        //    }
        //    catch
        //    {
        //    }
        //}
        //[Conditional("DEBUG")]
        //private static void LogToDb(Exception aException)
        //{
        //    try
        //    {
        //        ExceptionPolicy.HandleException(aException, "Debug");
        //    }
        //    catch (Exception ex)
        //    {
        //        LogToFile(ex);
        //    }
        //}
        //private static void LogToEvent(Exception aException)
        //{
        //    try
        //    {
        //        EventLog myLog = new EventLog();
        //        if (!EventLog.SourceExists(AppDomain.CurrentDomain.FriendlyName))
        //        {
        //            myLog.Source = AppDomain.CurrentDomain.FriendlyName;
        //            myLog.MachineName = Process.GetCurrentProcess().MachineName;
        //        }
        //        myLog.WriteEntry(aException.ToString());
        //    }
        //    catch { }
        //}
        //private void CreateEnterpriseConfig()
        //{
        //    string lDbSpName = string.Empty;
        //    if (string.IsNullOrEmpty(ConfigurationManager.AppSettings["ProjectId"]))
        //    {
        //        lDbSpName = "A000";
        //    }
        //    else
        //    {
        //        lDbSpName = ConfigurationManager.AppSettings["ProjectId"];
        //    }

        //    string lFilePath = AppDomain.CurrentDomain.BaseDirectory;
        //    StringBuilder lStringBuilder = new StringBuilder(Resource.enterpriseConfig);
        //    lStringBuilder.Replace("{0}", lDbSpName);
        //    lStringBuilder.Replace("{1}", lFilePath);
        //    lStringBuilder.Replace("{2}", DateTime.Now.Day.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString());
        //    if (!File.Exists(lFilePath + "exception.config"))
        //    {
        //        try
        //        {
        //            File.AppendAllText(lFilePath + "exception.config", lStringBuilder.ToString());
        //        }
        //        catch(Exception e)
        //        {
        //            try
        //            {
        //                lFilePath = @"C:\log\";
        //                File.AppendAllText(lFilePath + "exception.config", lStringBuilder.ToString());
        //            }
        //            catch (Exception ex)
        //            {
        //                new Exception(ex.Message, e);
        //                LogToEvent(ex);
        //            }
        //        }
        //    }
        //}
        #endregion
    }
}
