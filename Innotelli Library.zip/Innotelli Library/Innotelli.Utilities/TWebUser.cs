using System;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Web;
using System.Web.Security;

namespace Innotelli.Utilities
{

    public class TWebUser
    {
        public TWebUser()
        {
            // TODO: Add constructor logic here
        }

        public bool Add_User(string aUserName, string aPassword, string aEmail, string aRole)
        {
            //MembershipCreateStatus Member
            //---------------------------------------------------------------------------
            //DuplicateEmail --- The e-mail address already exists in the database for the application.  
            //DuplicateProviderUserKey --- The provider user key already exists in the database for the application.  
            //DuplicateUserName --- The user name already exists in the database for the application.  
            //InvalidAnswer --- The password answer is not formatted correctly.  
            //InvalidEmail --- The e-mail address is not formatted correctly.  
            //InvalidPassword --- The password is not formatted correctly.  
            //InvalidProviderUserKey --- The provider user key is of an invalid type or format.  
            //InvalidQuestion --- The password question is not formatted correctly.  
            //InvalidUserName --- The user name was not found in the database.  
            //ProviderError --- The provider returned an error that is not described by other MembershipCreateStatus enumeration values.  
            //Success --- The user was successfully created.  
            //UserRejected --- The user was not created, for a reason defined by the provider.  

            bool lUserCreated = false;
            string lAddUser = "";

            string lQuest = "What's my pet's name?";
            string lAnswer = "Lovely Rabbit";
            MembershipCreateStatus lResult;
            Membership.CreateUser(aUserName, aPassword, aEmail, lQuest, lAnswer, true, out lResult);

            Roles.AddUserToRole(aUserName, aRole);
            lAddUser = lResult.ToString();

            if (lAddUser.ToLower() == "success")
            {
                lUserCreated = true;
            }
            return lUserCreated;

        }

        public bool Change_Password(string aUserName, string aPassword)
        {
            bool lChangePW = false;
            try
            {
                MembershipUser lUser = Membership.GetUser(aUserName);
                string oldpswd = lUser.ResetPassword();
                string newpass = aPassword;
                lUser.ChangePassword(oldpswd, newpass);
                lChangePW = true;
            }
            catch
            {
            }
            return lChangePW;
        }

        public bool Change_Email(string aUserName, string aEmail)
        {
            bool lChangeEmail = false;
            if (aEmail.Trim() != "")
            {
                try
                {
                    MembershipUser lUser = Membership.GetUser(aUserName);
                    lUser.Email = aEmail;
                    Membership.UpdateUser(lUser);
                    lChangeEmail = true;
                }
                catch
                {
                }
            }
            return lChangeEmail;
        }

        public bool Change_UserID(string aUserName, string aNewUserName, string aNewPW)
        {
            bool lChangeUserID = false;
            string lEmail = "";
            string lQuest = "What's my pet's name?";
            string lAnswer = "Lovely Rabbit";
            string lAddUser = "";
            try
            {
                MembershipUser lUser = Membership.GetUser(aUserName);
                lEmail = lUser.Email;

                string[] lRoles = Roles.GetRolesForUser(aUserName);
                int lRolesCount = lRoles.Length;

                Membership.DeleteUser(aUserName);
                MembershipCreateStatus lResult;
                Membership.CreateUser(aNewUserName, aNewPW, lEmail, lQuest, lAnswer, true, out lResult);
                
                for (int i = 1; i <= lRolesCount; i++)
                {
                    Roles.AddUserToRole(aNewUserName, lRoles[i - 1]);
                }
                lAddUser = lResult.ToString();

                if (lAddUser.ToLower() == "success")
                {
                    lChangeUserID = true;
                }
            }
            catch
            {
            }

            return lChangeUserID;
        }

        public bool Delete_UserID(string aUserName)
        {
            bool lReturnValue = false;
            try
            {
                MembershipUser lUser = Membership.GetUser(aUserName);
                Membership.DeleteUser(aUserName);
                lReturnValue = true;
            }
            catch
            {
            }
            return lReturnValue;
        }

    }
}