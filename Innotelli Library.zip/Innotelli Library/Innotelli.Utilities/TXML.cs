using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;

namespace Innotelli.Utilities
{
    public sealed class TXML
    {
        private TXML()
        {
        }

        public static string Bool2Bit(string aXmlStr)
        {
            string lReturnValue = aXmlStr;

            lReturnValue = lReturnValue.Replace(">true</", ">1</");
            lReturnValue = lReturnValue.Replace(">false</", ">0</");

            return lReturnValue;
        }

        public static string ReformatDateTime(string aXmlStr)
        {
            string lReturnValue = aXmlStr;
            string lPattern = @"<(?'tag'\b\w+\b?).*>(?'date'(\d\d\d\d)-([01]\d)-([0-3]\d)?).*T(?'time'([0-2]\d):([0-5]\d):([0-5]\d)?).*(\+|\-)([0-2]\d):([0-5]\d)</\k'tag'>";
            string lReplacement = @"<${tag}>${date} ${time}</${tag}>";

            lReturnValue = Regex.Replace(aXmlStr, lPattern, lReplacement);
            
            return lReturnValue;
        }

        public static string Reformat(string aXmlStr)
        {
            string lReturnValue = aXmlStr;

            lReturnValue = Bool2Bit(lReturnValue);
            lReturnValue = ReformatDateTime(lReturnValue);

            return lReturnValue;
        }
    }
}
