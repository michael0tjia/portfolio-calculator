using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.Utilities
{
    public static class TEnum
    {

        #region Members

        #endregion

        #region Constructors

        #endregion

        #region Enums

        #endregion

        #region Properties

        #endregion

        #region Event Handlers

        #endregion

        #region Functions
        public static int GetLength(Type aType)
        {
            int lReturnValue = -1;
            Array lActionType = null;
            lActionType = Enum.GetValues(aType);
            lReturnValue = lActionType.Length;
            return lReturnValue;
        }
        public static string GetNameByValue(Type aType, int aValue)
        {
            string lReturnValue = null;
            lReturnValue = Enum.GetName(aType, aValue);
            return lReturnValue;
        }
        #endregion

    }
}
