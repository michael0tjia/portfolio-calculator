using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Innotelli.Utilities
{
    // Alex : Created at 2008/08/08 10:30am
    public class TLog
    {
        public TLog()
        {

        }

        public static void WriteLog(string aFileName , string aStrLogHeading)
        {
            try
            {
                FileStream lFS = new FileStream(aFileName, FileMode.OpenOrCreate, FileAccess.Write);
                StreamWriter lStreamWriter = new StreamWriter(lFS);

                lStreamWriter.BaseStream.Seek(0, SeekOrigin.End);
                lStreamWriter.WriteLine(aStrLogHeading + System.DateTime.Now.ToString() + " \n");
                lStreamWriter.Flush();
                lStreamWriter.Close();
            }
            catch
            {
            }
        }
    }
}
