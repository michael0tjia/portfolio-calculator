﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.Threading;
using System.Windows.Forms;

namespace Innotelli.Utilities
{
    public class TExceptionHandler
    {

        // Handles the exception event.
        public void OnThreadException(object sender, ThreadExceptionEventArgs e)
        {
            OnException(e);
        }

        public void OnUnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            OnException(e);
        }

        private void OnException(EventArgs e)
        {
            Exception caughtException;
            if (e is UnhandledExceptionEventArgs)
            {
                caughtException = GetInnerException((Exception)(e as UnhandledExceptionEventArgs).ExceptionObject);
                Trace.Write(caughtException, TraceEventType.Error.ToString());
            }
            else if (e is ThreadExceptionEventArgs)
            {
                try
                {
                    caughtException = GetInnerException((e as ThreadExceptionEventArgs).Exception);
                    Trace.Write(caughtException, TraceEventType.Error.ToString());
                    DialogResult lDialogResult = MessageBox.Show(caughtException.Message, "System Error", MessageBoxButtons.AbortRetryIgnore, MessageBoxIcon.Stop);
                    if (lDialogResult == DialogResult.Abort)
                        Application.Exit();
                }
                catch
                {
                    Application.Exit();
                }
            }
        }
        private Exception GetInnerException(Exception e)
        {
            if (e.InnerException != null)
            {
                return GetInnerException(e.InnerException);
            }
            else return e;
        }
    }
}
