using System.Diagnostics;
using System;
using System.Collections;
using System.Data;
using Innotelli.BO;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.Post
{
	public class TBTEAccPrd
	{
        public TBTEAccPrd()
        {
        }
		public static bool IsPeriodClose(DateTime aDocDate)
		{
            TSQL lSQL = new TSQL();
            
            bool lIsClose = false;
            TDomain.Lookup("IsClose", "AccPrd", "DBegin <=  " + TSQL.SqlDate(aDocDate) + " And DEnd >= " + TSQL.SqlDate(aDocDate) , out lIsClose);            
            return lIsClose;
		}
		
		public static byte GetPeriod(DateTime aDocDate)
		{
            TSQL lSQL = new TSQL();
            object lPrdNo = null;

            TDomain.Lookup("PrdNo", "AccPrd", "DBegin <= " + TSQL.SqlDate(aDocDate) + " And DEnd >= " + TSQL.SqlDate(aDocDate) , out lPrdNo);
            return byte.Parse(lPrdNo.ToString());
		}
	}
}
