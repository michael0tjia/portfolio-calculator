using System.Diagnostics;
using System;
using System.Collections;
using System.Data;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.Post
{

    public abstract class TBOT02
    {

        public TBOT02()
        {
        }

        const short cDecPlace = 2;

        public enum enumPostObj
        {
            POSTSuccess = 1,
            POSTFail = -1,
            POSTPeriodClosed = -2,
            POSTInValidDocumentID = -3,
            POSTNotBalance = -4,
            POSTRstNotSet = -5,
            POSTAlreadyPosted = -6,
            POSTNotPosted = -7,
            POSTAlreadyCleared = -8,
            POSTInPosting = -9,
            POSTInValidDocType = -10
        }

        TSPrpsBOT02 mSPrps = new TSPrpsBOT02();

        protected string mDocType;
        ArrayList mCrncyFlds = new ArrayList();
        ArrayList mDtlCrncyFlds = new ArrayList();
        protected string mIDFldNm;
        protected string mDTransFldNm;
        protected string mCrFldNm;
        protected string mERFldNm;
        protected string mDtlCIDFldNm;
        protected string mDtlERFldNm;
        protected bool mHasExchRate;
        protected bool mHasDtlExchRate;

        TDataObject mDao = new TDataObject();
        TDataObject mDaoDtl = new TDataObject();
        
        #region where is the description?

        public TSPrpsBOT02 SPrps
        {
            get
            {
                return mSPrps;
            }
        }

        public DateTime DocDate
        {
            get
            {
                return DateTime.Parse(mDao.Dr[mDTransFldNm].ToString());
            }
        }

        public string DocID
        {
            get
            {
                return mDao.Dr[mIDFldNm].ToString();
            }
        }

        public string DocType
        {
            get
            {
                return mDocType;
            }
            set
            {
                mDocType = value;
            }
        }

        public int CrncyPK
        {
            get
            {
                int lRtrnVal;
                if (mCrFldNm != "")
                {
                    lRtrnVal = int.Parse(mDao.Dr[mCrFldNm].ToString());
                }
                else
                {
                    TDomain.Lookup("slkCrncy", "Optn", "", out lRtrnVal);
                }
                return lRtrnVal;
            }
        }

        public string DtlCrncyPK
        {
            get
            {
                string lRtrnVal;
                if (mDtlCIDFldNm != "")
                {
                    lRtrnVal = mDaoDtl.Dr[mDtlCIDFldNm].ToString();
                }
                else
                {
                    TDomain.Lookup("slkCrncy", "Optn", "", out lRtrnVal);
                }
                return lRtrnVal;
            }
        }

        public double ExchRate
        {
            get
            {
                double lRtrnVal;
                if (mERFldNm != "")
                {
                    lRtrnVal = double.Parse(mDao.Dr[mERFldNm].ToString());
                }
                else
                {
                    lRtrnVal = 1;
                }
                return lRtrnVal;
            }
        }

        public double DtlExchRate
        {
            get
            {
                double lRtrnVal;
                if (mDtlERFldNm != "")
                {
                    lRtrnVal = double.Parse(mDaoDtl.Dr[mDtlERFldNm].ToString());
                }
                else
                {
                    lRtrnVal = 1;
                }
                return lRtrnVal;
            }
        }

        public bool Posted
        {
            get
            {
                bool lRtrnVal = false;
                lRtrnVal = bool.Parse(mDao.Dr["Posted"].ToString());
                return lRtrnVal;
            }
        }

        public TDataObject Dao
        {
            get
            {
                return mDao;
            }
            set
            {
                mDao = value;
            }
        }

        public TDataObject DaoDtl
        {
            get
            {
                return mDaoDtl;
            }
            set
            {
                mDaoDtl = value;
            }
        }

        public bool ForeignCurrencyInUse
        {
            get
            {
                int lslkCrncy = 0;
                TDomain.Lookup("slkCrncy", "Optn", "", out lslkCrncy);
                return (this.CrncyPK != lslkCrncy);
            }
        }

        #endregion

        public object Initialize(string aDocType)
        {
            try
            {
                mHasExchRate = false;
                mHasDtlExchRate = false;

               // this.Parent = aObject;
                this.DocType = aDocType;
                mSPrps.BOID = aDocType;

                mIDFldNm = mSPrps.SKFldNm;
                mDTransFldNm = mSPrps.DTransFldNm;

                mCrFldNm = mSPrps.CrFldNm;
                mERFldNm = mSPrps.ERFldNm;
                if (mERFldNm != "")
                {
                    mHasExchRate = true;
                }

                mDtlCIDFldNm = mSPrps.DtlCrFldNm;
                mDtlERFldNm = mSPrps.DtlERFldNm;
                if (mDtlERFldNm != "")
                {
                    mHasDtlExchRate = true;
                }

                CreateCrncyFlds();
                CreateDtlCrncyFlds();

                return null;
            }
            catch
            {
                return null;
            }

        }

        //public virtual bool Balance
        //{
        //    get
        //    {
        //        return true;
        //    }
        //}

        //public abstract bool Balance
        //{
        //    get;
        //}

        public void CreateCrncyFlds()
        {
            try
            {
                TDataObject mDao = new TDataObject();
                TSQL lSQL = new TSQL();
                string lTempStr;
                lSQL.SetEmptyStmtByTable(mSPrps.Dmn);
                //lSQL.Stmt  = "SELECT * FROM " + mSPrps.Dmn + " ";
                //lSQL.AddToWhereClause("prmykey Is Null");
                mDao.MainTable = mSPrps.Dmn.Substring(6);
                mDao.OpenTable(lSQL.Stmt);

                for (int i = 0; i <= mDao.Dt.Columns.Count - 1; i++)
                {
                    if (TMisc.Right(mDao.Dt.Columns[i].ColumnName, 4) == "Rate")
                    {
                        //lTempStr = TMisc.Mid(mRst.Dt.Columns[i].ColumnName, 1, mRst.Dt.Columns[i].ColumnName.Length - 4);
                        lTempStr = TMisc.Left(mDao.Dt.Columns[i].ColumnName, mDao.Dt.Columns[i].ColumnName.Length - 4);
                        if (mDao.Dt.Columns.Contains(lTempStr))
                        {
                            mCrncyFlds.Add(lTempStr);
                        }
                    }
                }
            }
            catch
            {
            }
        }

        public void CreateDtlCrncyFlds()
        {
            try
            {
                TDataObject mDao = new TDataObject();
                TSQL lSQL = new TSQL();
                string lTempStr;

                lSQL.SetEmptyStmtByTable(mSPrps.DtlDmn);
                //lSQL.Stmt = "SELECT * FROM " + mSPrps.DtlDmn + " ";
                //lSQL.AddToWhereClause("prmykey Is Null");
                mDao.MainTable = mSPrps.DtlDmn.Substring(6);
                mDao.OpenTable(lSQL.Stmt);

                for (int i = 0; i <= mDao.Dt.Columns.Count - 1; i++)
                {
                    if (TMisc.Right(mDao.Dt.Columns[i].ColumnName, 4) == "Rate")
                    {
                        lTempStr = TMisc.Left(mDao.Dt.Columns[i].ColumnName, mDao.Dt.Columns[i].ColumnName.Length - 4);
                        if (mDao.Dt.Columns.Contains(lTempStr))
                        {
                            mDtlCrncyFlds.Add(lTempStr);
                        }
                    }
                }
            }
            catch
            {
            }
        }

        abstract public enumPostObj PostTransaction(string aDocPK);

        abstract public enumPostObj UnPostTransaction(string aDocPK);

        abstract public bool Balance(string aDocPK);

        public enumPostObj Post(string aDocPK)
        {
            enumPostObj lRtrnVal = enumPostObj.POSTFail;

            TSQL lSQL = new TSQL();
            lSQL.SetStmtByTableAndPK(mSPrps.Dmn, aDocPK);
            mDao.MainTable = mSPrps.Dmn.Substring(6);
            mDao.OpenTable(lSQL.Stmt);        	
        	
	        //***** Initialization Begin *****
	        lRtrnVal = enumPostObj.POSTSuccess;
	        //***** Initialization End *****
        	
        	
	        //**** Open the document. Check for a valid DocID
	        if (OpenDocument(aDocPK) != enumPostObj.POSTSuccess)
	        {
		        lRtrnVal = enumPostObj.POSTInValidDocumentID;
	        }
	        if (lRtrnVal == enumPostObj.POSTSuccess)
	        {
		        // Sync visual fields to calculated fields
		        SyncFromForeignToLocal(mDao, mDaoDtl);

		        if (this.Posted)
		        {
			        lRtrnVal = enumPostObj.POSTAlreadyPosted;
			        //***** Check the Close Period Date before Posting!
		        }
                else if (TBTEAccPrd.IsPeriodClose(DateTime.Parse(mDao.Dr[mSPrps.DTransFldNm].ToString())))
                {
                    lRtrnVal = enumPostObj.POSTPeriodClosed;
                }
                else if (!Balance(aDocPK))
                {
                    lRtrnVal = enumPostObj.POSTNotBalance;
                }
                else
                {
                    
                    //TConnection.BeginTrans();
                    //Wiy Tmp
                    Innotelli.Db.TSingletons.GetCrrntCnnObj().BeginTrans();
                    //Wiy Tmp
                    TSingletons.gBTEGL.DocID = this.DocID;
                    TSingletons.gBTEGL.TransactionDate = this.DocDate;
                    TSingletons.gBTEGL.DocType = this.DocType;
                    TSingletons.gBTEGL.PrdNo = TBTEAccPrd.GetPeriod(this.DocDate);

                    TSingletons.gBTEGL.BeginTransaction();

                    lRtrnVal = PostTransaction(aDocPK);

                    //TSingletons.gBTEGL.EndTransaction();

                    //basGlobalVariables.gBTEGL.EndTransaction();

                    //***** Make sure all the transactions successful and Post action is successful


                    if (lRtrnVal != enumPostObj.POSTSuccess)
                    {
                        //TConnection.RollBack();
                        //Wiy Tmp
                        Innotelli.Db.TSingletons.GetCrrntCnnObj().RollBack();
                        //Wiy Tmp
                    }
                    else
                    {

                        //TConnection.Commit();
                        //Wiy Tmp
                        Innotelli.Db.TSingletons.GetCrrntCnnObj().Commit();
                        //Wiy Tmp
                    }

                    lSQL.SetStmtByTableAndPK(mSPrps.Dmn, aDocPK);
                    //lSQL.Stmt = lSQL.SetSQLByTableAndPK(mSPrps.Dmn, aDocPK);
                    mDao.MainTable = mSPrps.Dmn.Substring(6);
                    mDao.OpenTable(lSQL.Stmt);
                    if (!mDao.IsNoRow())
                    {
                        mDao.MoveFirst();
                        if (lRtrnVal == enumPostObj.POSTSuccess)
                        {
                            mDao.Dr["Posted"] = true;
                            mDao.Dr["PostStatus"] = "Posted";
                            mDao.Dr["DTPosted"] = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                            mDao.UpdateRows();

                            lRtrnVal = enumPostObj.POSTSuccess;
                        }
                        else
                        {
                            mDao.Dr["Posted"] = false;
                            mDao.Dr["PostStatus"] = "Not Posted";
                            mDao.UpdateRows();

                            lRtrnVal = enumPostObj.POSTFail;
                        }
                    }
                }
            }
            return lRtrnVal;
        }

        public enumPostObj UnPost(string aDocPK)
        {
            enumPostObj lRtrnVal = enumPostObj.POSTFail;
            TSQL lSQL = new TSQL();
            lSQL.SetStmtByTableAndPK(mSPrps.Dmn, aDocPK);
            //lSQL.Stmt = lSQL.SetSQLByTableAndPK(mSPrps.Dmn, aDocPK);
            mDao.MainTable = mSPrps.Dmn.Substring(6);
            mDao.OpenTable(lSQL.Stmt);
            

            enumPostObj lUnPostResult;

            lRtrnVal = enumPostObj.POSTSuccess;

            //**** Open the document. Check for a valid DocID
            if (OpenDocument(aDocPK) != enumPostObj.POSTSuccess)
            {
                lRtrnVal = enumPostObj.POSTInValidDocumentID;
            }
            if (lRtrnVal == enumPostObj.POSTSuccess)
            {
                if (!this.Posted)
                {
                    lRtrnVal = enumPostObj.POSTNotPosted;
                }
                else if (TBTEAccPrd.IsPeriodClose(this.DocDate))
                {
                    lRtrnVal = enumPostObj.POSTPeriodClosed;
                }
                else
                {
                    TSingletons.gBTEGL.DocID = this.DocID;
                    TSingletons.gBTEGL.DocType = this.DocType;

                    lUnPostResult = UnPostTransaction(aDocPK);
                    lSQL.SetStmtByTableAndPK(mSPrps.Dmn, aDocPK);
                    //lSQL.Stmt = lSQL.SetSQLByTableAndPK(mSPrps.Dmn, aDocPK);
                    mDao.MainTable = mSPrps.Dmn.Substring(6);
                    mDao.OpenTable(lSQL.Stmt);
                    if (!mDao.IsNoRow())
                    {
                        mDao.MoveFirst();
                        if (lRtrnVal == enumPostObj.POSTSuccess)
                        {
                            mDao.Dr["Posted"] = false;
                            mDao.Dr["PostStatus"] = "Not Posted";
                            mDao.Dr["DTPosted"] = Convert.DBNull;
                            mDao.UpdateRows();

                            lRtrnVal = enumPostObj.POSTSuccess;
                        }
                        else
                        {
                            mDao.Dr["Posted"] = true;
                            mDao.Dr["PostStatus"] = "Posted";
                            mDao.UpdateRows();

                            lRtrnVal = enumPostObj.POSTFail;
                        }
                    }
                }
            }
            return lRtrnVal;
        }

        public enumPostObj OpenDocument(string aDocPK)
        {
            enumPostObj lRtrnVal = enumPostObj.POSTFail;
            string lDmn = mSPrps.Dmn;
            string lDtlDmn = mSPrps.DtlDmn;

            TSQL lSQL = new TSQL();
            TSQL lDtlSQL = new TSQL();
            lSQL.SetStmtByTableAndPK(lDmn, aDocPK);
            //lSQL.Stmt = "Select * From " + lDmn;
            //lSQL.AddToWhereClause("prmykey = " + aDocPK);
            mDao.MainTable = mSPrps.Dmn.Substring(6);
            mDao.OpenTable(lSQL.Stmt);
            if (!mDao.IsNoRow())
            {
                if (lDtlDmn != "")
                {
                    lDtlSQL.SetStmtByTableAndFK(lDtlDmn, aDocPK);
                    //lDtlSQL.Stmt = "Select * From " + lDtlDmn;
                    //lDtlSQL.AddToWhereClause("prntkey = " + aDocPK);
                    mDaoDtl.MainTable = mSPrps.DtlDmn.Substring(6);
                    mDaoDtl.OpenTable(lDtlSQL.Stmt);
                    
                }
                lRtrnVal = enumPostObj.POSTSuccess;
            }
            else
            {
                lRtrnVal = enumPostObj.POSTInValidDocumentID;
            }
            return lRtrnVal;
        }

        public enumPostObj CloseDocument()
        {
            return enumPostObj.POSTSuccess;
        }

        public void SyncFromForeignToLocal(TDataObject mRst, TDataObject mRstDtl)
        {
            short intC;
            double lExchRate;
            double lDtlExchRate;
            //bool lMultiplying;

            if (!mHasExchRate && !mHasDtlExchRate)
            {
                //***** Nothing to do
            }
            else if (mHasExchRate && !mHasDtlExchRate)
            {
                lExchRate = this.ExchRate;

                //***** Header *****
                for (intC = 0; intC <= (mCrncyFlds.Count - 1) ; intC++)
                {
                    
                    mRst.Dr[mCrncyFlds[intC].ToString()] = System.Math.Round(double.Parse(mRst.Dr[mCrncyFlds[intC] + "Rate"].ToString()) * lExchRate, cDecPlace);
                    mRst.UpdateRows();
                }
  
                //***** Detail *****
                if (!mRstDtl.IsNoRow())
                {
                    mRstDtl.MoveFirst();
                    while (!mRstDtl.EOF())
                    {
                        for (intC = 0; intC <= (mDtlCrncyFlds.Count - 1) ; intC++)
                        {
                            mRstDtl.Dr[mDtlCrncyFlds[intC].ToString()] = System.Math.Round(double.Parse(mRstDtl.Dr[mDtlCrncyFlds[intC] + "Rate"].ToString()) * lExchRate, cDecPlace);
                        }
                        mRstDtl.MoveNext();
                    }
                    mRstDtl.UpdateRows();
                }
            }
            else if (mHasDtlExchRate)
            {
                lExchRate = this.ExchRate;
                //***** Header *****

                for (intC = 0; intC <= (mCrncyFlds.Count - 1) ; intC++)
                {
                    mRst.Dr[mCrncyFlds[intC].ToString()] = System.Math.Round(double.Parse(mRst.Dr[mCrncyFlds[intC] + "Rate"].ToString()) * lExchRate, cDecPlace);
                    mRst.UpdateRows();
                }
                
                //***** Detail *****
                if (!mRstDtl.IsNoRow())
                {
                    mRstDtl.MoveFirst();
                    while (!mRstDtl.EOF())
                    {
                        lDtlExchRate = this.DtlExchRate;

                        for (intC = 0; intC <= (mDtlCrncyFlds.Count - 1) ; intC++)
                        {
                            mRstDtl.Dr[mDtlCrncyFlds[intC].ToString()] = System.Math.Round(double.Parse(mRstDtl.Dr[mDtlCrncyFlds[intC] + "Rate"].ToString()) * lDtlExchRate, cDecPlace);
                        }
                        mRstDtl.MoveNext();
                    }
                    mRstDtl.UpdateRows();
                }
            }
        }
    }
}
