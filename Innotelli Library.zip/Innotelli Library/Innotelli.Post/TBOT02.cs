using System.Diagnostics;
using System;
using System.Collections;
using System.Data;
using Innotelli.BO;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.Post
{
    public abstract class TBOT02
    {
        #region Enums
        public enum enumPostObj
        {
            POSTSuccess = 1,
            POSTFail = -1,
            POSTPeriodClosed = -2,
            POSTInValidDocumentID = -3,
            POSTNotBalance = -4,
            POSTRstNotSet = -5,
            POSTAlreadyPosted = -6,
            POSTNotPosted = -7,
            POSTAlreadyCleared = -8,
            POSTInPosting = -9,
            POSTInValidDocType = -10
        }
        #endregion

        #region Members
        
        #endregion

        #region Constructors
        public TBOT02()
        {
            mSPrps.BOID = BOID;
        }
        #endregion

        #region Properties

        #region Namespace
        public string ClassFullName
        {
            get
            {
                return GetType().FullName;
            }
        }
        public string BOID
        {
            get
            {
                return GetType().Name;
            }
        }
        #endregion

        private TSPrpsBOT02 mSPrps = new TSPrpsBOT02();
        public TSPrpsBOT02 SPrps
        {
            get
            {
                return mSPrps;
            }
        }
        public DateTime TransDate
        {
            get
            {
                return DateTime.Parse(mDao.Dr[mSPrps.DTransFldNm].ToString());
            }
        }
        public string DocID
        {
            get
            {
                return mDao.Dr[mSPrps.SKFldNm].ToString();
            }
        }
        public bool Posted
        {
            get
            {
                bool lReturnValue = false;

                lReturnValue = (bool)mDao.Dr["Posted"];
                return lReturnValue;
            }
        }
        TDataObject mDao = new TDataObject();
        public TDataObject Dao
        {
            get
            {
                return mDao;
            }
            set
            {
                mDao = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        abstract public enumPostObj PostTransaction(string aDocPK);
        abstract public enumPostObj UnPostTransaction(string aDocPK);
        abstract public bool Balance(string aDocPK);
        public enumPostObj OpenDocument(string aDocPK)
        {
            enumPostObj lReturnValue = enumPostObj.POSTFail;

            mDao.MainTable = mSPrps.Tbl;
            mDao.SQL.SetStmtByTableAndPK(mSPrps.Dmn, aDocPK);            
            mDao.OpenTable();
            if (!mDao.IsNoRow())
            {
                lReturnValue = enumPostObj.POSTSuccess;
            }
            else
            {
                lReturnValue = enumPostObj.POSTInValidDocumentID;
            }
            return lReturnValue;
        }
        public enumPostObj Post(string aDocPK)
        {
            enumPostObj lReturnValue = enumPostObj.POSTFail;

            lReturnValue = OpenDocument(aDocPK);
            if (lReturnValue != enumPostObj.POSTSuccess)
            {
                lReturnValue = enumPostObj.POSTInValidDocumentID;
            }
            if (lReturnValue == enumPostObj.POSTSuccess)
            {
                if (Posted)
                {
                    lReturnValue = enumPostObj.POSTAlreadyPosted;
                }
                else if (TBTEAccPrd.IsPeriodClose(TransDate))
                {
                    lReturnValue = enumPostObj.POSTPeriodClosed;
                }
                else if (!Balance(aDocPK))
                {
                    lReturnValue = enumPostObj.POSTNotBalance;
                }
                else
                {
                    TSingletons.BTEGL.DocID = DocID;
                    TSingletons.BTEGL.TransactionDate = TransDate;
                    TSingletons.BTEGL.DocType = BOID;
                    TSingletons.BTEGL.PrdNo = TBTEAccPrd.GetPeriod(TransDate);

                    TSingletons.BTEGL.BeginTransaction();
                    lReturnValue = PostTransaction(aDocPK);
                    TSingletons.BTEGL.EndTransaction();
                    if (lReturnValue != enumPostObj.POSTSuccess)
                    {
                    }
                    else
                    {
                    }
                    if (lReturnValue == enumPostObj.POSTSuccess)
                    {
                        mDao.Dr["Posted"] = true;
                        mDao.Dr["PostStatus"] = "Posted";
                        mDao.Dr["DTPosted"] = DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss");
                        mDao.UpdateRows();
                        lReturnValue = enumPostObj.POSTSuccess;
                    }
                    else
                    {
                        mDao.Dr["Posted"] = false;
                        mDao.Dr["PostStatus"] = "Not Posted";
                        mDao.UpdateRows();
                        lReturnValue = enumPostObj.POSTFail;
                    }
                }
            }
            return lReturnValue;
        }
        public enumPostObj UnPost(string aDocPK)
        {
            enumPostObj lReturnValue = enumPostObj.POSTFail;

            lReturnValue = OpenDocument(aDocPK);
            if (lReturnValue != enumPostObj.POSTSuccess)
            {
                lReturnValue = enumPostObj.POSTInValidDocumentID;
            }
            if (lReturnValue == enumPostObj.POSTSuccess)
            {
                if (!this.Posted)
                {
                    lReturnValue = enumPostObj.POSTNotPosted;
                }
                else if (TBTEAccPrd.IsPeriodClose(this.TransDate))
                {
                    lReturnValue = enumPostObj.POSTPeriodClosed;
                }
                else
                {
                    TSingletons.BTEGL.DocID = this.DocID;
                    TSingletons.BTEGL.DocType = this.BOID;

                    lReturnValue = UnPostTransaction(aDocPK);
                    if (lReturnValue == enumPostObj.POSTSuccess)
                    {
                        mDao.Dr["Posted"] = false;
                        mDao.Dr["PostStatus"] = "Not Posted";
                        mDao.Dr["DTPosted"] = Convert.DBNull;
                        mDao.UpdateRows();
                        lReturnValue = enumPostObj.POSTSuccess;
                    }
                    else
                    {
                        mDao.Dr["Posted"] = true;
                        mDao.Dr["PostStatus"] = "Posted";
                        mDao.UpdateRows();
                        lReturnValue = enumPostObj.POSTFail;
                    }
                }
            }
            return lReturnValue;
        }
        #endregion
    }
}
