using System;
using System.Configuration;
using System.Collections.Generic;
using System.Text;
using Innotelli.BO;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.Post
{
    public class TPostBtch
    {
        //Alex  19/12/2007
        //TActionProcessor lActionProcessor = new TActionProcessor();

        public TPostBtch()
        {

            //Innotelli.Db.TSingletons.DbObj.CnnStr = ConfigurationManager.AppSettings["abcDataConnectionString"];
            
        }

        public void Process()
        {
            int lCountFailTrn = 0;
            string lPostBtchPK = null;
            string lPostType = "";
            TDataObject lDao = new TDataObject();
            TDataObject lDaoDtl = new TDataObject();
            TSQL lSQL = new TSQL();
            bool lIsRowLock = false;

            //temp vars
            string lDocType = "";

            
            //TDomain.Count("Stts", "PostBtch", "Stts = 1", out lCountStts);
            //while (lCountStts != 0)
            //{

            lSQL.Stmt = "SELECT * FROM PostBtch WHERE Stts = 1 ";
            lDao.MainTable = "PostBtch";
            lDao.OpenTable(lSQL.Stmt);
            if (!lDao.IsNoRow())
            {
                lDao.MoveFirst();
                // by commented by Michael
                // Alex why?
                //throw new Exception();
                while (!lDao.EOF())
                {
                    lCountFailTrn = 0;
                    lPostBtchPK = lDao.Dr["prmykey"].ToString();
                    lPostType = (int.Parse(lDao.Dr["Actn"].ToString()) == 1) ? "Post" : "UnPost";

                    lIsRowLock = TRowLock.IsRowLock("PostBtch", lPostBtchPK);

                    if (!lIsRowLock)
                    {

                        lDao.Dr["Stts"] = 2;
                        lDao.UpdateRows();

                        lSQL.Stmt = "SELECT * FROM PostBtchDtl WHERE prntkey = " + lPostBtchPK + " AND Stts = 0";
                        lDaoDtl.MainTable = "PostBtchDtl";
                        lDaoDtl.OpenTable(lSQL.Stmt);
                        if (!lDaoDtl.IsNoRow())
                        {
                            lDaoDtl.MoveFirst();
                            while (!lDaoDtl.EOF())
                            {
                                //Alex  19/12/2007
                                //int lResult = -1;
                                TActionProcessor lActionProcessor = new TActionProcessor();
                                lDocType = "TB02" + lDaoDtl.Dr["DocTypeID"].ToString().Substring(5);
                                int lResult = lActionProcessor.DocPost(lDocType, lDaoDtl.Dr["DocPK"].ToString(), lPostType);

                                if (lResult == 1)
                                {
                                    lDaoDtl.Dr["Stts"] = lResult;
                                    lDaoDtl.Dr["DCmplt"] = TDtTm.Date(System.DateTime.Today);
                                    lDaoDtl.Dr["TCmplt"] = TDtTm.Time(System.DateTime.Now);

                                }
                                else
                                {
                                    lDaoDtl.Dr["Stts"] = lResult;
                                    lCountFailTrn = lCountFailTrn + 1;
                                }
                                lDaoDtl.MoveNext();
                            }
                            lDaoDtl.UpdateRows();
                        }

                        if (lCountFailTrn == 0)
                        {
                            lDao.Dr["Stts"] = 3;  // 3 = Completed
                        }
                        else
                        {
                            lDao.Dr["Stts"] = 4;  // 4 = fail
                        }
                        lDao.Dr["DCmplt"] = TDtTm.Date(System.DateTime.Today);
                        lDao.Dr["TCmplt"] = TDtTm.Time(System.DateTime.Now);
                    }

                    lDao.MoveNext();

                }
                lDao.UpdateRows();
            }
        }
    }
}
