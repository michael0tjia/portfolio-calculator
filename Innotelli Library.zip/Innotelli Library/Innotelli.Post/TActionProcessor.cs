using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Innotelli.Db;
using Innotelli.Utilities;
using System.Configuration;

namespace Innotelli.Post
{
    public class TActionProcessor
    {
        public TActionProcessor()
        {
        }
        public int DocPost(string aB02ClassFullName, string aDocPK, string aAction)
        {
            TBOT02 lBOT02 = null;
            TBOT02.enumPostObj lPostResult = TBOT02.enumPostObj.POSTFail;
            int lReturnValue = -1;
            TReflection lReflection = new TReflection();

            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                lBOT02 = (TBOT02)lReflection.CreateInstance(aB02ClassFullName);
                if (aAction == "Post")
                {
                    lPostResult = lBOT02.Post(aDocPK);
                }
                else
                {
                    lPostResult = lBOT02.UnPost(aDocPK);
                }

                lReturnValue = (int)lPostResult;
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();

                lReflectionParams["aB02ClassFullName"] = aB02ClassFullName;
                lReflectionParams["aDocPK"] = aDocPK;
                lReflectionParams["aAction"] = aAction;
                lReturnValue = (int)TReflectionClient.ExecuteMethod(this.GetType().FullName, "WSDocPost", lReflectionParams);
            }
            return lReturnValue;
        }
        public int WSDocPost(string aB02ClassFullName, string aDocPK, string aAction)
        {
            return DocPost(aB02ClassFullName, aDocPK, aAction);
        }
    }
}