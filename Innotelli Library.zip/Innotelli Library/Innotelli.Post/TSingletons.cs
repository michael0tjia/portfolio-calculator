using System;
using System.Data;
using System.Configuration;
using System.Web;


/// <summary>
/// Summary description for TSingletons
/// </summary>
/// 
namespace Innotelli.Post
{
    public static class TSingletons
    {
        private static TBTEGL mBTEGL = new TBTEGL();
        public static TBTEGL BTEGL
        {
            get 
            { 
                return TSingletons.mBTEGL; 
            }
        }

    }
}