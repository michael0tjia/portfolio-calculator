using System.Diagnostics;
using System;
using System.Collections;
using System.Data;
using Innotelli.BO;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.Post
{
	public class TBTEGL
    {
        #region Enums
        public enum enumGL
        {
            GLSuccess = 1,
            GLFail = -1,
            GLTransactionNotBegun = -2,
            GLNotBalance = -3
        }
        #endregion

        #region Members
        string mPmtInfo;
        TDataObject mDao = new TDataObject();
        bool mTransactionBegun = true;
        #endregion

        #region Constructors
        public TBTEGL()
        {
        }
        #endregion

        #region Properties
        TSPrpsBOT02 mSPrps = new TSPrpsBOT02();
        public TSPrpsBOT02 SPrps
        {
            get
            {
                return mSPrps;
            }
        }
        decimal mDebitTotal = 0;
        public decimal DebitTotal
        {
            get
            {
                return mDebitTotal;
            }
        }
        decimal mCreditTotal = 0;
        public decimal CreditTotal
        {
            get
            {
                return mCreditTotal;
            }
        }
        int mPrdNo;
        public int PrdNo
        {
            get
            {
                return mPrdNo;
            }
            set
            {
                mPrdNo = value;
            }
        }
        DateTime mTransactionDate;
        public DateTime TransactionDate
        {
            get
            {
                return mTransactionDate;
            }
            set
            {
                mTransactionDate = value;
            }
        }
        string mDocID = "";
        public string DocID
        {
            get
            {
                return mDocID;
            }
            set
            {
                mDocID = value;
            }
        }
        string mDocType = "";
        public string DocType
        {
            get
            {
                return mDocType;
            }
            set
            {
                mDocType = value;
                this.SPrps.BOID = mDocType;
            }
        }
        bool mTransactionErrorOccured = false;
        public bool TransactionErrorOccured
        {
            get
            {
                return mTransactionErrorOccured;
            }
        }
        public bool TransactionBalance
        {
            get
            {
                return (mDebitTotal == mCreditTotal);
            }
        }
        public bool TransactionSuccess
        {
            get
            {
                return (this.TransactionBalance && !this.TransactionErrorOccured);

            }
        }
        public bool UndoTransactionSuccess
        {
            get
            {
                return (!this.TransactionErrorOccured);
            }
        }
        public string PmtInfo
        {
            get
            {
                return mPmtInfo;
            }
            set
            {
                mPmtInfo = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public enumGL BeginTransaction()
        {
            enumGL lReturnValue = enumGL.GLFail;

            mPrdNo = TBTEAccPrd.GetPeriod(mTransactionDate);
            mTransactionBegun = true;
            lReturnValue = enumGL.GLSuccess;
            return lReturnValue;
        }
        public enumGL EndTransaction()
        {
            enumGL lReturnValue = enumGL.GLFail;
            ClearOptionalParams();
            lReturnValue = enumGL.GLSuccess;
            return lReturnValue;
        }
        private void ClearOptionalParams()
        {
            mPmtInfo = "";
        }
        public enumGL Reset()
        {
            enumGL lReturnValue = enumGL.GLSuccess;
            mTransactionErrorOccured = false;
            mDebitTotal = 0;
            mCreditTotal = 0;
            return lReturnValue;
        }
        public enumGL UndoTransaction()
        {
            enumGL returnValue = enumGL.GLFail;
            try
            {
                string strDocumentName;

                strDocumentName = this.SPrps.DocType;
                TSPrc lSPrc = new TSPrc();
                lSPrc.CmdType = CommandType.Text;
                lSPrc.CmdText = "Delete From GL Where DocType = '" + strDocumentName + "' And DocID = '" + mDocID + "'";
                lSPrc.ExecuteNonQuery();
                returnValue = enumGL.GLSuccess;
                mTransactionErrorOccured = false;
                return returnValue;
            }
            catch
            {
                return returnValue;
            }
        }
        public enumGL Debit(object aCOAPK, object aAmt, object aDscp)
        {
            enumGL lReturnValue = enumGL.GLFail;
            string lHdrType = "";
            string lPK = null;
            decimal lAmt = 0; 

            try
            {
                lAmt = (decimal)aAmt;

                if (!TNull.IsValueNullOrEmpty(aCOAPK))
                {
                    TDomain.Lookup("HdrType", "COA", Utilities.TGC.PKeyName + " = " + aCOAPK, out lHdrType);
                    if (mTransactionBegun && (lHdrType == "Detail") && lAmt != 0)
                    {
                        mDao.MainTable = "GL";
                        mDao.SQL.Stmt = "SELECT " + Utilities.TGC.PKeyName + ", PrdNo, DDoc, slkCOA FROM GL WHERE " + Utilities.TGC.PKeyName + " IS NULL";                        
                        mDao.OpenTable();
                        mDao.AddNewRow();
                        mDao.Dr["PrdNo"] = mPrdNo;
                        mDao.Dr["DDoc"] = mTransactionDate;
                        mDao.Dr["slkCOA"] = aCOAPK;
                        mDao.UpdateRows();
                        lPK = mDao.Dr[Utilities.TGC.PKeyName].ToString();
                        mDao.MainTable = "GL";
                        mDao.SQL.SetStmtByTableAndPK("GL", lPK);
                        mDao.OpenTable();
                        if (lAmt > 0)
                        {
                            mDao.Dr["Debit"] = lAmt;
                            mDao.Dr["DebitRate"] = lAmt;
                            mDao.Dr["Credit"] = 0;
                            mDao.Dr["CreditRate"] = 0;
                        }
                        else
                        {
                            mDao.Dr["Debit"] = 0;
                            mDao.Dr["DebitRate"] = 0;
                            mDao.Dr["Credit"] = -lAmt;
                            mDao.Dr["CreditRate"] = -lAmt;
                        }
                        mDao.Dr["Dscp"] = aDscp;
                        mDao.Dr["slkCrncy"] = 1;    // Functional Currency
                        mDao.Dr["ExchRate"] = 1;
                        mDao.Dr["DocType"] = SPrps.DocType;
                        mDao.Dr["DocID"] = mDocID;

                        if (mPmtInfo != null)
                        {
                            mDao.Dr["PmtInfo"] = mPmtInfo;
                        }
                        mDao.UpdateRows();
                        mDebitTotal = mDebitTotal + lAmt;

                        lReturnValue = enumGL.GLSuccess;
                    }
                    else
                    {
                        lReturnValue = enumGL.GLTransactionNotBegun;
                    }
                }
            }
            catch (Exception ex)
            {
                TAppLog.LogException(ex);
                lReturnValue = enumGL.GLFail;
            }

            return lReturnValue;
        }
        public enumGL Debit(object aCOAPK, object aAmt, object aDscp, object aCrncyPK, object aExchRate, object aAmtRate)
        {
            enumGL lReturnValue = enumGL.GLFail;
            string lHdrType = "";
            string lPK = null;
            decimal lAmt = 0; 
            decimal lAmtRate = 0; 

            try
            {
                lAmt = (decimal)aAmt;
                lAmtRate = (decimal)aAmtRate;

                if (!TNull.IsValueNullOrEmpty(aCOAPK))
                {
                    TDomain.Lookup("HdrType", "COA", Utilities.TGC.PKeyName + " = " + aCOAPK, out lHdrType);
                    if (mTransactionBegun && (lHdrType == "Detail") && lAmt != 0)
                    {
                        mDao.MainTable = "GL";
                        mDao.SQL.Stmt = "SELECT " + Utilities.TGC.PKeyName + ", PrdNo, DDoc, slkCOA FROM GL WHERE " + Utilities.TGC.PKeyName + " IS NULL";
                        mDao.OpenTable();
                        mDao.AddNewRow();
                        mDao.Dr["PrdNo"] = mPrdNo;
                        mDao.Dr["DDoc"] = mTransactionDate;
                        mDao.Dr["slkCOA"] = aCOAPK;
                        mDao.UpdateRows();
                        lPK = mDao.Dr[Utilities.TGC.PKeyName].ToString();
                        mDao.MainTable = "GL";
                        mDao.SQL.SetStmtByTableAndPK("GL", lPK);
                        mDao.OpenTable();
                        if (lAmt > 0)
                        {
                            mDao.Dr["Debit"] = lAmt;
                            mDao.Dr["DebitRate"] = lAmtRate;
                            mDao.Dr["Credit"] = 0;
                            mDao.Dr["CreditRate"] = 0;
                        }
                        else
                        {
                            mDao.Dr["Debit"] = 0;
                            mDao.Dr["DebitRate"] = 0;
                            mDao.Dr["Credit"] = -lAmt;
                            mDao.Dr["CreditRate"] = -lAmtRate;
                        }
                        mDao.Dr["Dscp"] = aDscp;
                        mDao.Dr["slkCrncy"] = aCrncyPK;
                        mDao.Dr["ExchRate"] = aExchRate;
                        mDao.Dr["DocType"] = SPrps.DocType;
                        mDao.Dr["DocID"] = mDocID;

                        if (mPmtInfo != null)
                        {
                            mDao.Dr["PmtInfo"] = mPmtInfo;
                        }
                        mDao.UpdateRows();
                        mDebitTotal = mDebitTotal + lAmt;

                        lReturnValue = enumGL.GLSuccess;
                    }
                    else
                    {
                        lReturnValue = enumGL.GLTransactionNotBegun;
                    }
                }
            }
            catch (Exception ex)
            {
                TAppLog.LogException(ex);
                lReturnValue = enumGL.GLFail;
            }

            return lReturnValue;
        }
        public enumGL Credit(object aCOAPK, object aAmt, object aDscp)
        {
            enumGL lReturnValue = enumGL.GLFail;
            string lHdrType = "";
            string lPK = null;
            decimal lAmt = 0;

            try
            {
                lAmt = (decimal)aAmt;

                if (!TNull.IsValueNullOrEmpty(aCOAPK))
                {
                    TDomain.Lookup("HdrType", "COA", Utilities.TGC.PKeyName + " = " + aCOAPK, out lHdrType);
                    if (mTransactionBegun && (lHdrType == "Detail") && lAmt != 0)
                    {
                        mDao.MainTable = "GL";
                        mDao.SQL.Stmt = "SELECT " + Utilities.TGC.PKeyName + ", PrdNo, DDoc, slkCOA FROM GL WHERE " + Utilities.TGC.PKeyName + " IS NULL";
                        mDao.OpenTable();
                        mDao.AddNewRow();
                        mDao.Dr["PrdNo"] = mPrdNo;
                        mDao.Dr["DDoc"] = mTransactionDate;
                        mDao.Dr["slkCOA"] = aCOAPK;
                        mDao.UpdateRows();
                        lPK = mDao.Dr[Utilities.TGC.PKeyName].ToString();
                        mDao.MainTable = "GL";
                        mDao.SQL.SetStmtByTableAndPK("GL", lPK);
                        mDao.OpenTable();
                        if (lAmt > 0)
                        {
                            mDao.Dr["Debit"] = 0;
                            mDao.Dr["DebitRate"] = 0;
                            mDao.Dr["Credit"] = lAmt;
                            mDao.Dr["CreditRate"] = lAmt;
                        }
                        else
                        {
                            mDao.Dr["Debit"] = -lAmt;
                            mDao.Dr["DebitRate"] = -lAmt;
                            mDao.Dr["Credit"] = 0;
                            mDao.Dr["CreditRate"] = 0;
                        }
                        mDao.Dr["Dscp"] = aDscp;
                        mDao.Dr["slkCrncy"] = 1;    // Functional Currency
                        mDao.Dr["ExchRate"] = 1;
                        mDao.Dr["DocType"] = SPrps.DocType;
                        mDao.Dr["DocID"] = mDocID;

                        if (mPmtInfo != null)
                        {
                            mDao.Dr["PmtInfo"] = mPmtInfo;
                        }
                        mDao.UpdateRows();
                        mDebitTotal = mDebitTotal + lAmt;

                        lReturnValue = enumGL.GLSuccess;
                    }
                    else
                    {
                        lReturnValue = enumGL.GLTransactionNotBegun;
                    }
                }
            }
            catch (Exception ex)
            {
                TAppLog.LogException(ex);
                lReturnValue = enumGL.GLFail;
            }

            return lReturnValue;
        }
        public enumGL Credit(object aCOAPK, object aAmt, object aDscp, object aCrncyPK, object aExchRate, object aAmtRate)
        {
            enumGL lReturnValue = enumGL.GLFail;
            string lHdrType = "";
            string lPK = null;
            decimal lAmt = 0;
            decimal lAmtRate = 0;

            try
            {
                lAmt = (decimal)aAmt;
                lAmtRate = (decimal)aAmtRate;

                if (!TNull.IsValueNullOrEmpty(aCOAPK))
                {
                    TDomain.Lookup("HdrType", "COA", Utilities.TGC.PKeyName + " = " + aCOAPK, out lHdrType);
                    if (mTransactionBegun && (lHdrType == "Detail") && lAmt != 0)
                    {
                        mDao.MainTable = "GL";
                        mDao.SQL.Stmt = "SELECT " + Utilities.TGC.PKeyName + ", PrdNo, DDoc, slkCOA FROM GL WHERE " + Utilities.TGC.PKeyName + " IS NULL";
                        mDao.OpenTable();
                        mDao.AddNewRow();
                        mDao.Dr["PrdNo"] = mPrdNo;
                        mDao.Dr["DDoc"] = mTransactionDate;
                        mDao.Dr["slkCOA"] = aCOAPK;
                        mDao.UpdateRows();
                        lPK = mDao.Dr[Utilities.TGC.PKeyName].ToString();
                        mDao.MainTable = "GL";
                        mDao.SQL.SetStmtByTableAndPK("GL", lPK);
                        mDao.OpenTable();
                        if (lAmt > 0)
                        {
                            mDao.Dr["Debit"] = 0;
                            mDao.Dr["DebitRate"] = 0;
                            mDao.Dr["Credit"] = lAmt;
                            mDao.Dr["CreditRate"] = lAmtRate;
                        }
                        else
                        {
                            mDao.Dr["Debit"] = -lAmt;
                            mDao.Dr["DebitRate"] = -lAmtRate;
                            mDao.Dr["Credit"] = 0;
                            mDao.Dr["CreditRate"] = 0;
                        }
                        mDao.Dr["Dscp"] = aDscp;
                        mDao.Dr["slkCrncy"] = aCrncyPK;
                        mDao.Dr["ExchRate"] = aExchRate;
                        mDao.Dr["DocType"] = SPrps.DocType;
                        mDao.Dr["DocID"] = mDocID;

                        if (mPmtInfo != null)
                        {
                            mDao.Dr["PmtInfo"] = mPmtInfo;
                        }
                        mDao.UpdateRows();
                        mDebitTotal = mDebitTotal + lAmt;

                        lReturnValue = enumGL.GLSuccess;
                    }
                    else
                    {
                        lReturnValue = enumGL.GLTransactionNotBegun;
                    }
                }
            }
            catch (Exception ex)
            {
                TAppLog.LogException(ex);
                lReturnValue = enumGL.GLFail;
            }

            return lReturnValue;
        }
        #endregion
	}
}
