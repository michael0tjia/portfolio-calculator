using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.IO;

namespace Innotelli.Drawing
{
    public class TTifConverter
    {
        byte[] mSrcBffr = null;
        bool mReqToStop = false;
        int mSrcBffrSize = 0;

        public bool ReqToStop
        {
            get
            {
                return mReqToStop;
            }
            set
            {
                mReqToStop = value;
            }
        }

        public Bitmap ConvertToBitonal(Bitmap aOrgImg)
        {
            Bitmap lRtrnVal = null;
            Bitmap lSrcImg = null;
            int lWdth = aOrgImg.Width;
            int lHght = aOrgImg.Height;
            bool lConverted = false;

            // If original bitmap is not already in 32 BPP, ARGB format, then convert
            lSrcImg = ConvertToARGB(aOrgImg, out lConverted);

            // Lock lSrcImg bitmap in memory
            BitmapData lSrcData = lSrcImg.LockBits(new Rectangle(0, 0, lWdth, lHght), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);

            // Copy image data to binary array
            int lImgSz = lSrcData.Stride * lSrcData.Height;
            if (mSrcBffrSize != lImgSz)
            {
                mSrcBffrSize = lImgSz;
                mSrcBffr = null;
                mSrcBffr = new byte[mSrcBffrSize];
            }

            Marshal.Copy(lSrcData.Scan0, mSrcBffr, 0, lImgSz);

            // Unlock lSrcImg bitmap
            lSrcImg.UnlockBits(lSrcData);
            if (lConverted)
            {
                lSrcImg.Dispose();
            }

            // Create lRtrnVal bitmap
            lRtrnVal = new Bitmap(lWdth, lHght, PixelFormat.Format1bppIndexed);

            // Lock lRtrnVal bitmap in memory
            BitmapData lDstData = lRtrnVal.LockBits(new Rectangle(0, 0, lRtrnVal.Width, lRtrnVal.Height), ImageLockMode.WriteOnly, PixelFormat.Format1bppIndexed);

            // Create lRtrnVal buffer
            lImgSz = lDstData.Stride * lDstData.Height;
            byte[] lDstBffr = new byte[lImgSz];

            int lSrcIdx = 0;
            int lDstIdx = 0;
            int lTtlPxl = 0;
            byte lDstVal = 0;
            int lPxlVal = 128;
            int lThrshld = 544;

            // Iterate lines
            for (int y = 0; y < lHght; y++)
            {
                lSrcIdx = y * lSrcData.Stride;
                lDstIdx = y * lDstData.Stride;
                lDstVal = 0;
                lPxlVal = 128;

                // Iterate pixels
                for (int x = 0; x < lWdth; x++)
                {
                    // Compute pixel brightness (i.e. total of Red, Green, and Blue values)
                    lTtlPxl = mSrcBffr[lSrcIdx + 1] + mSrcBffr[lSrcIdx + 2] + mSrcBffr[lSrcIdx + 3];
                    if (lTtlPxl > lThrshld)
                    {
                        lDstVal += (byte)lPxlVal;
                    }
                    if (lPxlVal == 1)
                    {
                        lDstBffr[lDstIdx] = lDstVal;
                        lDstIdx++;
                        lDstVal = 0;
                        lPxlVal = 128;
                    }
                    else
                    {
                        lPxlVal >>= 1;
                    }
                    lSrcIdx += 4;
                }
                if (lPxlVal != 128)
                {
                    lDstBffr[lDstIdx] = lDstVal;
                }
            }

            // Copy binary image data to lRtrnVal bitmap
            Marshal.Copy(lDstBffr, 0, lDstData.Scan0, lImgSz);

            // Unlock lRtrnVal bitmap
            lRtrnVal.UnlockBits(lDstData);

            lDstBffr = null;

            return lRtrnVal;
        }

        public Bitmap ConvertToARGB(Bitmap aOrgImg, out bool aConverted)
        {
            Bitmap lRtrnVal = null;

            // If original bitmap is not already in 32 BPP, ARGB format, then convert
            if (aOrgImg.PixelFormat != PixelFormat.Format32bppArgb)
            {
                aConverted = true;
                lRtrnVal = new Bitmap(aOrgImg.Width, aOrgImg.Height, PixelFormat.Format32bppArgb);
                lRtrnVal.SetResolution(aOrgImg.HorizontalResolution, aOrgImg.VerticalResolution);
                using (Graphics g = Graphics.FromImage(lRtrnVal))
                {
                    g.DrawImageUnscaled(aOrgImg, 0, 0);
                    g.Dispose();
                }
            }
            else
            {
                aConverted = false;
                lRtrnVal = aOrgImg;
            }

            return lRtrnVal;
        }

        public bool ConvertTiff(string aSrcPath, string aDstPath)
        {
            bool lRtrnVal = false;
            Bitmap lSrcImg = new Bitmap(aSrcPath);
            Bitmap lNewImg = null;
            Bitmap lTmpImg = null;
            Guid[] lFrmLst = lSrcImg.FrameDimensionsList;
            Guid lGd = lFrmLst[0];
            FrameDimension lFrmDim = new FrameDimension(lGd);
            int lFrmCnt = lSrcImg.GetFrameCount(lFrmDim);
            EncoderParameter lSaveParam;
            EncoderParameter lCompressParam;
            EncoderParameters lEncodeParams;
            ImageCodecInfo lImageCodecInfo = GetEncoderInfo("image/tiff");

            if (lFrmCnt > 0)
            {
                try
                {
                    if (lFrmCnt == 1)
                    {
                        lEncodeParams = new EncoderParameters(1);

                        // define compression parameter
                        lCompressParam = new EncoderParameter(Encoder.Compression, (long)EncoderValue.CompressionCCITT4);
                        lEncodeParams.Param[0] = lCompressParam;
                        lNewImg = ConvertToBitonal(lSrcImg);
                        //lNewImg = lSrcImg;
                        lNewImg.Save(aDstPath, lImageCodecInfo, lEncodeParams);
                    }
                    else
                    {
                        lEncodeParams = new EncoderParameters(2);

                        //save master bitmap
                        // define save and compression parameters for first page
                        lSaveParam = new EncoderParameter(Encoder.SaveFlag, (long)EncoderValue.MultiFrame);
                        lCompressParam = new EncoderParameter(Encoder.Compression, (long)EncoderValue.CompressionCCITT4);
                        lEncodeParams.Param[0] = lCompressParam;
                        lEncodeParams.Param[1] = lSaveParam;

                        lSrcImg.SelectActiveFrame(lFrmDim, 0);
                        lNewImg = ConvertToBitonal(lSrcImg);

                        lNewImg.Save(aDstPath, lImageCodecInfo, lEncodeParams);

                        //add frame
                        // define save and compression parameters for the rest
                        lSaveParam = new EncoderParameter(Encoder.SaveFlag, (long)EncoderValue.FrameDimensionPage);
                        lCompressParam = new EncoderParameter(Encoder.Compression, (long)EncoderValue.CompressionCCITT4);
                        lEncodeParams.Param[0] = lCompressParam;
                        lEncodeParams.Param[1] = lSaveParam;

                        for (int i = 1; i < lFrmCnt; i++)
                        {
                            if (!this.ReqToStop)
                            {
                                lSrcImg.SelectActiveFrame(lFrmDim, i);
                                lTmpImg = ConvertToBitonal(lSrcImg);
                                lNewImg.SaveAdd(lTmpImg, lEncodeParams);
                                lTmpImg.Dispose();
                            }
                            else
                            {
                                break;
                            }
                        }

                        //close
                        lSaveParam = new EncoderParameter(Encoder.SaveFlag, (long)EncoderValue.Flush);
                        lEncodeParams.Param[0] = lSaveParam;
                        lNewImg.SaveAdd(lEncodeParams);
                    }

                    lRtrnVal = true;
                }
                catch (Exception)
                {
                }
            }

            if (lSrcImg != null)
            {
                lSrcImg.Dispose();
            }
            if (lNewImg != null)
            {
                lNewImg.Dispose();
            }

            return lRtrnVal;
        }

        private ImageCodecInfo GetEncoderInfo(string aMimeType)
        {
            ImageCodecInfo[] lImgCdcInfo = ImageCodecInfo.GetImageEncoders();
            for (int i = 0; i < lImgCdcInfo.Length; i++)
            {
                if (lImgCdcInfo[i].MimeType == aMimeType)
                    return lImgCdcInfo[i];
            }
            return null;
        }
    }
}