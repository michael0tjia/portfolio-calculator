namespace Innotelli.WinForm.Control
{
    partial class TRptExplr1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TRptExplr1));
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnPreview = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gclFilter = new DevExpress.XtraGrid.GridControl();
            this.gdvFilter = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.FldNm = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colDisplayText = new DevExpress.XtraGrid.Columns.GridColumn();
            this.FldType = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colOperator = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Value1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Value2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.SelObjID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.BndCol = new DevExpress.XtraGrid.Columns.GridColumn();
            this.RwFltr = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemTextEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemTextEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemDateEditor031 = new Innotelli.WinForm.Control.RepositoryItemDateEditor03();
            this.lstRptCat = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lstRpt = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gclFilter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdvFilter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor031)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor031.VistaTimeProperties)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnPrint
            // 
            this.btnPrint.AccessibleDescription = null;
            this.btnPrint.AccessibleName = null;
            resources.ApplyResources(this.btnPrint, "btnPrint");
            this.btnPrint.BackgroundImage = null;
            this.btnPrint.Font = null;
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnPreview
            // 
            this.btnPreview.AccessibleDescription = null;
            this.btnPreview.AccessibleName = null;
            resources.ApplyResources(this.btnPreview, "btnPreview");
            this.btnPreview.BackgroundImage = null;
            this.btnPreview.Font = null;
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.UseVisualStyleBackColor = true;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.AccessibleDescription = null;
            this.groupBox2.AccessibleName = null;
            resources.ApplyResources(this.groupBox2, "groupBox2");
            this.groupBox2.BackgroundImage = null;
            this.groupBox2.Controls.Add(this.gclFilter);
            this.groupBox2.Font = null;
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.TabStop = false;
            // 
            // gclFilter
            // 
            this.gclFilter.AccessibleDescription = null;
            this.gclFilter.AccessibleName = null;
            resources.ApplyResources(this.gclFilter, "gclFilter");
            this.gclFilter.BackgroundImage = null;
            this.gclFilter.EmbeddedNavigator.AccessibleDescription = null;
            this.gclFilter.EmbeddedNavigator.AccessibleName = null;
            this.gclFilter.EmbeddedNavigator.AllowHtmlTextInToolTip = ((DevExpress.Utils.DefaultBoolean)(resources.GetObject("gclFilter.EmbeddedNavigator.AllowHtmlTextInToolTip")));
            this.gclFilter.EmbeddedNavigator.Anchor = ((System.Windows.Forms.AnchorStyles)(resources.GetObject("gclFilter.EmbeddedNavigator.Anchor")));
            this.gclFilter.EmbeddedNavigator.BackgroundImage = null;
            this.gclFilter.EmbeddedNavigator.BackgroundImageLayout = ((System.Windows.Forms.ImageLayout)(resources.GetObject("gclFilter.EmbeddedNavigator.BackgroundImageLayout")));
            this.gclFilter.EmbeddedNavigator.ImeMode = ((System.Windows.Forms.ImeMode)(resources.GetObject("gclFilter.EmbeddedNavigator.ImeMode")));
            this.gclFilter.EmbeddedNavigator.TextLocation = ((DevExpress.XtraEditors.NavigatorButtonsTextLocation)(resources.GetObject("gclFilter.EmbeddedNavigator.TextLocation")));
            this.gclFilter.EmbeddedNavigator.ToolTip = resources.GetString("gclFilter.EmbeddedNavigator.ToolTip");
            this.gclFilter.EmbeddedNavigator.ToolTipIconType = ((DevExpress.Utils.ToolTipIconType)(resources.GetObject("gclFilter.EmbeddedNavigator.ToolTipIconType")));
            this.gclFilter.EmbeddedNavigator.ToolTipTitle = resources.GetString("gclFilter.EmbeddedNavigator.ToolTipTitle");
            this.gclFilter.Font = null;
            this.gclFilter.MainView = this.gdvFilter;
            this.gclFilter.Name = "gclFilter";
            this.gclFilter.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit1,
            this.repositoryItemDateEdit1,
            this.repositoryItemCheckEdit1,
            this.repositoryItemTextEdit2,
            this.repositoryItemTextEdit3,
            this.repositoryItemDateEditor031});
            this.gclFilter.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gdvFilter});
            // 
            // gdvFilter
            // 
            resources.ApplyResources(this.gdvFilter, "gdvFilter");
            this.gdvFilter.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.FldNm,
            this.colDisplayText,
            this.FldType,
            this.colOperator,
            this.Value1,
            this.Value2,
            this.SelObjID,
            this.BndCol,
            this.RwFltr});
            this.gdvFilter.GridControl = this.gclFilter;
            this.gdvFilter.Name = "gdvFilter";
            this.gdvFilter.OptionsView.ShowColumnHeaders = false;
            this.gdvFilter.OptionsView.ShowGroupPanel = false;
            this.gdvFilter.CustomRowCellEdit += new DevExpress.XtraGrid.Views.Grid.CustomRowCellEditEventHandler(this.gdvFilter_CustomRowCellEdit);
            // 
            // FldNm
            // 
            resources.ApplyResources(this.FldNm, "FldNm");
            this.FldNm.FieldName = "FldNm";
            this.FldNm.Name = "FldNm";
            // 
            // colDisplayText
            // 
            resources.ApplyResources(this.colDisplayText, "colDisplayText");
            this.colDisplayText.FieldName = "FldAls";
            this.colDisplayText.Name = "colDisplayText";
            this.colDisplayText.OptionsColumn.AllowEdit = false;
            this.colDisplayText.OptionsColumn.AllowFocus = false;
            this.colDisplayText.OptionsColumn.ReadOnly = true;
            // 
            // FldType
            // 
            resources.ApplyResources(this.FldType, "FldType");
            this.FldType.FieldName = "FldType";
            this.FldType.Name = "FldType";
            // 
            // colOperator
            // 
            resources.ApplyResources(this.colOperator, "colOperator");
            this.colOperator.FieldName = "Condition";
            this.colOperator.Name = "colOperator";
            this.colOperator.OptionsColumn.AllowEdit = false;
            this.colOperator.OptionsColumn.AllowFocus = false;
            this.colOperator.OptionsColumn.ReadOnly = true;
            // 
            // Value1
            // 
            resources.ApplyResources(this.Value1, "Value1");
            this.Value1.FieldName = "Value1";
            this.Value1.Name = "Value1";
            // 
            // Value2
            // 
            resources.ApplyResources(this.Value2, "Value2");
            this.Value2.FieldName = "Value2";
            this.Value2.Name = "Value2";
            // 
            // SelObjID
            // 
            resources.ApplyResources(this.SelObjID, "SelObjID");
            this.SelObjID.FieldName = "SelObjID";
            this.SelObjID.Name = "SelObjID";
            // 
            // BndCol
            // 
            resources.ApplyResources(this.BndCol, "BndCol");
            this.BndCol.FieldName = "BndCol";
            this.BndCol.Name = "BndCol";
            // 
            // RwFltr
            // 
            resources.ApplyResources(this.RwFltr, "RwFltr");
            this.RwFltr.FieldName = "RwFltr";
            this.RwFltr.Name = "RwFltr";
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AccessibleDescription = null;
            this.repositoryItemTextEdit1.AccessibleName = null;
            resources.ApplyResources(this.repositoryItemTextEdit1, "repositoryItemTextEdit1");
            this.repositoryItemTextEdit1.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemTextEdit1.Mask.AutoComplete")));
            this.repositoryItemTextEdit1.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemTextEdit1.Mask.BeepOnError")));
            this.repositoryItemTextEdit1.Mask.EditMask = resources.GetString("repositoryItemTextEdit1.Mask.EditMask");
            this.repositoryItemTextEdit1.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemTextEdit1.Mask.IgnoreMaskBlank")));
            this.repositoryItemTextEdit1.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemTextEdit1.Mask.MaskType")));
            this.repositoryItemTextEdit1.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemTextEdit1.Mask.PlaceHolder")));
            this.repositoryItemTextEdit1.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemTextEdit1.Mask.SaveLiteral")));
            this.repositoryItemTextEdit1.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemTextEdit1.Mask.ShowPlaceHolders")));
            this.repositoryItemTextEdit1.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemTextEdit1.Mask.UseMaskAsDisplayFormat")));
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.AccessibleDescription = null;
            this.repositoryItemDateEdit1.AccessibleName = null;
            resources.ApplyResources(this.repositoryItemDateEdit1, "repositoryItemDateEdit1");
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemDateEdit1.Buttons"))))});
            this.repositoryItemDateEdit1.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemDateEdit1.Mask.AutoComplete")));
            this.repositoryItemDateEdit1.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemDateEdit1.Mask.BeepOnError")));
            this.repositoryItemDateEdit1.Mask.EditMask = resources.GetString("repositoryItemDateEdit1.Mask.EditMask");
            this.repositoryItemDateEdit1.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemDateEdit1.Mask.IgnoreMaskBlank")));
            this.repositoryItemDateEdit1.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemDateEdit1.Mask.MaskType")));
            this.repositoryItemDateEdit1.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemDateEdit1.Mask.PlaceHolder")));
            this.repositoryItemDateEdit1.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemDateEdit1.Mask.SaveLiteral")));
            this.repositoryItemDateEdit1.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemDateEdit1.Mask.ShowPlaceHolders")));
            this.repositoryItemDateEdit1.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemDateEdit1.Mask.UseMaskAsDisplayFormat")));
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            this.repositoryItemDateEdit1.VistaTimeProperties.AccessibleDescription = null;
            this.repositoryItemDateEdit1.VistaTimeProperties.AccessibleName = null;
            this.repositoryItemDateEdit1.VistaTimeProperties.AutoHeight = ((bool)(resources.GetObject("repositoryItemDateEdit1.VistaTimeProperties.AutoHeight")));
            this.repositoryItemDateEdit1.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemDateEdit1.VistaTimeProperties.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemDateEdit1.VistaTimeProperties.Mask.AutoComplete")));
            this.repositoryItemDateEdit1.VistaTimeProperties.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemDateEdit1.VistaTimeProperties.Mask.BeepOnError")));
            this.repositoryItemDateEdit1.VistaTimeProperties.Mask.EditMask = resources.GetString("repositoryItemDateEdit1.VistaTimeProperties.Mask.EditMask");
            this.repositoryItemDateEdit1.VistaTimeProperties.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemDateEdit1.VistaTimeProperties.Mask.IgnoreMaskBlank")));
            this.repositoryItemDateEdit1.VistaTimeProperties.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemDateEdit1.VistaTimeProperties.Mask.MaskType")));
            this.repositoryItemDateEdit1.VistaTimeProperties.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemDateEdit1.VistaTimeProperties.Mask.PlaceHolder")));
            this.repositoryItemDateEdit1.VistaTimeProperties.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemDateEdit1.VistaTimeProperties.Mask.SaveLiteral")));
            this.repositoryItemDateEdit1.VistaTimeProperties.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemDateEdit1.VistaTimeProperties.Mask.ShowPlaceHolders")));
            this.repositoryItemDateEdit1.VistaTimeProperties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemDateEdit1.VistaTimeProperties.Mask.UseMaskAsDisplayFormat")));
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.AccessibleDescription = null;
            this.repositoryItemCheckEdit1.AccessibleName = null;
            resources.ApplyResources(this.repositoryItemCheckEdit1, "repositoryItemCheckEdit1");
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // repositoryItemTextEdit2
            // 
            this.repositoryItemTextEdit2.AccessibleDescription = null;
            this.repositoryItemTextEdit2.AccessibleName = null;
            this.repositoryItemTextEdit2.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.repositoryItemTextEdit2.Appearance.Options.UseBackColor = true;
            resources.ApplyResources(this.repositoryItemTextEdit2, "repositoryItemTextEdit2");
            this.repositoryItemTextEdit2.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemTextEdit2.Mask.AutoComplete")));
            this.repositoryItemTextEdit2.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemTextEdit2.Mask.BeepOnError")));
            this.repositoryItemTextEdit2.Mask.EditMask = resources.GetString("repositoryItemTextEdit2.Mask.EditMask");
            this.repositoryItemTextEdit2.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemTextEdit2.Mask.IgnoreMaskBlank")));
            this.repositoryItemTextEdit2.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemTextEdit2.Mask.MaskType")));
            this.repositoryItemTextEdit2.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemTextEdit2.Mask.PlaceHolder")));
            this.repositoryItemTextEdit2.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemTextEdit2.Mask.SaveLiteral")));
            this.repositoryItemTextEdit2.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemTextEdit2.Mask.ShowPlaceHolders")));
            this.repositoryItemTextEdit2.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemTextEdit2.Mask.UseMaskAsDisplayFormat")));
            this.repositoryItemTextEdit2.Name = "repositoryItemTextEdit2";
            this.repositoryItemTextEdit2.ReadOnly = true;
            // 
            // repositoryItemTextEdit3
            // 
            this.repositoryItemTextEdit3.AccessibleDescription = null;
            this.repositoryItemTextEdit3.AccessibleName = null;
            resources.ApplyResources(this.repositoryItemTextEdit3, "repositoryItemTextEdit3");
            this.repositoryItemTextEdit3.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemTextEdit3.Mask.AutoComplete")));
            this.repositoryItemTextEdit3.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemTextEdit3.Mask.BeepOnError")));
            this.repositoryItemTextEdit3.Mask.EditMask = resources.GetString("repositoryItemTextEdit3.Mask.EditMask");
            this.repositoryItemTextEdit3.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemTextEdit3.Mask.IgnoreMaskBlank")));
            this.repositoryItemTextEdit3.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemTextEdit3.Mask.MaskType")));
            this.repositoryItemTextEdit3.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemTextEdit3.Mask.PlaceHolder")));
            this.repositoryItemTextEdit3.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemTextEdit3.Mask.SaveLiteral")));
            this.repositoryItemTextEdit3.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemTextEdit3.Mask.ShowPlaceHolders")));
            this.repositoryItemTextEdit3.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemTextEdit3.Mask.UseMaskAsDisplayFormat")));
            this.repositoryItemTextEdit3.Name = "repositoryItemTextEdit3";
            // 
            // repositoryItemDateEditor031
            // 
            this.repositoryItemDateEditor031.AccessibleDescription = null;
            this.repositoryItemDateEditor031.AccessibleName = null;
            resources.ApplyResources(this.repositoryItemDateEditor031, "repositoryItemDateEditor031");
            this.repositoryItemDateEditor031.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemDateEditor031.Buttons"))))});
            this.repositoryItemDateEditor031.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemDateEditor031.Mask.AutoComplete")));
            this.repositoryItemDateEditor031.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemDateEditor031.Mask.BeepOnError")));
            this.repositoryItemDateEditor031.Mask.EditMask = resources.GetString("repositoryItemDateEditor031.Mask.EditMask");
            this.repositoryItemDateEditor031.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemDateEditor031.Mask.IgnoreMaskBlank")));
            this.repositoryItemDateEditor031.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemDateEditor031.Mask.MaskType")));
            this.repositoryItemDateEditor031.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemDateEditor031.Mask.PlaceHolder")));
            this.repositoryItemDateEditor031.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemDateEditor031.Mask.SaveLiteral")));
            this.repositoryItemDateEditor031.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemDateEditor031.Mask.ShowPlaceHolders")));
            this.repositoryItemDateEditor031.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemDateEditor031.Mask.UseMaskAsDisplayFormat")));
            this.repositoryItemDateEditor031.Name = "repositoryItemDateEditor031";
            this.repositoryItemDateEditor031.VistaTimeProperties.AccessibleDescription = null;
            this.repositoryItemDateEditor031.VistaTimeProperties.AccessibleName = null;
            this.repositoryItemDateEditor031.VistaTimeProperties.AutoHeight = ((bool)(resources.GetObject("repositoryItemDateEditor031.VistaTimeProperties.AutoHeight")));
            this.repositoryItemDateEditor031.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.repositoryItemDateEditor031.VistaTimeProperties.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemDateEditor031.VistaTimeProperties.Mask.AutoComplete")));
            this.repositoryItemDateEditor031.VistaTimeProperties.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemDateEditor031.VistaTimeProperties.Mask.BeepOnError")));
            this.repositoryItemDateEditor031.VistaTimeProperties.Mask.EditMask = resources.GetString("repositoryItemDateEditor031.VistaTimeProperties.Mask.EditMask");
            this.repositoryItemDateEditor031.VistaTimeProperties.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemDateEditor031.VistaTimeProperties.Mask.IgnoreMaskBlank")));
            this.repositoryItemDateEditor031.VistaTimeProperties.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemDateEditor031.VistaTimeProperties.Mask.MaskType")));
            this.repositoryItemDateEditor031.VistaTimeProperties.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemDateEditor031.VistaTimeProperties.Mask.PlaceHolder")));
            this.repositoryItemDateEditor031.VistaTimeProperties.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemDateEditor031.VistaTimeProperties.Mask.SaveLiteral")));
            this.repositoryItemDateEditor031.VistaTimeProperties.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemDateEditor031.VistaTimeProperties.Mask.ShowPlaceHolders")));
            this.repositoryItemDateEditor031.VistaTimeProperties.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemDateEditor031.VistaTimeProperties.Mask.UseMaskAsDisplayFormat")));
            // 
            // lstRptCat
            // 
            this.lstRptCat.AccessibleDescription = null;
            this.lstRptCat.AccessibleName = null;
            resources.ApplyResources(this.lstRptCat, "lstRptCat");
            this.lstRptCat.BackgroundImage = null;
            this.lstRptCat.Font = null;
            this.lstRptCat.FormattingEnabled = true;
            this.lstRptCat.Name = "lstRptCat";
            this.lstRptCat.SelectedIndexChanged += new System.EventHandler(this.lstRptCat_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AccessibleDescription = null;
            this.label2.AccessibleName = null;
            resources.ApplyResources(this.label2, "label2");
            this.label2.Font = null;
            this.label2.Name = "label2";
            // 
            // groupBox1
            // 
            this.groupBox1.AccessibleDescription = null;
            this.groupBox1.AccessibleName = null;
            resources.ApplyResources(this.groupBox1, "groupBox1");
            this.groupBox1.BackgroundImage = null;
            this.groupBox1.Controls.Add(this.lstRptCat);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.lstRpt);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = null;
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.TabStop = false;
            // 
            // lstRpt
            // 
            this.lstRpt.AccessibleDescription = null;
            this.lstRpt.AccessibleName = null;
            resources.ApplyResources(this.lstRpt, "lstRpt");
            this.lstRpt.BackgroundImage = null;
            this.lstRpt.Font = null;
            this.lstRpt.FormattingEnabled = true;
            this.lstRpt.Name = "lstRpt";
            this.lstRpt.SelectedIndexChanged += new System.EventHandler(this.lstRpt_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AccessibleDescription = null;
            this.label1.AccessibleName = null;
            resources.ApplyResources(this.label1, "label1");
            this.label1.Font = null;
            this.label1.Name = "label1";
            // 
            // label3
            // 
            this.label3.AccessibleDescription = null;
            this.label3.AccessibleName = null;
            resources.ApplyResources(this.label3, "label3");
            this.label3.Font = null;
            this.label3.Name = "label3";
            // 
            // TRptExplr1
            // 
            this.AccessibleDescription = null;
            this.AccessibleName = null;
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnPreview);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = null;
            this.Name = "TRptExplr1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TRptExplr1_FormClosing);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gclFilter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdvFilter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor031.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor031)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnPreview;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lstRptCat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox lstRpt;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraGrid.GridControl gclFilter;
        private DevExpress.XtraGrid.Views.Grid.GridView gdvFilter;
        private DevExpress.XtraGrid.Columns.GridColumn FldNm;
        private DevExpress.XtraGrid.Columns.GridColumn colDisplayText;
        private DevExpress.XtraGrid.Columns.GridColumn FldType;
        private DevExpress.XtraGrid.Columns.GridColumn colOperator;
        private DevExpress.XtraGrid.Columns.GridColumn Value1;
        private DevExpress.XtraGrid.Columns.GridColumn Value2;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit2;
        private DevExpress.XtraGrid.Columns.GridColumn SelObjID;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit3;
        private DevExpress.XtraGrid.Columns.GridColumn BndCol;
        private Innotelli.WinForm.Control.RepositoryItemDateEditor03 repositoryItemDateEditor031;
        private DevExpress.XtraGrid.Columns.GridColumn RwFltr;
        private System.Windows.Forms.Label label3;
    
    }
}