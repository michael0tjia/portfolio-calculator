using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Innotelli.BO;

namespace Innotelli.WinForm.Control
{
    public partial class TFrmChgID : DevExpress.XtraEditors.XtraForm
    {
        private string mOldVal = "";
        private string mNewVal = "";
        private TBOT01 mBOT01 = null;

        public string OldVal
        {
            get { return mOldVal; }
            set { mOldVal = value; }
        }

        public string NewVal
        {
            get { return mNewVal; }
            set { mNewVal = value; }
        }

        public TBOT01 BOT01
        {
            get { return mBOT01; }
            set { mBOT01 = value; }
        }

        public TFrmChgID()
        {
            InitializeComponent();
        }

        private void groupControl1_Paint(object sender, PaintEventArgs e)
        {
            
        }


        private void frmChgID_Load(object sender, EventArgs e)
        {
            txtOldVal.EditValue = this.OldVal;
            this.NewVal = this.OldVal; 
        }


        private void txtOldVal_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void txtNewVal_EditValueChanged(object sender, EventArgs e)
        {

        }

        private void btnOK_Click(object sender, EventArgs e)
        {
 
                if (txtNewVal.EditValue != null)
                {
                    mNewVal = txtNewVal.EditValue.ToString();
                }
                else
                {
                    mNewVal = "";
                }
                if (mNewVal != "")
                {
                    if (!mBOT01.IsNewIDDuplicate(mNewVal))
                    {
                        DialogResult = DialogResult.OK;
                    }
                    else
                    {
                        TMessageBox.ShowInformation(Innotelli.Utilities.TSingletons.StrResx.GetStr(103));
                    }
                }
                else
                {
                    DialogResult = DialogResult.OK;
                }

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {

                DialogResult = DialogResult.Cancel;

        }
    }
}