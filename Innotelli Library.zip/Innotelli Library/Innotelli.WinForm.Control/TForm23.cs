using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace Innotelli.WinForm.Control
{
    public partial class TForm23 : DevExpress.XtraEditors.XtraForm
    {
        public TForm23()
        {
            InitializeComponent();
        }
    }
}