using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using Innotelli.BO;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterButton08")]
    public class RepositoryItemButton08 : RepositoryItemButtonEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemButton08() { RegisterButton08(); }

        //The unique name for the custom editor
        public const string Button08Name = "TButton08";

        //Return the unique name
        public override string EditorTypeName { get { return Button08Name; } }

        //Register the editor
        public static void RegisterButton08()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;

            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.Button08.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(Button08Name,
              typeof(TButton08), typeof(RepositoryItemButton08),
              typeof(ButtonEditViewInfo), new ButtonEditPainter(), true, img));
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        //Initialize new properties
        public RepositoryItemButton08()
        {
        }
        #endregion

        #region Properties
        private string mBOID = "";
        public string BOID
        {
            get
            {
                return mBOID;
            }
            set
            {
                mBOID = value;
                OnPropertiesChanged();
            }
        }

        private TBOT01 mBOT01;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
            }
        }
        private TDataGrid05 mOwnerGrid;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TDataGrid05 OwnerGrid
        {
            get
            {
                return mOwnerGrid;
            }
            set
            {
                mOwnerGrid = value;
            }
        }
        private Form mParentForm;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Form ParentForm
        {
            get
            {
                return mParentForm;
            }
            set
            {
                mParentForm = value;
            }
        }
        #endregion

        #region Event Handlers
        private void RepositoryItemButton08_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            TButton08 lButton08 = (sender as TButton08);
            TForm02 lForm02 = null;
            string lPK = "";
            //Type lPrntFrmBsTp = mParentForm.GetType().BaseType;
            string lParentFormBasicType = mParentForm.GetType().BaseType.Name;

            if (lButton08.EditValue != null && lButton08.EditValue != DBNull.Value)
            {
                lPK = lButton08.EditValue.ToString();
                if (lPK != "")
                {
                    lForm02 = TSingletons.Form02Pool.GetForm("BackOffice.UI.TF02" + mBOID.Substring(4));
                    if (lForm02 != null)
                    {
                        //lForm02.BOT01.Dt = mBOT01.Dt;
                        //lForm02.BOT01.PK2 = lPK;
                        //lForm02.BOT01.GotoRowByPK(lPK);
                        //lForm02.JustShow();
                        lForm02.LoadByPK(lPK);
                        //lForm02.DsMode = ((lPrntFrmBsTp)mParentForm).DsMode;
                        //lForm02.ShowDialog();
                        //((lPrntFrmBsTp)mParentForm).Reload();
                        switch (lParentFormBasicType)
                        {
                            case "TForm02":
                                lForm02.BOT01.FK = ((TForm02)mParentForm).BOT01.PrmyKey;
                                ((TForm02)mParentForm).DsMode = DSFormMode.DSBrowse;
                                //lForm02.DsMode = ((TForm02)mParentForm).DsMode;
                                break;
                            case "TForm07":
                                lForm02.BOT01.FK = ((TForm07)mParentForm).BOT01.PrmyKey;
                                lForm02.DsMode = ((TForm07)mParentForm).DsMode;
                                break;
                            case "TForm12":
                                lForm02.BOT01.FK = ((TForm12)mParentForm).BOT01.PrmyKey;
                                lForm02.DsMode = ((TForm12)mParentForm).DsMode;
                                break;
                            case "TForm01":
                                //lForm02.BOT01.FK = ((TForm01)mParentForm).BOT01.prmykey2;
                                //lForm02.DsMode = ((TForm01)mParentForm).DsMode;
                                break;
                            case "TForm06":
                                lForm02.BOT01.FK = ((TForm06)mParentForm).BOT01.PrmyKey;
                                lForm02.DsMode = ((TForm06)mParentForm).DsMode;
                                break;
                        }
                        lForm02.DSUpdateFormState();
                        //lForm02.MdiParent = null;
                        lForm02.Show();
                        //lForm02.ShowDialog();
                        //if (lForm02.DialogResult == DialogResult.Cancel)
                        //{
                        //    mOwnerGrid.BOT01.LoadDataSet();
                        //    mOwnerGrid.BindData();
                        //    mOwnerGrid.BOT01.IsDirty = true;
                        //}
                    }
                }
            }
        }
        #endregion

        #region Functions
        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemButton08 source = item as RepositoryItemButton08;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        public void Init()
        {
            Image img = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TButton08.Button.png"));
            Buttons[0].Kind = DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph;
            Buttons[0].Image = img;
            Buttons[0].IsLeft = true;
            Buttons[0].Width = 10;
            BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            AssignEventHandlers();
        }
        private void AssignEventHandlers()
        {
            ButtonClick += RepositoryItemButton08_ButtonClick;
        }
        #endregion
    }
    public class TButton08 : ButtonEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TButton08() { RepositoryItemButton08.RegisterButton08(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemButton08.Button08Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemButton08 Properties
        {
            get { return base.Properties as RepositoryItemButton08; }
        }
        #endregion

        #region Members
        //bool mBorderStyleIsModified = false;
        #endregion

        #region Constructors
        //Initialize the new instance
        public TButton08()
        {
            Init();
        }
        #endregion
        
        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(19, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(19, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}
