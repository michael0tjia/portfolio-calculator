using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using System;
using DevExpress.Utils;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterDateTextBox02")]
    public class RepositoryItemDateTextBox02 : RepositoryItemTextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemDateTextBox02() { RegisterDateTextBox02(); }

        //The unique name for the custom editor
        public const string DateTextBox02Name = "TDateTextBox02";

        //Return the unique name
        public override string EditorTypeName { get { return DateTextBox02Name; } }

        //Register the editor
        public static void RegisterDateTextBox02()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.DateTextBox02.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(DateTextBox02Name,
              typeof(TDateTextBox02), typeof(RepositoryItemDateTextBox02),
              typeof(TextEditViewInfo), new TextEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemDateTextBox02 source = item as RepositoryItemDateTextBox02;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        //Initialize new properties
        public RepositoryItemDateTextBox02()
        {
        }
        #endregion

        #region Properties
        private DSFormMode mDSFormMode = DSFormMode.DSEditable;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        break;
                    case DSFormMode.DSEditable:
                        break;
                    case DSFormMode.DSInsert:
                        break;
                }
                mDSFormMode = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Init()
        {
            AllowFocused = false;
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            Appearance.Options.UseBackColor = true;
            AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            AppearanceReadOnly.Options.UseBackColor = true;
            DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            DisplayFormat.FormatString = TSettings.DateFormat;
            //EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            //EditFormat.FormatString = TSettings.DateFormat;
            Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTime;
            Mask.EditMask = TSettings.DateFormat;
            //Mask.EditMask = resources.GetString("RepositoryItemDateTextBox02.Mask.EditMask");
            //Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("RepositoryItemDateTextBox02.Mask.MaskType")));
            //Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("RepositoryItemDateTextBox02.Mask.UseMaskAsDisplayFormat")));
            ReadOnly = true;
        }
        #endregion
    }


    public class TDateTextBox02 : TextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TDateTextBox02() { RepositoryItemDateTextBox02.RegisterDateTextBox02(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemDateTextBox02.DateTextBox02Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemDateTextBox02 Properties
        {
            get { return base.Properties as RepositoryItemDateTextBox02; }
        }
        #endregion

        #region Members
        private string mFormat = TSettings.DateFormat;
        #endregion

        #region Constructors


        //Initialize the new instance
        public TDateTextBox02()
        {
            Init();
        }
        #endregion

        #region Properties
        [Bindable(true),
        Category("Behavior"),
        DefaultValue("yyyy/MM/dd"),
        Description("Indicates the date format."),
        Localizable(true)]
        public string Format
        {
            get
            {
                return mFormat;
            }
            set
            {
                mFormat = value;
            }
        }
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(60, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            EditValue = null;
            Margin = new System.Windows.Forms.Padding(0);
            TabStop = false;
        }
        #endregion
    }
}