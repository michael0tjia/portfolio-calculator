namespace Innotelli.WinForm.Control
{
    partial class TForm11
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TForm11));
            this.lyc01Base = new Innotelli.WinForm.Control.TLayoutControl01();
            this.lcg01Base = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.lcg01Base2 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            ((System.ComponentModel.ISupportInitialize)(this.lyc01Base)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base2)).BeginInit();
            this.SuspendLayout();
            // 
            // lyc01Base
            // 
            this.lyc01Base.Appearance.DisabledLayoutGroupCaption.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lyc01Base.Appearance.DisabledLayoutGroupCaption.Options.UseForeColor = true;
            this.lyc01Base.Appearance.DisabledLayoutItem.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lyc01Base.Appearance.DisabledLayoutItem.Options.UseForeColor = true;
            resources.ApplyResources(this.lyc01Base, "lyc01Base");
            this.lyc01Base.Name = "lyc01Base";
            this.lyc01Base.OptionsItemText.TextAlignMode = DevExpress.XtraLayout.TextAlignMode.AlignInGroups;
            this.lyc01Base.OptionsView.EnableIndentsInGroupsWithoutBorders = true;
            this.lyc01Base.Root = this.lcg01Base;
            // 
            // lcg01Base
            // 
            resources.ApplyResources(this.lcg01Base, "lcg01Base");
            this.lcg01Base.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lcg01Base2});
            this.lcg01Base.Location = new System.Drawing.Point(0, 0);
            this.lcg01Base.Name = "lcg01Base";
            this.lcg01Base.OptionsItemText.TextToControlDistance = 2;
            this.lcg01Base.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base.Size = new System.Drawing.Size(449, 310);
            this.lcg01Base.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.lcg01Base.TextVisible = false;
            // 
            // lcg01Base2
            // 
            resources.ApplyResources(this.lcg01Base2, "lcg01Base2");
            this.lcg01Base2.Location = new System.Drawing.Point(0, 0);
            this.lcg01Base2.Name = "lcg01Base2";
            this.lcg01Base2.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base2.Size = new System.Drawing.Size(445, 306);
            this.lcg01Base2.Spacing = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base2.TextVisible = false;
            // 
            // TForm11
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lyc01Base);
            this.KeyPreview = true;
            this.Name = "TForm11";
            this.Load += new System.EventHandler(this.TForm11_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TForm11_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.lyc01Base)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        protected TLayoutControl01 lyc01Base;
        protected LayoutControlGroup01 lcg01Base;
        protected LayoutControlGroup01 lcg01Base2;
    }
}