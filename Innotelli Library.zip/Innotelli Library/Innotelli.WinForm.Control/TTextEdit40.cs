﻿using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.ViewInfo;
using Innotelli.BO;
using Innotelli.Utilities;
using System;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterTextEdit40")]
    public class RepositoryItemTextEdit40 : RepositoryItemTextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemTextEdit40() { RegisterTextEdit40(); }

        //The unique name for the custom editor
        public const string TextEdit40Name = "TTextEdit40";

        //Return the unique name
        public override string EditorTypeName { get { return TextEdit40Name; } }

        //Register the editor
        public static void RegisterTextEdit40()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.TextEdit40.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(TextEdit40Name,
              typeof(TTextEdit40), typeof(RepositoryItemTextEdit40),
              typeof(TextEditViewInfo), new TextEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemTextEdit40 source = item as RepositoryItemTextEdit40;
                if (source == null) return;
                IsLocked = source.IsLocked;
                DSFormMode = source.DSFormMode;
                BOT01 = source.BOT01;
                MaxLengthFromSysData = source.MaxLengthFromSysData;
                BoundColumnName = source.BoundColumnName;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public RepositoryItemTextEdit40()
        {
        }
        #endregion

        #region Properties
        private bool mIsLocked = false;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                ReadOnly = value;
                if (value)
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                }
                else
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
                }
                if (OwnerEdit != null)
                {
                    OwnerEdit.TabStop = !value;
                }
                mIsLocked = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        DSFormMode mDSFormMode = DSFormMode.DSEditable;
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        ReadOnly = true;
                        break;
                    case DSFormMode.DSEditable:
                        ReadOnly = false;
                        break;
                    case DSFormMode.DSInsert:
                        ReadOnly = false;
                        break;
                }
                mDSFormMode = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        TBOT01 mBOT01 = null;
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
            }
        }
        private int mMaxLengthFromSysData = 0;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int MaxLengthFromSysData
        {
            get
            {
                if (mMaxLengthFromSysData == 0)
                {
                    mMaxLengthFromSysData = GetMaxLengthFromSysData();
                }
                return mMaxLengthFromSysData;
            }
            set
            {
                mMaxLengthFromSysData = value;
            }
        }
        private string mBoundColumnName = string.Empty;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string BoundColumnName
        {
            get
            {
                if (mBoundColumnName == string.Empty)
                {
                    mBoundColumnName = TControlUtil.GetFirstBindingFieldNameFromOwnerEdit(this);
                }
                return mBoundColumnName;
            }
            set
            {
                mBoundColumnName = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Init(TBOT01 aBOT01)
        {
            AppearanceReadOnly.Options.UseBackColor = false;
            BOT01 = aBOT01;
        }
        private int GetMaxLengthFromSysData()
        {
            return (int)TNull.Nz(BOT01.SPrps.SPrpsBOT01Flds[BoundColumnName].FldSize, 0);
        }
        #endregion
    }

    public class TTextEdit40 : TextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TTextEdit40() { RepositoryItemTextEdit40.RegisterTextEdit40(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemTextEdit40.TextEdit40Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemTextEdit40 Properties
        {
            get { return base.Properties as RepositoryItemTextEdit40; }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TTextEdit40()
        {
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(15, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        protected override void OnGotFocus(EventArgs e)
        {
            base.OnGotFocus(e);
            Properties.MaxLength = Properties.MaxLengthFromSysData;
        }
        #endregion
    }
}
