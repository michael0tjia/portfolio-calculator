﻿using System;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Threading;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using DevExpress.Utils;
using Innotelli.BO;
using Innotelli.Utilities;
using DevExpress.Utils.Menu;
using System.Configuration;
using Innotelli.Db;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterPageSelector01")]
    public class RepositoryItemPageSelector01 : RepositoryItemLookUpEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemPageSelector01() { RegisterPageSelector01(); }

        //The unique name for the custom editor
        public const string PageSelector01Name = "TPageSelector01";

        //Return the unique name
        public override string EditorTypeName { get { return PageSelector01Name; } }

        //Register the editor
        public static void RegisterPageSelector01()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.PageSelector01.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(PageSelector01Name,
              typeof(TPageSelector01), typeof(RepositoryItemPageSelector01),
              typeof(LookUpEditBaseViewInfo), new ButtonEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemPageSelector01 source = item as RepositoryItemPageSelector01;
                if (source == null) return;
                TotalRecords = source.TotalRecords;
                //SelectedPage = source.SelectedPage;
                CapacityPerPage = source.CapacityPerPage;

            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        //Initialize new properties
        public RepositoryItemPageSelector01()
        {
            NullText = "";
        }

        #endregion

        #region Properties

        private int mTotalRecords = 0;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int TotalRecords
        {
            get
            {
                return mTotalRecords;
            }

            set
            {
                mTotalRecords = value;
            }
        }

        private int mTotalPages = 0;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int TotalPages
        {
            get
            {
                if (CapacityPerPage != 0)
                {
                    bool IsMod = false;
                    if (mTotalRecords % CapacityPerPage != 0)
                    {
                        IsMod = true;
                    }

                    mTotalPages = mTotalRecords / CapacityPerPage;
                    if (IsMod)
                    {
                        mTotalPages++;
                    }
                }
                return mTotalPages;
            }
        }

        //private int mSelectedPage = 1;
        //[Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        //public int SelectedPage
        //{
        //    get
        //    {
        //        return;
        //    }
        //}

        private int mCapacityPerPage = 0;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int CapacityPerPage
        {
            get
            {
                return mCapacityPerPage;
            }

            set
            {
                mCapacityPerPage = value;
            }
        }

        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Init()
        {
            AppearanceReadOnly.Options.UseBackColor = false;
            AllowNullInput = DefaultBoolean.True;
            NullText = "";
            TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
        }
        public void BindList()
        {
            DataTable lDt = null;
            //DataView lDv = null;

            lDt = GetList();
            if (lDt != null)
            {
                //lDv = new DataView();
                //lDv.Table = lDt;
                //lDv.Sort = "Val";
                DisplayMember = "Page";
                //ValueMember = "PageIndex";
                DataSource = lDt;
                InitProperties();
            }
        }
        private DataTable GetList()
        {
            DataTable lReturnValue = new DataTable("Page");

            lReturnValue.Columns.Add("Page", typeof(string));
            //lReturnValue.Columns.Add("DisplayedText", typeof(string));

            for (int i = 0; i < TotalPages; i++)
            {
                DataRow lDr = lReturnValue.NewRow();

                int lPageIndex = i + 1;
                string lDsplyPattern = "Page " + lPageIndex.ToString();
                lDr["Page"] = lDsplyPattern;
                lReturnValue.Rows.Add(lDr);
            }
            return lReturnValue;
        }
        private void InitProperties()
        {

            //View.Columns[0].Visible = false;
            ////View.Columns[0].Width = 100;
            //View.Columns[0].BestFit();
            //View.OptionsView.ShowIndicator = false;
            //View.OptionsView.ShowColumnHeaders = false;

            //View.Columns[0].Visible = false;
            //View.Columns[1].Visible = true;
            //View.Columns[2].Visible = false;
            //View.Columns[1].BestFit();
            //View.OptionsView.ShowIndicator = false;
            //View.OptionsView.ShowColumnHeaders = false;
            PopupSizeable = true;
        }
        #endregion
    }
    public class TPageSelector01 : LookUpEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TPageSelector01() { RepositoryItemPageSelector01.RegisterPageSelector01(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemPageSelector01.PageSelector01Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemPageSelector01 Properties
        {
            get { return base.Properties as RepositoryItemPageSelector01; }
        }


        #endregion

        #region Members
        #endregion

        #region Constructors
        public TPageSelector01()
        {
            EditValueChanged += new EventHandler(TPageSelector01_EditValueChanged);
        }

        void TPageSelector01_EditValueChanged(object sender, EventArgs e)
        {
            //throw new NotImplementedException();

            //DataTable lDt = (DataTable)Properties.DataSource;
            //DataRow[] lDrLs = lDt.Select("DisplayedText = '" + this.ItemIndex + "'");
            //mSelectedPage = int.Parse(lDrLs[0]["PageIndex"].ToString());

            mSelectedPage = this.ItemIndex + 1;
        }
        #endregion

        #region Properties
        private int mSelectedPage = 1;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int SelectedPage
        {
            get
            {
                return mSelectedPage;
            }
        }

        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(15 + 20, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }

        
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}