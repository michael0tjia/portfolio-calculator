namespace Innotelli.WinForm.Control
{
    partial class TForm12
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TForm12));
            this.bbi01PostAndUnPost = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.beiPostStatus = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemTextEdit9 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            ((System.ComponentModel.ISupportInitialize)(this.bmgBase)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit9)).BeginInit();
            this.SuspendLayout();
            // 
            // bmgBase
            // 
            this.bmgBase.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.bbi01PostAndUnPost,
            this.barButtonItem1,
            this.beiPostStatus});
            this.bmgBase.MaxItemId = 49;
            this.bmgBase.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit9});
            // 
            // bbi01New
            // 
            this.bbi01New.AccessibleDescription = null;
            this.bbi01New.AccessibleName = null;
            resources.ApplyResources(this.bbi01New, "bbi01New");
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.AccessibleDescription = null;
            this.barDockControlTop.AccessibleName = null;
            resources.ApplyResources(this.barDockControlTop, "barDockControlTop");
            this.barDockControlTop.Font = null;
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.AccessibleDescription = null;
            this.barDockControlBottom.AccessibleName = null;
            resources.ApplyResources(this.barDockControlBottom, "barDockControlBottom");
            this.barDockControlBottom.Font = null;
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.AccessibleDescription = null;
            this.barDockControlLeft.AccessibleName = null;
            resources.ApplyResources(this.barDockControlLeft, "barDockControlLeft");
            this.barDockControlLeft.Font = null;
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.AccessibleDescription = null;
            this.barDockControlRight.AccessibleName = null;
            resources.ApplyResources(this.barDockControlRight, "barDockControlRight");
            this.barDockControlRight.Font = null;
            // 
            // bbi01Edit
            // 
            this.bbi01Edit.AccessibleDescription = null;
            this.bbi01Edit.AccessibleName = null;
            resources.ApplyResources(this.bbi01Edit, "bbi01Edit");
            // 
            // bbi01Save
            // 
            this.bbi01Save.AccessibleDescription = null;
            this.bbi01Save.AccessibleName = null;
            resources.ApplyResources(this.bbi01Save, "bbi01Save");
            // 
            // bbi01Delete
            // 
            this.bbi01Delete.AccessibleDescription = null;
            this.bbi01Delete.AccessibleName = null;
            resources.ApplyResources(this.bbi01Delete, "bbi01Delete");
            // 
            // bbi01CancelSave
            // 
            this.bbi01CancelSave.AccessibleDescription = null;
            this.bbi01CancelSave.AccessibleName = null;
            resources.ApplyResources(this.bbi01CancelSave, "bbi01CancelSave");
            // 
            // btn02BaseExit
            // 
            this.btn02BaseExit.AccessibleDescription = null;
            this.btn02BaseExit.AccessibleName = null;
            resources.ApplyResources(this.btn02BaseExit, "btn02BaseExit");
            // 
            // bbi01First
            // 
            this.bbi01First.AccessibleDescription = null;
            this.bbi01First.AccessibleName = null;
            resources.ApplyResources(this.bbi01First, "bbi01First");
            // 
            // bbi01Prev
            // 
            this.bbi01Prev.AccessibleDescription = null;
            this.bbi01Prev.AccessibleName = null;
            resources.ApplyResources(this.bbi01Prev, "bbi01Prev");
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AccessibleDescription = null;
            this.repositoryItemTextEdit1.AccessibleName = null;
            resources.ApplyResources(this.repositoryItemTextEdit1, "repositoryItemTextEdit1");
            this.repositoryItemTextEdit1.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemTextEdit1.Mask.AutoComplete")));
            this.repositoryItemTextEdit1.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemTextEdit1.Mask.BeepOnError")));
            this.repositoryItemTextEdit1.Mask.EditMask = resources.GetString("repositoryItemTextEdit1.Mask.EditMask");
            this.repositoryItemTextEdit1.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemTextEdit1.Mask.IgnoreMaskBlank")));
            this.repositoryItemTextEdit1.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemTextEdit1.Mask.MaskType")));
            this.repositoryItemTextEdit1.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemTextEdit1.Mask.PlaceHolder")));
            this.repositoryItemTextEdit1.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemTextEdit1.Mask.SaveLiteral")));
            this.repositoryItemTextEdit1.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemTextEdit1.Mask.ShowPlaceHolders")));
            this.repositoryItemTextEdit1.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemTextEdit1.Mask.UseMaskAsDisplayFormat")));
            // 
            // repositoryItemTextEdit2
            // 
            this.repositoryItemTextEdit2.AccessibleDescription = null;
            this.repositoryItemTextEdit2.AccessibleName = null;
            resources.ApplyResources(this.repositoryItemTextEdit2, "repositoryItemTextEdit2");
            this.repositoryItemTextEdit2.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemTextEdit2.Mask.AutoComplete")));
            this.repositoryItemTextEdit2.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemTextEdit2.Mask.BeepOnError")));
            this.repositoryItemTextEdit2.Mask.EditMask = resources.GetString("repositoryItemTextEdit2.Mask.EditMask");
            this.repositoryItemTextEdit2.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemTextEdit2.Mask.IgnoreMaskBlank")));
            this.repositoryItemTextEdit2.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemTextEdit2.Mask.MaskType")));
            this.repositoryItemTextEdit2.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemTextEdit2.Mask.PlaceHolder")));
            this.repositoryItemTextEdit2.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemTextEdit2.Mask.SaveLiteral")));
            this.repositoryItemTextEdit2.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemTextEdit2.Mask.ShowPlaceHolders")));
            this.repositoryItemTextEdit2.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemTextEdit2.Mask.UseMaskAsDisplayFormat")));
            // 
            // bbi01Next
            // 
            this.bbi01Next.AccessibleDescription = null;
            this.bbi01Next.AccessibleName = null;
            resources.ApplyResources(this.bbi01Next, "bbi01Next");
            // 
            // bbi01Last
            // 
            this.bbi01Last.AccessibleDescription = null;
            this.bbi01Last.AccessibleName = null;
            resources.ApplyResources(this.bbi01Last, "bbi01Last");
            // 
            // beiBaseSelectOpt
            // 
            this.beiBaseSelectOpt.AccessibleDescription = null;
            this.beiBaseSelectOpt.AccessibleName = null;
            resources.ApplyResources(this.beiBaseSelectOpt, "beiBaseSelectOpt");
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.AccessibleDescription = null;
            this.repositoryItemComboBox1.AccessibleName = null;
            resources.ApplyResources(this.repositoryItemComboBox1, "repositoryItemComboBox1");
            // 
            // barEditItem2
            // 
            this.barEditItem2.AccessibleDescription = null;
            this.barEditItem2.AccessibleName = null;
            resources.ApplyResources(this.barEditItem2, "barEditItem2");
            // 
            // bsiEmpty2
            // 
            this.bsiEmpty2.AccessibleDescription = null;
            this.bsiEmpty2.AccessibleName = null;
            resources.ApplyResources(this.bsiEmpty2, "bsiEmpty2");
            // 
            // repositoryItemTextEdit3
            // 
            this.repositoryItemTextEdit3.AccessibleDescription = null;
            this.repositoryItemTextEdit3.AccessibleName = null;
            resources.ApplyResources(this.repositoryItemTextEdit3, "repositoryItemTextEdit3");
            this.repositoryItemTextEdit3.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemTextEdit3.Mask.AutoComplete")));
            this.repositoryItemTextEdit3.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemTextEdit3.Mask.BeepOnError")));
            this.repositoryItemTextEdit3.Mask.EditMask = resources.GetString("repositoryItemTextEdit3.Mask.EditMask");
            this.repositoryItemTextEdit3.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemTextEdit3.Mask.IgnoreMaskBlank")));
            this.repositoryItemTextEdit3.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemTextEdit3.Mask.MaskType")));
            this.repositoryItemTextEdit3.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemTextEdit3.Mask.PlaceHolder")));
            this.repositoryItemTextEdit3.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemTextEdit3.Mask.SaveLiteral")));
            this.repositoryItemTextEdit3.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemTextEdit3.Mask.ShowPlaceHolders")));
            this.repositoryItemTextEdit3.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemTextEdit3.Mask.UseMaskAsDisplayFormat")));
            // 
            // repositoryItemTextEdit4
            // 
            this.repositoryItemTextEdit4.AccessibleDescription = null;
            this.repositoryItemTextEdit4.AccessibleName = null;
            resources.ApplyResources(this.repositoryItemTextEdit4, "repositoryItemTextEdit4");
            this.repositoryItemTextEdit4.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemTextEdit4.Mask.AutoComplete")));
            this.repositoryItemTextEdit4.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemTextEdit4.Mask.BeepOnError")));
            this.repositoryItemTextEdit4.Mask.EditMask = resources.GetString("repositoryItemTextEdit4.Mask.EditMask");
            this.repositoryItemTextEdit4.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemTextEdit4.Mask.IgnoreMaskBlank")));
            this.repositoryItemTextEdit4.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemTextEdit4.Mask.MaskType")));
            this.repositoryItemTextEdit4.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemTextEdit4.Mask.PlaceHolder")));
            this.repositoryItemTextEdit4.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemTextEdit4.Mask.SaveLiteral")));
            this.repositoryItemTextEdit4.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemTextEdit4.Mask.ShowPlaceHolders")));
            this.repositoryItemTextEdit4.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemTextEdit4.Mask.UseMaskAsDisplayFormat")));
            // 
            // barStaticItem6
            // 
            this.barStaticItem6.AccessibleDescription = null;
            this.barStaticItem6.AccessibleName = null;
            resources.ApplyResources(this.barStaticItem6, "barStaticItem6");
            // 
            // barEditItem7
            // 
            this.barEditItem7.AccessibleDescription = null;
            this.barEditItem7.AccessibleName = null;
            resources.ApplyResources(this.barEditItem7, "barEditItem7");
            // 
            // repositoryItemTextEdit5
            // 
            this.repositoryItemTextEdit5.AccessibleDescription = null;
            this.repositoryItemTextEdit5.AccessibleName = null;
            resources.ApplyResources(this.repositoryItemTextEdit5, "repositoryItemTextEdit5");
            this.repositoryItemTextEdit5.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemTextEdit5.Mask.AutoComplete")));
            this.repositoryItemTextEdit5.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemTextEdit5.Mask.BeepOnError")));
            this.repositoryItemTextEdit5.Mask.EditMask = resources.GetString("repositoryItemTextEdit5.Mask.EditMask");
            this.repositoryItemTextEdit5.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemTextEdit5.Mask.IgnoreMaskBlank")));
            this.repositoryItemTextEdit5.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemTextEdit5.Mask.MaskType")));
            this.repositoryItemTextEdit5.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemTextEdit5.Mask.PlaceHolder")));
            this.repositoryItemTextEdit5.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemTextEdit5.Mask.SaveLiteral")));
            this.repositoryItemTextEdit5.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemTextEdit5.Mask.ShowPlaceHolders")));
            this.repositoryItemTextEdit5.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemTextEdit5.Mask.UseMaskAsDisplayFormat")));
            // 
            // repositoryItemTextEdit6
            // 
            this.repositoryItemTextEdit6.AccessibleDescription = null;
            this.repositoryItemTextEdit6.AccessibleName = null;
            resources.ApplyResources(this.repositoryItemTextEdit6, "repositoryItemTextEdit6");
            this.repositoryItemTextEdit6.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemTextEdit6.Mask.AutoComplete")));
            this.repositoryItemTextEdit6.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemTextEdit6.Mask.BeepOnError")));
            this.repositoryItemTextEdit6.Mask.EditMask = resources.GetString("repositoryItemTextEdit6.Mask.EditMask");
            this.repositoryItemTextEdit6.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemTextEdit6.Mask.IgnoreMaskBlank")));
            this.repositoryItemTextEdit6.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemTextEdit6.Mask.MaskType")));
            this.repositoryItemTextEdit6.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemTextEdit6.Mask.PlaceHolder")));
            this.repositoryItemTextEdit6.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemTextEdit6.Mask.SaveLiteral")));
            this.repositoryItemTextEdit6.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemTextEdit6.Mask.ShowPlaceHolders")));
            this.repositoryItemTextEdit6.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemTextEdit6.Mask.UseMaskAsDisplayFormat")));
            // 
            // barButtonItem14
            // 
            this.barButtonItem14.AccessibleDescription = null;
            this.barButtonItem14.AccessibleName = null;
            resources.ApplyResources(this.barButtonItem14, "barButtonItem14");
            // 
            // bsiEmpty3
            // 
            this.bsiEmpty3.AccessibleDescription = null;
            this.bsiEmpty3.AccessibleName = null;
            resources.ApplyResources(this.bsiEmpty3, "bsiEmpty3");
            // 
            // bbi01QuickFind
            // 
            this.bbi01QuickFind.AccessibleDescription = null;
            this.bbi01QuickFind.AccessibleName = null;
            resources.ApplyResources(this.bbi01QuickFind, "bbi01QuickFind");
            // 
            // barStandard
            // 
            this.barStandard.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.bbi01PostAndUnPost, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.barStandard.OptionsBar.AllowQuickCustomization = false;
            this.barStandard.OptionsBar.DrawDragBorder = false;
            this.barStandard.OptionsBar.UseWholeRow = true;
            resources.ApplyResources(this.barStandard, "barStandard");
            // 
            // barBaseStatus
            // 
            this.barBaseStatus.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.Width, this.beiPostStatus, "", false, true, true, 70)});
            this.barBaseStatus.OptionsBar.AllowQuickCustomization = false;
            this.barBaseStatus.OptionsBar.DisableClose = true;
            this.barBaseStatus.OptionsBar.DrawDragBorder = false;
            this.barBaseStatus.OptionsBar.UseWholeRow = true;
            resources.ApplyResources(this.barBaseStatus, "barBaseStatus");
            // 
            // bbi01PrintPreview
            // 
            this.bbi01PrintPreview.AccessibleDescription = null;
            this.bbi01PrintPreview.AccessibleName = null;
            resources.ApplyResources(this.bbi01PrintPreview, "bbi01PrintPreview");
            // 
            // bbi01Print
            // 
            this.bbi01Print.AccessibleDescription = null;
            this.bbi01Print.AccessibleName = null;
            resources.ApplyResources(this.bbi01Print, "bbi01Print");
            // 
            // repositoryItemTextEdit7
            // 
            this.repositoryItemTextEdit7.AccessibleDescription = null;
            this.repositoryItemTextEdit7.AccessibleName = null;
            resources.ApplyResources(this.repositoryItemTextEdit7, "repositoryItemTextEdit7");
            this.repositoryItemTextEdit7.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemTextEdit7.Mask.AutoComplete")));
            this.repositoryItemTextEdit7.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemTextEdit7.Mask.BeepOnError")));
            this.repositoryItemTextEdit7.Mask.EditMask = resources.GetString("repositoryItemTextEdit7.Mask.EditMask");
            this.repositoryItemTextEdit7.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemTextEdit7.Mask.IgnoreMaskBlank")));
            this.repositoryItemTextEdit7.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemTextEdit7.Mask.MaskType")));
            this.repositoryItemTextEdit7.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemTextEdit7.Mask.PlaceHolder")));
            this.repositoryItemTextEdit7.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemTextEdit7.Mask.SaveLiteral")));
            this.repositoryItemTextEdit7.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemTextEdit7.Mask.ShowPlaceHolders")));
            this.repositoryItemTextEdit7.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemTextEdit7.Mask.UseMaskAsDisplayFormat")));
            // 
            // repositoryItemTextEdit8
            // 
            this.repositoryItemTextEdit8.AccessibleDescription = null;
            this.repositoryItemTextEdit8.AccessibleName = null;
            resources.ApplyResources(this.repositoryItemTextEdit8, "repositoryItemTextEdit8");
            this.repositoryItemTextEdit8.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemTextEdit8.Mask.AutoComplete")));
            this.repositoryItemTextEdit8.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemTextEdit8.Mask.BeepOnError")));
            this.repositoryItemTextEdit8.Mask.EditMask = resources.GetString("repositoryItemTextEdit8.Mask.EditMask");
            this.repositoryItemTextEdit8.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemTextEdit8.Mask.IgnoreMaskBlank")));
            this.repositoryItemTextEdit8.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemTextEdit8.Mask.MaskType")));
            this.repositoryItemTextEdit8.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemTextEdit8.Mask.PlaceHolder")));
            this.repositoryItemTextEdit8.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemTextEdit8.Mask.SaveLiteral")));
            this.repositoryItemTextEdit8.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemTextEdit8.Mask.ShowPlaceHolders")));
            this.repositoryItemTextEdit8.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemTextEdit8.Mask.UseMaskAsDisplayFormat")));
            // 
            // bbi01TextOf
            // 
            this.bbi01TextOf.AccessibleDescription = null;
            this.bbi01TextOf.AccessibleName = null;
            resources.ApplyResources(this.bbi01TextOf, "bbi01TextOf");
            // 
            // beiCurRec
            // 
            this.beiCurRec.AccessibleDescription = null;
            this.beiCurRec.AccessibleName = null;
            resources.ApplyResources(this.beiCurRec, "beiCurRec");
            // 
            // beiRecCount
            // 
            this.beiRecCount.AccessibleDescription = null;
            this.beiRecCount.AccessibleName = null;
            resources.ApplyResources(this.beiRecCount, "beiRecCount");
            // 
            // bbi01PostAndUnPost
            // 
            this.bbi01PostAndUnPost.AccessibleDescription = null;
            this.bbi01PostAndUnPost.AccessibleName = null;
            resources.ApplyResources(this.bbi01PostAndUnPost, "bbi01PostAndUnPost");
            this.bbi01PostAndUnPost.Id = 46;
            this.bbi01PostAndUnPost.ImageIndex = 12;
            this.bbi01PostAndUnPost.Name = "bbi01PostAndUnPost";
            this.bbi01PostAndUnPost.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbi01PostAndUnPost_ItemClick);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.AccessibleDescription = null;
            this.barButtonItem1.AccessibleName = null;
            resources.ApplyResources(this.barButtonItem1, "barButtonItem1");
            this.barButtonItem1.Id = 47;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // beiPostStatus
            // 
            this.beiPostStatus.AccessibleDescription = null;
            this.beiPostStatus.AccessibleName = null;
            this.beiPostStatus.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right;
            resources.ApplyResources(this.beiPostStatus, "beiPostStatus");
            this.beiPostStatus.Edit = this.repositoryItemTextEdit9;
            this.beiPostStatus.EditValue = "UnPosted";
            this.beiPostStatus.Id = 48;
            this.beiPostStatus.Name = "beiPostStatus";
            // 
            // repositoryItemTextEdit9
            // 
            this.repositoryItemTextEdit9.AccessibleDescription = null;
            this.repositoryItemTextEdit9.AccessibleName = null;
            this.repositoryItemTextEdit9.Appearance.BackColor = System.Drawing.Color.Red;
            this.repositoryItemTextEdit9.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.repositoryItemTextEdit9.Appearance.ForeColor = System.Drawing.Color.White;
            this.repositoryItemTextEdit9.Appearance.Options.UseBackColor = true;
            this.repositoryItemTextEdit9.Appearance.Options.UseFont = true;
            this.repositoryItemTextEdit9.Appearance.Options.UseForeColor = true;
            this.repositoryItemTextEdit9.Appearance.Options.UseTextOptions = true;
            this.repositoryItemTextEdit9.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center;
            resources.ApplyResources(this.repositoryItemTextEdit9, "repositoryItemTextEdit9");
            this.repositoryItemTextEdit9.Mask.AutoComplete = ((DevExpress.XtraEditors.Mask.AutoCompleteType)(resources.GetObject("repositoryItemTextEdit9.Mask.AutoComplete")));
            this.repositoryItemTextEdit9.Mask.BeepOnError = ((bool)(resources.GetObject("repositoryItemTextEdit9.Mask.BeepOnError")));
            this.repositoryItemTextEdit9.Mask.EditMask = resources.GetString("repositoryItemTextEdit9.Mask.EditMask");
            this.repositoryItemTextEdit9.Mask.IgnoreMaskBlank = ((bool)(resources.GetObject("repositoryItemTextEdit9.Mask.IgnoreMaskBlank")));
            this.repositoryItemTextEdit9.Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("repositoryItemTextEdit9.Mask.MaskType")));
            this.repositoryItemTextEdit9.Mask.PlaceHolder = ((char)(resources.GetObject("repositoryItemTextEdit9.Mask.PlaceHolder")));
            this.repositoryItemTextEdit9.Mask.SaveLiteral = ((bool)(resources.GetObject("repositoryItemTextEdit9.Mask.SaveLiteral")));
            this.repositoryItemTextEdit9.Mask.ShowPlaceHolders = ((bool)(resources.GetObject("repositoryItemTextEdit9.Mask.ShowPlaceHolders")));
            this.repositoryItemTextEdit9.Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("repositoryItemTextEdit9.Mask.UseMaskAsDisplayFormat")));
            this.repositoryItemTextEdit9.Name = "repositoryItemTextEdit9";
            this.repositoryItemTextEdit9.ReadOnly = true;
            // 
            // TForm12
            // 
            this.AccessibleDescription = null;
            this.AccessibleName = null;
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Icon = null;
            this.Name = "TForm12";
            ((System.ComponentModel.ISupportInitialize)(this.bmgBase)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit9)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraBars.BarButtonItem bbi01PostAndUnPost;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarEditItem beiPostStatus;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit9;
    }
}