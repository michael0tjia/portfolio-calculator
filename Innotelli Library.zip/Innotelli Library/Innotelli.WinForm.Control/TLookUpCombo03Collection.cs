using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    public class TLookUpCombo03Collection : ArrayList
    {
        #region Members
        #endregion

        #region Constructors
        public TLookUpCombo03Collection()
        {
        }
        #endregion

        #region Enums
        #endregion

        #region Properties
        private int mRefreshIndex = 0;
        public int RefreshIndex
        {
            get
            {
                return mRefreshIndex; 
            }
            set 
            { 
                mRefreshIndex = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Add(System.Windows.Forms.Control aControl)
        {
            base.Add(aControl);
        }
        public void Init()
        {

                for (int i = 0; i < this.Count; i++)
                {
                    ((TLookupCombo03)this[i]).Properties.Init();
                }

        }
        public void BindAllLists()
        {

                for (int i = 0; i < this.Count; i++)
                {
                    ((TLookupCombo03)this[i]).Properties.BindList();
                }

        }
        public void BindNextList()
        {

                if (Count != 0)
                {
                    if (mRefreshIndex < 0 || mRefreshIndex > Count - 1)
                    {
                        mRefreshIndex = 0;
                    }
                    ((TLookupCombo03)this[mRefreshIndex]).Properties.BindList();
                    mRefreshIndex++;
                    if (mRefreshIndex > Count - 1)
                    {
                        mRefreshIndex = 0;
                    }
                }

        }
        public void InitForReuse()
        {

                for (int i = 0; i < this.Count; i++)
                {
                    ((TLookupCombo03)this[i]).EditValue = null;
                }

        }
        #endregion
    }
}
