namespace Innotelli.WinForm.Control
{
    partial class TForm05
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TForm05));
            this.btnSubmit = new DevExpress.XtraEditors.SimpleButton();
            this.lyc01Base = new Innotelli.WinForm.Control.TLayoutControl01();
            this.btnCancel = new DevExpress.XtraEditors.SimpleButton();
            this.lcg01Base = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.lcg01Base2 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.layoutControlGroup013 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.lci01Submit = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.lci01Cancel = new Innotelli.WinForm.Control.LayoutControlItem01();
            ((System.ComponentModel.ISupportInitialize)(this.lyc01Base)).BeginInit();
            this.lyc01Base.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup013)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Submit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Cancel)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSubmit
            // 
            resources.ApplyResources(this.btnSubmit, "btnSubmit");
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.StyleController = this.lyc01Base;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // lyc01Base
            // 
            this.lyc01Base.Appearance.DisabledLayoutGroupCaption.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lyc01Base.Appearance.DisabledLayoutGroupCaption.Options.UseForeColor = true;
            this.lyc01Base.Appearance.DisabledLayoutItem.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lyc01Base.Appearance.DisabledLayoutItem.Options.UseForeColor = true;
            this.lyc01Base.Controls.Add(this.btnCancel);
            this.lyc01Base.Controls.Add(this.btnSubmit);
            resources.ApplyResources(this.lyc01Base, "lyc01Base");
            this.lyc01Base.Name = "lyc01Base";
            this.lyc01Base.OptionsItemText.TextAlignMode = DevExpress.XtraLayout.TextAlignMode.AlignInGroups;
            this.lyc01Base.OptionsView.EnableIndentsInGroupsWithoutBorders = true;
            this.lyc01Base.Root = this.lcg01Base;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            resources.ApplyResources(this.btnCancel, "btnCancel");
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.StyleController = this.lyc01Base;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lcg01Base
            // 
            resources.ApplyResources(this.lcg01Base, "lcg01Base");
            this.lcg01Base.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lcg01Base2,
            this.layoutControlGroup013});
            this.lcg01Base.Location = new System.Drawing.Point(0, 0);
            this.lcg01Base.Name = "lcg01Base";
            this.lcg01Base.OptionsItemText.TextToControlDistance = 2;
            this.lcg01Base.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base.Size = new System.Drawing.Size(449, 310);
            this.lcg01Base.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.lcg01Base.TextVisible = false;
            // 
            // lcg01Base2
            // 
            resources.ApplyResources(this.lcg01Base2, "lcg01Base2");
            this.lcg01Base2.Location = new System.Drawing.Point(0, 0);
            this.lcg01Base2.Name = "lcg01Base2";
            this.lcg01Base2.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base2.Size = new System.Drawing.Size(445, 274);
            this.lcg01Base2.Spacing = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base2.TextVisible = false;
            // 
            // layoutControlGroup013
            // 
            resources.ApplyResources(this.layoutControlGroup013, "layoutControlGroup013");
            this.layoutControlGroup013.GroupBordersVisible = false;
            this.layoutControlGroup013.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem1,
            this.lci01Submit,
            this.lci01Cancel});
            this.layoutControlGroup013.Location = new System.Drawing.Point(0, 274);
            this.layoutControlGroup013.Name = "layoutControlGroup013";
            this.layoutControlGroup013.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup013.Size = new System.Drawing.Size(445, 32);
            this.layoutControlGroup013.Spacing = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup013.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            resources.ApplyResources(this.emptySpaceItem1, "emptySpaceItem1");
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(277, 28);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // lci01Submit
            // 
            this.lci01Submit.Control = this.btnSubmit;
            resources.ApplyResources(this.lci01Submit, "lci01Submit");
            this.lci01Submit.Location = new System.Drawing.Point(277, 0);
            this.lci01Submit.MaxSize = new System.Drawing.Size(82, 28);
            this.lci01Submit.MinSize = new System.Drawing.Size(82, 28);
            this.lci01Submit.Name = "lci01Submit";
            this.lci01Submit.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01Submit.Size = new System.Drawing.Size(82, 28);
            this.lci01Submit.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lci01Submit.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.lci01Submit.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01Submit.TextSize = new System.Drawing.Size(0, 0);
            this.lci01Submit.TextToControlDistance = 0;
            this.lci01Submit.TextVisible = false;
            // 
            // lci01Cancel
            // 
            this.lci01Cancel.Control = this.btnCancel;
            resources.ApplyResources(this.lci01Cancel, "lci01Cancel");
            this.lci01Cancel.Location = new System.Drawing.Point(359, 0);
            this.lci01Cancel.MaxSize = new System.Drawing.Size(82, 28);
            this.lci01Cancel.MinSize = new System.Drawing.Size(82, 28);
            this.lci01Cancel.Name = "lci01Cancel";
            this.lci01Cancel.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01Cancel.Size = new System.Drawing.Size(82, 28);
            this.lci01Cancel.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lci01Cancel.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.lci01Cancel.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01Cancel.TextSize = new System.Drawing.Size(0, 0);
            this.lci01Cancel.TextToControlDistance = 0;
            this.lci01Cancel.TextVisible = false;
            // 
            // TForm05
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lyc01Base);
            this.KeyPreview = true;
            this.Name = "TForm05";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TForm05_FormClosing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TForm05_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.lyc01Base)).EndInit();
            this.lyc01Base.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup013)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Submit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Cancel)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        protected TLayoutControl01 lyc01Base;
        protected LayoutControlGroup01 lcg01Base;
        protected LayoutControlGroup01 lcg01Base2;
        protected LayoutControlGroup01 layoutControlGroup013;
        protected DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        protected DevExpress.XtraEditors.SimpleButton btnCancel;
        protected DevExpress.XtraEditors.SimpleButton btnSubmit;
        protected LayoutControlItem01 lci01Submit;
        protected LayoutControlItem01 lci01Cancel;
    }
}