namespace Innotelli.WinForm.Control
{
    partial class TForm04
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TForm04));
            this.lyc01Base = new Innotelli.WinForm.Control.TLayoutControl01();
            this.txtTotalSearchedRecord = new DevExpress.XtraEditors.TextEdit();
            this.pgbSearch = new DevExpress.XtraEditors.ProgressBarControl();
            this.grdSearchResults = new DevExpress.XtraGrid.GridControl();
            this.gdvSearchResults = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.btnSearch = new DevExpress.XtraEditors.SimpleButton();
            this.grdCriteria = new DevExpress.XtraGrid.GridControl();
            this.gdvCriteria = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.colFieldName = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colOperator = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colValue1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colAnd = new DevExpress.XtraGrid.Columns.GridColumn();
            this.colValue2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemDateEditor021 = new Innotelli.WinForm.Control.RepositoryItemDateEditor02();
            this.repositoryItemDateEditor022 = new Innotelli.WinForm.Control.RepositoryItemDateEditor02();
            this.repositoryItemCheckBox031 = new Innotelli.WinForm.Control.RepositoryItemCheckBox03();
            this.btnNew = new DevExpress.XtraEditors.SimpleButton();
            this.btnOpen = new DevExpress.XtraEditors.SimpleButton();
            this.btnShowAll = new DevExpress.XtraEditors.SimpleButton();
            this.lcg01Base = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.lcg01Base2 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.layoutControlGroup011 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.lci01Search = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.lci01SearchButton = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlGroup013 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.lci01ShowAll = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.lci01Open = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.lci01New = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem011 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlItem012 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlGroup012 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.lci01SearchResults = new Innotelli.WinForm.Control.LayoutControlItem01();
            ((System.ComponentModel.ISupportInitialize)(this.lyc01Base)).BeginInit();
            this.lyc01Base.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalSearchedRecord.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pgbSearch.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdSearchResults)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdvSearchResults)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdCriteria)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdvCriteria)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor021)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor021.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor022)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor022.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckBox031)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup011)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Search)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01SearchButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup013)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01ShowAll)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Open)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01New)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem011)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem012)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup012)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01SearchResults)).BeginInit();
            this.SuspendLayout();
            // 
            // lyc01Base
            // 
            this.lyc01Base.Appearance.DisabledLayoutGroupCaption.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lyc01Base.Appearance.DisabledLayoutGroupCaption.Options.UseForeColor = true;
            this.lyc01Base.Appearance.DisabledLayoutItem.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lyc01Base.Appearance.DisabledLayoutItem.Options.UseForeColor = true;
            this.lyc01Base.Controls.Add(this.txtTotalSearchedRecord);
            this.lyc01Base.Controls.Add(this.pgbSearch);
            this.lyc01Base.Controls.Add(this.grdSearchResults);
            this.lyc01Base.Controls.Add(this.btnSearch);
            this.lyc01Base.Controls.Add(this.grdCriteria);
            this.lyc01Base.Controls.Add(this.btnNew);
            this.lyc01Base.Controls.Add(this.btnOpen);
            this.lyc01Base.Controls.Add(this.btnShowAll);
            resources.ApplyResources(this.lyc01Base, "lyc01Base");
            this.lyc01Base.Name = "lyc01Base";
            this.lyc01Base.OptionsItemText.TextAlignMode = DevExpress.XtraLayout.TextAlignMode.AlignInGroups;
            this.lyc01Base.OptionsView.EnableIndentsInGroupsWithoutBorders = true;
            this.lyc01Base.Root = this.lcg01Base;
            // 
            // txtTotalSearchedRecord
            // 
            this.txtTotalSearchedRecord.Cursor = System.Windows.Forms.Cursors.Arrow;
            resources.ApplyResources(this.txtTotalSearchedRecord, "txtTotalSearchedRecord");
            this.txtTotalSearchedRecord.Name = "txtTotalSearchedRecord";
            this.txtTotalSearchedRecord.Properties.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.txtTotalSearchedRecord.Properties.ReadOnly = true;
            this.txtTotalSearchedRecord.StyleController = this.lyc01Base;
            // 
            // pgbSearch
            // 
            resources.ApplyResources(this.pgbSearch, "pgbSearch");
            this.pgbSearch.Name = "pgbSearch";
            this.pgbSearch.StyleController = this.lyc01Base;
            // 
            // grdSearchResults
            // 
            resources.ApplyResources(this.grdSearchResults, "grdSearchResults");
            this.grdSearchResults.MainView = this.gdvSearchResults;
            this.grdSearchResults.Name = "grdSearchResults";
            this.grdSearchResults.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gdvSearchResults});
            // 
            // gdvSearchResults
            // 
            this.gdvSearchResults.GridControl = this.grdSearchResults;
            this.gdvSearchResults.Name = "gdvSearchResults";
            this.gdvSearchResults.DoubleClick += new System.EventHandler(this.gdvSearchResults_DoubleClick);
            this.gdvSearchResults.KeyUp += new System.Windows.Forms.KeyEventHandler(this.gdvSearchResults_KeyUp);
            // 
            // btnSearch
            // 
            resources.ApplyResources(this.btnSearch, "btnSearch");
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.StyleController = this.lyc01Base;
            this.btnSearch.Click += new System.EventHandler(this.btnSearch_Click);
            // 
            // grdCriteria
            // 
            resources.ApplyResources(this.grdCriteria, "grdCriteria");
            this.grdCriteria.MainView = this.gdvCriteria;
            this.grdCriteria.Name = "grdCriteria";
            this.grdCriteria.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemDateEditor021,
            this.repositoryItemDateEditor022,
            this.repositoryItemCheckBox031});
            this.grdCriteria.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gdvCriteria});
            // 
            // gdvCriteria
            // 
            this.gdvCriteria.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.colFieldName,
            this.colOperator,
            this.colValue1,
            this.colAnd,
            this.colValue2});
            this.gdvCriteria.GridControl = this.grdCriteria;
            this.gdvCriteria.HorzScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Never;
            this.gdvCriteria.Name = "gdvCriteria";
            this.gdvCriteria.OptionsSelection.EnableAppearanceFocusedRow = false;
            this.gdvCriteria.OptionsView.ShowColumnHeaders = false;
            this.gdvCriteria.OptionsView.ShowGroupPanel = false;
            this.gdvCriteria.OptionsView.ShowIndicator = false;
            this.gdvCriteria.VertScrollVisibility = DevExpress.XtraGrid.Views.Base.ScrollVisibility.Never;
            this.gdvCriteria.CellValueChanged += new DevExpress.XtraGrid.Views.Base.CellValueChangedEventHandler(this.gdvCriteria_CellValueChanged);
            this.gdvCriteria.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gdvCriteria_KeyDown);
            this.gdvCriteria.KeyUp += new System.Windows.Forms.KeyEventHandler(this.gdvCriteria_KeyUp);
            // 
            // colFieldName
            // 
            resources.ApplyResources(this.colFieldName, "colFieldName");
            this.colFieldName.FieldName = "FieldName";
            this.colFieldName.Name = "colFieldName";
            // 
            // colOperator
            // 
            resources.ApplyResources(this.colOperator, "colOperator");
            this.colOperator.FieldName = "Operator";
            this.colOperator.Name = "colOperator";
            // 
            // colValue1
            // 
            resources.ApplyResources(this.colValue1, "colValue1");
            this.colValue1.FieldName = "Value1";
            this.colValue1.Name = "colValue1";
            // 
            // colAnd
            // 
            resources.ApplyResources(this.colAnd, "colAnd");
            this.colAnd.FieldName = "And";
            this.colAnd.Name = "colAnd";
            this.colAnd.OptionsColumn.AllowEdit = false;
            this.colAnd.OptionsColumn.AllowFocus = false;
            this.colAnd.OptionsColumn.FixedWidth = true;
            this.colAnd.OptionsColumn.ReadOnly = true;
            this.colAnd.OptionsColumn.ShowCaption = false;
            // 
            // colValue2
            // 
            resources.ApplyResources(this.colValue2, "colValue2");
            this.colValue2.FieldName = "Value2";
            this.colValue2.Name = "colValue2";
            // 
            // repositoryItemDateEditor021
            // 
            this.repositoryItemDateEditor021.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemDateEditor021.Buttons"))))});
            this.repositoryItemDateEditor021.Name = "repositoryItemDateEditor021";
            this.repositoryItemDateEditor021.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // repositoryItemDateEditor022
            // 
            this.repositoryItemDateEditor022.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemDateEditor022.Buttons"))))});
            this.repositoryItemDateEditor022.Name = "repositoryItemDateEditor022";
            this.repositoryItemDateEditor022.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // repositoryItemCheckBox031
            // 
            this.repositoryItemCheckBox031.Name = "repositoryItemCheckBox031";
            // 
            // btnNew
            // 
            resources.ApplyResources(this.btnNew, "btnNew");
            this.btnNew.Name = "btnNew";
            this.btnNew.StyleController = this.lyc01Base;
            this.btnNew.Click += new System.EventHandler(this.btnNew_Click);
            // 
            // btnOpen
            // 
            this.btnOpen.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            resources.ApplyResources(this.btnOpen, "btnOpen");
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.StyleController = this.lyc01Base;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // btnShowAll
            // 
            resources.ApplyResources(this.btnShowAll, "btnShowAll");
            this.btnShowAll.Name = "btnShowAll";
            this.btnShowAll.StyleController = this.lyc01Base;
            this.btnShowAll.Click += new System.EventHandler(this.btnShowAll_Click);
            // 
            // lcg01Base
            // 
            resources.ApplyResources(this.lcg01Base, "lcg01Base");
            this.lcg01Base.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lcg01Base2,
            this.layoutControlGroup013,
            this.layoutControlGroup012});
            this.lcg01Base.Location = new System.Drawing.Point(0, 0);
            this.lcg01Base.Name = "lcg01Base";
            this.lcg01Base.OptionsItemText.TextToControlDistance = 2;
            this.lcg01Base.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base.Size = new System.Drawing.Size(772, 516);
            this.lcg01Base.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.lcg01Base.TextVisible = false;
            // 
            // lcg01Base2
            // 
            resources.ApplyResources(this.lcg01Base2, "lcg01Base2");
            this.lcg01Base2.GroupBordersVisible = false;
            this.lcg01Base2.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup011});
            this.lcg01Base2.Location = new System.Drawing.Point(0, 0);
            this.lcg01Base2.Name = "lcg01Base2";
            this.lcg01Base2.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base2.Size = new System.Drawing.Size(768, 38);
            this.lcg01Base2.TextVisible = false;
            // 
            // layoutControlGroup011
            // 
            resources.ApplyResources(this.layoutControlGroup011, "layoutControlGroup011");
            this.layoutControlGroup011.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lci01Search,
            this.lci01SearchButton});
            this.layoutControlGroup011.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup011.Name = "layoutControlGroup011";
            this.layoutControlGroup011.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup011.Size = new System.Drawing.Size(762, 32);
            this.layoutControlGroup011.Spacing = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup011.TextVisible = false;
            // 
            // lci01Search
            // 
            this.lci01Search.Control = this.grdCriteria;
            resources.ApplyResources(this.lci01Search, "lci01Search");
            this.lci01Search.Location = new System.Drawing.Point(0, 0);
            this.lci01Search.Name = "lci01Search";
            this.lci01Search.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01Search.Size = new System.Drawing.Size(676, 26);
            this.lci01Search.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 1, 1);
            this.lci01Search.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01Search.TextSize = new System.Drawing.Size(0, 0);
            this.lci01Search.TextToControlDistance = 0;
            this.lci01Search.TextVisible = false;
            // 
            // lci01SearchButton
            // 
            this.lci01SearchButton.Control = this.btnSearch;
            resources.ApplyResources(this.lci01SearchButton, "lci01SearchButton");
            this.lci01SearchButton.Location = new System.Drawing.Point(676, 0);
            this.lci01SearchButton.MaxSize = new System.Drawing.Size(80, 26);
            this.lci01SearchButton.MinSize = new System.Drawing.Size(80, 26);
            this.lci01SearchButton.Name = "lci01SearchButton";
            this.lci01SearchButton.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lci01SearchButton.Size = new System.Drawing.Size(80, 26);
            this.lci01SearchButton.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lci01SearchButton.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01SearchButton.TextSize = new System.Drawing.Size(0, 0);
            this.lci01SearchButton.TextToControlDistance = 0;
            this.lci01SearchButton.TextVisible = false;
            // 
            // layoutControlGroup013
            // 
            resources.ApplyResources(this.layoutControlGroup013, "layoutControlGroup013");
            this.layoutControlGroup013.GroupBordersVisible = false;
            this.layoutControlGroup013.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lci01ShowAll,
            this.lci01Open,
            this.lci01New,
            this.emptySpaceItem1,
            this.layoutControlItem011,
            this.layoutControlItem012});
            this.layoutControlGroup013.Location = new System.Drawing.Point(0, 480);
            this.layoutControlGroup013.Name = "layoutControlGroup013";
            this.layoutControlGroup013.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup013.Size = new System.Drawing.Size(768, 32);
            this.layoutControlGroup013.Spacing = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup013.TextVisible = false;
            // 
            // lci01ShowAll
            // 
            this.lci01ShowAll.Control = this.btnShowAll;
            resources.ApplyResources(this.lci01ShowAll, "lci01ShowAll");
            this.lci01ShowAll.Location = new System.Drawing.Point(600, 0);
            this.lci01ShowAll.MaxSize = new System.Drawing.Size(82, 28);
            this.lci01ShowAll.MinSize = new System.Drawing.Size(82, 28);
            this.lci01ShowAll.Name = "lci01ShowAll";
            this.lci01ShowAll.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01ShowAll.Size = new System.Drawing.Size(82, 28);
            this.lci01ShowAll.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lci01ShowAll.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.lci01ShowAll.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01ShowAll.TextSize = new System.Drawing.Size(0, 0);
            this.lci01ShowAll.TextToControlDistance = 0;
            this.lci01ShowAll.TextVisible = false;
            // 
            // lci01Open
            // 
            this.lci01Open.Control = this.btnOpen;
            resources.ApplyResources(this.lci01Open, "lci01Open");
            this.lci01Open.Location = new System.Drawing.Point(682, 0);
            this.lci01Open.MaxSize = new System.Drawing.Size(82, 28);
            this.lci01Open.MinSize = new System.Drawing.Size(82, 28);
            this.lci01Open.Name = "lci01Open";
            this.lci01Open.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01Open.Size = new System.Drawing.Size(82, 28);
            this.lci01Open.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lci01Open.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.lci01Open.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01Open.TextSize = new System.Drawing.Size(0, 0);
            this.lci01Open.TextToControlDistance = 0;
            this.lci01Open.TextVisible = false;
            // 
            // lci01New
            // 
            this.lci01New.Control = this.btnNew;
            resources.ApplyResources(this.lci01New, "lci01New");
            this.lci01New.Location = new System.Drawing.Point(0, 0);
            this.lci01New.MaxSize = new System.Drawing.Size(82, 28);
            this.lci01New.MinSize = new System.Drawing.Size(82, 28);
            this.lci01New.Name = "lci01New";
            this.lci01New.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01New.Size = new System.Drawing.Size(82, 28);
            this.lci01New.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lci01New.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.lci01New.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01New.TextSize = new System.Drawing.Size(0, 0);
            this.lci01New.TextToControlDistance = 0;
            this.lci01New.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            resources.ApplyResources(this.emptySpaceItem1, "emptySpaceItem1");
            this.emptySpaceItem1.Location = new System.Drawing.Point(302, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(106, 28);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem011
            // 
            this.layoutControlItem011.ContentVisible = false;
            this.layoutControlItem011.Control = this.pgbSearch;
            resources.ApplyResources(this.layoutControlItem011, "layoutControlItem011");
            this.layoutControlItem011.Location = new System.Drawing.Point(82, 0);
            this.layoutControlItem011.Name = "layoutControlItem011";
            this.layoutControlItem011.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem011.Size = new System.Drawing.Size(220, 28);
            this.layoutControlItem011.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 4, 4);
            this.layoutControlItem011.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem011.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem011.TextToControlDistance = 0;
            this.layoutControlItem011.TextVisible = false;
            // 
            // layoutControlItem012
            // 
            this.layoutControlItem012.Control = this.txtTotalSearchedRecord;
            resources.ApplyResources(this.layoutControlItem012, "layoutControlItem012");
            this.layoutControlItem012.Location = new System.Drawing.Point(408, 0);
            this.layoutControlItem012.Name = "layoutControlItem012";
            this.layoutControlItem012.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem012.Size = new System.Drawing.Size(192, 28);
            this.layoutControlItem012.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 4, 0);
            this.layoutControlItem012.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem012.TextSize = new System.Drawing.Size(128, 13);
            this.layoutControlItem012.TextToControlDistance = 2;
            // 
            // layoutControlGroup012
            // 
            resources.ApplyResources(this.layoutControlGroup012, "layoutControlGroup012");
            this.layoutControlGroup012.GroupBordersVisible = false;
            this.layoutControlGroup012.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lci01SearchResults});
            this.layoutControlGroup012.Location = new System.Drawing.Point(0, 38);
            this.layoutControlGroup012.Name = "layoutControlGroup012";
            this.layoutControlGroup012.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup012.Size = new System.Drawing.Size(768, 442);
            this.layoutControlGroup012.TextVisible = false;
            // 
            // lci01SearchResults
            // 
            this.lci01SearchResults.Control = this.grdSearchResults;
            resources.ApplyResources(this.lci01SearchResults, "lci01SearchResults");
            this.lci01SearchResults.Location = new System.Drawing.Point(0, 0);
            this.lci01SearchResults.Name = "lci01SearchResults";
            this.lci01SearchResults.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01SearchResults.Size = new System.Drawing.Size(762, 436);
            this.lci01SearchResults.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01SearchResults.TextSize = new System.Drawing.Size(0, 0);
            this.lci01SearchResults.TextToControlDistance = 0;
            this.lci01SearchResults.TextVisible = false;
            // 
            // TForm04
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lyc01Base);
            this.KeyPreview = true;
            this.Name = "TForm04";
            this.Load += new System.EventHandler(this.TForm04_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.TForm04_KeyUp);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TForm04_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.lyc01Base)).EndInit();
            this.lyc01Base.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalSearchedRecord.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pgbSearch.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdSearchResults)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdvSearchResults)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grdCriteria)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdvCriteria)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor021.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor021)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor022.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor022)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckBox031)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup011)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Search)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01SearchButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup013)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01ShowAll)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Open)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01New)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem011)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem012)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup012)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01SearchResults)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        protected TLayoutControl01 lyc01Base;
        private DevExpress.XtraEditors.SimpleButton btnOpen;
        private DevExpress.XtraEditors.SimpleButton btnShowAll;
        private LayoutControlGroup01 lcg01Base;
        protected LayoutControlGroup01 lcg01Base2;
        private LayoutControlGroup01 layoutControlGroup013;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private LayoutControlItem01 lci01ShowAll;
        private LayoutControlItem01 lci01Open;
        private DevExpress.XtraEditors.SimpleButton btnSearch;
        protected DevExpress.XtraGrid.GridControl grdCriteria;
        private DevExpress.XtraGrid.Views.Grid.GridView gdvCriteria;
        private DevExpress.XtraGrid.Columns.GridColumn colFieldName;
        private DevExpress.XtraGrid.Columns.GridColumn colOperator;
        private DevExpress.XtraGrid.Columns.GridColumn colValue1;
        private DevExpress.XtraGrid.Columns.GridColumn colAnd;
        private DevExpress.XtraGrid.Columns.GridColumn colValue2;
        private DevExpress.XtraEditors.SimpleButton btnNew;
        protected LayoutControlItem01 lci01Search;
        protected LayoutControlItem01 lci01SearchButton;
        private LayoutControlItem01 lci01New;
        protected DevExpress.XtraGrid.GridControl grdSearchResults;
        private DevExpress.XtraGrid.Views.Grid.GridView gdvSearchResults;
        private LayoutControlItem01 lci01SearchResults;
        private LayoutControlGroup01 layoutControlGroup012;
        protected LayoutControlGroup01 layoutControlGroup011;
        private RepositoryItemDateEditor02 repositoryItemDateEditor021;
        private RepositoryItemDateEditor02 repositoryItemDateEditor022;
        private RepositoryItemCheckBox03 repositoryItemCheckBox031;
        private DevExpress.XtraEditors.ProgressBarControl pgbSearch;
        private LayoutControlItem01 layoutControlItem011;
        private DevExpress.XtraEditors.TextEdit txtTotalSearchedRecord;
        private LayoutControlItem01 layoutControlItem012;
    }
}