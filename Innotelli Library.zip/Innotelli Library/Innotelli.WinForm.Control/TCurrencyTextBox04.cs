using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using System;
using DevExpress.Utils;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterCurrencyTextBox04")]
    public class RepositoryItemCurrencyTextBox04 : RepositoryItemTextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemCurrencyTextBox04() { RegisterCurrencyTextBox04(); }

        //The unique name for the custom editor
        public const string CurrencyTextBox04Name = "TCurrencyTextBox04";

        //Return the unique name
        public override string EditorTypeName { get { return CurrencyTextBox04Name; } }

        //Register the editor
        public static void RegisterCurrencyTextBox04()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            //TODO: Michael help
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.CurrencyTextBox04.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(CurrencyTextBox04Name,
              typeof(TCurrencyTextBox04), typeof(RepositoryItemCurrencyTextBox04),
              typeof(TextEditViewInfo), new TextEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemCurrencyTextBox04 source = item as RepositoryItemCurrencyTextBox04;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Constructors
        //Initialize new properties
        public RepositoryItemCurrencyTextBox04()
        {
        }
        #endregion

        #region Properties
        private DSFormMode mDSFormMode = DSFormMode.DSEditable;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                TRepositoryItemTextEditUtil.SetDSFormModeReadOnly(this, value);
                mDSFormMode = value;
            }
        }
        #endregion

        #region Functions
        public void Init()
        {
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            Appearance.Options.UseBackColor = true;
            Appearance.Options.UseTextOptions = true;
            Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            AppearanceReadOnly.Options.UseBackColor = true;
            AppearanceReadOnly.Options.UseTextOptions = true;
            AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            MaxLength = 255;
            ReadOnly = true;
            DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            DisplayFormat.FormatString = TSettings.CurFormat;
            EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            EditFormat.FormatString = TSettings.CurFormat;
            Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            Mask.EditMask = TSettings.CurFormat;
        }
        #endregion
    }

    public class TCurrencyTextBox04 : TextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TCurrencyTextBox04() { RepositoryItemCurrencyTextBox04.RegisterCurrencyTextBox04(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemCurrencyTextBox04.CurrencyTextBox04Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemCurrencyTextBox04 Properties
        {
            get { return base.Properties as RepositoryItemCurrencyTextBox04; }
        }
        #endregion

        #region Constructors
        //Initialize the new instance
        public TCurrencyTextBox04()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(50, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        //DefaultValue("###,###,###,##0.00; -###,###,###,##0.00"),
        private string mFormat = TSettings.CurFormat;
        [Bindable(true),
        Category("Behavior"),
        DefaultValue("n2"),
        Description("Indicates the numeric format."),
        Localizable(true)]
        public string Format
        {
            get
            {
                return mFormat;
            }
            set
            {
                mFormat = value;
            }
        }
        #endregion

        #region Event Handlers
        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);
            SelectionStart = 0;
            SelectionLength = 255;
        }
        protected override void OnEditValueChanged()
        {
            base.OnEditValueChanged();
            if (Utilities.TGC.IsRunTime)
            {
                TTextEditUtil.UpdateForeColor(this);
            }
        }
        #endregion

        #region Functions
        private void Init()
        {
            TabStop = false;
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}