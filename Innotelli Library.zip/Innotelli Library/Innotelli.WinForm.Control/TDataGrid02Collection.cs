using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Innotelli.Utilities;
using System.Windows.Forms;

namespace Innotelli.WinForm.Control
{
    public class TDataGrid02Collection : ArrayList
    {
        #region Members
        #endregion

        #region Constructors
        public TDataGrid02Collection()
        {
        }
        #endregion

        #region Enums
        #endregion

        #region Properties
        public List<TForm02> OpenedChildForms
        {
            get
            {
                List<TForm02> lReturnValue = new List<TForm02>();

                for (int i = 0; i < Count; i++)
                {
                    foreach (KeyValuePair<TDbRowID, TForm02> keyValuePair in ((TDataGrid02)this[i]).ChildForm02s)
                    {
                        lReturnValue.Add(keyValuePair.Value);
                    }
                }

                return lReturnValue;
            }
        }    
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Add(System.Windows.Forms.Control aControl)
        {
            base.Add(aControl);
        }
        public void Init(Form aParentForm)
        {
            for (int i = 0; i < Count; i++)
            {

                ((TDataGrid02)this[i]).ParentForm = aParentForm;
                ((TDataGrid02)this[i]).Init();
            }
        }
        public void BindData()
        {
            for (int i = 0; i < Count; i++)
            {
                ((TDataGrid02)this[i]).BindData();
            }
        }
        public void SetDSMode(DSFormMode aDSFormMode)
        {
            for (int i = 0; i < Count; i++)
            {
                ((TDataGrid02)this[i]).DSFormMode = aDSFormMode;
            }
        }
        //TODO: Button05 Open
        public void SetButton05EnableVal(bool aVal)
        {
            for (int i = 0; i < Count; i++)
            {
                ((TDataGrid02)this[i]).SetButton05EnableVal(aVal);
            }
        }
        public void EnforceDoValidate()
        {
            for (int i = 0; i < Count; i++)
            {
                ((TDataGrid02)this[i]).EnforceDoValidate();
            }
        }

        #endregion
    }
}