using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Innotelli.WinForm.Control;
using Innotelli.BO;
using System.Reflection;

namespace Innotelli.WinForm.Control
{
    public partial class TForm05 : DevExpress.XtraEditors.XtraForm
    {
        #region Enums

        #endregion

        #region Members
        private TBOT05 mBOT05 = null;
        private TBOT06 mBOT06 = null;
        private TDataGrid04Collection mDataGridCollection = new TDataGrid04Collection();
        #endregion

        #region Constructors
        public TForm05()
        {
            InitializeComponent();
        }
        #endregion

        #region Properties
        public TBOT05 BOT05
        {
            get
            {
                return mBOT05;
            }
            set
            {
                mBOT05 = value;
            }
        }
        public TBOT06 BOT06
        {
            get
            {
                return mBOT06;
            }
            set
            {
                mBOT06 = value;
            }
        }
        public TDataGrid04Collection DataGridCollection
        {
            get
            {
                return mDataGridCollection;
            }
            set
            {
                if (mDataGridCollection == value)
                    return;
                mDataGridCollection = value;
            }
        }
        #endregion

        #region Event Handlers
        private void btnSubmit_Click(object sender, EventArgs e)
        {

                Submit();

        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Cancel();
        }
        #endregion

        #region Functions
        protected virtual void Init()
        {
            if (Utilities.TGC.IsRunTime)
            {
                CreateDataGridCollection();
                AssignBOToGrids();
                InitDataGridCollection();
            }
        }
        public virtual void Submit()
        {
            DialogResult = DialogResult.OK;
            mBOT06.Dt.Clear();
            //Close();
        }
        public virtual void Cancel()
        {
            DialogResult = DialogResult.Cancel;
            //Close();
        }
        public void CreateDataGridCollection()
        {

                foreach (System.Windows.Forms.Control lControl in lyc01Base.Controls)
                {
                    if ((lControl.GetType() == typeof(TDataGrid04)))
                    {
                        DataGridCollection.Add(lControl);
                    }
                }

        }
        private void InitDataGridCollection()
        {

                foreach (TDataGrid04 lDataGrid04 in DataGridCollection)
                {
                    lDataGrid04.Init();
                }
  
        }
        protected virtual void AssignBOToGrids()
        {
        }
        protected void BindDataGridCollection()
        {

                foreach (TDataGrid04 lDataGrid04 in DataGridCollection)
                {
                    lDataGrid04.BindData();
                }
    
        }
        #endregion

        private void TForm05_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.S && e.Control && e.Alt && e.Shift)
            {
                foreach (TDataGrid04 lDataGrid04 in mDataGridCollection)
                {
                    ((DevExpress.XtraGrid.Views.Base.ColumnView)lDataGrid04.MainView).SaveLayoutToXml("D:\\" + lDataGrid04.Name + ".xml");
                }
                e.Handled = true;
            }
        }

        private void TForm05_FormClosing(object sender, FormClosingEventArgs e)
        {
            foreach (TDataGrid04 lDataGrid04 in mDataGridCollection)
            {
                ((DevExpress.XtraGrid.Views.Base.ColumnView)lDataGrid04.MainView).SaveLayoutToXml("D:\\" + lDataGrid04.Name + ".xml");
            }
        }
    }
}