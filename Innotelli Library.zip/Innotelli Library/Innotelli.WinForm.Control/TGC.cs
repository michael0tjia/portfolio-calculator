using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.WinForm.Control
{
    public sealed class TGC
    {
        private static double cPixelPerCm = 37.795275591;
        private static double cTwipsPerPixel = 15;

        public static double PixelPerCm
        {
            get
            {
                return cPixelPerCm;
            }
        }

        public static double TwipsPerPixel
        {
            get
            {
                return cTwipsPerPixel;
            }
        }
    }
}
