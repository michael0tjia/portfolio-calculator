﻿using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.Utils;
using DevExpress.Utils.Menu;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.ViewInfo;
using Innotelli.BO;
using Innotelli.Utilities;
using DevExpress.XtraGrid.Columns;
using DevExpress.Data.Filtering;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterLookupCombo40")]
    public class RepositoryItemLookupCombo40 : RepositoryItemGridLookUpEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemLookupCombo40()
        {
            RegisterLookupCombo40();
        }

        //The unique name for the custom editor
        public const string LookupCombo40Name = "TLookupCombo40";

        //Return the unique name
        public override string EditorTypeName
        {
            get
            {
                return LookupCombo40Name;
            }
        }

        //Register the editor
        public static void RegisterLookupCombo40()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.LookupCombo40.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(LookupCombo40Name,
              typeof(TLookupCombo40), typeof(RepositoryItemLookupCombo40),
              typeof(GridLookUpEditBaseViewInfo), new ButtonEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemLookupCombo40 source = item as RepositoryItemLookupCombo40;
                if (source == null) return;
                BndCol = source.BndCol;
                BOID = source.BOID;
                BOT01 = source.BOT01;
                BoundColumnName = source.BoundColumnName;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public RepositoryItemLookupCombo40()
        {
            View.CustomFilterDisplayText += new DevExpress.XtraEditors.Controls.ConvertEditValueEventHandler(View_CustomFilterDisplayText);
        }
        #endregion

        #region Properties
        private bool mIsLocked = false;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                ReadOnly = value;
                if (value)
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                }
                else
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
                }
                if (OwnerEdit != null)
                {
                    OwnerEdit.TabStop = !value;
                }
                for (int i = 0; i < Buttons.Count; i++)
                {
                    Buttons[i].Enabled = !value;
                }
                mIsLocked = value;
            }
        }
        private DSFormMode mDSFormMode = DSFormMode.DSEditable;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        ReadOnly = true;
                        break;
                    case DSFormMode.DSEditable:
                        ReadOnly = false;
                        break;
                    case DSFormMode.DSInsert:
                        ReadOnly = false;
                        break;
                }
                for (int i = 0; i < Buttons.Count; i++)
                {
                    Buttons[i].Enabled = !ReadOnly;
                }
                mDSFormMode = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string RowFilter
        {
            get
            {
                if (DataSource != null)
                {
                    return ((DataView)DataSource).RowFilter;
                }
                else
                {
                    return string.Empty;
                }
            }
            set
            {
                string lRowFilter = string.Empty;
                TDbRowID lSelectionPK = TDbRowID.Null;

                if (value != null && DataSource != null)
                {
                    if (mBOT01 != null && !string.IsNullOrEmpty(mValueMemberValue))
                    {
                        if (mBOT01.Dr[mBoundColumnName] != null)
                        {
                            lSelectionPK = (int)mBOT01.Dr[mBoundColumnName];

                        }
                        lRowFilter = "(" + ValueMember + " = " + lSelectionPK + ")";
                        lRowFilter = lRowFilter + " OR (" + value + ")";
                    }
                    else
                    {
                        lRowFilter = value;
                    }
                    ((DataView)DataSource).RowFilter = lRowFilter;
                }
            }
        }
        private string mValueMemberValue = string.Empty;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string ValueMemberValue
        {
            get
            {
                return mValueMemberValue;
            }
            set
            {
                mValueMemberValue = value;
            }
        }
        private bool mNormalMode = true;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool NormalMode
        {
            get
            {
                return mNormalMode;
            }
            set
            {
                mNormalMode = value;
            }
        }
        private TBOT01 mBOT01 = null;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
                if (mBOT01 != null && OwnerEdit != null)
                {
                    mBoundColumnName = TControlUtil.GetFirstBindingFieldName(OwnerEdit);
                    if (mBoundColumnName != string.Empty)
                    {
                        mBOID = mBOT01.SPrps.SPrpsBOT01Flds[mBoundColumnName].SelObjID;
                    }
                }
            }
        }
        private string mBoundColumnName = string.Empty;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string BoundColumnName
        {
            get
            {
                return mBoundColumnName;

            }
            set
            {
                mBoundColumnName = value;
                if (mBOT01 != null)
                {
                    mBOID = mBOT01.SPrps.SPrpsBOT01Flds[mBoundColumnName].SelObjID;
                }
            }
        }
        private string mBOID = string.Empty;
        public string BOID
        {
            get
            {
                return mBOID;
            }
            set
            {
                mBOID = value;
                OnPropertiesChanged();
            }
        }
        private int mBndCol = 0;
        public int BndCol
        {
            get
            {
                return mBndCol;
            }
            set
            {
                mBndCol = value;
                OnPropertiesChanged();
            }
        }
        private int mType = 0;
        public int Type
        {
            get
            {
                return mType;
            }
            set
            {
                mType = value;
                OnPropertiesChanged();
            }
        }
        #endregion

        #region Event Handlers
        private void View_CustomFilterDisplayText(object sender, DevExpress.XtraEditors.Controls.ConvertEditValueEventArgs e)
        {
            e.Value = string.Empty;
            e.Handled = true;
        }
        #endregion

        #region Functions
        public void Init()
        {
            Image lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TLookupCombo40.Button.png"));

            AppearanceReadOnly.Options.UseBackColor = false;
            NullText = string.Empty;
            AllowNullInput = DefaultBoolean.True;
            TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            View.OptionsView.ShowAutoFilterRow = true;
            if (Buttons.Count == 0)
            {
                Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] { new DevExpress.XtraEditors.Controls.EditorButton() });
            }
            Buttons[0].Kind = DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph;
            Buttons[0].Image = lImage;
        }
        private void InitColumns()
        {
            int lListWidth = 0;
            TSPrpsBOT01LookUpColumns lSPrpsBOT01LookUpColumns = null;
            GridColumn lGc = null;
            int lVisibleIndex = 0;

            if (!string.IsNullOrEmpty(mBOID))
            {
                View.OptionsView.ColumnAutoWidth = false;
                View.Columns.Clear();

                lSPrpsBOT01LookUpColumns = Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].SPrpsBOT01LookUpColumns;
                for (int i = 0; i < lSPrpsBOT01LookUpColumns.Count; i++)
                {
                    if (lSPrpsBOT01LookUpColumns[i].FieldName == Innotelli.Utilities.TGC.PKeyName)
                    {
                        lGc = new GridColumn();
                        lGc.FieldName = lSPrpsBOT01LookUpColumns[i].FieldName;
                        lGc.Caption = string.Empty;
                        lGc.Visible = false;
                        View.Columns.Add(lGc);
                    }
                    else if (lSPrpsBOT01LookUpColumns[i].ColumnWidth != 0)
                    {
                        lGc = new GridColumn();
                        lGc.FieldName = lSPrpsBOT01LookUpColumns[i].FieldName;
                        lGc.Width = lSPrpsBOT01LookUpColumns[i].ColumnWidth;
                        lGc.Caption = lSPrpsBOT01LookUpColumns[i].Caption;
                        lGc.VisibleIndex = lVisibleIndex;
                        lListWidth += lGc.Width;
                        View.Columns.Add(lGc);
                        lVisibleIndex++;
                    }
                }

                if (mType == 2)
                {
                    string lTmp = string.Empty;
                    int lTmpWidth = 0;

                    lTmp = View.Columns[1].FieldName;
                    View.Columns[1].FieldName = View.Columns[2].FieldName;
                    View.Columns[2].FieldName = lTmp;
                    lTmp = View.Columns[1].Caption;
                    View.Columns[1].Caption = View.Columns[2].Caption;
                    View.Columns[2].Caption = lTmp;
                    lTmpWidth = View.Columns[1].VisibleWidth;
                    View.Columns[1].Width = View.Columns[2].Width;
                    View.Columns[2].Width = lTmpWidth;
                }
                PopupFormWidth = lListWidth + 36;
            }
        }
        public void BindList()
        {
            DataView lDv = null;

            InitColumns();

            if (mBOID != string.Empty)
            {
                lDv = new DataView();
                lDv.Table = BO.TSingletons.LookUpListProxy.GetList(mBOID);
                if (lDv.Table != null)
                {
                    DataSource = lDv;
                    //TODO: Create Another Selection Combo Type
                    if (mType == 2)
                    {
                        if (BndCol == 1)
                        {
                            ValueMember = lDv.Table.Columns[2].ColumnName;
                        }
                        else
                        {
                            ValueMember = lDv.Table.Columns[BndCol].ColumnName;
                        }
                        DisplayMember = lDv.Table.Columns[2].ColumnName;
                    }
                    else
                    {
                        ValueMember = lDv.Table.Columns[BndCol].ColumnName;
                        DisplayMember = lDv.Table.Columns[1].ColumnName;
                    }
                }
            }
        }
        public void RefreshList()
        {
            if (mBOID != string.Empty && DataSource != null)
            {
                if (TAppSettings.ClientMode == ClientModes.ThickClient)
                {
                    BO.TSingletons.LookUpListProxy.UpdateCacheForOneBO(mBOID);
                }
                ((DataView)DataSource).Table = BO.TSingletons.LookUpListProxy.GetList(mBOID);
            }
        }
        public void FilterList()
        {
            if (mBOT01 != null)
            {
                //This filter is applied on UI only, not DataView
                View.ActiveFilter.NonColumnFilter = mBOT01.GetLookUpListRowFilter(mBoundColumnName);
            }
        }
        #endregion
    }

    public class TLookupCombo40 : GridLookUpEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TLookupCombo40() { RepositoryItemLookupCombo40.RegisterLookupCombo40(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemLookupCombo40.LookupCombo40Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemLookupCombo40 Properties
        {
            get { return base.Properties as RepositoryItemLookupCombo40; }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TLookupCombo40()
        {
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                AssignEventHandlers();
            }
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(15 + 20, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        #endregion

        #region Event Handlers
        private void TLookupCombo40_Closed(object sender, DevExpress.XtraEditors.Controls.ClosedEventArgs e)
        {
            if (EditValue != OldEditValue)
            {
                DoValidate();
            }
        }
        private void OpenDetailItem_Click(object sender, EventArgs e)
        {
            TForm02 lForm02 = null;
            string lPK = string.Empty;


            if (!TNull.IsValueNull(EditValue))
            {
                lPK = EditValue.ToString();
                if (lPK != string.Empty)
                {
                    lForm02 = TSingletons.Form02Pool.GetForm(Innotelli.BO.TSingletons.SPrpsBOT01s[Properties.BOID].DefaultForm02Name);
                    lForm02.LoadByPK(lPK);
                    lForm02.Visible = true;
                }
            }
        }
        private void AdvSearchItem_Click(object sender, EventArgs e)
        {
            //TForm04 lForm04 = new TForm04();
            //lForm04.Form02FullName = "BackOffice.UI." + "TF02" + Properties.BOID.Substring(4);
            //lForm04.BOID = Properties.BOID;
            ////lForm04.MainContainer = (Form)this.Parent.Parent;
            //lForm04.Show();
            string lEditValue = TForm04.ShowAndGetSelectedPK(Properties.BOID, string.Empty, false);
            if (lEditValue != null)
            {
                EditValue = lEditValue;
                DoValidate();
            }
        }
        #endregion

        #region Functions
        private void AssignEventHandlers()
        {
            Closed += TLookupCombo40_Closed;

        }
        protected override void OnGotFocus(EventArgs e)
        {
            base.OnGotFocus(e);
            Properties.RefreshList();
            Properties.FilterList();
        }
        protected override void UpdateMenu()
        {
            base.UpdateMenu();
            bool lIsEditValueExisted = (!TNull.IsValueNull(EditValue) && EditValue.ToString() != string.Empty);
            Menu.Items[0].Enabled = lIsEditValueExisted;
            Menu.Items[1].Enabled = lIsEditValueExisted;
        }
        protected override DevExpress.Utils.Menu.DXPopupMenu CreateMenu()
        {
            DXPopupMenu lReturnValue = null;
            bool lIsEditValueExisted = (!TNull.IsValueNull(EditValue) && EditValue.ToString() != string.Empty);
            Image lOpenDetailImage = Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TLookupCombo40.OpenDetail.png"));
            Image lAdvSearchImage = Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TLookupCombo40.AdvSearch.png"));

            lReturnValue = base.CreateMenu();
            lReturnValue.Items[0].BeginGroup = true;
            DXMenuItem lOpenDetailItem = new DXMenuItem("Open Details", OpenDetailItem_Click, lOpenDetailImage);
            DXMenuItem lAdvSearchItem = new DXMenuItem("Advanced Search", AdvSearchItem_Click, lAdvSearchImage);
            lOpenDetailItem.Enabled = lIsEditValueExisted;
            lAdvSearchItem.Enabled = lIsEditValueExisted;
            lReturnValue.Items.Insert(0, lOpenDetailItem);
            lReturnValue.Items.Insert(1, lAdvSearchItem);

            return lReturnValue;
        }
        #endregion
    }
}
