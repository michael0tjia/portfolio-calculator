using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Windows.Forms;

/// <summary>
/// Summary description for TSingletons
/// </summary>
/// 
namespace Innotelli.WinForm.Control
{
    public static class TSingletons
    {
        private static bool mInitialized = false;
        public static bool Initialized
        {
            get
            {
                return TSingletons.mInitialized;
            }
            set
            {
                TSingletons.mInitialized = value;
            }
        }
        private static Form mRootMdiParent = null;
        public static Form RootMdiParent
        {
            get
            {
                return mRootMdiParent;
            }
            set
            {
                mRootMdiParent = value;
            }
        }
        private static TForm02Pool mForm02Pool = null;
        public static TForm02Pool Form02Pool
        {
            get
            {
                return mForm02Pool;
            }
        }
        public static void Init()
        {
            mInitialized = true;
            mForm02Pool = new TForm02Pool();
        }
    }
}