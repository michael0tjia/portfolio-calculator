namespace Innotelli.WinForm.Control
{
    partial class TForm26
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TForm26));
            this.tLayoutControl011 = new Innotelli.WinForm.Control.TLayoutControl01();
            this.lueUILanguage = new DevExpress.XtraEditors.LookUpEdit();
            this.txtPasswd = new DevExpress.XtraEditors.TextEdit();
            this.txtUser = new DevExpress.XtraEditors.TextEdit();
            this.lueApplicationServer = new DevExpress.XtraEditors.LookUpEdit();
            this.lblCompany = new DevExpress.XtraEditors.LabelControl();
            this.lblBOServerURL = new DevExpress.XtraEditors.LabelControl();
            this.btnCancel = new Innotelli.WinForm.Control.TButton02();
            this.btnEnter = new Innotelli.WinForm.Control.TButton02();
            this.lblHead = new DevExpress.XtraEditors.LabelControl();
            this.layoutControlGroup011 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.layoutControlGroup012 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.layoutControlItem014 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlItem013 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlGroup013 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.lci01Head = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlGroup014 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.lci01User = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.lci01Passwd = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlItem012 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlGroup015 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.lci01Company = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.lci01BOServerURL = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.lci01ApplicationServer = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.emptySpaceItem4 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem5 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.barThis = new DevExpress.XtraBars.BarManager(this.components);
            this.bar3 = new DevExpress.XtraBars.Bar();
            this.bsiStatus = new DevExpress.XtraBars.BarStaticItem();
            this.beiProgress = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemProgressBar1 = new DevExpress.XtraEditors.Repository.RepositoryItemProgressBar();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.tmrThis = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.tLayoutControl011)).BeginInit();
            this.tLayoutControl011.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lueUILanguage.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPasswd.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUser.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueApplicationServer.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup011)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup012)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem014)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem013)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup013)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Head)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup014)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01User)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Passwd)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem012)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup015)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Company)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01BOServerURL)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01ApplicationServer)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barThis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemProgressBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // tLayoutControl011
            // 
            this.tLayoutControl011.Controls.Add(this.lueUILanguage);
            this.tLayoutControl011.Controls.Add(this.txtPasswd);
            this.tLayoutControl011.Controls.Add(this.txtUser);
            this.tLayoutControl011.Controls.Add(this.lueApplicationServer);
            this.tLayoutControl011.Controls.Add(this.lblCompany);
            this.tLayoutControl011.Controls.Add(this.lblBOServerURL);
            this.tLayoutControl011.Controls.Add(this.btnCancel);
            this.tLayoutControl011.Controls.Add(this.btnEnter);
            this.tLayoutControl011.Controls.Add(this.lblHead);
            resources.ApplyResources(this.tLayoutControl011, "tLayoutControl011");
            this.tLayoutControl011.Name = "tLayoutControl011";
            this.tLayoutControl011.OptionsItemText.TextAlignMode = DevExpress.XtraLayout.TextAlignMode.AlignInGroups;
            this.tLayoutControl011.OptionsView.EnableIndentsInGroupsWithoutBorders = true;
            this.tLayoutControl011.Root = this.layoutControlGroup011;
            // 
            // lueUILanguage
            // 
            resources.ApplyResources(this.lueUILanguage, "lueUILanguage");
            this.lueUILanguage.Name = "lueUILanguage";
            this.lueUILanguage.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("lueUILanguage.Properties.Buttons"))))});
            this.lueUILanguage.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("lueUILanguage.Properties.Columns"), resources.GetString("lueUILanguage.Properties.Columns1"))});
            this.lueUILanguage.Properties.ShowHeader = false;
            this.lueUILanguage.StyleController = this.tLayoutControl011;
            // 
            // txtPasswd
            // 
            resources.ApplyResources(this.txtPasswd, "txtPasswd");
            this.txtPasswd.Name = "txtPasswd";
            this.txtPasswd.Properties.PasswordChar = '*';
            this.txtPasswd.StyleController = this.tLayoutControl011;
            // 
            // txtUser
            // 
            resources.ApplyResources(this.txtUser, "txtUser");
            this.txtUser.Name = "txtUser";
            this.txtUser.StyleController = this.tLayoutControl011;
            // 
            // lueApplicationServer
            // 
            resources.ApplyResources(this.lueApplicationServer, "lueApplicationServer");
            this.lueApplicationServer.Name = "lueApplicationServer";
            this.lueApplicationServer.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("lueApplicationServer.Properties.Buttons"))))});
            this.lueApplicationServer.Properties.Columns.AddRange(new DevExpress.XtraEditors.Controls.LookUpColumnInfo[] {
            new DevExpress.XtraEditors.Controls.LookUpColumnInfo(resources.GetString("lueApplicationServer.Properties.Columns"), resources.GetString("lueApplicationServer.Properties.Columns1"))});
            this.lueApplicationServer.Properties.NullText = resources.GetString("lueApplicationServer.Properties.NullText");
            this.lueApplicationServer.StyleController = this.tLayoutControl011;
            this.lueApplicationServer.EditValueChanged += new System.EventHandler(this.lue1DB_EditValueChanged);
            this.lueApplicationServer.Validated += new System.EventHandler(this.lue1DB_Validated);
            // 
            // lblCompany
            // 
            resources.ApplyResources(this.lblCompany, "lblCompany");
            this.lblCompany.Name = "lblCompany";
            this.lblCompany.StyleController = this.tLayoutControl011;
            // 
            // lblBOServerURL
            // 
            resources.ApplyResources(this.lblBOServerURL, "lblBOServerURL");
            this.lblBOServerURL.Name = "lblBOServerURL";
            this.lblBOServerURL.StyleController = this.tLayoutControl011;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            resources.ApplyResources(this.btnCancel, "btnCancel");
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.StyleController = this.tLayoutControl011;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnEnter
            // 
            resources.ApplyResources(this.btnEnter, "btnEnter");
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.StyleController = this.tLayoutControl011;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // lblHead
            // 
            this.lblHead.Appearance.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblHead.Appearance.Options.UseFont = true;
            resources.ApplyResources(this.lblHead, "lblHead");
            this.lblHead.Name = "lblHead";
            this.lblHead.StyleController = this.tLayoutControl011;
            // 
            // layoutControlGroup011
            // 
            resources.ApplyResources(this.layoutControlGroup011, "layoutControlGroup011");
            this.layoutControlGroup011.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup012});
            this.layoutControlGroup011.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup011.Name = "layoutControlGroup011";
            this.layoutControlGroup011.OptionsItemText.TextToControlDistance = 2;
            this.layoutControlGroup011.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup011.Size = new System.Drawing.Size(448, 231);
            this.layoutControlGroup011.TextVisible = false;
            // 
            // layoutControlGroup012
            // 
            resources.ApplyResources(this.layoutControlGroup012, "layoutControlGroup012");
            this.layoutControlGroup012.GroupBordersVisible = false;
            this.layoutControlGroup012.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem014,
            this.layoutControlItem013,
            this.emptySpaceItem1,
            this.layoutControlGroup013,
            this.emptySpaceItem3,
            this.layoutControlGroup014,
            this.layoutControlGroup015});
            this.layoutControlGroup012.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup012.Name = "layoutControlGroup012";
            this.layoutControlGroup012.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup012.Size = new System.Drawing.Size(444, 227);
            this.layoutControlGroup012.Spacing = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup012.TextVisible = false;
            // 
            // layoutControlItem014
            // 
            this.layoutControlItem014.Control = this.btnCancel;
            resources.ApplyResources(this.layoutControlItem014, "layoutControlItem014");
            this.layoutControlItem014.Location = new System.Drawing.Point(358, 170);
            this.layoutControlItem014.MaxSize = new System.Drawing.Size(82, 28);
            this.layoutControlItem014.MinSize = new System.Drawing.Size(82, 28);
            this.layoutControlItem014.Name = "layoutControlItem014";
            this.layoutControlItem014.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem014.Size = new System.Drawing.Size(82, 53);
            this.layoutControlItem014.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem014.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.layoutControlItem014.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem014.TextToControlDistance = 0;
            this.layoutControlItem014.TextVisible = false;
            // 
            // layoutControlItem013
            // 
            this.layoutControlItem013.Control = this.btnEnter;
            resources.ApplyResources(this.layoutControlItem013, "layoutControlItem013");
            this.layoutControlItem013.Location = new System.Drawing.Point(276, 170);
            this.layoutControlItem013.MaxSize = new System.Drawing.Size(82, 28);
            this.layoutControlItem013.MinSize = new System.Drawing.Size(82, 28);
            this.layoutControlItem013.Name = "layoutControlItem013";
            this.layoutControlItem013.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem013.Size = new System.Drawing.Size(82, 53);
            this.layoutControlItem013.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem013.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.layoutControlItem013.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem013.TextToControlDistance = 0;
            this.layoutControlItem013.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            resources.ApplyResources(this.emptySpaceItem1, "emptySpaceItem1");
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 170);
            this.emptySpaceItem1.MinSize = new System.Drawing.Size(110, 30);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(276, 53);
            this.emptySpaceItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlGroup013
            // 
            resources.ApplyResources(this.layoutControlGroup013, "layoutControlGroup013");
            this.layoutControlGroup013.GroupBordersVisible = false;
            this.layoutControlGroup013.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lci01Head});
            this.layoutControlGroup013.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup013.Name = "layoutControlGroup013";
            this.layoutControlGroup013.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup013.Size = new System.Drawing.Size(440, 17);
            this.layoutControlGroup013.Spacing = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup013.TextVisible = false;
            // 
            // lci01Head
            // 
            this.lci01Head.Control = this.lblHead;
            resources.ApplyResources(this.lci01Head, "lci01Head");
            this.lci01Head.Location = new System.Drawing.Point(0, 0);
            this.lci01Head.Name = "lci01Head";
            this.lci01Head.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01Head.Size = new System.Drawing.Size(436, 13);
            this.lci01Head.TextSize = new System.Drawing.Size(0, 0);
            this.lci01Head.TextToControlDistance = 0;
            this.lci01Head.TextVisible = false;
            // 
            // emptySpaceItem3
            // 
            resources.ApplyResources(this.emptySpaceItem3, "emptySpaceItem3");
            this.emptySpaceItem3.Location = new System.Drawing.Point(0, 160);
            this.emptySpaceItem3.MaxSize = new System.Drawing.Size(0, 10);
            this.emptySpaceItem3.MinSize = new System.Drawing.Size(10, 10);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(440, 10);
            this.emptySpaceItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlGroup014
            // 
            resources.ApplyResources(this.layoutControlGroup014, "layoutControlGroup014");
            this.layoutControlGroup014.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lci01User,
            this.lci01Passwd,
            this.layoutControlItem012});
            this.layoutControlGroup014.Location = new System.Drawing.Point(0, 17);
            this.layoutControlGroup014.Name = "layoutControlGroup014";
            this.layoutControlGroup014.Padding = new DevExpress.XtraLayout.Utils.Padding(5, 5, 5, 5);
            this.layoutControlGroup014.Size = new System.Drawing.Size(172, 143);
            this.layoutControlGroup014.Spacing = new DevExpress.XtraLayout.Utils.Padding(3, 3, 3, 3);
            // 
            // lci01User
            // 
            this.lci01User.Control = this.txtUser;
            resources.ApplyResources(this.lci01User, "lci01User");
            this.lci01User.Location = new System.Drawing.Point(0, 0);
            this.lci01User.Name = "lci01User";
            this.lci01User.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01User.Size = new System.Drawing.Size(154, 35);
            this.lci01User.TextLocation = DevExpress.Utils.Locations.Top;
            this.lci01User.TextSize = new System.Drawing.Size(52, 13);
            this.lci01User.TextToControlDistance = 2;
            // 
            // lci01Passwd
            // 
            this.lci01Passwd.Control = this.txtPasswd;
            resources.ApplyResources(this.lci01Passwd, "lci01Passwd");
            this.lci01Passwd.Location = new System.Drawing.Point(0, 35);
            this.lci01Passwd.Name = "lci01Passwd";
            this.lci01Passwd.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01Passwd.Size = new System.Drawing.Size(154, 35);
            this.lci01Passwd.TextLocation = DevExpress.Utils.Locations.Top;
            this.lci01Passwd.TextSize = new System.Drawing.Size(52, 13);
            this.lci01Passwd.TextToControlDistance = 2;
            // 
            // layoutControlItem012
            // 
            this.layoutControlItem012.Control = this.lueUILanguage;
            resources.ApplyResources(this.layoutControlItem012, "layoutControlItem012");
            this.layoutControlItem012.Location = new System.Drawing.Point(0, 70);
            this.layoutControlItem012.Name = "layoutControlItem012";
            this.layoutControlItem012.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem012.Size = new System.Drawing.Size(154, 35);
            this.layoutControlItem012.TextLocation = DevExpress.Utils.Locations.Top;
            this.layoutControlItem012.TextSize = new System.Drawing.Size(52, 13);
            this.layoutControlItem012.TextToControlDistance = 2;
            // 
            // layoutControlGroup015
            // 
            resources.ApplyResources(this.layoutControlGroup015, "layoutControlGroup015");
            this.layoutControlGroup015.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lci01Company,
            this.lci01BOServerURL,
            this.lci01ApplicationServer,
            this.emptySpaceItem4,
            this.emptySpaceItem5});
            this.layoutControlGroup015.Location = new System.Drawing.Point(172, 17);
            this.layoutControlGroup015.Name = "layoutControlGroup015";
            this.layoutControlGroup015.Padding = new DevExpress.XtraLayout.Utils.Padding(5, 5, 5, 5);
            this.layoutControlGroup015.Size = new System.Drawing.Size(268, 143);
            this.layoutControlGroup015.Spacing = new DevExpress.XtraLayout.Utils.Padding(3, 3, 3, 3);
            // 
            // lci01Company
            // 
            this.lci01Company.Control = this.lblCompany;
            resources.ApplyResources(this.lci01Company, "lci01Company");
            this.lci01Company.Location = new System.Drawing.Point(0, 42);
            this.lci01Company.Name = "lci01Company";
            this.lci01Company.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 4, 2, 2);
            this.lci01Company.Size = new System.Drawing.Size(250, 17);
            this.lci01Company.TextSize = new System.Drawing.Size(0, 0);
            this.lci01Company.TextToControlDistance = 0;
            this.lci01Company.TextVisible = false;
            // 
            // lci01BOServerURL
            // 
            this.lci01BOServerURL.Control = this.lblBOServerURL;
            resources.ApplyResources(this.lci01BOServerURL, "lci01BOServerURL");
            this.lci01BOServerURL.Location = new System.Drawing.Point(0, 59);
            this.lci01BOServerURL.Name = "lci01BOServerURL";
            this.lci01BOServerURL.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 4, 2, 2);
            this.lci01BOServerURL.Size = new System.Drawing.Size(250, 17);
            this.lci01BOServerURL.TextSize = new System.Drawing.Size(0, 0);
            this.lci01BOServerURL.TextToControlDistance = 0;
            this.lci01BOServerURL.TextVisible = false;
            // 
            // lci01ApplicationServer
            // 
            this.lci01ApplicationServer.Control = this.lueApplicationServer;
            resources.ApplyResources(this.lci01ApplicationServer, "lci01ApplicationServer");
            this.lci01ApplicationServer.Location = new System.Drawing.Point(0, 0);
            this.lci01ApplicationServer.Name = "lci01ApplicationServer";
            this.lci01ApplicationServer.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01ApplicationServer.Size = new System.Drawing.Size(250, 35);
            this.lci01ApplicationServer.TextLocation = DevExpress.Utils.Locations.Top;
            this.lci01ApplicationServer.TextSize = new System.Drawing.Size(87, 13);
            this.lci01ApplicationServer.TextToControlDistance = 2;
            // 
            // emptySpaceItem4
            // 
            resources.ApplyResources(this.emptySpaceItem4, "emptySpaceItem4");
            this.emptySpaceItem4.Location = new System.Drawing.Point(0, 35);
            this.emptySpaceItem4.MaxSize = new System.Drawing.Size(250, 7);
            this.emptySpaceItem4.MinSize = new System.Drawing.Size(250, 7);
            this.emptySpaceItem4.Name = "emptySpaceItem4";
            this.emptySpaceItem4.Size = new System.Drawing.Size(250, 7);
            this.emptySpaceItem4.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem4.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem5
            // 
            resources.ApplyResources(this.emptySpaceItem5, "emptySpaceItem5");
            this.emptySpaceItem5.Location = new System.Drawing.Point(0, 76);
            this.emptySpaceItem5.Name = "emptySpaceItem5";
            this.emptySpaceItem5.Size = new System.Drawing.Size(250, 29);
            this.emptySpaceItem5.TextSize = new System.Drawing.Size(0, 0);
            // 
            // barThis
            // 
            this.barThis.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.bar3});
            this.barThis.DockControls.Add(this.barDockControlTop);
            this.barThis.DockControls.Add(this.barDockControlBottom);
            this.barThis.DockControls.Add(this.barDockControlLeft);
            this.barThis.DockControls.Add(this.barDockControlRight);
            this.barThis.Form = this;
            this.barThis.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.bsiStatus,
            this.beiProgress});
            this.barThis.MaxItemId = 2;
            this.barThis.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemProgressBar1});
            this.barThis.StatusBar = this.bar3;
            // 
            // bar3
            // 
            this.bar3.BarName = "Status bar";
            this.bar3.CanDockStyle = DevExpress.XtraBars.BarCanDockStyle.Bottom;
            this.bar3.DockCol = 0;
            this.bar3.DockRow = 0;
            this.bar3.DockStyle = DevExpress.XtraBars.BarDockStyle.Bottom;
            this.bar3.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bsiStatus),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.Width, this.beiProgress, "", false, true, true, 189)});
            this.bar3.OptionsBar.AllowQuickCustomization = false;
            this.bar3.OptionsBar.DisableClose = true;
            this.bar3.OptionsBar.DrawDragBorder = false;
            this.bar3.OptionsBar.UseWholeRow = true;
            resources.ApplyResources(this.bar3, "bar3");
            // 
            // bsiStatus
            // 
            this.bsiStatus.Border = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            resources.ApplyResources(this.bsiStatus, "bsiStatus");
            this.bsiStatus.Id = 0;
            this.bsiStatus.Name = "bsiStatus";
            this.bsiStatus.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // beiProgress
            // 
            this.beiProgress.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right;
            resources.ApplyResources(this.beiProgress, "beiProgress");
            this.beiProgress.Edit = this.repositoryItemProgressBar1;
            this.beiProgress.Id = 1;
            this.beiProgress.Name = "beiProgress";
            this.beiProgress.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // repositoryItemProgressBar1
            // 
            this.repositoryItemProgressBar1.Name = "repositoryItemProgressBar1";
            this.repositoryItemProgressBar1.ShowTitle = true;
            // 
            // TForm26
            // 
            this.AcceptButton = this.btnEnter;
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.Controls.Add(this.tLayoutControl011);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TForm26";
            this.Load += new System.EventHandler(this.frmLogin_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tLayoutControl011)).EndInit();
            this.tLayoutControl011.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lueUILanguage.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtPasswd.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUser.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lueApplicationServer.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup011)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup012)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem014)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem013)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup013)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Head)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup014)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01User)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Passwd)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem012)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup015)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Company)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01BOServerURL)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01ApplicationServer)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barThis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemProgressBar1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Innotelli.WinForm.Control.TLayoutControl01 tLayoutControl011;
        private Innotelli.WinForm.Control.LayoutControlGroup01 layoutControlGroup011;
        private Innotelli.WinForm.Control.TButton02 btnCancel;
        private Innotelli.WinForm.Control.TButton02 btnEnter;
        private DevExpress.XtraEditors.LabelControl lblHead;
        private Innotelli.WinForm.Control.LayoutControlItem01 lci01Head;
        private Innotelli.WinForm.Control.LayoutControlGroup01 layoutControlGroup012;
        private Innotelli.WinForm.Control.LayoutControlItem01 layoutControlItem014;
        private Innotelli.WinForm.Control.LayoutControlItem01 layoutControlItem013;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraEditors.LookUpEdit lueApplicationServer;
        private Innotelli.WinForm.Control.LayoutControlItem01 lci01ApplicationServer;
        private Innotelli.WinForm.Control.LayoutControlGroup01 layoutControlGroup013;
        private DevExpress.XtraEditors.TextEdit txtPasswd;
        private DevExpress.XtraEditors.TextEdit txtUser;
        private Innotelli.WinForm.Control.LayoutControlItem01 lci01User;
        private Innotelli.WinForm.Control.LayoutControlItem01 lci01Passwd;
        private DevExpress.XtraBars.BarManager barThis;
        private DevExpress.XtraBars.Bar bar3;
        private DevExpress.XtraBars.BarStaticItem bsiStatus;
        private DevExpress.XtraBars.BarEditItem beiProgress;
        private DevExpress.XtraEditors.Repository.RepositoryItemProgressBar repositoryItemProgressBar1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraEditors.LabelControl lblBOServerURL;
        private Innotelli.WinForm.Control.LayoutControlItem01 lci01BOServerURL;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;
        private Innotelli.WinForm.Control.LayoutControlGroup01 layoutControlGroup014;
        private Innotelli.WinForm.Control.LayoutControlGroup01 layoutControlGroup015;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem4;
        private Innotelli.WinForm.Control.LayoutControlItem01 lci01Company;
        private System.Windows.Forms.Timer tmrThis;
        public DevExpress.XtraEditors.LabelControl lblCompany;
        private DevExpress.XtraEditors.LookUpEdit lueUILanguage;
        private LayoutControlItem01 layoutControlItem012;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem5;

    }
}

