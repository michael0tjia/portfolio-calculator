﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.WinForm.Control
{
    public class RepositoryItemTextEditUtil
    {
    }
}
