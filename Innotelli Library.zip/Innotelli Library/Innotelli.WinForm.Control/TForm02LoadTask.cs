using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    public class TForm02LoadTask : TThreadWrapperBase
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TForm02LoadTask()
        {
            SupportsProgress = true;
        }
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        protected override void DoTask()
        {
            Innotelli.WinForm.Control.TSingletons.Form02Pool.AddNewFormToList("BackOffice.UI.TF02OutHAWB");
            Innotelli.WinForm.Control.TSingletons.Form02Pool.AddNewFormToList("BackOffice.UI.TF02OutHAWB");
            Innotelli.WinForm.Control.TSingletons.Form02Pool.AddNewFormToList("BackOffice.UI.TF02OutHAWB");
            Innotelli.WinForm.Control.TSingletons.Form02Pool.AddNewFormToList("BackOffice.UI.TF02OutHAWB");
            Innotelli.WinForm.Control.TSingletons.Form02Pool.AddNewFormToList("BackOffice.UI.TF02OutHAWB");
        }
        #endregion
    }
}
