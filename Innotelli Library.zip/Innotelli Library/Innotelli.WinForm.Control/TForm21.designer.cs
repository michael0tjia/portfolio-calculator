namespace Innotelli.WinForm.Control
{
    partial class TForm21
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TForm21));
            this.tLayoutControl011 = new Innotelli.WinForm.Control.TLayoutControl01();
            this.pgbThis = new DevExpress.XtraEditors.ProgressBarControl();
            this.btnCancel = new DevExpress.XtraEditors.SimpleButton();
            this.layoutControlGroup011 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.layoutControlGroup012 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem012 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlGroup013 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.lci02This = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.emptySpaceItem3 = new DevExpress.XtraLayout.EmptySpaceItem();
            ((System.ComponentModel.ISupportInitialize)(this.tLayoutControl011)).BeginInit();
            this.tLayoutControl011.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pgbThis.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup011)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup012)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem012)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup013)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci02This)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).BeginInit();
            this.SuspendLayout();
            // 
            // tLayoutControl011
            // 
            this.tLayoutControl011.AccessibleDescription = null;
            this.tLayoutControl011.AccessibleName = null;
            resources.ApplyResources(this.tLayoutControl011, "tLayoutControl011");
            this.tLayoutControl011.Appearance.DisabledLayoutGroupCaption.ForeColor = System.Drawing.SystemColors.GrayText;
            this.tLayoutControl011.Appearance.DisabledLayoutGroupCaption.Options.UseForeColor = true;
            this.tLayoutControl011.Appearance.DisabledLayoutItem.ForeColor = System.Drawing.SystemColors.GrayText;
            this.tLayoutControl011.Appearance.DisabledLayoutItem.Options.UseForeColor = true;
            this.tLayoutControl011.BackgroundImage = null;
            this.tLayoutControl011.Controls.Add(this.pgbThis);
            this.tLayoutControl011.Controls.Add(this.btnCancel);
            this.tLayoutControl011.Font = null;
            this.tLayoutControl011.Name = "tLayoutControl011";
            this.tLayoutControl011.OptionsItemText.TextAlignMode = DevExpress.XtraLayout.TextAlignMode.AlignInGroups;
            this.tLayoutControl011.OptionsView.EnableIndentsInGroupsWithoutBorders = true;
            this.tLayoutControl011.Root = this.layoutControlGroup011;
            // 
            // pgbThis
            // 
            resources.ApplyResources(this.pgbThis, "pgbThis");
            this.pgbThis.BackgroundImage = null;
            this.pgbThis.Name = "pgbThis";
            this.pgbThis.Properties.AccessibleDescription = null;
            this.pgbThis.Properties.AccessibleName = null;
            this.pgbThis.Properties.AutoHeight = ((bool)(resources.GetObject("pgbThis.Properties.AutoHeight")));
            this.pgbThis.Properties.ShowTitle = true;
            this.pgbThis.StyleController = this.tLayoutControl011;
            // 
            // btnCancel
            // 
            this.btnCancel.AccessibleDescription = null;
            this.btnCancel.AccessibleName = null;
            resources.ApplyResources(this.btnCancel, "btnCancel");
            this.btnCancel.BackgroundImage = null;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.StyleController = this.tLayoutControl011;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // layoutControlGroup011
            // 
            resources.ApplyResources(this.layoutControlGroup011, "layoutControlGroup011");
            this.layoutControlGroup011.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup012});
            this.layoutControlGroup011.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup011.Name = "layoutControlGroup011";
            this.layoutControlGroup011.OptionsItemText.TextToControlDistance = 2;
            this.layoutControlGroup011.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup011.Size = new System.Drawing.Size(277, 117);
            this.layoutControlGroup011.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup011.TextVisible = false;
            // 
            // layoutControlGroup012
            // 
            resources.ApplyResources(this.layoutControlGroup012, "layoutControlGroup012");
            this.layoutControlGroup012.GroupBordersVisible = false;
            this.layoutControlGroup012.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem1,
            this.layoutControlItem012,
            this.layoutControlGroup013});
            this.layoutControlGroup012.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup012.Name = "layoutControlGroup012";
            this.layoutControlGroup012.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup012.Size = new System.Drawing.Size(273, 113);
            this.layoutControlGroup012.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            resources.ApplyResources(this.emptySpaceItem1, "emptySpaceItem1");
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 79);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(185, 28);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem012
            // 
            this.layoutControlItem012.Control = this.btnCancel;
            resources.ApplyResources(this.layoutControlItem012, "layoutControlItem012");
            this.layoutControlItem012.Location = new System.Drawing.Point(185, 79);
            this.layoutControlItem012.MaxSize = new System.Drawing.Size(82, 28);
            this.layoutControlItem012.MinSize = new System.Drawing.Size(82, 28);
            this.layoutControlItem012.Name = "layoutControlItem012";
            this.layoutControlItem012.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem012.Size = new System.Drawing.Size(82, 28);
            this.layoutControlItem012.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem012.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.layoutControlItem012.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem012.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem012.TextToControlDistance = 0;
            this.layoutControlItem012.TextVisible = false;
            // 
            // layoutControlGroup013
            // 
            resources.ApplyResources(this.layoutControlGroup013, "layoutControlGroup013");
            this.layoutControlGroup013.GroupBordersVisible = false;
            this.layoutControlGroup013.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem2,
            this.lci02This,
            this.emptySpaceItem3});
            this.layoutControlGroup013.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup013.Name = "layoutControlGroup013";
            this.layoutControlGroup013.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup013.Size = new System.Drawing.Size(267, 79);
            this.layoutControlGroup013.Spacing = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup013.TextVisible = false;
            // 
            // emptySpaceItem2
            // 
            this.emptySpaceItem2.AppearanceItemCaption.Options.UseTextOptions = true;
            this.emptySpaceItem2.AppearanceItemCaption.TextOptions.VAlignment = DevExpress.Utils.VertAlignment.Top;
            resources.ApplyResources(this.emptySpaceItem2, "emptySpaceItem2");
            this.emptySpaceItem2.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(263, 47);
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 20);
            this.emptySpaceItem2.TextVisible = true;
            // 
            // lci02This
            // 
            this.lci02This.Control = this.pgbThis;
            resources.ApplyResources(this.lci02This, "lci02This");
            this.lci02This.Location = new System.Drawing.Point(0, 47);
            this.lci02This.MaxSize = new System.Drawing.Size(0, 18);
            this.lci02This.MinSize = new System.Drawing.Size(53, 18);
            this.lci02This.Name = "lci02This";
            this.lci02This.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci02This.Size = new System.Drawing.Size(263, 18);
            this.lci02This.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lci02This.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci02This.TextSize = new System.Drawing.Size(0, 0);
            this.lci02This.TextToControlDistance = 0;
            this.lci02This.TextVisible = false;
            // 
            // emptySpaceItem3
            // 
            resources.ApplyResources(this.emptySpaceItem3, "emptySpaceItem3");
            this.emptySpaceItem3.Location = new System.Drawing.Point(0, 65);
            this.emptySpaceItem3.MaxSize = new System.Drawing.Size(0, 10);
            this.emptySpaceItem3.MinSize = new System.Drawing.Size(10, 10);
            this.emptySpaceItem3.Name = "emptySpaceItem3";
            this.emptySpaceItem3.Size = new System.Drawing.Size(263, 10);
            this.emptySpaceItem3.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem3.TextSize = new System.Drawing.Size(0, 0);
            // 
            // TForm21
            // 
            this.AccessibleDescription = null;
            this.AccessibleName = null;
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tLayoutControl011);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = null;
            this.KeyPreview = true;
            this.Name = "TForm21";
            this.Load += new System.EventHandler(this.TForm21_Load);
            ((System.ComponentModel.ISupportInitialize)(this.tLayoutControl011)).EndInit();
            this.tLayoutControl011.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pgbThis.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup011)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup012)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem012)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup013)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci02This)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.SimpleButton btnCancel;
        private DevExpress.XtraEditors.ProgressBarControl pgbThis;
        private TLayoutControl01 tLayoutControl011;
        private LayoutControlGroup01 layoutControlGroup011;
        private LayoutControlGroup01 layoutControlGroup012;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private LayoutControlItem01 layoutControlItem012;
        private LayoutControlGroup01 layoutControlGroup013;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private LayoutControlItem01 lci02This;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem3;

    }
}