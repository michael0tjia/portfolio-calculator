using System;
using System.Configuration;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraReports.UI;
using Innotelli.Utilities;
using Innotelli.WinForm.Control;
using Innotelli.BO;
using Innotelli.Report;

namespace Innotelli.WinForm.Control
{
    public partial class TRptExplr : DevExpress.XtraEditors.XtraForm
    {
        #region Enums
        #endregion

        #region Members
        private bool mInitInProgress = false;
        private DataSet mRptCatDs = null;
        private DataSet mRptDs = null;
        private TSysDataRdr mSysDataRdr = Innotelli.Utilities.TSingletons.SysData01Rdr;
        private Dictionary<Guid, TRptLaunch> mRptLaunchs = new Dictionary<Guid, TRptLaunch>();
        private Dictionary<string, RepositoryItemLookupCombo02> mRepositoryItemLookupCombo02s =
            new Dictionary<string, RepositoryItemLookupCombo02>();
        #endregion

        #region Constructors
        public TRptExplr()
        {
            InitializeComponent();
        }
        public TRptExplr(string aCatID)
        {

            InitializeComponent();
            Init(aCatID);

        }
        #endregion

        #region Properties
        private DataView mRptCatDv = new DataView();
        public DataView RptCatDv
        {
            get
            {
                return mRptCatDv;
            }
            set
            {
                mRptCatDv = value;
            }
        }
        private DataView mRptDv = new DataView();
        public DataView RptDv
        {
            get
            {
                return mRptDv;
            }
            set
            {
                mRptDv = value;
            }
        }
        private TRptFltr mRptFltr = new TRptFltr();
        public TRptFltr RptFltr
        {
            get
            {
                return mRptFltr;
            }
            set
            {
                mRptFltr = value;
            }
        }
        private string mCatID = string.Empty;
        public string CatID
        {
            get
            {
                return mCatID;
            }
            set
            {
                mCatID = value;
                mRptDv.RowFilter = "Shown = True AND CatID = '" + mCatID + "'";
            }
        }
        private string mRptAls = string.Empty;
        public string RptAls
        {
            get
            {
                return mRptAls;
            }
            set
            {
                mRptAls = value;
            }
        }
        private string mRptNm = string.Empty;
        public string RptNm
        {
            get
            {
                return mRptNm;
            }
            set
            {
                mRptNm = value;
                SetupFilterGrid();
            }
        }
        #endregion

        #region Event Handlers
        private void btnPreview_Click(object sender, EventArgs e)
        {
            if (RequiredValueCorrect())
            {
                Guid lGuid = BeforeGenRpt();
                mRptLaunchs[lGuid].PreviewAsync(mRptNm, mRptFltr);
            }
        }
        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (RequiredValueCorrect())
            {
                Guid lGuid = BeforeGenRpt();
                mRptLaunchs[lGuid].PrintAsync(mRptNm, mRptFltr);
            }
        }
        private void TRptExplr_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (mRptLaunchs.Count != 0)
            {
                e.Cancel = true;
                Hide();
            }
        }
        private void lstRptCat_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (!mInitInProgress && lstRptCat.SelectedIndex >= 0)
            {
                CatID = mRptCatDv[lstRptCat.SelectedIndex]["CatID"].ToString();
                if (mRptDv.Count > 0)
                {
                    lstRpt.SelectedIndex = 0;
                    RptNm = mRptDv[0].Row["RptNm"].ToString();
                    RptAls = mRptDv[0].Row["RptAls"].ToString();
                }
            }

        }
        private void lstRpt_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (!mInitInProgress && lstRpt.SelectedIndex >= 0)
            {
                RptNm = mRptDv[lstRpt.SelectedIndex].Row["RptNm"].ToString();
                RptAls = mRptDv[lstRpt.SelectedIndex].Row["RptAls"].ToString();
            }

        }
        private void gdvFilter_CustomRowCellEdit(object sender, DevExpress.XtraGrid.Views.Grid.CustomRowCellEditEventArgs e)
        {
            string lFldType = string.Empty;
            string lCndtn = string.Empty;
            string lSelObjID = string.Empty;
            string lBOID = string.Empty;
            int lType = 1;
            int lBndCol = 0;
            string lKey = string.Empty;
            string lRwFltr = string.Empty;
            DataRow lDr = null;
            GridView gv = null;


            RepositoryItemLookupCombo02 lRepositoryItemLookupCombo02;
            if (e.Column.FieldName == "Value1" || e.Column.FieldName == "Value2")
            {
                gv = sender as GridView;
                lDr = gv.GetDataRow(e.RowHandle);

                lFldType = gv.GetRowCellValue(e.RowHandle, gv.Columns["FldType"]).ToString();
                lFldType = lDr["FldType"].ToString();
                lCndtn = lDr["Condition"].ToString();
                lSelObjID = lDr["SelObjID"].ToString();
                //lRwFltr = lDr["RwFltr"].ToString();

                if (lSelObjID != string.Empty)
                {
                    //#check! temp code, to be removed
                    if (TStr.Right(lSelObjID, 4) == "_T02")
                    {
                        lBOID = lSelObjID.Substring(0, lSelObjID.Length - 4);
                        lType = 2;
                    }
                    else if (TStr.Right(lSelObjID, 5) == "_Bank")
                    {
                        lBOID = lSelObjID.Substring(0, lSelObjID.Length - 5);
                        lType = 1;
                    }
                    else
                    {
                        lBOID = lSelObjID;
                        lType = 1;
                    }
                    lKey = lBOID + "." + lType;

                    if (mRepositoryItemLookupCombo02s.ContainsKey(lKey))
                    {

                        e.RepositoryItem = mRepositoryItemLookupCombo02s[lKey];
                    }
                    else
                    {
                        lRepositoryItemLookupCombo02 = new RepositoryItemLookupCombo02();
                        lBndCol = int.Parse(gv.GetRowCellValue(e.RowHandle, gv.Columns["BndCol"]).ToString()) - 1;
                        lRepositoryItemLookupCombo02.BndCol = lBndCol;
                        lRepositoryItemLookupCombo02.BOID = lBOID;
                        lRepositoryItemLookupCombo02.Type = lType;
                        lRepositoryItemLookupCombo02.Init();
                        lRepositoryItemLookupCombo02.BindList();
                        lRepositoryItemLookupCombo02.RowFilter = lRwFltr;
                        e.RepositoryItem = lRepositoryItemLookupCombo02;

                        mRepositoryItemLookupCombo02s.Add(lKey, lRepositoryItemLookupCombo02);

                    }
                }
                else
                {
                    switch (lFldType.ToUpper())
                    {
                        case "TEXT":
                            e.RepositoryItem = repositoryItemTextEdit1;
                            break;
                        case "DATETIME":
                            repositoryItemDateEditor031.Init();
                            e.RepositoryItem = repositoryItemDateEditor031;
                            break;
                        case "LONG":
                            e.RepositoryItem = repositoryItemTextEdit1;
                            break;
                        case "BIT":
                            e.RepositoryItem = repositoryItemCheckEdit1;
                            break;
                        default:
                            e.RepositoryItem = repositoryItemTextEdit1;
                            break;
                    }
                }
                if (lCndtn.ToUpper() != "IS BETWEEN" && e.Column.FieldName == "Value2")
                {
                    e.RepositoryItem = repositoryItemTextEdit2;
                    //e.RowHandle.Column.AppearanceCell.BackColor = Color.Gray;
                }
            }
        }
        public void mRptLaunch_ReportWorkerProgress(object sender, TReportWorkerProgressEventArgs e)
        {
            mRptLaunchs[e.ID].UpdateRptPreview();
            switch (e.Progress)
            {
                case 77:
                    //label3.Text = "Job Cancelled";
                    if (mRptLaunchs.ContainsKey(e.ID))
                    {
                        RemoveKey(e.ID);
                    }
                    Cursor.Current = Cursors.Default;
                    break;
                default:
                    //label3.Text = e.Progress.ToString();
                    break;
            }
        }
        public void mRptLaunch_WorkerCompleted(object sender, TWorkerCompletedEventArgs e)
        {
            if (mRptLaunchs.ContainsKey(e.ID))
            {
                mRptLaunchs[e.ID].CompleteTask();
                RemoveKey(e.ID);
            }
            Cursor.Current = Cursors.Default;
        }
        #endregion

        #region Functions

        private void RemoveKey(Guid aGuid)
        {
            mRptLaunchs.Remove(aGuid);
            if (mRptLaunchs.Count == 0 && !Visible)
            {
                Close();
            }
        }
        private Guid BeforeGenRpt()
        {
            Cursor.Current = Cursors.WaitCursor;
            TRptLaunch lRptLaunch = new TRptLaunch(this);
            lRptLaunch.WorkerCompleted +=
                new Innotelli.Utilities.WorkerCompletedEventHandler(mRptLaunch_WorkerCompleted);
            lRptLaunch.ReportWorkerProgress +=
                new Innotelli.Utilities.ReportWorkerProgressEventHandler(mRptLaunch_ReportWorkerProgress);
            mRptLaunchs.Add(lRptLaunch.ID, lRptLaunch);
            return lRptLaunch.ID;
        }
        public bool RequiredValueCorrect()
        {
            bool lRtrnVal = true;
            string lMsg = string.Empty;
            DataView lDv = mRptFltr.CriteiraDv;

            for (int i = 0; i < mRptFltr.CriteiraDv.Count; i++)
            {
                if (Convert.ToBoolean(lDv[i]["IsParam"]))
                {
                    if (TNull.IsValueNullOrEmpty(lDv[i]["Value1"]))
                    {
                        lRtrnVal = false;
                        lMsg += lDv[i]["FldAls"] + ", ";
                    }
                }
                if (lDv[i]["Condition"].ToString() == "Is between")
                {
                    if (TNull.IsValueNullOrEmpty(lDv[i]["Value1"]) ^ TNull.IsValueNullOrEmpty(lDv[i]["Value2"]))
                    {
                        lRtrnVal = false;
                        lMsg += lDv[i]["FldAls"] + ", ";
                    }
                }
            }
            if (!lRtrnVal)
            {
                TMessageBox.ShowWarning(TStr.Left(lMsg, lMsg.Length - 2) + " IS REQUIRED");
            }
            return lRtrnVal;
        }
        public void Init(string aCatID)
        {
            TB01UserRpt lB01UserRpt = new TB01UserRpt();
            DataTable lDtRpt = null;
            string lRptNm = String.Empty;
            bool lAuthorized = false;
            string lSeqNo = null;

            mInitInProgress = true;

            // Prepare DataSets and DataViews
            mRptCatDs = mSysDataRdr.GetSysData("RPT01Cat1");
            mRptCatDs.Tables[0].PrimaryKey = new DataColumn[] { mRptCatDs.Tables[0].Columns["CatID"] };
            mRptCatDv.Table = mRptCatDs.Tables[0];
            mRptCatDv.Sort = "SeqNo";

            mRptDs = mSysDataRdr.GetSysData("RPT01");
            mRptDv.Table = mRptDs.Tables[0];
            mRptDv.Sort = "RptAls";

            lB01UserRpt.ParentKeyFieldName = Innotelli.Utilities.TGC.FKeyName;
            lB01UserRpt.ParentKey = TCurrentUser.PK;
            lB01UserRpt.LoadDataSet();

            lDtRpt = mRptDs.Tables[0];
            for (int i = lDtRpt.Rows.Count - 1; i >= 0; i--)
            {
                lRptNm = lDtRpt.Rows[i]["RptNm"].ToString();

                lAuthorized = TCurrentUser.B01UserRpt.RptAuthorized(lRptNm);

                if (!lAuthorized)
                {
                    mRptDs.Tables[0].Rows.RemoveAt(i);
                }
            }

            // Prepare Controls' binding
            lstRptCat.DisplayMember = "Dscp";
            lstRptCat.ValueMember = "CatID";
            lstRptCat.DataSource = mRptCatDv;

            lstRpt.DisplayMember = "RptAls";
            lstRpt.ValueMember = "RptNm";
            lstRpt.DataSource = mRptDv;

            mInitInProgress = false;

            lstRptCat.SelectedIndex = -1;   //not selected
            lSeqNo = mRptCatDs.Tables[0].Rows.Find(aCatID)["SeqNo"].ToString();
            lstRptCat.SelectedIndex = mRptCatDv.Find(lSeqNo);
        }
        private void SetupFilterGrid()
        {
            mRptFltr.RptNm = RptNm;
            gclFilter.Text = RptAls;
            gclFilter.DataSource = mRptFltr.CriteiraDv;
        }

        #endregion
    }
}