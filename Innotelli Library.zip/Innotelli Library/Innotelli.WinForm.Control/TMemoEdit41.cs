﻿using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.ViewInfo;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterMemoEdit41")]
    public class RepositoryItemMemoEdit41 : RepositoryItemMemoEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemMemoEdit41() { RegisterMemoEdit41(); }

        //The unique name for the custom editor
        public const string MemoEdit41Name = "TMemoEdit41";

        //Return the unique name
        public override string EditorTypeName { get { return MemoEdit41Name; } }

        //Register the editor
        public static void RegisterMemoEdit41()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.MemoEdit41.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(MemoEdit41Name,
              typeof(TMemoEdit41), typeof(RepositoryItemMemoEdit41),
              typeof(MemoEditViewInfo), new MemoEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemMemoEdit41 source = item as RepositoryItemMemoEdit41;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public RepositoryItemMemoEdit41()
        {
        }
        #endregion

        #region Properties
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        DSFormMode mDSFormMode = DSFormMode.DSEditable;
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        break;
                    case DSFormMode.DSEditable:
                        break;
                    case DSFormMode.DSInsert:
                        break;
                }
                mDSFormMode = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Init()
        {
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            Appearance.Options.UseBackColor = true;
            AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            AppearanceReadOnly.Options.UseBackColor = true;
            ReadOnly = true;
        }
        #endregion
    }

    public class TMemoEdit41 : MemoEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TMemoEdit41() { RepositoryItemMemoEdit41.RegisterMemoEdit41(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemMemoEdit41.MemoEdit41Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemMemoEdit41 Properties
        {
            get { return base.Properties as RepositoryItemMemoEdit41; }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TMemoEdit41()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(50, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(200, 39);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
            TabStop = false;
        }
        #endregion
    }
}
