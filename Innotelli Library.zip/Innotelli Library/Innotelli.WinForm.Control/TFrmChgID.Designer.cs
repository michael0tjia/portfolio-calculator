namespace Innotelli.WinForm.Control
{
    partial class TFrmChgID
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TFrmChgID));
            this.txtNewVal = new DevExpress.XtraEditors.TextEdit();
            this.tLayoutControl011 = new Innotelli.WinForm.Control.TLayoutControl01();
            this.btnCancel = new DevExpress.XtraEditors.SimpleButton();
            this.btnOK = new DevExpress.XtraEditors.SimpleButton();
            this.txtOldVal = new DevExpress.XtraEditors.TextEdit();
            this.layoutControlGroup011 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.layoutControlGroup012 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.lci01OldVal = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.lci01NewVal = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.layoutControlItem011 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlItem012 = new Innotelli.WinForm.Control.LayoutControlItem01();
            ((System.ComponentModel.ISupportInitialize)(this.txtNewVal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLayoutControl011)).BeginInit();
            this.tLayoutControl011.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtOldVal.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup011)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup012)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01OldVal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01NewVal)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem011)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem012)).BeginInit();
            this.SuspendLayout();
            // 
            // txtNewVal
            // 
            resources.ApplyResources(this.txtNewVal, "txtNewVal");
            this.txtNewVal.Name = "txtNewVal";
            this.txtNewVal.StyleController = this.tLayoutControl011;
            // 
            // tLayoutControl011
            // 
            this.tLayoutControl011.Appearance.DisabledLayoutGroupCaption.ForeColor = System.Drawing.SystemColors.GrayText;
            this.tLayoutControl011.Appearance.DisabledLayoutGroupCaption.Options.UseForeColor = true;
            this.tLayoutControl011.Appearance.DisabledLayoutItem.ForeColor = System.Drawing.SystemColors.GrayText;
            this.tLayoutControl011.Appearance.DisabledLayoutItem.Options.UseForeColor = true;
            this.tLayoutControl011.Controls.Add(this.btnCancel);
            this.tLayoutControl011.Controls.Add(this.txtNewVal);
            this.tLayoutControl011.Controls.Add(this.btnOK);
            this.tLayoutControl011.Controls.Add(this.txtOldVal);
            resources.ApplyResources(this.tLayoutControl011, "tLayoutControl011");
            this.tLayoutControl011.Name = "tLayoutControl011";
            this.tLayoutControl011.OptionsItemText.TextAlignMode = DevExpress.XtraLayout.TextAlignMode.AlignInGroups;
            this.tLayoutControl011.OptionsView.EnableIndentsInGroupsWithoutBorders = true;
            this.tLayoutControl011.Root = this.layoutControlGroup011;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            resources.ApplyResources(this.btnCancel, "btnCancel");
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.StyleController = this.tLayoutControl011;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnOK
            // 
            resources.ApplyResources(this.btnOK, "btnOK");
            this.btnOK.Name = "btnOK";
            this.btnOK.StyleController = this.tLayoutControl011;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // txtOldVal
            // 
            resources.ApplyResources(this.txtOldVal, "txtOldVal");
            this.txtOldVal.Name = "txtOldVal";
            this.txtOldVal.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtOldVal.Properties.Appearance.Options.UseBackColor = true;
            this.txtOldVal.StyleController = this.tLayoutControl011;
            // 
            // layoutControlGroup011
            // 
            resources.ApplyResources(this.layoutControlGroup011, "layoutControlGroup011");
            this.layoutControlGroup011.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlGroup012});
            this.layoutControlGroup011.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup011.Name = "layoutControlGroup011";
            this.layoutControlGroup011.OptionsItemText.TextToControlDistance = 2;
            this.layoutControlGroup011.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup011.Size = new System.Drawing.Size(239, 89);
            this.layoutControlGroup011.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup011.TextVisible = false;
            // 
            // layoutControlGroup012
            // 
            resources.ApplyResources(this.layoutControlGroup012, "layoutControlGroup012");
            this.layoutControlGroup012.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lci01OldVal,
            this.lci01NewVal,
            this.emptySpaceItem1,
            this.layoutControlItem011,
            this.layoutControlItem012});
            this.layoutControlGroup012.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup012.Name = "layoutControlGroup012";
            this.layoutControlGroup012.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup012.Size = new System.Drawing.Size(235, 85);
            this.layoutControlGroup012.Spacing = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup012.TextVisible = false;
            // 
            // lci01OldVal
            // 
            this.lci01OldVal.Control = this.txtOldVal;
            resources.ApplyResources(this.lci01OldVal, "lci01OldVal");
            this.lci01OldVal.Location = new System.Drawing.Point(0, 0);
            this.lci01OldVal.Name = "lci01OldVal";
            this.lci01OldVal.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01OldVal.Size = new System.Drawing.Size(229, 21);
            this.lci01OldVal.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01OldVal.TextSize = new System.Drawing.Size(50, 20);
            this.lci01OldVal.TextToControlDistance = 2;
            // 
            // lci01NewVal
            // 
            this.lci01NewVal.Control = this.txtNewVal;
            resources.ApplyResources(this.lci01NewVal, "lci01NewVal");
            this.lci01NewVal.Location = new System.Drawing.Point(0, 21);
            this.lci01NewVal.Name = "lci01NewVal";
            this.lci01NewVal.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01NewVal.Size = new System.Drawing.Size(229, 21);
            this.lci01NewVal.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01NewVal.TextSize = new System.Drawing.Size(50, 20);
            this.lci01NewVal.TextToControlDistance = 2;
            // 
            // emptySpaceItem1
            // 
            resources.ApplyResources(this.emptySpaceItem1, "emptySpaceItem1");
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 42);
            this.emptySpaceItem1.MaxSize = new System.Drawing.Size(50, 29);
            this.emptySpaceItem1.MinSize = new System.Drawing.Size(50, 29);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(50, 37);
            this.emptySpaceItem1.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // layoutControlItem011
            // 
            this.layoutControlItem011.Control = this.btnOK;
            resources.ApplyResources(this.layoutControlItem011, "layoutControlItem011");
            this.layoutControlItem011.Location = new System.Drawing.Point(50, 42);
            this.layoutControlItem011.MaxSize = new System.Drawing.Size(82, 28);
            this.layoutControlItem011.MinSize = new System.Drawing.Size(82, 28);
            this.layoutControlItem011.Name = "layoutControlItem011";
            this.layoutControlItem011.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem011.Size = new System.Drawing.Size(82, 37);
            this.layoutControlItem011.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem011.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.layoutControlItem011.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem011.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem011.TextToControlDistance = 0;
            this.layoutControlItem011.TextVisible = false;
            // 
            // layoutControlItem012
            // 
            this.layoutControlItem012.Control = this.btnCancel;
            resources.ApplyResources(this.layoutControlItem012, "layoutControlItem012");
            this.layoutControlItem012.Location = new System.Drawing.Point(132, 42);
            this.layoutControlItem012.MaxSize = new System.Drawing.Size(82, 28);
            this.layoutControlItem012.MinSize = new System.Drawing.Size(82, 28);
            this.layoutControlItem012.Name = "layoutControlItem012";
            this.layoutControlItem012.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem012.Size = new System.Drawing.Size(97, 37);
            this.layoutControlItem012.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem012.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.layoutControlItem012.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem012.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem012.TextToControlDistance = 0;
            this.layoutControlItem012.TextVisible = false;
            // 
            // TFrmChgID
            // 
            this.AcceptButton = this.btnOK;
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ControlBox = false;
            this.Controls.Add(this.tLayoutControl011);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "TFrmChgID";
            this.Load += new System.EventHandler(this.frmChgID_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtNewVal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLayoutControl011)).EndInit();
            this.tLayoutControl011.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.txtOldVal.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup011)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup012)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01OldVal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01NewVal)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem011)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem012)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.SimpleButton btnOK;
        private DevExpress.XtraEditors.SimpleButton btnCancel;
        private DevExpress.XtraEditors.TextEdit txtNewVal;
        private DevExpress.XtraEditors.TextEdit txtOldVal;
        private TLayoutControl01 tLayoutControl011;
        private LayoutControlGroup01 layoutControlGroup011;
        private LayoutControlItem01 lci01OldVal;
        private LayoutControlItem01 lci01NewVal;
        private LayoutControlItem01 layoutControlItem011;
        private LayoutControlItem01 layoutControlItem012;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private LayoutControlGroup01 layoutControlGroup012;
    }
}