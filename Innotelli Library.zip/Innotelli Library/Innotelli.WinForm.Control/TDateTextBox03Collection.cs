using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    public class TDateTextBox03Collection : ArrayList
    {
        #region Members
        #endregion

        #region Constructors
        public TDateTextBox03Collection()
        {
        }
        #endregion

        #region Enums
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Add(System.Windows.Forms.Control aControl)
        {
            base.Add(aControl);
        }
        public void Init()
        {

                for (int i = 0; i < this.Count; i++)
                {
                    ((TDateTextBox03)this[i]).Properties.Init();
                }
 
        }
        public void SetDSMode(DSFormMode aDSFormMode)
        {

                for (int i = 0; i < this.Count; i++)
                {
                    ((TDateTextBox03)this[i]).Properties.DSFormMode = aDSFormMode;
                }

        }
        #endregion
    }
}