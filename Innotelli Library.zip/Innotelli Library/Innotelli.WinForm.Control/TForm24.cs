using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Innotelli.BO;
using Innotelli.Utilities;
using System.Configuration;
using Innotelli.WinForm.Control;
using System.Reflection;

namespace Innotelli.WinForm.Control
{
    public partial class TForm24 : DevExpress.XtraEditors.XtraForm
    {
        #region Members
        private TSysDataRdr mSysDataRdr = Innotelli.Utilities.TSingletons.SysData03Rdr;
        private int mTries = 0;
        private DataSet mBOServerDs = null;
        private DataTable mBOServerDt = null;
        private TLookUpListLoadTask mTLookUpListLoadTask = null;
        #endregion

        #region Constructors
        public TForm24()
        {
            InitializeComponent();
        }
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (mTLookUpListLoadTask != null)
            {
                mTLookUpListLoadTask.StopTask();
            }
            DialogResult = DialogResult.Cancel;
        }
        private void btnEnter_Click(object sender, EventArgs e)
        {
            TLogin lLogin = new TLogin();

            //TAppLog.LogMessage(this.Name + " : Enter Button Is Clicked!");
            if (!TNull.IsValueNullOrEmpty(txtUser.EditValue) && !TNull.IsValueNullOrEmpty(txtPasswd.EditValue) && !TNull.IsValueNull(lueApplicationServer.EditValue))
            {
                bsiStatus.Caption = Innotelli.Utilities.TSingletons.StrResx.GetStr(130);

                Guid l = new Guid(lueApplicationServer.EditValue.ToString());
                TCurrentUser.BOServerID = new Guid(lueApplicationServer.EditValue.ToString());
                TCurrentUser.BOServerURL = mBOServerDt.Rows[lueApplicationServer.ItemIndex]["URL"].ToString();
                TReflectionClientFactory.EndpointAddress = TCurrentUser.BOServerURL;
                if (TCurrentUser.Authenticate(txtUser.EditValue.ToString(), txtPasswd.EditValue.ToString()))
                {
                    btnCancel.Select();
                    txtUser.Enabled = false;
                    txtPasswd.Enabled = false;
                    lueApplicationServer.Enabled = false;
                    btnEnter.Enabled = false;
                    lueUILanguage.Enabled = false;
                    bsiStatus.Caption = Innotelli.Utilities.TSingletons.StrResx.GetStr(131);

                    // save default BO Server
                    for (int i = 0; i < mBOServerDt.Rows.Count; i++)
                    {
                        mBOServerDt.Rows[i]["Dft"] = false;
                    }
                    mBOServerDt.Rows[lueApplicationServer.ItemIndex]["Dft"] = true;
                    mBOServerDt.AcceptChanges();
                    mSysDataRdr.SetSysData("BOServer", mBOServerDs);

                    switch (lueUILanguage.EditValue.ToString())
                    {
                        case "Eng":
                            Innotelli.Utilities.TAppSettings.SystemLanguage = SystemLanguages.English;
                            break;
                        case "TCh":
                            Innotelli.Utilities.TAppSettings.SystemLanguage = SystemLanguages.TraditionalChinese;
                            break;
                        case "SCh":
                            Innotelli.Utilities.TAppSettings.SystemLanguage = SystemLanguages.SimplifiedChinese;
                            break;
                    }
                    bsiStatus.Caption = Innotelli.Utilities.TSingletons.StrResx.GetStr(100);
                    beiProgress.Visibility = DevExpress.XtraBars.BarItemVisibility.Always;
                    StartLoadingLookUpCache();
                }
                else
                {
                    mTries++;
                    if (mTries == 3)
                    {
                        TMessageBox.ShowInformation(Innotelli.Utilities.TSingletons.StrResx.GetStr(101) + mTries + Innotelli.Utilities.TSingletons.StrResx.GetStr(102));
                        DialogResult = DialogResult.Cancel;
                    }
                    else
                    {
                        TMessageBox.ShowInformation(Innotelli.Utilities.TSingletons.StrResx.GetStr(104));
                    }
                }
            }
        }
        private void frmLogin_Load(object sender, EventArgs e)
        {
            DataView lDv = new DataView();
            DataTable lUILanguageDt = null;
            DataView lUILanguageDv = new DataView();

            Assembly lAssembly = null;


            try
            {
                lAssembly = Assembly.Load(Innotelli.Utilities.TGC.SysDataNamespace);
                pceThis.Image = (Bitmap)Bitmap.FromStream(lAssembly.GetManifestResourceStream(Innotelli.Utilities.TGC.SysDataNamespace + ".LoginFormPicture.png"));
            }
            catch
            {
            }

            txtUser.Select();
            bsiStatus.Caption = string.Empty;

            lUILanguageDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("UILanguage").Tables[0];
            lUILanguageDt.Columns.Remove(Innotelli.Utilities.TGC.PKeyName);
            lUILanguageDv.Table = lUILanguageDt;
            lueUILanguage.Properties.DataSource = lUILanguageDv;
            lueUILanguage.Properties.DisplayMember = "Language";
            lueUILanguage.Properties.ValueMember = "LanguageCode";
            lueUILanguage.EditValue = "Eng";

            mBOServerDs = mSysDataRdr.GetSysData("BOServer");
            mBOServerDt = mBOServerDs.Tables[0];
            if (mBOServerDt != null)
            {
                mBOServerDt.PrimaryKey = new DataColumn[] { mBOServerDt.Columns["BOServerID"] };
                lueApplicationServer.Properties.DataSource = mBOServerDt;
                lueApplicationServer.Properties.DisplayMember = "Dscp";
                lueApplicationServer.Properties.ValueMember = "BOServerID";

                lDv.Table = mBOServerDt;
                lDv.RowFilter = "Dft = True";
                if (lDv.Count != 0)
                {
                    lueApplicationServer.EditValue = lDv[0]["BOServerID"];
                    lblCompany.Text = lDv[0]["Cmpny"].ToString();
                    lblBOServerURL.Text = lDv[0]["URL"].ToString();
                }
            }
        }
        private void lue1DB_EditValueChanged(object sender, EventArgs e)
        {
            if (!TNull.IsValueNull(lueApplicationServer.EditValue))
            {
                DataRow[] lDrs = mBOServerDt.Select("BOServerID = '" + lueApplicationServer.EditValue.ToString() + "'");
                lblCompany.Text = lDrs[0]["Cmpny"].ToString();
                lblBOServerURL.Text = lDrs[0]["URL"].ToString();
            }

        }
        private void lue1DB_Validated(object sender, EventArgs e)
        {
        }
        private void mTLookUpListLoadTask_ReportWorkerProgress(object sender, TReportWorkerProgressEventArgs e)
        {
            beiProgress.EditValue = e.Progress;
        }
        private void mTLookUpListLoadTask_WorkerCompleted(object sender, TWorkerCompletedEventArgs e)
        {
            beiProgress.EditValue = 100;
            DialogResult = DialogResult.OK;
        }
        #endregion

        #region Functions
        public void StartLoadingLookUpCache()
        {
            mTLookUpListLoadTask = new TLookUpListLoadTask();
            mTLookUpListLoadTask.InvokeContext = this;
            mTLookUpListLoadTask.WorkerCompleted += new Innotelli.Utilities.WorkerCompletedEventHandler(mTLookUpListLoadTask_WorkerCompleted);
            mTLookUpListLoadTask.ReportWorkerProgress += new Innotelli.Utilities.ReportWorkerProgressEventHandler(mTLookUpListLoadTask_ReportWorkerProgress);
            mTLookUpListLoadTask.Start();
        }
        #endregion
    }
}