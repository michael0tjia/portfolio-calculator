using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Innotelli.Utilities;
using System.Windows.Forms;

namespace Innotelli.WinForm.Control
{
    public class TDataGrid01Collection : ArrayList
    {
        #region Members
        #endregion

        #region Constructors
        public TDataGrid01Collection()
        {
        }
        #endregion

        #region Enums
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Add(System.Windows.Forms.Control aControl)
        {
            base.Add(aControl);
        }
        public void Init(Form aParentForm)
        {

            for (int i = 0; i < this.Count; i++)
            {

                ((TDataGrid01)this[i]).ParentForm = aParentForm;
                ((TDataGrid01)this[i]).Init();
            }

        }
        public void BindData()
        {

            for (int i = 0; i < this.Count; i++)
            {
                ((TDataGrid01)this[i]).BindData();
            }

        }
        public void SetDSMode(DSFormMode aDSFormMode)
        {

            for (int i = 0; i < this.Count; i++)
            {
                ((TDataGrid01)this[i]).DSFormMode = aDSFormMode;
            }

        }
        #endregion
    }
}