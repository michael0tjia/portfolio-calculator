using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using System;
using DevExpress.Utils;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterDateEditor03")]
    public class RepositoryItemDateEditor03 : RepositoryItemDateEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemDateEditor03() { RegisterDateEditor03(); }

        //The unique name for the custom editor
        public const string DateEditor03Name = "TDateEditor03";

        //Return the unique name
        public override string EditorTypeName { get { return DateEditor03Name; } }

        //Register the editor
        public static void RegisterDateEditor03()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.DateEditor03.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(DateEditor03Name,
              typeof(TDateEditor03), typeof(RepositoryItemDateEditor03),
              typeof(DateEditViewInfo), new ButtonEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemDateEditor03 source = item as RepositoryItemDateEditor03;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        #endregion

        #region Properties
        //Initialize new properties
        public RepositoryItemDateEditor03()
        {
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Init()
        {
            DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            DisplayFormat.FormatString = TSettings.DateFormat;
            EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            EditFormat.FormatString = TSettings.DateFormat;
            EditMask = TSettings.DateFormat;
            Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTime;
            Mask.EditMask = TSettings.DateFormat;
        }
        #endregion
    }


    public class TDateEditor03 : DateEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TDateEditor03() { RepositoryItemDateEditor03.RegisterDateEditor03(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemDateEditor03.DateEditor03Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemDateEditor03 Properties
        {
            get { return base.Properties as RepositoryItemDateEditor03; }
        }
        #endregion

        #region Members
        private string mFormat = TSettings.DateFormat;
        #endregion

        #region Constructors

        //Initialize the new instance
        public TDateEditor03()
        {
            Init();
        }
        #endregion

        #region Properties
        [Bindable(true),
        Category("Behavior"),
        DefaultValue("yyyy/MM/dd"),
        Description("Indicates the date format."),
        Localizable(true)]
        public string Format
        {
            get
            {
                return mFormat;
            }
            set
            {
                mFormat = value;
            }
        }
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(60+20, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        public override object EditValue
        {
            get
            {
                object lEditValue = base.EditValue;
                if (!TNull.IsValueNull(lEditValue))
                {
                    return (DateTime.Parse(lEditValue.ToString()).ToString("yyyy/MM/dd"));
                }
                else
                {
                    return lEditValue;
                }
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
        }
        #endregion
    }
}
