using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    public class TForm06Pool
    {
        #region Members
        Hashtable mForm02s = new Hashtable();
        #endregion

        #region Constructors
        public TForm06Pool()
        {
        }
        #endregion

        #region Enums
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions

        private TForm06 CreateForm(string aForm02Name)
        {
            TForm06 lReturnValue = null;
            string lExecuteFile = null;
            Assembly lAssembly = null;

            lExecuteFile = AppDomain.CurrentDomain.BaseDirectory + Innotelli.Utilities.TGC.GetFormNameSpace(aForm02Name) + ".DLL";
            lAssembly = System.Reflection.Assembly.LoadFile(lExecuteFile);
            lReturnValue = (TForm06)lAssembly.CreateInstance(aForm02Name, true, BindingFlags.Default | BindingFlags.InvokeMethod, null, null, null, null);

            return lReturnValue;
        }
        public TForm06 GetForm(string aForm02Name)
        {
            TForm06 lReturnValue = null;
            ArrayList lFormList = null;
            bool lFound = false;
            int i = 0;

            if (mForm02s[aForm02Name] != null)
            {
                lFormList = (ArrayList)mForm02s[aForm02Name];
                for (i = 0; i < lFormList.Count; i++)
                {
                    lReturnValue = (TForm06)lFormList[i];
                    if (!lReturnValue.Visible)
                    {
                        lFound = true;
                        break;
                    }
                }
                if (!lFound)
                {
                    lReturnValue = CreateForm(aForm02Name);
                    lFormList.Add(lReturnValue);
                }
            }
            else
            {
                lFormList = new ArrayList();
                mForm02s[aForm02Name] = lFormList;
                lReturnValue = CreateForm(aForm02Name);
                lFormList.Add(lReturnValue);
            }
            return lReturnValue;
        }
        #endregion
    }
}
