﻿using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using System;
using DevExpress.Utils;

namespace Innotelli.WinForm.Control
{


    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterCheckEdit41")]
    public class RepositoryItemCheckEdit41 : RepositoryItemCheckEdit
    {

        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemCheckEdit41() { RegisterCheckEdit41(); }

        //The unique name for the custom editor
        public const string CheckEdit41Name = "TCheckEdit41";

        //Return the unique name
        public override string EditorTypeName { get { return CheckEdit41Name; } }

        //Register the editor
        public static void RegisterCheckEdit41()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;

            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.CheckEdit41.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(CheckEdit41Name,
              typeof(TCheckEdit41), typeof(RepositoryItemCheckEdit41),
              typeof(CheckEditViewInfo), new CheckEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemCheckEdit41 source = item as RepositoryItemCheckEdit41;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        //Initialize new properties
        public RepositoryItemCheckEdit41()
        {
        }
        #endregion

        #region Properties
        private DSFormMode mDSFormMode = DSFormMode.DSEditable;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        break;
                    case DSFormMode.DSEditable:
                        break;
                    case DSFormMode.DSInsert:
                        break;
                }
                mDSFormMode = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Init()
        {
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            Appearance.Options.UseBackColor = true;
            AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            AppearanceReadOnly.Options.UseBackColor = true;
            Caption = "";
            FullFocusRect = true;
            ReadOnly = true;
        }
        #endregion
    }


    public class TCheckEdit41 : CheckEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TCheckEdit41() { RepositoryItemCheckEdit41.RegisterCheckEdit41(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemCheckEdit41.CheckEdit41Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemCheckEdit41 Properties
        {
            get { return base.Properties as RepositoryItemCheckEdit41; }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        //Initialize the new instance
        public TCheckEdit41()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(19, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(19, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            TabStop = false;
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}
