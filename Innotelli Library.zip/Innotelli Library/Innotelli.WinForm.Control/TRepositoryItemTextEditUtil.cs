﻿using System;
using System.Collections.Generic;
using System.Text;
using DevExpress.XtraEditors.Repository;

namespace Innotelli.WinForm.Control
{
    public class TRepositoryItemTextEditUtil
    {
        public static void SetLocked(RepositoryItemTextEdit aRepositoryItemTextEdit, bool aBool)
        {
            aRepositoryItemTextEdit.ReadOnly = aBool;
            if (aBool)
            {
                aRepositoryItemTextEdit.Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            }
            else
            {
                aRepositoryItemTextEdit.Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            }
            if (aRepositoryItemTextEdit.OwnerEdit != null)
            {
                aRepositoryItemTextEdit.OwnerEdit.TabStop = !aBool;
            }
        }
        public static void SetDSFormMode(RepositoryItemTextEdit aRepositoryItemTextEdit, DSFormMode aDSFormMode)
        {
            switch (aDSFormMode)
            {
                case DSFormMode.DSBrowse:
                    aRepositoryItemTextEdit.ReadOnly = true;
                    break;
                case DSFormMode.DSEditable:
                case DSFormMode.DSInsert:
                    aRepositoryItemTextEdit.ReadOnly = false;
                    break;
            }
        }
        public static void SetDSFormModeReadOnly(RepositoryItemTextEdit aRepositoryItemTextEdit, DSFormMode aDSFormMode)
        {
            
        }
    }
}
