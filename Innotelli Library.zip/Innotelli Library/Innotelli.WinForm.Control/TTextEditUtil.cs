﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text;
using DevExpress.XtraEditors;
using System.Drawing;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    public class TTextEditUtil
    {
        public static void UpdateForeColor(TextEdit aTextEdit)
        {
            double lVal = 0;

            if (!TNull.IsValueNull(aTextEdit.EditValue))
            {
                double.TryParse(aTextEdit.EditValue.ToString(), out lVal);
            }
            if (lVal < 0)
            {
                aTextEdit.ForeColor = Color.Red;
            }
            else
            {
                aTextEdit.ForeColor = Color.Black;
            }
        }
        public static void Highlight(TextEdit aTextEdit)
        {
            aTextEdit.SelectionStart = 0;
            aTextEdit.SelectionLength = 255;
        }
        
    }
}
