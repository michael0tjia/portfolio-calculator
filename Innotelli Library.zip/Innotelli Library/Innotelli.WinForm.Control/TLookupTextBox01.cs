using System;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.ViewInfo;
using Innotelli.BO;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterLookupTextBox01")]
    public class RepositoryItemLookupTextBox01 : RepositoryItemGridLookUpEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemLookupTextBox01() { RegisterLookupTextBox01(); }

        //The unique name for the custom editor
        public const string LookupTextBox01Name = "TLookupTextBox01";

        //Return the unique name
        public override string EditorTypeName { get { return LookupTextBox01Name; } }

        //Register the editor
        public static void RegisterLookupTextBox01()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.LookupTextBox01.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(LookupTextBox01Name,
              typeof(TLookupTextBox01), typeof(RepositoryItemLookupTextBox01),
              typeof(GridLookUpEditBaseViewInfo), new ButtonEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemLookupTextBox01 source = item as RepositoryItemLookupTextBox01;
                if (source == null) return;
                BndCol = source.BndCol;
                BOID = source.BOID;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors

        //Initialize new properties
        public RepositoryItemLookupTextBox01()
        {
        }

        #endregion

        #region Properties
        private bool mIsLocked = false;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                ReadOnly = value;
                if (value)
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                }
                else
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
                }
                if (OwnerEdit != null)
                {
                    OwnerEdit.TabStop = !value;
                }
                for (int i = 0; i < Buttons.Count; i++)
                {
                    Buttons[i].Enabled = !value;
                }
                mIsLocked = value;
            }
        }
        private DSFormMode mDSFormMode = DSFormMode.DSEditable;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        ReadOnly = true;
                        break;
                    case DSFormMode.DSEditable:
                        ReadOnly = false;
                        break;
                    case DSFormMode.DSInsert:
                        ReadOnly = false;
                        break;
                }
                for (int i = 0; i < Buttons.Count; i++)
                {
                    Buttons[i].Enabled = !ReadOnly;
                }
                mDSFormMode = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        private TBOT01 mBOT01 = null;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
                if (mBOT01 != null && OwnerEdit != null)
                {
                    mBoundColumnName = TControlUtil.GetFirstBindingFieldName(OwnerEdit);
                    if (mBoundColumnName != string.Empty)
                    {
                        mBOID = mBOT01.SPrps.SPrpsBOT01Flds[mBoundColumnName].SelObjID;
                    }
                }
            }
        }
        private string mBoundColumnName = string.Empty;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string BoundColumnName
        {
            get
            {
                return mBoundColumnName;
            }
            set
            {
                mBoundColumnName = value;
                if (mBOT01 != null)
                {
                    mBOID = mBOT01.SPrps.SPrpsBOT01Flds[mBoundColumnName].SelObjID;
                }
            }
        }
        private string mBOID = string.Empty;
        public string BOID
        {
            get
            {
                return mBOID;
            }
            set
            {
                mBOID = value;
                OnPropertiesChanged();
            }
        }
        private int mBndCol = 0;
        public int BndCol
        {
            get
            {
                return mBndCol;
            }
            set
            {
                mBndCol = value;
                OnPropertiesChanged();
            }
        }
        private int mType = 0;
        public int Type
        {
            get
            {
                return mType;
            }
            set
            {
                mType = value;
                OnPropertiesChanged();
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Init()
        {
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            Appearance.Options.UseBackColor = true;
            AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            AppearanceReadOnly.Options.UseBackColor = true;
            ReadOnly = true;
            NullText = string.Empty;
            TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            if (OwnerEdit != null)
            {
                OwnerEdit.TabStop = false;
            }
        }
        public void BindList()
        {
            DataView lDv = null;

            if (mBOID != string.Empty)
            {
                lDv = new DataView();
                lDv.Table = BO.TSingletons.LookUpListProxy.GetList(mBOID);
                if (lDv.Table != null)
                {
                    DataSource = lDv;
                    //TODO: Create Another Selection Combo Type
                    if (mType == 2)
                    {
                        if (BndCol == 1)
                        {
                            ValueMember = lDv.Table.Columns[2].ColumnName;
                        }
                        else
                        {
                            ValueMember = lDv.Table.Columns[BndCol].ColumnName;
                        }
                        DisplayMember = lDv.Table.Columns[2].ColumnName;
                    }
                    else
                    {
                        ValueMember = lDv.Table.Columns[BndCol].ColumnName;
                        DisplayMember = lDv.Table.Columns[1].ColumnName;
                    }
                }
            }
        }
        public void RefreshList()
        {
            if (mBOID != string.Empty && DataSource != null)
            {
                ((DataView)DataSource).Table = BO.TSingletons.LookUpListProxy.GetList(mBOID);
            }
        }
        #endregion
    }
    public class TLookupTextBox01 : GridLookUpEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TLookupTextBox01() { RepositoryItemLookupTextBox01.RegisterLookupTextBox01(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemLookupTextBox01.LookupTextBox01Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemLookupTextBox01 Properties
        {
            get { return base.Properties as RepositoryItemLookupTextBox01; }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TLookupTextBox01()
        {
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(15 + 20, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }        
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        protected override void OnGotFocus(EventArgs e)
        {
            base.OnGotFocus(e);
            Properties.RefreshList();
        }
        #endregion
    }
}
