using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using System;
using DevExpress.Utils;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterPictureBox02")]
    public class RepositoryItemPictureBox02 : RepositoryItemPictureEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemPictureBox02() { RegisterPictureBox02(); }

        //The unique name for the custom editor
        public const string PictureBox02Name = "TPictureBox02";

        //Return the unique name
        public override string EditorTypeName { get { return PictureBox02Name; } }

        //Register the editor
        public static void RegisterPictureBox02()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.PictureBox02.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(PictureBox02Name,
              typeof(TPictureBox02), typeof(RepositoryItemPictureBox02),
              typeof(PictureEditViewInfo), new PictureEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemPictureBox02 source = item as RepositoryItemPictureBox02;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public RepositoryItemPictureBox02()
        {
        }
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }

    public class TPictureBox02 : PictureEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TPictureBox02() { RepositoryItemPictureBox02.RegisterPictureBox02(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemPictureBox02.PictureBox02Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemPictureBox02 Properties
        {
            get { return base.Properties as RepositoryItemPictureBox02; }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors        
        public TPictureBox02()
        {
            Init();
        }
        #endregion

        #region Properties        
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}