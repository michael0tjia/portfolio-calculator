using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    public class TTextBox04Collection : List<TTextBox04>
    {
        #region Members
        #endregion

        #region Constructors
        public TTextBox04Collection()
        {
        }
        #endregion

        #region Enums
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Add(System.Windows.Forms.Control aControl)
        {
            base.Add((TTextBox04)aControl);
        }
        public void Init(TBOT01 aBOT01)
        {
            for (int i = 0; i < this.Count; i++)
            {
                this[i].Properties.Init(aBOT01);
            }
        }
        public void SetDSMode(DSFormMode aDSFormMode)
        {
            for (int i = 0; i < this.Count; i++)
            {
                this[i].Properties.DSFormMode = aDSFormMode;
            }
        }
        #endregion
    }
}