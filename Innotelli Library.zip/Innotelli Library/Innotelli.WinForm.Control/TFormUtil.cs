﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.Windows.Forms;
using Innotelli.Utilities;
using Innotelli.BO;

namespace Innotelli.WinForm.Control
{
    public static class TFormUtil
    {
        public static void Show(string aFormName)
        {
            Assembly lAssembly = null;
            Form lForm = null;

            lAssembly = Assembly.Load(Innotelli.Utilities.TGC.GetFormNameSpace(aFormName));
            lForm = (Form)lAssembly.CreateInstance(aFormName, true, BindingFlags.Default | BindingFlags.InvokeMethod, null, null, null, null);
            if (lForm != null)
            {
                lForm.MdiParent = Innotelli.WinForm.Control.TSingletons.RootMdiParent;
                lForm.Show();
            }
        }
        public static void OpenForm06(string aFormName, string aBOID)
        {
            Assembly lAssembly = null;
            TForm06 lForm06 = null;
            string lTblName = Innotelli.BO.TSingletons.SPrpsBOT01s[aBOID].TblName;
            TDbRowID lPK;

            if (TDomain.LookupPK(lTblName, string.Empty, out lPK))
            {
                lAssembly = Assembly.Load(Innotelli.Utilities.TGC.GetFormNameSpace(aFormName));
                lForm06 = (TForm06)lAssembly.CreateInstance(aFormName, true, BindingFlags.Default | BindingFlags.InvokeMethod, null, null, null, null);
                if (lForm06 != null)
                {
                    lForm06.MdiParent = Innotelli.WinForm.Control.TSingletons.RootMdiParent;
                    lForm06.LoadByPK(lPK);
                    lForm06.Visible = true;
                }
            }
        }
        public static void CreateFindForm(string aBOID)
        {
            Assembly lAssembly = null;
            TForm04 lForm04 = null;

            //TODO: Michael Move to A401 BackOffice
            #region Move to A401
            if (aBOID == "TB01OutOrder")
            {
                lAssembly = Assembly.Load(Innotelli.BO.TSingletons.SPrpsBOT01s[aBOID].UINameSpace);
                lForm04 = (TForm04)lAssembly.CreateInstance(Innotelli.BO.TSingletons.SPrpsBOT01s[aBOID].UINameSpace + "." + "TF04OutOrder", true, BindingFlags.Default | BindingFlags.InvokeMethod, null, null, null, null);

                lForm04.MdiParent = Innotelli.WinForm.Control.TSingletons.RootMdiParent;
                lForm04.BOID = aBOID;
                lForm04.Show();
            }
            else if (aBOID == "TB01Empy")
            {
                lAssembly = Assembly.Load(Innotelli.BO.TSingletons.SPrpsBOT01s[aBOID].UINameSpace);
                lForm04 = (TForm04)lAssembly.CreateInstance(Innotelli.BO.TSingletons.SPrpsBOT01s[aBOID].UINameSpace + "." + "TF04Empy", true, BindingFlags.Default | BindingFlags.InvokeMethod, null, null, null, null);

                lForm04.MdiParent = Innotelli.WinForm.Control.TSingletons.RootMdiParent;
                lForm04.BOID = aBOID;
                lForm04.Show();
            }
            #endregion
            else
            {
                lForm04 = new TForm04();
                lForm04.MdiParent = Innotelli.WinForm.Control.TSingletons.RootMdiParent;
                lForm04.BOID = aBOID;
                lForm04.Show();
            }
        }
        public static void OpenReportExplorer(string aCatID)
        {
            TRptExplr1 lRptExplr = new TRptExplr1(aCatID);
            lRptExplr.MdiParent = Innotelli.WinForm.Control.TSingletons.RootMdiParent;
            lRptExplr.Show();
        }
    }
}
