namespace Innotelli.WinForm.Control
{
    partial class TForm01
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TForm01));
            this.btnSave = new DevExpress.XtraEditors.SimpleButton();
            this.lyc01Base = new Innotelli.WinForm.Control.TLayoutControl01();
            this.btnCancel = new DevExpress.XtraEditors.SimpleButton();
            this.lcg01Base = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.lcg01Base2 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.lcg01Base3 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.lci01Submit = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.lci01Cancel = new Innotelli.WinForm.Control.LayoutControlItem01();
            ((System.ComponentModel.ISupportInitialize)(this.lyc01Base)).BeginInit();
            this.lyc01Base.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Submit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Cancel)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSave
            // 
            resources.ApplyResources(this.btnSave, "btnSave");
            this.btnSave.Name = "btnSave";
            this.btnSave.StyleController = this.lyc01Base;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // lyc01Base
            // 
            this.lyc01Base.Controls.Add(this.btnCancel);
            this.lyc01Base.Controls.Add(this.btnSave);
            resources.ApplyResources(this.lyc01Base, "lyc01Base");
            this.lyc01Base.Name = "lyc01Base";
            this.lyc01Base.OptionsItemText.TextAlignMode = DevExpress.XtraLayout.TextAlignMode.AlignInGroups;
            this.lyc01Base.OptionsView.EnableIndentsInGroupsWithoutBorders = true;
            this.lyc01Base.Root = this.lcg01Base;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            resources.ApplyResources(this.btnCancel, "btnCancel");
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.StyleController = this.lyc01Base;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // lcg01Base
            // 
            resources.ApplyResources(this.lcg01Base, "lcg01Base");
            this.lcg01Base.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lcg01Base2,
            this.lcg01Base3});
            this.lcg01Base.Location = new System.Drawing.Point(0, 0);
            this.lcg01Base.Name = "lcg01Base";
            this.lcg01Base.OptionsItemText.TextToControlDistance = 2;
            this.lcg01Base.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base.Size = new System.Drawing.Size(449, 310);
            this.lcg01Base.TextVisible = false;
            // 
            // lcg01Base2
            // 
            resources.ApplyResources(this.lcg01Base2, "lcg01Base2");
            this.lcg01Base2.Location = new System.Drawing.Point(0, 0);
            this.lcg01Base2.Name = "lcg01Base2";
            this.lcg01Base2.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base2.Size = new System.Drawing.Size(445, 274);
            this.lcg01Base2.Spacing = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base2.TextVisible = false;
            // 
            // lcg01Base3
            // 
            resources.ApplyResources(this.lcg01Base3, "lcg01Base3");
            this.lcg01Base3.GroupBordersVisible = false;
            this.lcg01Base3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem1,
            this.lci01Submit,
            this.lci01Cancel});
            this.lcg01Base3.Location = new System.Drawing.Point(0, 274);
            this.lcg01Base3.Name = "lcg01Base3";
            this.lcg01Base3.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base3.Size = new System.Drawing.Size(445, 32);
            this.lcg01Base3.Spacing = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base3.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            resources.ApplyResources(this.emptySpaceItem1, "emptySpaceItem1");
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(277, 28);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // lci01Submit
            // 
            this.lci01Submit.Control = this.btnSave;
            resources.ApplyResources(this.lci01Submit, "lci01Submit");
            this.lci01Submit.Location = new System.Drawing.Point(277, 0);
            this.lci01Submit.MaxSize = new System.Drawing.Size(82, 28);
            this.lci01Submit.MinSize = new System.Drawing.Size(82, 28);
            this.lci01Submit.Name = "lci01Submit";
            this.lci01Submit.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01Submit.Size = new System.Drawing.Size(82, 28);
            this.lci01Submit.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lci01Submit.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.lci01Submit.TextSize = new System.Drawing.Size(0, 0);
            this.lci01Submit.TextToControlDistance = 0;
            this.lci01Submit.TextVisible = false;
            // 
            // lci01Cancel
            // 
            this.lci01Cancel.Control = this.btnCancel;
            resources.ApplyResources(this.lci01Cancel, "lci01Cancel");
            this.lci01Cancel.Location = new System.Drawing.Point(359, 0);
            this.lci01Cancel.MaxSize = new System.Drawing.Size(82, 28);
            this.lci01Cancel.MinSize = new System.Drawing.Size(82, 28);
            this.lci01Cancel.Name = "lci01Cancel";
            this.lci01Cancel.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01Cancel.Size = new System.Drawing.Size(82, 28);
            this.lci01Cancel.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lci01Cancel.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.lci01Cancel.TextSize = new System.Drawing.Size(0, 0);
            this.lci01Cancel.TextToControlDistance = 0;
            this.lci01Cancel.TextVisible = false;
            // 
            // TForm01
            // 
            this.AcceptButton = this.btnSave;
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.Controls.Add(this.lyc01Base);
            this.KeyPreview = true;
            this.Name = "TForm01";
            this.Load += new System.EventHandler(this.TForm01_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TForm01_FormClosing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TForm01_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.lyc01Base)).EndInit();
            this.lyc01Base.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Submit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Cancel)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        protected TLayoutControl01 lyc01Base;
        protected LayoutControlGroup01 lcg01Base;
        protected LayoutControlGroup01 lcg01Base2;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraEditors.SimpleButton btnCancel;
        private DevExpress.XtraEditors.SimpleButton btnSave;
        private LayoutControlItem01 lci01Submit;
        private LayoutControlItem01 lci01Cancel;
        protected LayoutControlGroup01 lcg01Base3;
    }
}