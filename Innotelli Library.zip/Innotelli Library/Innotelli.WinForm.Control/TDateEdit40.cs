﻿using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.ViewInfo;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method 
    [UserRepositoryItem("RegisterDateEdit40")]
    public class RepositoryItemDateEdit40 : RepositoryItemDateEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemDateEdit40() { RegisterDateEdit40(); }
        //The unique name for the custom editor
        public const string DateEdit40Name = "TDateEdit40";

        //Return the unique name
        public override string EditorTypeName { get { return DateEdit40Name; } }

        //Register the editor
        public static void RegisterDateEdit40()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.DateEdit40.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(DateEdit40Name,
              typeof(TDateEdit40), typeof(RepositoryItemDateEdit40),
              typeof(DateEditViewInfo), new ButtonEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemDateEdit40 source = item as RepositoryItemDateEdit40;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        //Initialize new properties
        public RepositoryItemDateEdit40()
        {
        }
        #endregion

        #region Properties
        private bool mIsLocked = false;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                ReadOnly = value;
                if (value)
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                }
                else
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
                }
                if (OwnerEdit != null)
                {
                    OwnerEdit.TabStop = !value;
                }
                for (int i = 0; i < Buttons.Count; i++)
                {
                    Buttons[i].Enabled = !value;
                }
                mIsLocked = value;
            }
        }

        private DSFormMode mDSFormMode = DSFormMode.DSEditable;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        ReadOnly = true;
                        break;
                    case DSFormMode.DSEditable:
                        ReadOnly = false;
                        break;
                    case DSFormMode.DSInsert:
                        ReadOnly = false;
                        break;
                }
                for (int i = 0; i < Buttons.Count; i++)
                {
                    Buttons[i].Enabled = !ReadOnly;
                }
                mDSFormMode = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Init()
        {
            AppearanceReadOnly.Options.UseBackColor = false;
            //#check!
            //Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            //new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            DisplayFormat.FormatString = TSettings.DateFormat;
            EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            EditFormat.FormatString = TSettings.DateFormat;
            EditMask = TSettings.DateFormat;
            Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTime;
            Mask.EditMask = TSettings.DateFormat;
            //Mask.EditMask = resources.GetString("RepositoryItemDateEdit40.Mask.EditMask");
            //Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("RepositoryItemDateEdit40.Mask.UseMaskAsDisplayFormat")));
            //#check! - 20080423
            //VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            //    new DevExpress.XtraEditors.Controls.EditorButton()});
        }
        #endregion
    }

    public class TDateEdit40 : DateEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TDateEdit40() { RepositoryItemDateEdit40.RegisterDateEdit40(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemDateEdit40.DateEdit40Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemDateEdit40 Properties
        {
            get { return base.Properties as RepositoryItemDateEdit40; }
        }
        #endregion

        #region Constructors
        //Initialize the new instance
        public TDateEdit40()
        {
            Init();
        }
        #endregion

        #region Members
        #endregion

        #region Properties
        private string mFormat = TSettings.DateFormat;
        [Bindable(true),
        Category("Behavior"),
        DefaultValue("yyyy/MM/dd"),
        Description("Indicates the date format."),
        Localizable(true)]
        public string Format
        {
            get
            {
                return mFormat;
            }
            set
            {
                mFormat = value;
            }
        }
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(60 + 20, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}