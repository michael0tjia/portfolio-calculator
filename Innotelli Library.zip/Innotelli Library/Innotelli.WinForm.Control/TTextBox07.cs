using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using System;
using DevExpress.Utils;

namespace Innotelli.WinForm.Control
{

    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterTextBox07")]
    public class RepositoryItemTextBox07 : RepositoryItemTextEdit
    {
        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static RepositoryItemTextBox07() { RegisterTextBox07(); }

        //The unique name for the custom editor
        public const string TextBox07Name = "TTextBox07";

        //Return the unique name
        public override string EditorTypeName { get { return TextBox07Name; } }

        //Register the editor
        public static void RegisterTextBox07()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.TextBox07.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(TextBox07Name,
              typeof(TTextBox07), typeof(RepositoryItemTextBox07),
              typeof(TextEditViewInfo), new TextEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemTextBox07 source = item as RepositoryItemTextBox07;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }

        #endregion

        #region Members

        DSFormMode mDSFormMode = DSFormMode.DSEditable;

        #endregion

        #region Constructors

        //Initialize new properties
        public RepositoryItemTextBox07()
        {
        }

        #endregion

        #region Properties

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        break;
                    case DSFormMode.DSEditable:
                        break;
                    case DSFormMode.DSInsert:
                        break;
                }
                mDSFormMode = value;
            }
        }

        #endregion

        #region Event Handlers
        #endregion

        #region Functions

        public void Init()
        {
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            Appearance.Options.UseBackColor = true;
            AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            AppearanceReadOnly.Options.UseBackColor = true;
            ReadOnly = true;
        }

        #endregion   
    }


    public class TTextBox07 : TextEdit
    {
        #region Enums

        #endregion

        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static TTextBox07() { RepositoryItemTextBox07.RegisterTextBox07(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemTextBox07.TextBox07Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemTextBox07 Properties
        {
            get { return base.Properties as RepositoryItemTextBox07; }
        }

        #endregion

        #region Members
        #endregion

        #region Constructors
        

        //Initialize the new instance
        public TTextBox07()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(15, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
            TabStop = false;
        }
        #endregion
    }
}
