﻿using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using System;
using DevExpress.Utils;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{

    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterDecimalTextEdit40")]
    public class RepositoryItemDecimalTextEdit40 : RepositoryItemTextEdit
    {
        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static RepositoryItemDecimalTextEdit40() { RegisterDecimalTextEdit40(); }

        //The unique name for the custom editor
        public const string DecimalTextEdit40Name = "TDecimalTextEdit40";

        //Return the unique name
        public override string EditorTypeName { get { return DecimalTextEdit40Name; } }

        //Register the editor
        public static void RegisterDecimalTextEdit40()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.DecimalTextEdit40.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(DecimalTextEdit40Name,
              typeof(TDecimalTextEdit40), typeof(RepositoryItemDecimalTextEdit40),
              typeof(TextEditViewInfo), new TextEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemDecimalTextEdit40 source = item as RepositoryItemDecimalTextEdit40;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }

        #endregion

        #region Constructors
        //Initialize new properties
        public RepositoryItemDecimalTextEdit40()
        {
        }
        #endregion

        #region Properties
        private bool mIsLocked = false;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                TRepositoryItemTextEditUtil.SetLocked(this, value);
                mIsLocked = value;
            }
        }
        DSFormMode mDSFormMode = DSFormMode.DSEditable;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                TRepositoryItemTextEditUtil.SetDSFormMode(this, value);
                mDSFormMode = value;
            }
        }
        #endregion

        #region Functions

        public void Init()
        {
            Appearance.Options.UseTextOptions = true;
            Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            AppearanceReadOnly.Options.UseBackColor = false;
            AppearanceReadOnly.Options.UseTextOptions = true;
            AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            MaxLength = 255;

            DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            DisplayFormat.FormatString = TSettings.DecFormat;
            EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            EditFormat.FormatString = TSettings.DecFormat;
            Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            Mask.EditMask = TSettings.DecFormat;

            ////System.Globalization.CultureInfo lCulture = System.Threading.Thread.CurrentThread.CurrentCulture.Clone() as System.Globalization.CultureInfo;
            //System.Globalization.CultureInfo lCulture = new System.Globalization.CultureInfo("en-us");
            //lCulture.NumberFormat.NegativeSign = "-";
            ////lCulture.NumberFormat.NumberDecimalDigits = TSettings.DecDecimalPlaces;
            //lCulture.NumberFormat.NumberDecimalSeparator = ".";
            //lCulture.NumberFormat.NumberGroupSeparator = ",";
            //lCulture.NumberFormat.NumberGroupSizes = new int[1] { 3 };
            ////lCulture.NumberFormat.NumberNegativePattern = -1;
            //Mask.Culture = lCulture;

            //Mask.UseMaskAsDisplayFormat = true;
        }

        #endregion


    }


    public class TDecimalTextEdit40 : TextEdit
    {
        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static TDecimalTextEdit40() { RepositoryItemDecimalTextEdit40.RegisterDecimalTextEdit40(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemDecimalTextEdit40.DecimalTextEdit40Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemDecimalTextEdit40 Properties
        {
            get { return base.Properties as RepositoryItemDecimalTextEdit40; }
        }

        #endregion

        #region Constructors


        //Initialize the new instance
        public TDecimalTextEdit40()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(50, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        private string mFormat = TSettings.DecFormat;
        [Bindable(true),
        Category("Behavior"),
        DefaultValue("n"),
        Description("Indicates the numeric format."),
        Localizable(true)]
        public string Format
        {
            get
            {
                return mFormat;
            }
            set
            {
                mFormat = value;
            }
        }
        #endregion

        #region Event Handlers
        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);

            SelectionStart = 0;
            SelectionLength = 255;

        }
        protected override void OnEditValueChanged()
        {
            base.OnEditValueChanged();
            if (Utilities.TGC.IsRunTime)
            {
                TTextEditUtil.UpdateForeColor(this);
            }
        }
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}
