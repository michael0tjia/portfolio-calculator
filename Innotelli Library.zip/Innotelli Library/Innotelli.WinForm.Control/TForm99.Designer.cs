namespace Innotelli.WinForm.Control
{
    partial class TForm99
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TForm99));
            this.btn02BaseNew = new Innotelli.WinForm.Control.TButton02();
            this.btn02BaseSave = new Innotelli.WinForm.Control.TButton02();
            this.btn02BaseEdit = new Innotelli.WinForm.Control.TButton02();
            this.btn02BaseDelete = new Innotelli.WinForm.Control.TButton02();
            this.btn02BaseCancel = new Innotelli.WinForm.Control.TButton02();
            this.btn02BaseFirst = new Innotelli.WinForm.Control.TButton02();
            this.btn02BasePrevious = new Innotelli.WinForm.Control.TButton02();
            this.btn02BaseNext = new Innotelli.WinForm.Control.TButton02();
            this.btn02BaseLast = new Innotelli.WinForm.Control.TButton02();
            this.SuspendLayout();
            // 
            // btn02BaseNew
            // 
            resources.ApplyResources(this.btn02BaseNew, "btn02BaseNew");
            this.btn02BaseNew.Name = "btn02BaseNew";
            this.btn02BaseNew.Click += new System.EventHandler(this.btn02BaseNew_Click);
            // 
            // btn02BaseSave
            // 
            resources.ApplyResources(this.btn02BaseSave, "btn02BaseSave");
            this.btn02BaseSave.Name = "btn02BaseSave";
            this.btn02BaseSave.Click += new System.EventHandler(this.btn02BaseSave_Click);
            // 
            // btn02BaseEdit
            // 
            resources.ApplyResources(this.btn02BaseEdit, "btn02BaseEdit");
            this.btn02BaseEdit.Name = "btn02BaseEdit";
            this.btn02BaseEdit.Click += new System.EventHandler(this.btn02BaseEdit_Click);
            // 
            // btn02BaseDelete
            // 
            resources.ApplyResources(this.btn02BaseDelete, "btn02BaseDelete");
            this.btn02BaseDelete.Name = "btn02BaseDelete";
            this.btn02BaseDelete.Click += new System.EventHandler(this.btn02BaseDelete_Click);
            // 
            // btn02BaseCancel
            // 
            resources.ApplyResources(this.btn02BaseCancel, "btn02BaseCancel");
            this.btn02BaseCancel.Name = "btn02BaseCancel";
            this.btn02BaseCancel.Click += new System.EventHandler(this.btn02BaseCancel_Click);
            // 
            // btn02BaseFirst
            // 
            resources.ApplyResources(this.btn02BaseFirst, "btn02BaseFirst");
            this.btn02BaseFirst.Name = "btn02BaseFirst";
            this.btn02BaseFirst.Click += new System.EventHandler(this.btn02BaseFirst_Click);
            // 
            // btn02BasePrevious
            // 
            resources.ApplyResources(this.btn02BasePrevious, "btn02BasePrevious");
            this.btn02BasePrevious.Name = "btn02BasePrevious";
            this.btn02BasePrevious.Click += new System.EventHandler(this.btn02BasePrevious_Click);
            // 
            // btn02BaseNext
            // 
            resources.ApplyResources(this.btn02BaseNext, "btn02BaseNext");
            this.btn02BaseNext.Name = "btn02BaseNext";
            this.btn02BaseNext.Click += new System.EventHandler(this.btn02BaseNext_Click);
            // 
            // btn02BaseLast
            // 
            resources.ApplyResources(this.btn02BaseLast, "btn02BaseLast");
            this.btn02BaseLast.Name = "btn02BaseLast";
            this.btn02BaseLast.Click += new System.EventHandler(this.btn02BaseLast_Click);
            // 
            // Form99
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btn02BaseLast);
            this.Controls.Add(this.btn02BaseNext);
            this.Controls.Add(this.btn02BasePrevious);
            this.Controls.Add(this.btn02BaseFirst);
            this.Controls.Add(this.btn02BaseCancel);
            this.Controls.Add(this.btn02BaseDelete);
            this.Controls.Add(this.btn02BaseEdit);
            this.Controls.Add(this.btn02BaseSave);
            this.Controls.Add(this.btn02BaseNew);
            this.Name = "TForm99";
            this.Load += new System.EventHandler(this.Form02_Load);
            this.ResumeLayout(false);

        }

        #endregion

        protected TButton02 btn02BaseNew;
        protected TButton02 btn02BaseSave;
        protected TButton02 btn02BaseEdit;
        protected TButton02 btn02BaseDelete;
        protected TButton02 btn02BaseCancel;
        protected TButton02 btn02BaseFirst;
        protected TButton02 btn02BasePrevious;
        protected TButton02 btn02BaseNext;
        protected TButton02 btn02BaseLast;
    }
}