using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Innotelli.WinForm.Control;
using Innotelli.BO;

namespace Innotelli.WinForm.Control
{
    public partial class TForm03 : DevExpress.XtraEditors.XtraForm
    {
        #region Enums

        #endregion

        #region Members
        #region Control Collections
        private TCheckBox05Collection mCheckBox05Collection = new TCheckBox05Collection();
        private TCheckBox06Collection mCheckBox06Collection = new TCheckBox06Collection();
        private TCurrencyTextBox05Collection mCurrencyTextBox05Collection = new TCurrencyTextBox05Collection();
        private TDateEditor02Collection mDateEditor02Collection = new TDateEditor02Collection();
        private TDateTextBox03Collection mDateTextBox03Collection = new TDateTextBox03Collection();
        private TDataGrid03Collection mDataGrid03Collection = new TDataGrid03Collection();
        private TDecimalTextBox05Collection mDecimalTextBox05Collection = new TDecimalTextBox05Collection();
        private TIntegerTextBox05Collection mIntegerTextBox05Collection = new TIntegerTextBox05Collection();
        private TMemoBox03Collection mMemoBox03Collection = new TMemoBox03Collection();
        private TRadioButton05Collection mRadioButton05Collection = new TRadioButton05Collection();
        private TTextBox07Collection mTextBox07Collection = new TTextBox07Collection();
        private TTimeEditor02Collection mTimeEditor02Collection = new TTimeEditor02Collection();
        private TTimeTextBox02Collection mTimeTextBox02Collection = new TTimeTextBox02Collection();
        #endregion
        #endregion

        #region Constructors
        public TForm03()
        {
            InitializeComponent();

        }
        #endregion

        #region Properties
        private BindingSource mBdsMaster = null;
        public BindingSource BdsMaster
        {
            get
            {
                return mBdsMaster;
            }
            set
            {
                if (mBdsMaster == value)
                    return;
                mBdsMaster = value;
            }
        }
        private TBOT03 mBOT03 = null;
        public TBOT03 BOT03
        {
            get
            {
                return mBOT03;
            }
            set
            {
                mBOT03 = value;
            }
        }
        private TBOT04 mBOT04 = null;
        public TBOT04 BOT04
        {
            get
            {
                return mBOT04;
            }
            set
            {
                mBOT04 = value;
            }
        }
        public TDataGrid03Collection DataGrid03Collection
        {
            get
            {
                return mDataGrid03Collection;
            }
            set
            {
                if (mDataGrid03Collection == value)
                    return;
                mDataGrid03Collection = value;
            }
        }
        #endregion

        #region Event Handlers
        private void btnSelectAll_Click(object sender, EventArgs e)
        {

            SetAllIsSelVals(true);

        }
        private void btnDeselectAll_Click(object sender, EventArgs e)
        {

            SetAllIsSelVals(false);

        }
        private void btnOK_Click(object sender, EventArgs e)
        {

            OK();

        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            Cancel();
        }
        #endregion

        #region Functions
        public virtual void Init()
        {
            if (Utilities.TGC.IsRunTime)
            {
                CreateControlCollections();
                AssignBOToGrids();
                InitControlCollections();
            }
        }
        public virtual void SetAllIsSelVals(bool aVal)
        {
            mBOT04.SetAllIsSelVals(aVal);
        }
        public virtual void OK()
        {
            DialogResult = DialogResult.OK;
        }
        public virtual void Cancel()
        {
            DialogResult = DialogResult.Cancel;
        }
        public void CreateControlCollections()
        {

            foreach (System.Windows.Forms.Control lControl in lyc01Base.Controls)
            {
                switch (lControl.GetType().Name)
                {
                    case "TCheckBox05":
                        mCheckBox05Collection.Add(lControl);
                        break;
                    case "TCheckBox06":
                        mCheckBox06Collection.Add(lControl);
                        break;
                    case "TCurrencyTextBox05":
                        mCurrencyTextBox05Collection.Add(lControl);
                        break;
                    case "TDateEditor02":
                        mDateEditor02Collection.Add(lControl);
                        break;
                    case "TDateTextBox03":
                        mDateTextBox03Collection.Add(lControl);
                        break;
                    case "TDataGrid03":
                        mDataGrid03Collection.Add(lControl);
                        break;
                    case "TDecimalTextBox05":
                        mDecimalTextBox05Collection.Add(lControl);
                        break;
                    case "TIntegerTextBox05":
                        mIntegerTextBox05Collection.Add(lControl);
                        break;
                    case "TMemoBox03":
                        mMemoBox03Collection.Add(lControl);
                        break;
                    case "TRadioButton05":
                        mRadioButton05Collection.Add(lControl);
                        break;
                    case "TTextBox07":
                        mTextBox07Collection.Add(lControl);
                        break;
                    case "TTimeEditor02":
                        mTimeEditor02Collection.Add(lControl);
                        break;
                    case "TTimeTextBox02":
                        mTimeTextBox02Collection.Add(lControl);
                        break;
                    default:
                        break;
                }
            }

        }
        public virtual void AssignBOToGrids()
        {
        }
        private void InitControlCollections()
        {

            mCheckBox05Collection.Init();
            mCheckBox06Collection.Init();
            mCurrencyTextBox05Collection.Init();
            mDateEditor02Collection.Init();
            mDateTextBox03Collection.Init();
            mDataGrid03Collection.Init(this);
            mDecimalTextBox05Collection.Init();
            mIntegerTextBox05Collection.Init();
            mMemoBox03Collection.Init();
            mRadioButton05Collection.Init();
            mTextBox07Collection.Init();
            mTimeEditor02Collection.Init();
            mTimeTextBox02Collection.Init();

        }
        public void BindDataGridCollection()
        {
            mDataGrid03Collection.BindData();
        }
        public virtual void Prepare()
        {
            if (mBOT03 != null)
            {
                mBOT03.LoadDataSet();
                mBdsMaster.DataSource = mBOT03.Dt;
                mBdsMaster.ResetBindings(true);
            }
            mBOT04.LoadDataSet();
            mDataGrid03Collection.BindData();
        }
        public virtual bool Process()
        {
            return true;
        }
        #endregion

        private void TForm03_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.S && e.Control && e.Alt && e.Shift)
            {
                foreach (TDataGrid03 lDataGrid03 in mDataGrid03Collection)
                {
                    ((DevExpress.XtraGrid.Views.Base.ColumnView)lDataGrid03.MainView).SaveLayoutToXml("D:\\" + lDataGrid03.Name + ".xml");
                }
                e.Handled = true;
            }
        }
    }
}