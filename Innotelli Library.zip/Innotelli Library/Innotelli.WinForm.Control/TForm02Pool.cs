using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using System.Data;
using System.Configuration;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    public class TForm02Pool
    {
        #region Enums
        #endregion

        #region Members
        Hashtable mForm02Lists = new Hashtable();
        #endregion

        #region Constructors
        public TForm02Pool()
        {
            mBODv.Table = Innotelli.BO.TSingletons.SPrpsBOT01s.Dt;
            mBODv.RowFilter = "PreLoadFrm02Tp = 1";
        }
        #endregion

        #region Properties
        private DataView mBODv = new DataView();
        public DataView BODv
        {
            get
            {
                return mBODv;
            }
            set
            {
                mBODv = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public TForm02 CreateForm(string aForm02Name)
        {
            TForm02 lReturnValue = null;
            Assembly lAssembly = null;

            lAssembly = System.Reflection.Assembly.Load(Innotelli.Utilities.TGC.GetFormNameSpace(aForm02Name));
            lReturnValue = (TForm02)lAssembly.CreateInstance(aForm02Name, true, BindingFlags.Default | BindingFlags.InvokeMethod, null, null, null, null);
            if (lReturnValue != null)
            {
                lReturnValue.Init();
            }

            return lReturnValue;
        }
        public TForm02 AddNewFormToList(string aForm02FullName)
        {
            TForm02 lReturnValue = null;
            ArrayList lFormList = null;

            if (mForm02Lists[aForm02FullName] != null)
            {
                lFormList = (ArrayList)mForm02Lists[aForm02FullName];
            }
            else
            {
                lFormList = new ArrayList();
                mForm02Lists[aForm02FullName] = lFormList;
            }
            lReturnValue = CreateForm(aForm02FullName);
            lFormList.Add(lReturnValue);

            return lReturnValue;
        }
        public TForm02 GetForm(string aForm02FullName)
        {
            TForm02 lReturnValue = null;
            ArrayList lFormList = null;
            bool lFound = false;
            int i = 0;

            if (mForm02Lists[aForm02FullName] != null)
            {
                lFormList = (ArrayList)mForm02Lists[aForm02FullName];
                for (i = 0; i < lFormList.Count; i++)
                {
                    lReturnValue = (TForm02)lFormList[i];
                    if (!lReturnValue.Visible)
                    {
                        lFound = true;
                        break;
                    }
                }
                if (!lFound)
                {
                    lReturnValue = CreateForm(aForm02FullName);
                    lFormList.Add(lReturnValue);
                }
            }
            else
            {
                lFormList = new ArrayList();
                mForm02Lists[aForm02FullName] = lFormList;
                lReturnValue = CreateForm(aForm02FullName);
                lFormList.Add(lReturnValue);
            }

            if (lReturnValue != null)
            {
                lReturnValue.InitForReuse();
                lReturnValue.MdiParent = Innotelli.WinForm.Control.TSingletons.RootMdiParent;
            }

            return lReturnValue;
        }
        public void BindAllLookUpListCombo02()
        {
            TForm02 lForm02 = null;
            ArrayList lForm02List = null;

            foreach (object lObj in mForm02Lists)
            {
                lForm02List = (ArrayList)((System.Collections.DictionaryEntry)lObj).Value;
                for (int i = 0; i < lForm02List.Count; i++)
                {
                    lForm02 = (TForm02)lForm02List[i];
                    lForm02.LookUpCombo02Collection.BindAllLists(lForm02.BOT01);
                }

            }
        }
        #endregion
    }
}
