﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.ViewInfo;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterCurrencyTextEdit40")]
    public class RepositoryItemCurrencyTextEdit40 : RepositoryItemTextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemCurrencyTextEdit40() { RegisterCurrencyTextEdit40(); }

        //The unique name for the custom editor
        public const string CurrencyTextEdit40Name = "TCurrencyTextEdit40";

        //Return the unique name
        public override string EditorTypeName { get { return CurrencyTextEdit40Name; } }

        //Register the editor
        public static void RegisterCurrencyTextEdit40()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.CurrencyTextEdit40.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(CurrencyTextEdit40Name,
              typeof(TCurrencyTextEdit40), typeof(RepositoryItemCurrencyTextEdit40),
              typeof(TextEditViewInfo), new TextEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemCurrencyTextEdit40 source = item as RepositoryItemCurrencyTextEdit40;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Constructors
        public RepositoryItemCurrencyTextEdit40()
        {
        }
        #endregion

        #region Properties

        private bool mIsLocked = false;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                TRepositoryItemTextEditUtil.SetLocked(this, value);
                mIsLocked = value;
            }
        }

        private DSFormMode mDSFormMode = DSFormMode.DSEditable;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                TRepositoryItemTextEditUtil.SetDSFormMode(this, value);
                mDSFormMode = value;
            }
        }
        #endregion

        #region Functions
        public void Init()
        {
            Appearance.Options.UseTextOptions = true;
            Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            AppearanceReadOnly.Options.UseBackColor = false;
            AppearanceReadOnly.Options.UseTextOptions = true;
            AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            MaxLength = 255;
            DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            DisplayFormat.FormatString = TSettings.CurFormat;
            EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            EditFormat.FormatString = TSettings.CurFormat;
            Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            Mask.EditMask = TSettings.CurFormat;
        }
        #endregion
    }

    public class TCurrencyTextEdit40 : TextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TCurrencyTextEdit40() { RepositoryItemCurrencyTextEdit40.RegisterCurrencyTextEdit40(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemCurrencyTextEdit40.CurrencyTextEdit40Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemCurrencyTextEdit40 Properties
        {
            get { return base.Properties as RepositoryItemCurrencyTextEdit40; }
        }
        #endregion

        #region Constructors
        public TCurrencyTextEdit40()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(50, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        //TODO: To be removed later
        [Bindable(true),
        Category("Behavior"),
        DefaultValue("n2"),
        Description("Indicates the numeric format."),
        Localizable(true)]
        private string mFormat = TSettings.CurFormat;
        public string Format
        {
            get
            {
                return mFormat;
            }
            set
            {
                mFormat = value;
            }
        }
        #endregion

        #region Event Handlers
        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);
            TTextEditUtil.Highlight(this);
        }
        protected override void OnEditValueChanged()
        {
            base.OnEditValueChanged();
            if (Utilities.TGC.IsRunTime)
            {
                TTextEditUtil.UpdateForeColor(this);
            }
        }
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}