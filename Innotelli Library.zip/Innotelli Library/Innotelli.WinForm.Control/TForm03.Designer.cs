namespace Innotelli.WinForm.Control
{
    partial class TForm03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TForm03));
            this.btnOK = new DevExpress.XtraEditors.SimpleButton();
            this.lyc01Base = new Innotelli.WinForm.Control.TLayoutControl01();
            this.btnCancel = new DevExpress.XtraEditors.SimpleButton();
            this.btnDeselectAll = new DevExpress.XtraEditors.SimpleButton();
            this.btnSelectAll = new DevExpress.XtraEditors.SimpleButton();
            this.lcg01Base = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.lcg01Base2 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.layoutControlGroup013 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.emptySpaceItem2 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.lci01SelectAll = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.lci01DeselectAll = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.lci01OK = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.lci01Cancel = new Innotelli.WinForm.Control.LayoutControlItem01();
            ((System.ComponentModel.ISupportInitialize)(this.lyc01Base)).BeginInit();
            this.lyc01Base.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup013)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01SelectAll)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01DeselectAll)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01OK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Cancel)).BeginInit();
            this.SuspendLayout();
            // 
            // btnOK
            // 
            resources.ApplyResources(this.btnOK, "btnOK");
            this.btnOK.Name = "btnOK";
            this.btnOK.StyleController = this.lyc01Base;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // lyc01Base
            // 
            this.lyc01Base.Appearance.DisabledLayoutGroupCaption.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lyc01Base.Appearance.DisabledLayoutGroupCaption.Options.UseForeColor = true;
            this.lyc01Base.Appearance.DisabledLayoutItem.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lyc01Base.Appearance.DisabledLayoutItem.Options.UseForeColor = true;
            this.lyc01Base.Controls.Add(this.btnCancel);
            this.lyc01Base.Controls.Add(this.btnOK);
            this.lyc01Base.Controls.Add(this.btnDeselectAll);
            this.lyc01Base.Controls.Add(this.btnSelectAll);
            resources.ApplyResources(this.lyc01Base, "lyc01Base");
            this.lyc01Base.Name = "lyc01Base";
            this.lyc01Base.OptionsItemText.TextAlignMode = DevExpress.XtraLayout.TextAlignMode.AlignInGroups;
            this.lyc01Base.OptionsView.EnableIndentsInGroupsWithoutBorders = true;
            this.lyc01Base.Root = this.lcg01Base;
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            resources.ApplyResources(this.btnCancel, "btnCancel");
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.StyleController = this.lyc01Base;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnDeselectAll
            // 
            resources.ApplyResources(this.btnDeselectAll, "btnDeselectAll");
            this.btnDeselectAll.Name = "btnDeselectAll";
            this.btnDeselectAll.StyleController = this.lyc01Base;
            this.btnDeselectAll.Click += new System.EventHandler(this.btnDeselectAll_Click);
            // 
            // btnSelectAll
            // 
            resources.ApplyResources(this.btnSelectAll, "btnSelectAll");
            this.btnSelectAll.Name = "btnSelectAll";
            this.btnSelectAll.StyleController = this.lyc01Base;
            this.btnSelectAll.Click += new System.EventHandler(this.btnSelectAll_Click);
            // 
            // lcg01Base
            // 
            resources.ApplyResources(this.lcg01Base, "lcg01Base");
            this.lcg01Base.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lcg01Base2,
            this.layoutControlGroup013});
            this.lcg01Base.Location = new System.Drawing.Point(0, 0);
            this.lcg01Base.Name = "lcg01Base";
            this.lcg01Base.OptionsItemText.TextToControlDistance = 2;
            this.lcg01Base.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base.Size = new System.Drawing.Size(628, 392);
            this.lcg01Base.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.lcg01Base.TextVisible = false;
            // 
            // lcg01Base2
            // 
            resources.ApplyResources(this.lcg01Base2, "lcg01Base2");
            this.lcg01Base2.Location = new System.Drawing.Point(0, 0);
            this.lcg01Base2.Name = "lcg01Base2";
            this.lcg01Base2.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base2.Size = new System.Drawing.Size(624, 356);
            this.lcg01Base2.Spacing = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base2.TextVisible = false;
            // 
            // layoutControlGroup013
            // 
            resources.ApplyResources(this.layoutControlGroup013, "layoutControlGroup013");
            this.layoutControlGroup013.GroupBordersVisible = false;
            this.layoutControlGroup013.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.emptySpaceItem1,
            this.emptySpaceItem2,
            this.lci01SelectAll,
            this.lci01DeselectAll,
            this.lci01OK,
            this.lci01Cancel});
            this.layoutControlGroup013.Location = new System.Drawing.Point(0, 356);
            this.layoutControlGroup013.Name = "layoutControlGroup013";
            this.layoutControlGroup013.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup013.Size = new System.Drawing.Size(624, 32);
            this.layoutControlGroup013.Spacing = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup013.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            resources.ApplyResources(this.emptySpaceItem1, "emptySpaceItem1");
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 0);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(272, 28);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // emptySpaceItem2
            // 
            resources.ApplyResources(this.emptySpaceItem2, "emptySpaceItem2");
            this.emptySpaceItem2.Location = new System.Drawing.Point(436, 0);
            this.emptySpaceItem2.MaxSize = new System.Drawing.Size(20, 0);
            this.emptySpaceItem2.MinSize = new System.Drawing.Size(20, 10);
            this.emptySpaceItem2.Name = "emptySpaceItem2";
            this.emptySpaceItem2.Size = new System.Drawing.Size(20, 28);
            this.emptySpaceItem2.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.emptySpaceItem2.TextSize = new System.Drawing.Size(0, 0);
            // 
            // lci01SelectAll
            // 
            this.lci01SelectAll.Control = this.btnSelectAll;
            resources.ApplyResources(this.lci01SelectAll, "lci01SelectAll");
            this.lci01SelectAll.Location = new System.Drawing.Point(272, 0);
            this.lci01SelectAll.MaxSize = new System.Drawing.Size(82, 28);
            this.lci01SelectAll.MinSize = new System.Drawing.Size(82, 28);
            this.lci01SelectAll.Name = "lci01SelectAll";
            this.lci01SelectAll.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01SelectAll.Size = new System.Drawing.Size(82, 28);
            this.lci01SelectAll.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lci01SelectAll.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.lci01SelectAll.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01SelectAll.TextSize = new System.Drawing.Size(0, 0);
            this.lci01SelectAll.TextToControlDistance = 0;
            this.lci01SelectAll.TextVisible = false;
            // 
            // lci01DeselectAll
            // 
            this.lci01DeselectAll.Control = this.btnDeselectAll;
            resources.ApplyResources(this.lci01DeselectAll, "lci01DeselectAll");
            this.lci01DeselectAll.Location = new System.Drawing.Point(354, 0);
            this.lci01DeselectAll.MaxSize = new System.Drawing.Size(82, 28);
            this.lci01DeselectAll.MinSize = new System.Drawing.Size(82, 28);
            this.lci01DeselectAll.Name = "lci01DeselectAll";
            this.lci01DeselectAll.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01DeselectAll.Size = new System.Drawing.Size(82, 28);
            this.lci01DeselectAll.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lci01DeselectAll.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.lci01DeselectAll.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01DeselectAll.TextSize = new System.Drawing.Size(0, 0);
            this.lci01DeselectAll.TextToControlDistance = 0;
            this.lci01DeselectAll.TextVisible = false;
            // 
            // lci01OK
            // 
            this.lci01OK.Control = this.btnOK;
            resources.ApplyResources(this.lci01OK, "lci01OK");
            this.lci01OK.Location = new System.Drawing.Point(456, 0);
            this.lci01OK.MaxSize = new System.Drawing.Size(82, 28);
            this.lci01OK.MinSize = new System.Drawing.Size(82, 28);
            this.lci01OK.Name = "lci01OK";
            this.lci01OK.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01OK.Size = new System.Drawing.Size(82, 28);
            this.lci01OK.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lci01OK.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.lci01OK.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01OK.TextSize = new System.Drawing.Size(0, 0);
            this.lci01OK.TextToControlDistance = 0;
            this.lci01OK.TextVisible = false;
            // 
            // lci01Cancel
            // 
            this.lci01Cancel.Control = this.btnCancel;
            resources.ApplyResources(this.lci01Cancel, "lci01Cancel");
            this.lci01Cancel.Location = new System.Drawing.Point(538, 0);
            this.lci01Cancel.MaxSize = new System.Drawing.Size(82, 28);
            this.lci01Cancel.MinSize = new System.Drawing.Size(82, 28);
            this.lci01Cancel.Name = "lci01Cancel";
            this.lci01Cancel.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01Cancel.Size = new System.Drawing.Size(82, 28);
            this.lci01Cancel.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lci01Cancel.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.lci01Cancel.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01Cancel.TextSize = new System.Drawing.Size(0, 0);
            this.lci01Cancel.TextToControlDistance = 0;
            this.lci01Cancel.TextVisible = false;
            // 
            // TForm03
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lyc01Base);
            this.KeyPreview = true;
            this.Name = "TForm03";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TForm03_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.lyc01Base)).EndInit();
            this.lyc01Base.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup013)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01SelectAll)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01DeselectAll)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01OK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01Cancel)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        protected TLayoutControl01 lyc01Base;
        protected LayoutControlGroup01 lcg01Base;
        protected LayoutControlGroup01 lcg01Base2;
        private LayoutControlGroup01 layoutControlGroup013;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem2;
        private DevExpress.XtraEditors.SimpleButton btnCancel;
        private DevExpress.XtraEditors.SimpleButton btnOK;
        private DevExpress.XtraEditors.SimpleButton btnDeselectAll;
        private DevExpress.XtraEditors.SimpleButton btnSelectAll;
        private LayoutControlItem01 lci01SelectAll;
        private LayoutControlItem01 lci01DeselectAll;
        private LayoutControlItem01 lci01OK;
        private LayoutControlItem01 lci01Cancel;
    }
}