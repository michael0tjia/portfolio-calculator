using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Innotelli.WinForm.Control
{
    [System.Drawing.ToolboxBitmap(typeof(System.Windows.Forms.Button)), DefaultProperty("")]
    public partial class TButton01 : System.Windows.Forms.Button
    {
        #region Enums

        #endregion

        #region Members
        #endregion

        #region Constructors
        public TButton01()
        {
            InitializeComponent();
        }
        #endregion

        #region Properties
        public bool SetReadOnly
        {
            set
            {
                this.Enabled = !value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions

        #endregion
    }
}
