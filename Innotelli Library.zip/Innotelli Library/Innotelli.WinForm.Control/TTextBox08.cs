using System;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.ViewInfo;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterTextBox08")]
    public class RepositoryItemTextBox08 : RepositoryItemButtonEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemTextBox08() { RegisterTextBox08(); }

        //The unique name for the custom editor
        public const string TextBox08Name = "TTextBox08";

        //Return the unique name
        public override string EditorTypeName { get { return TextBox08Name; } }

        //Register the editor
        public static void RegisterTextBox08()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.TextBox08.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(TextBox08Name,
              typeof(TTextBox08), typeof(RepositoryItemTextBox08),
              typeof(ButtonEditViewInfo), new ButtonEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemTextBox08 source = item as RepositoryItemTextBox08;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public RepositoryItemTextBox08()
        {
        }
        #endregion

        #region Properties
        private string mBOID = "";
        public string BOID
        {
            get
            {
                return mBOID;
            }
            set
            {
                mBOID = value;
                OnPropertiesChanged();
            }
        }
        
        private bool mIsLocked = false;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                ReadOnly = value;
                if (value)
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                }
                else
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
                }
                if (OwnerEdit != null)
                {
                    OwnerEdit.TabStop = !value;
                }
                mIsLocked = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        DSFormMode mDSFormMode = DSFormMode.DSEditable;
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        ReadOnly = true;
                        break;
                    case DSFormMode.DSEditable:
                        ReadOnly = false;
                        break;
                    case DSFormMode.DSInsert:
                        ReadOnly = false;
                        break;
                }
                mDSFormMode = value;
            }
        }
        #endregion

        #region Event Handlers
        private void RepositoryItemTextBox08_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            TTextBox08 lTextBox08 = (sender as TTextBox08);
            TForm02 lForm02 = null;
            string lBOSKFldNm = "";
            string lPK = "";
            string lSKVal = "";
            string lTblNm = "";

            if (!TNull.IsValueNull(lTextBox08.EditValue))
            {
                lSKVal = lTextBox08.EditValue.ToString();
                if (lSKVal != "")
                {
                    lBOSKFldNm = Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].SPrpsBOT01Flds.SKeyFieldName;
                    lTblNm = mBOID.Substring(4);
                    TDomain.LookupPK(lTblNm, lBOSKFldNm + " = '" + lSKVal + "'", out lPK);
                    lForm02 = TSingletons.Form02Pool.GetForm(Innotelli.BO.TSingletons.SPrpsBOT01s[BOID].DefaultForm02Name);
                    lForm02.LoadByPK(lPK);
                    lForm02.DsMode = DSFormMode.DSBrowse;
                    lForm02.DSUpdateFormState();
                    lForm02.Visible = true;
                }
            }
        }
        #endregion

        #region Functions
        public void Init()
        {
            Image img = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TTextBox08.Button.png"));
            AppearanceReadOnly.Options.UseBackColor = false;
            Buttons[0].Kind = DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph;
            Buttons[0].Image = img;
            Buttons[0].Width = 10;
            //BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            AssignEventHandlers();
        }        
        private void AssignEventHandlers()
        {
            ButtonClick += RepositoryItemTextBox08_ButtonClick;
        }
        #endregion
    }

    public class TTextBox08 : ButtonEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TTextBox08() { RepositoryItemTextBox08.RegisterTextBox08(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemTextBox08.TextBox08Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemTextBox08 Properties
        {
            get { return base.Properties as RepositoryItemTextBox08; }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TTextBox08()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(15 + 20, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}
