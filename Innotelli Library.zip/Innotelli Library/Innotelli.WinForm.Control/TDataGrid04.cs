using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Registrator;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Base.Handler;
using DevExpress.XtraGrid.Views.Base.ViewInfo;
using DevExpress.XtraGrid.Views.Grid.Handler;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using DevExpress.XtraGrid.Views.BandedGrid;
using DevExpress.XtraGrid.Views.BandedGrid.ViewInfo;
using DevExpress.XtraGrid.Views.BandedGrid.Handler;
using DevExpress.Utils.Serializing;
using Innotelli.BO;
using Innotelli.Utilities;
using System.Reflection;
using Innotelli.Db;

namespace Innotelli.WinForm.Control
{
    #region Grid Class
    public class TDataGrid04 : GridControl
    {
        #region Members
        private bool mHasOpnDtlCol = false;
        private bool mIsLocked = false;
        private ColumnView mGv = null;
        private DataSet mDs = null;
        private DSFormMode mDSFormMode = DSFormMode.DSEditable;
        private string mType = "";
        private TBOT06 mBOT06 = null;
        private TSysDataRdr mSysDataRdr = Innotelli.Utilities.TSingletons.SysData01Rdr;
        private TGridView04 mGridView04 = null;
        private TBandedGridView04 mBandedGridView04 = null;
        private TAdvBandedGridView04 mAdvBandedGridView04 = null;
        #endregion

        #region Constructors
        public TDataGrid04()
        {
        }
        #endregion

        #region Properties
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TBOT06 BOT06
        {
            get
            {
                return mBOT06;
            }
            set
            {
                mBOT06 = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                this.Enabled = !value;
                this.TabStop = !value;
                mIsLocked = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                mDSFormMode = value;
                //SetAllColumnsReadOnlyVal();
            }
        }
        public bool HasOpnDtlCol
        {
            get
            {
                return mHasOpnDtlCol;
            }
            set
            {
                mHasOpnDtlCol = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions

        #region DevExpress Required Part
        protected override BaseView CreateDefaultView()
        {
            return CreateView("TGridView04");
        }
        protected override void RegisterAvailableViewsCore(InfoCollection collection)
        {
            base.RegisterAvailableViewsCore(collection);
            collection.Add(new TGridViewInfoRegistrator04());
            collection.Add(new TBandedGridViewInfoRegistrator04());
            collection.Add(new TAdvBandedGridViewInfoRegistrator04());
        }
        #endregion

        public void BindData()
        {
            if (mBOT06 != null)
            {
                DataSource = mBOT06.Dt;
            }
        }
        public void Init()
        {
            if (Utilities.TGC.IsRunTime)
            {
                mDs = mSysDataRdr.GetSysData("BOT06Fld");
                if (mDs != null)
                {
                    mGv = (ColumnView)MainView;
                    mGv.OptionsSelection.MultiSelect = true;
                    mType = MainView.GetType().Name;

                    switch (mType)
                    {
                        case "TGridView04":
                            mGridView04 = (TGridView04)MainView;
                            mGridView04.Init();
                            break;
                        case "TBandedGridView04":
                            mBandedGridView04 = (TBandedGridView04)MainView;
                            mBandedGridView04.Init();
                            break;
                        case "TAdvBandedGridView04":
                            mAdvBandedGridView04 = (TAdvBandedGridView04)MainView;
                            mAdvBandedGridView04.Init();
                            break;
                    }
                    SetAllColumnsReadOnlyVal();
                    SetColumnFormat();
                    AssignInPlaceEditors();
                }
            }
            //LoadLayout();


        }

        private void SetAllColumnsReadOnlyVal()
        {
            string lFldNm = string.Empty;

            for (int i = 0; i < mGv.Columns.Count; i++)
            {
                lFldNm = mGv.Columns[i].FieldName;
                // The else case should be not done.
                //TODO: DataGrid ReadOnly
                try
                {
                    if (mBOT06.SPrps.SPrpsBOT06Flds[lFldNm].IsReadOnly)
                    {
                        mGv.Columns[i].OptionsColumn.ReadOnly = true;
                    }
                    if (mGv.Columns[i].OptionsColumn.ReadOnly)
                    {
                        mGv.Columns[i].AppearanceCell.BackColor = Color.FromArgb(255, 255, 192);
                    }
                }
                catch
                {
                }
            }
        }
        private void SetColumnFormat()
        {
            int lColumnCount = mGv.Columns.Count;
            string lFldNm = string.Empty;

            for (int i = 0; i < lColumnCount; i++)
            {
                lFldNm = mGv.Columns[i].FieldName.ToString();

                //TODO: Temp Fields
                try
                {
                    switch (mBOT06.SPrps.SPrpsBOT06Flds[lFldNm].SimpleDataTypeCat1)
                    {
                        case SimpleDataTypeCat1s.Integer:
                        case SimpleDataTypeCat1s.PreciseReal:
                        case SimpleDataTypeCat1s.UnpreciseReal:
                            #region Numeric Columns

                            #region Negative Value Color Setting
                            StyleFormatCondition lStyleFormatCondition = new StyleFormatCondition();
                            lStyleFormatCondition.Appearance.ForeColor = Color.Red;
                            lStyleFormatCondition.Appearance.Options.UseForeColor = true;
                            lStyleFormatCondition.Appearance.Options.HighPriority = true;
                            //lStyleFormatCondition.ApplyToRow = false;
                            lStyleFormatCondition.Column = mGv.Columns[i];
                            lStyleFormatCondition.Condition = FormatConditionEnum.Less;
                            lStyleFormatCondition.Value1 = 0;
                            MainView.FormatConditions.Add(lStyleFormatCondition);
                            #endregion

                            mGv.Columns[i].AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
                            mGv.Columns[i].DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
                            switch (mBOT06.SPrps.SPrpsBOT06Flds[lFldNm].SimpleDataType)
                            {
                                case SimpleDataType.Currency:
                                    mGv.Columns[i].DisplayFormat.FormatString = TSettings.CurFormat;
                                    mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = TSettings.CurFormat;
                                    if (mGv.Columns[i].SummaryItem.DisplayFormat == "")
                                    {
                                        mGv.Columns[i].SummaryItem.DisplayFormat = "{0:" + TSettings.CurFormat + "}";
                                    }
                                    break;
                                case SimpleDataType.Decimal:
                                case SimpleDataType.Double:
                                case SimpleDataType.Single:
                                    mGv.Columns[i].DisplayFormat.FormatString = TSettings.DecFormat;
                                    mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = TSettings.DecFormat;
                                    if (mGv.Columns[i].SummaryItem.DisplayFormat == "")
                                    {
                                        mGv.Columns[i].SummaryItem.DisplayFormat = "{0:" + TSettings.DecFormat + "}";
                                    }
                                    break;
                                case SimpleDataType.Byte:
                                case SimpleDataType.Short:
                                case SimpleDataType.Int:
                                case SimpleDataType.Long:
                                    mGv.Columns[i].DisplayFormat.FormatString = TSettings.IntFormat;
                                    mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = TSettings.IntFormat;
                                    if (mGv.Columns[i].SummaryItem.DisplayFormat == "")
                                    {
                                        mGv.Columns[i].SummaryItem.DisplayFormat = "{0:" + TSettings.IntFormat + "}";
                                    }
                                    break;
                                default:
                                    break;
                            }
                            #endregion
                            break;
                        case SimpleDataTypeCat1s.DateTime:
                            #region DateTime Columns
                            mGv.Columns[i].DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
                            switch (mBOT06.SPrps.SPrpsBOT06Flds[lFldNm].SimpleDataType)
                            {
                                case SimpleDataType.Date:
                                    mGv.Columns[i].DisplayFormat.FormatString = TSettings.DateFormat;
                                    mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = TSettings.DateFormat;
                                    if (mGv.Columns[i].SummaryItem.DisplayFormat == "")
                                    {
                                        mGv.Columns[i].SummaryItem.DisplayFormat = "{0:" + TSettings.DateFormat + "}";
                                    }
                                    break;
                                case SimpleDataType.Time:
                                    mGv.Columns[i].DisplayFormat.FormatString = TSettings.TimeFormat;
                                    mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = TSettings.TimeFormat;
                                    if (mGv.Columns[i].SummaryItem.DisplayFormat == "")
                                    {
                                        mGv.Columns[i].SummaryItem.DisplayFormat = "{0:" + TSettings.TimeFormat + "}";
                                    }
                                    break;
                                default:
                                    mGv.Columns[i].DisplayFormat.FormatString = TSettings.DateFormat + " " + TSettings.TimeFormat;
                                    mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = TSettings.DateFormat + " " + TSettings.TimeFormat;
                                    if (mGv.Columns[i].SummaryItem.DisplayFormat == "")
                                    {
                                        mGv.Columns[i].SummaryItem.DisplayFormat = "{0:" + TSettings.DateFormat + " " + TSettings.TimeFormat + "}";
                                    }
                                    break;
                            }
                            #endregion
                            break;
                    }
                }
                catch
                {
                }
            }
        }
        private void AssignInPlaceEditors()
        {
            int lIndexOfSemiColon = -1;
            int lValLstBndCol = 1;
            string lControlName = string.Empty;
            string lFieldName = string.Empty;
            string lTag = string.Empty;
            Assembly lAssembly = Assembly.GetExecutingAssembly();

            for (int i = 0; i < mGv.Columns.Count; i++)
            {
                //TODO: Temp
                try
                {
                    if (mGv.Columns[i].Tag != null)
                    {
                        #region By Tag Specified
                        lTag = mGv.Columns[i].Tag.ToString();
                        lIndexOfSemiColon = lTag.IndexOf(";");
                        if (lIndexOfSemiColon == -1)
                        {
                            lControlName = lTag;
                        }
                        else
                        {
                            lControlName = TStr.Left(lTag, lIndexOfSemiColon);
                        }
                        switch (lControlName)
                        {
                            case "TTextBox08":
                                RepositoryItemTextBox08 lRepositoryItemTextBox08 = new RepositoryItemTextBox08();
                                lRepositoryItemTextBox08.Init();
                                lRepositoryItemTextBox08.BOID = lTag.Substring(lIndexOfSemiColon + 1);
                                RepositoryItems.Add(lRepositoryItemTextBox08);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemTextBox08;
                                mGv.Columns[i].ShowButtonMode = ShowButtonModeEnum.ShowAlways;
                                break;
                            case "TMemoBoxEx01":
                                RepositoryItemMemoBoxEx01 lRepositoryItemMemoBoxEx01 = new RepositoryItemMemoBoxEx01();
                                lRepositoryItemMemoBoxEx01.Init();
                                lRepositoryItemMemoBoxEx01.Buttons[0].Visible = false;
                                RepositoryItems.Add(lRepositoryItemMemoBoxEx01);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemMemoBoxEx01;
                                break;
                            default:
                                break;
                        }
                        #endregion
                    }
                    else
                    {
                        lFieldName = mGv.Columns[i].FieldName;
                        if (mBOT06.SPrps.SPrpsBOT06Flds[lFieldName].SelObjID != string.Empty)
                        {
                            #region LookUpCombo
                            if (mGv.Columns[i].ReadOnly)
                            {
                                RepositoryItemLookupTextBox01 lRepositoryItemLookupTextBox01 = new RepositoryItemLookupTextBox01();
                                lRepositoryItemLookupTextBox01.BndCol = 0;
                                lRepositoryItemLookupTextBox01.BOID = mBOT06.SPrps.SPrpsBOT06Flds[lFieldName].SelObjID;
                                lRepositoryItemLookupTextBox01.Init();
                                lRepositoryItemLookupTextBox01.BindList();
                                RepositoryItems.Add(lRepositoryItemLookupTextBox01);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemLookupTextBox01;
                            }
                            else
                            {
                                RepositoryItemLookupCombo02 lRepositoryItemLookupCombo02 = new RepositoryItemLookupCombo02();
                                lRepositoryItemLookupCombo02.BndCol = 0;
                                lRepositoryItemLookupCombo02.BOID = mBOT06.SPrps.SPrpsBOT06Flds[lFieldName].SelObjID;
                                lRepositoryItemLookupCombo02.Init();
                                lRepositoryItemLookupCombo02.BindList();
                                RepositoryItems.Add(lRepositoryItemLookupCombo02);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemLookupCombo02;
                                mGv.Columns[i].ShowButtonMode = ShowButtonModeEnum.ShowAlways;
                            }
                            #endregion
                        }
                        else
                        {
                            #region By Data Type
                            switch (mBOT06.SPrps.SPrpsBOT06Flds[lFieldName].SimpleDataType)
                            {
                                case SimpleDataType.Date:
                                    if (mGv.Columns[i].ReadOnly)
                                    {
                                        RepositoryItemDateTextBox02 lRepositoryItemDateTextBox02 = new RepositoryItemDateTextBox02();
                                        lRepositoryItemDateTextBox02.Init();
                                        RepositoryItems.Add(lRepositoryItemDateTextBox02);
                                        mGv.Columns[i].ColumnEdit = lRepositoryItemDateTextBox02;
                                    }
                                    else
                                    {
                                        RepositoryItemDateEditor02 lRepositoryItemDateEditor02 = new RepositoryItemDateEditor02();
                                        lRepositoryItemDateEditor02.Init();
                                        lRepositoryItemDateEditor02.CreateDefaultButton();
                                        RepositoryItems.Add(lRepositoryItemDateEditor02);
                                        mGv.Columns[i].ColumnEdit = lRepositoryItemDateEditor02;
                                    }
                                    break;
                                case SimpleDataType.Time:
                                    if (mGv.Columns[i].ReadOnly)
                                    {
                                        RepositoryItemTimeTextBox02 lRepositoryItemTimeTextBox02 = new RepositoryItemTimeTextBox02();
                                        lRepositoryItemTimeTextBox02.Init();
                                        RepositoryItems.Add(lRepositoryItemTimeTextBox02);
                                        mGv.Columns[i].ColumnEdit = lRepositoryItemTimeTextBox02;
                                    }
                                    else
                                    {
                                        RepositoryItemTimeEditor02 lRepositoryItemTimeEditor02 = new RepositoryItemTimeEditor02();
                                        lRepositoryItemTimeEditor02.CreateDefaultButton();
                                        lRepositoryItemTimeEditor02.Init();
                                        RepositoryItems.Add(lRepositoryItemTimeEditor02);
                                        mGv.Columns[i].ColumnEdit = lRepositoryItemTimeEditor02;
                                    }
                                    break;
                                case SimpleDataType.ValueList:
                                    if (mGv.Columns[i].ReadOnly)
                                    {
                                        RepositoryItemValueListTextBox01 lRepositoryItemValueListTextBox01 = new RepositoryItemValueListTextBox01();
                                        lRepositoryItemValueListTextBox01.BndCol = lValLstBndCol - 1;
                                        lRepositoryItemValueListTextBox01.Init(BOT06.BOID);
                                        lRepositoryItemValueListTextBox01.BindList(lFieldName);
                                        RepositoryItems.Add(lRepositoryItemValueListTextBox01);
                                        mGv.Columns[i].ColumnEdit = lRepositoryItemValueListTextBox01;
                                    }
                                    else
                                    {
                                        RepositoryItemValueListCombo02 lRepositoryItemValueListCombo02 = new RepositoryItemValueListCombo02();
                                        lRepositoryItemValueListCombo02.BndCol = lValLstBndCol - 1;
                                        lRepositoryItemValueListCombo02.Init(BOT06.BOID);
                                        lRepositoryItemValueListCombo02.BindList(lFieldName);
                                        RepositoryItems.Add(lRepositoryItemValueListCombo02);
                                        mGv.Columns[i].ColumnEdit = lRepositoryItemValueListCombo02;
                                        mGv.Columns[i].ShowButtonMode = ShowButtonModeEnum.ShowAlways;

                                    }
                                    break;
                                case SimpleDataType.Bool:
                                    RepositoryItemCheckBox03 lRepositoryItemCheckBox03 = new RepositoryItemCheckBox03();
                                    lRepositoryItemCheckBox03.Init();
                                    RepositoryItems.Add(lRepositoryItemCheckBox03);
                                    mGv.Columns[i].ColumnEdit = lRepositoryItemCheckBox03;
                                    break;
                                case SimpleDataType.Currency:
                                    RepositoryItemCurrencyTextBox03 lRepositoryItemCurrencyTextBox03 = new RepositoryItemCurrencyTextBox03();
                                    lRepositoryItemCurrencyTextBox03.Init();
                                    RepositoryItems.Add(lRepositoryItemCurrencyTextBox03);
                                    mGv.Columns[i].ColumnEdit = lRepositoryItemCurrencyTextBox03;
                                    break;
                                case SimpleDataType.Decimal:
                                case SimpleDataType.Double:
                                case SimpleDataType.Single:
                                    RepositoryItemDecimalTextBox03 lRepositoryItemDecimalTextBox03 = new RepositoryItemDecimalTextBox03();
                                    lRepositoryItemDecimalTextBox03.Init();
                                    RepositoryItems.Add(lRepositoryItemDecimalTextBox03);
                                    mGv.Columns[i].ColumnEdit = lRepositoryItemDecimalTextBox03;
                                    break;
                                case SimpleDataType.Byte:
                                case SimpleDataType.Short:
                                case SimpleDataType.Int:
                                case SimpleDataType.Long:
                                    RepositoryItemIntegerTextBox03 lRepositoryItemIntegerTextBox03 = new RepositoryItemIntegerTextBox03();
                                    lRepositoryItemIntegerTextBox03.Init();
                                    RepositoryItems.Add(lRepositoryItemIntegerTextBox03);
                                    mGv.Columns[i].ColumnEdit = lRepositoryItemIntegerTextBox03;
                                    break;
                                case SimpleDataType.NText:
                                    RepositoryItemMemoBoxEx01 lRepositoryItemMemoBoxEx01 = new RepositoryItemMemoBoxEx01();
                                    lRepositoryItemMemoBoxEx01.Init();
                                    lRepositoryItemMemoBoxEx01.Buttons[0].Visible = false;
                                    RepositoryItems.Add(lRepositoryItemMemoBoxEx01);
                                    mGv.Columns[i].ColumnEdit = lRepositoryItemMemoBoxEx01;
                                    break;
                                case SimpleDataType.NVarChar:
                                    //RepositoryItemTextBox04 lRepositoryItemTextBox04 = new RepositoryItemTextBox04();
                                    //lRepositoryItemTextBox04.Init(mBOT06);
                                    //RepositoryItems.Add(lRepositoryItemTextBox04);
                                    //mGv.Columns[i].ColumnEdit = lRepositoryItemTextBox04;
                                    break;
                                default:
                                    break;
                            }
                            #endregion
                        }

                        if (mGv.Columns[i].ColumnEdit != null)
                        {
                            mGv.Columns[i].ColumnEdit.ReadOnly = mGv.Columns[i].ReadOnly;
                        }
                    }
                }
                catch
                {
                }
            }
        }

        private void SaveLayout()
        {
            //TGrdLyt02 lGrdLyt02 = null;

            //lGrdLyt02 = new TGrdLyt02();
            //lGrdLyt02.UserPK = "1";
            //lGrdLyt02.SaveLayout(this, true);
        }
        private void LoadLayout()
        {
            //TGrdLyt02 lGrdLyt02 = null;

            //lGrdLyt02 = new TGrdLyt02();
            //lGrdLyt02.UserPK = "1";
            //lGrdLyt02.LoadLayout(this, true);            
        }
        #endregion
    }
    #endregion

    #region GridView Classes
    public class TGridViewInfoRegistrator04 : GridInfoRegistrator
    {
        #region DevExpress Required Part
        public override string ViewName { get { return "TGridView04"; } }
        public override BaseView CreateView(GridControl grid) { return new TGridView04(grid as GridControl); }
        public override BaseViewInfo CreateViewInfo(BaseView view) { return new TGridViewInfo04(view as TGridView04); }
        public override BaseViewHandler CreateHandler(BaseView view) { return new TGridHandler04(view as TGridView04); }
        #endregion
    }
    public class TGridView04 : GridView
    {
        #region Members
        #endregion

        #region Constructors

        #region DevExpress Required Part
        public TGridView04() : this(null) { }
        public TGridView04(DevExpress.XtraGrid.GridControl grid)
            : base(grid)
        {
            //Init();
        }
        #endregion

        #endregion

        #region Properties

        #region DevExpress Required Part
        protected override string ViewName { get { return "TGridView04"; } }
        #endregion

        #endregion

        #region Event Handlers
        private void TGridView04_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            TBOT06 lBOT06 = null;

            lBOT06 = ((TDataGrid04)GridControl).BOT06;
            if (lBOT06 != null)
            {
                if (e.FocusedRowHandle != GridControl.NewItemRowHandle && e.FocusedRowHandle != GridControl.InvalidRowHandle)
                {
                    lBOT06.SetCurrentRow(GetDataRow(e.FocusedRowHandle));
                }
                else
                {
                    lBOT06.CurrentRowIndex = TDataObject.EOFRowIndex;
                }
            }
        }
        #endregion

        #region Functions
        public void Init()
        {
            FixedLineWidth = 1;
            Appearance.FocusedRow.BackColor = Color.FromArgb(60, 128, 128, 240);
            Appearance.FocusedRow.Options.UseBackColor = true;
            Appearance.SelectedRow.BackColor = Color.FromArgb(30, 128, 128, 240);
            Appearance.SelectedRow.Options.UseBackColor = true;
            OptionsView.NewItemRowPosition = NewItemRowPosition.Bottom;
            OptionsView.ColumnAutoWidth = false;
            OptionsView.ShowGroupPanel = false;
            OptionsCustomization.AllowGroup = false;
            OptionsMenu.EnableFooterMenu = false;
            AssignEventHandlers();
        }        
        private void AssignEventHandlers()
        {
            FocusedRowChanged += new FocusedRowChangedEventHandler(TGridView04_FocusedRowChanged);
        }
        #endregion
    }
    public class TGridViewInfo04 : GridViewInfo
    {
        #region DevExpress Required Part
        public TGridViewInfo04(GridView gridView) : base(gridView) { }
        #endregion
    }
    public class TGridHandler04 : GridHandler
    {
        #region DevExpress Required Part
        public TGridHandler04(GridView gridView) : base(gridView) { }
        #endregion
    }
    #endregion

    #region BandedGridView Classes
    public class TBandedGridViewInfoRegistrator04 : BandedGridInfoRegistrator
    {
        #region DevExpress Required Part
        public override string ViewName { get { return "TBandedGridView04"; } }
        public override BaseView CreateView(GridControl grid) { return new TBandedGridView04(grid as GridControl); }
        public override BaseViewInfo CreateViewInfo(BaseView view) { return new TBandedGridViewInfo04(view as TBandedGridView04); }
        public override BaseViewHandler CreateHandler(BaseView view) { return new TBandedGridHandler04(view as TBandedGridView04); }
        #endregion
    }
    public class TBandedGridView04 : BandedGridView
    {
        #region Members
        #endregion

        #region Constructors

        #region DevExpress Required Part
        public TBandedGridView04() : this(null) { }
        public TBandedGridView04(DevExpress.XtraGrid.GridControl grid)
            : base(grid)
        {
            //Init();
        }
        #endregion

        #endregion

        #region Properties

        #region DevExpress Required Part
        protected override string ViewName { get { return "TBandedGridView04"; } }
        #endregion

        #endregion

        #region Event Handlers
        private void TBandedGridView04_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            TBOT06 lBOT06 = null;

            lBOT06 = ((TDataGrid04)GridControl).BOT06;
            if (lBOT06 != null)
            {
                if (e.FocusedRowHandle != GridControl.NewItemRowHandle && e.FocusedRowHandle != GridControl.InvalidRowHandle)
                {
                    lBOT06.SetCurrentRow(GetDataRow(e.FocusedRowHandle));
                }
                else
                {
                    lBOT06.CurrentRowIndex = TDataObject.EOFRowIndex;
                }
            }
        }
        #endregion

        #region Functions
        public void Init()
        {
            FixedLineWidth = 1;
            Appearance.FocusedRow.BackColor = Color.FromArgb(60, 128, 128, 240);
            Appearance.FocusedRow.Options.UseBackColor = true;
            Appearance.SelectedRow.BackColor = Color.FromArgb(30, 128, 128, 240);
            Appearance.SelectedRow.Options.UseBackColor = true;
            OptionsView.NewItemRowPosition = NewItemRowPosition.Bottom;
            OptionsView.ColumnAutoWidth = false;
            OptionsView.ShowGroupPanel = false;
            OptionsCustomization.AllowGroup = false;
            OptionsMenu.EnableFooterMenu = false;
            AssignEventHandlers();
        }
        private void AssignEventHandlers()
        {
            FocusedRowChanged += new FocusedRowChangedEventHandler(TBandedGridView04_FocusedRowChanged);
        }
        #endregion
    }
    public class TBandedGridViewInfo04 : BandedGridViewInfo
    {
        #region DevExpress Required Part
        public TBandedGridViewInfo04(BandedGridView gridView) : base(gridView) { }
        #endregion
    }
    public class TBandedGridHandler04 : BandedGridHandler
    {
        #region DevExpress Required Part
        public TBandedGridHandler04(BandedGridView gridView) : base(gridView) { }
        #endregion
    }
    #endregion

    #region AdvBandedGridView Classes
    public class TAdvBandedGridViewInfoRegistrator04 : AdvBandedGridInfoRegistrator
    {
        #region DevExpress Required Part
        public override string ViewName { get { return "TAdvBandedGridView04"; } }
        public override BaseView CreateView(GridControl grid) { return new TAdvBandedGridView04(grid as GridControl); }
        public override BaseViewInfo CreateViewInfo(BaseView view) { return new TAdvBandedGridViewInfo04(view as TAdvBandedGridView04); }
        public override BaseViewHandler CreateHandler(BaseView view) { return new TAdvBandedGridHandler04(view as TAdvBandedGridView04); }
        #endregion
    }

    public class TAdvBandedGridView04 : AdvBandedGridView
    {
        #region Members
        #endregion

        #region Constructors

        #region DevExpress Required Part
        public TAdvBandedGridView04() : this(null) { }
        public TAdvBandedGridView04(DevExpress.XtraGrid.GridControl grid)
            : base(grid)
        {
            //Init();
        }
        #endregion

        #endregion

        #region Properties

        #region DevExpress Required Part
        protected override string ViewName { get { return "TAdvBandedGridView04"; } }
        #endregion

        #endregion

        #region Event Handlers
        private void TAdvBandedGridView04_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            TBOT06 lBOT06 = null;

            lBOT06 = ((TDataGrid04)GridControl).BOT06;
            if (lBOT06 != null)
            {
                if (e.FocusedRowHandle != GridControl.NewItemRowHandle && e.FocusedRowHandle != GridControl.InvalidRowHandle)
                {
                    lBOT06.SetCurrentRow(GetDataRow(e.FocusedRowHandle));
                }
                else
                {
                    lBOT06.CurrentRowIndex = TDataObject.EOFRowIndex;
                }
            }
        }
        #endregion

        #region Functions
        public void Init()
        {
            FixedLineWidth = 1;
            Appearance.FocusedRow.BackColor = Color.FromArgb(60, 128, 128, 240);
            Appearance.FocusedRow.Options.UseBackColor = true;
            Appearance.SelectedRow.BackColor = Color.FromArgb(30, 128, 128, 240);
            Appearance.SelectedRow.Options.UseBackColor = true;
            OptionsView.NewItemRowPosition = NewItemRowPosition.Bottom;
            OptionsView.ColumnAutoWidth = false;
            OptionsView.ShowGroupPanel = false;
            OptionsCustomization.AllowGroup = false;
            OptionsMenu.EnableFooterMenu = false;
            AssignEventHandlers();
        }
        private void AssignEventHandlers()
        {
            FocusedRowChanged += new FocusedRowChangedEventHandler(TAdvBandedGridView04_FocusedRowChanged);
        }
        #endregion
    }
    public class TAdvBandedGridViewInfo04 : AdvBandedGridViewInfo
    {
        #region DevExpress Required Part
        public TAdvBandedGridViewInfo04(AdvBandedGridView gridView) : base(gridView) { }
        #endregion
    }
    public class TAdvBandedGridHandler04 : AdvBandedGridHandler
    {
        #region DevExpress Required Part
        public TAdvBandedGridHandler04(AdvBandedGridView gridView) : base(gridView) { }
        #endregion
    }
    #endregion
}