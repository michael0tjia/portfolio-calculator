﻿using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using System;
using DevExpress.Utils;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterCurrencyTextEdit41")]
    public class RepositoryItemCurrencyTextEdit41 : RepositoryItemTextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemCurrencyTextEdit41() { RegisterCurrencyTextEdit41(); }

        //The unique name for the custom editor
        public const string CurrencyTextEdit41Name = "TCurrencyTextEdit41";

        //Return the unique name
        public override string EditorTypeName { get { return CurrencyTextEdit41Name; } }

        //Register the editor
        public static void RegisterCurrencyTextEdit41()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            //TODO: Michael help
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.CurrencyTextEdit41.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(CurrencyTextEdit41Name,
              typeof(TCurrencyTextEdit41), typeof(RepositoryItemCurrencyTextEdit41),
              typeof(TextEditViewInfo), new TextEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemCurrencyTextEdit41 source = item as RepositoryItemCurrencyTextEdit41;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Constructors
        //Initialize new properties
        public RepositoryItemCurrencyTextEdit41()
        {
        }
        #endregion

        #region Properties
        private DSFormMode mDSFormMode = DSFormMode.DSEditable;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                TRepositoryItemTextEditUtil.SetDSFormModeReadOnly(this, value);
                mDSFormMode = value;
            }
        }
        #endregion

        #region Functions
        public void Init()
        {
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            Appearance.Options.UseBackColor = true;
            Appearance.Options.UseTextOptions = true;
            Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            AppearanceReadOnly.Options.UseBackColor = true;
            AppearanceReadOnly.Options.UseTextOptions = true;
            AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            MaxLength = 255;
            ReadOnly = true;
            DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            DisplayFormat.FormatString = TSettings.CurFormat;
            EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            EditFormat.FormatString = TSettings.CurFormat;
            Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            Mask.EditMask = TSettings.CurFormat;
        }
        #endregion
    }

    public class TCurrencyTextEdit41 : TextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TCurrencyTextEdit41() { RepositoryItemCurrencyTextEdit41.RegisterCurrencyTextEdit41(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemCurrencyTextEdit41.CurrencyTextEdit41Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemCurrencyTextEdit41 Properties
        {
            get { return base.Properties as RepositoryItemCurrencyTextEdit41; }
        }
        #endregion

        #region Constructors
        //Initialize the new instance
        public TCurrencyTextEdit41()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(50, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        //DefaultValue("###,###,###,##0.00; -###,###,###,##0.00"),
        private string mFormat = TSettings.CurFormat;
        [Bindable(true),
        Category("Behavior"),
        DefaultValue("n2"),
        Description("Indicates the numeric format."),
        Localizable(true)]
        public string Format
        {
            get
            {
                return mFormat;
            }
            set
            {
                mFormat = value;
            }
        }
        #endregion

        #region Event Handlers
        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);
            SelectionStart = 0;
            SelectionLength = 255;
        }
        protected override void OnEditValueChanged()
        {
            base.OnEditValueChanged();
            if (Utilities.TGC.IsRunTime)
            {
                TTextEditUtil.UpdateForeColor(this);
            }
        }
        #endregion

        #region Functions
        private void Init()
        {
            TabStop = false;
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}