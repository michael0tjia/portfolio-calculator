using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Innotelli.WinForm.Control;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    public partial class TForm21 : DevExpress.XtraEditors.XtraForm
    {
        #region Enums
        #endregion

        #region Members
        private TTaskManager mTaskManager = new TTaskManager();
        #endregion

        #region Constructors
        public TForm21()
        {
            InitializeComponent();
        }
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        private void mTaskManager_ReportWorkerProgress(object sender, TReportWorkerProgressEventArgs e)
        {
            pgbThis.Position = e.Progress;
        }
        private void mTaskManager_WorkerCompleted(object sender, TWorkerCompletedEventArgs e)
        {
            pgbThis.Position = 100;
            DialogResult = DialogResult.OK;
        }
        private void TForm21_Load(object sender, EventArgs e)
        {
            TLookUpListLoadTask lTLookUpListLoadTask = new TLookUpListLoadTask();
            mTaskManager.WorkerCompleted += new Innotelli.Utilities.WorkerCompletedEventHandler(this.mTaskManager_WorkerCompleted);
            mTaskManager.ReportWorkerProgress += new Innotelli.Utilities.ReportWorkerProgressEventHandler(this.mTaskManager_ReportWorkerProgress);

            mTaskManager.StartAllocatingWork(this);
            // Enqueue the task.
            mTaskManager.EnqueueTask(lTLookUpListLoadTask);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            mTaskManager.StopAllTasks();
            DialogResult = DialogResult.Cancel;
        }
        #endregion

        #region Functions
        #endregion

    }
}