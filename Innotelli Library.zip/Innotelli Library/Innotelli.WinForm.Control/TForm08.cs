using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Innotelli.WinForm.Control;
using Innotelli.BO;
using System.Reflection;

namespace Innotelli.WinForm.Control
{
    public partial class TForm08 : DevExpress.XtraEditors.XtraForm
    {
        #region Enums

        #endregion

        #region Members
        private TBOT01 mBOT01 = null;
        private TTreeList01 mTreeList01This = null;
        
        #endregion

        #region Constructors
        public TForm08()
        {
            InitializeComponent();
        }
        #endregion

        #region Properties
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
            }
        }
        public TTreeList01 TreeList01This
        {
            get { 
                return mTreeList01This; 
            }
            set { 
                mTreeList01This = value; 
            }
        }
        #endregion

        #region Event Handlers
        private void btnSave_Click(object sender, EventArgs e)
        {

                SaveData();
 
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            CancelSave();
        }
        #endregion

        #region Functions
        protected virtual void Init()
        {
            if (Utilities.TGC.IsRunTime)
            {
                TreeList01This.BOT01 = BOT01;
                TreeList01This.ParentForm = this;
                TreeList01This.Init();
            }
        }
        protected virtual void AssignBOToTreeList()
        {
        }
        public virtual void LoadData()
        {
            BOT01.LoadDataSet();
        }
        public virtual void SaveData()
        {
            BOT01.Save();
            DialogResult = DialogResult.OK;
            Close();
        }
        public virtual void CancelSave()
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
        protected void BindData()
        {
            TreeList01This.BindData();
            OtherBinding();
        }
        protected virtual void OtherBinding()
        {
        }
        protected virtual void LateSettings()
        {
        }
        #endregion

        private void TForm08_Load(object sender, EventArgs e)
        {
            if (Utilities.TGC.IsRunTime)
            {
                LoadData();
                BindData();
                LateSettings();
            }
        }

        private void TForm08_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.S && e.Control)
            {
                TreeList01This.SaveLayoutToXml("D:\\" + TreeList01This.Name + ".xml");
                e.Handled = true;
            }
        }
    }
}