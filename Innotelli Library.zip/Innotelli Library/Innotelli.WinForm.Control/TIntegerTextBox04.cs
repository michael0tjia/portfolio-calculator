using System;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.ViewInfo;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterIntegerTextBox04")]
    public class RepositoryItemIntegerTextBox04 : RepositoryItemTextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemIntegerTextBox04() { RegisterIntegerTextBox04(); }

        //The unique name for the custom editor
        public const string IntegerTextBox04Name = "TIntegerTextBox04";

        //Return the unique name
        public override string EditorTypeName { get { return IntegerTextBox04Name; } }

        //Register the editor
        public static void RegisterIntegerTextBox04()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.IntegerTextBox04.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(IntegerTextBox04Name,
              typeof(TIntegerTextBox04), typeof(RepositoryItemIntegerTextBox04),
              typeof(TextEditViewInfo), new TextEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemIntegerTextBox04 source = item as RepositoryItemIntegerTextBox04;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Constructors
        public RepositoryItemIntegerTextBox04()
        {
        }
        #endregion

        #region Properties
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        DSFormMode mDSFormMode = DSFormMode.DSEditable;
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                TRepositoryItemTextEditUtil.SetDSFormModeReadOnly(this, value);
                mDSFormMode = value;
            }
        }
        #endregion

        #region Functions
        public void Init()
        {
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            Appearance.Options.UseBackColor = true;
            Appearance.Options.UseTextOptions = true;
            Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            AppearanceReadOnly.Options.UseBackColor = true;
            AppearanceReadOnly.Options.UseTextOptions = true;
            AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            MaxLength = 255;
            ReadOnly = true;
            DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            DisplayFormat.FormatString = TSettings.IntFormat;
            EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            EditFormat.FormatString = TSettings.IntFormat;
            Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            Mask.EditMask = TSettings.IntFormat;
        }
        #endregion
    }

    public class TIntegerTextBox04 : TextEdit
    {
        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static TIntegerTextBox04() { RepositoryItemIntegerTextBox04.RegisterIntegerTextBox04(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemIntegerTextBox04.IntegerTextBox04Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemIntegerTextBox04 Properties
        {
            get { return base.Properties as RepositoryItemIntegerTextBox04; }
        }
        #endregion

        #region Constructors
        

        //Initialize the new instance
        public TIntegerTextBox04()
        {
            Init();
        }
        #endregion

        #region Properties

        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(30, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        private string mFormat = TSettings.IntFormat;
        [Bindable(true),
        Category("Behavior"),
        DefaultValue("n0"),
        Description("Indicates the numeric format."),
        Localizable(true)]
        public string Format
        {
            get
            {
                return mFormat;
            }
            set
            {
                mFormat = value;
            }
        }
        #endregion

        #region Event Handlers
        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);
            TTextEditUtil.Highlight(this);
        }
        protected override void OnEditValueChanged()
        {
            base.OnEditValueChanged();
            if (Utilities.TGC.IsRunTime)
            {
                TTextEditUtil.UpdateForeColor(this);
            }
        }
        #endregion

        #region Functions
        private void Init()
        {
            TabStop = false;
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}