using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.Windows.Forms;
using Innotelli.BO;

namespace Innotelli.WinForm.Control
{
    public class TTextBox06Collection : ArrayList
    {
        #region Members
        #endregion

        #region Constructors
        public TTextBox06Collection()
        {
        }
        #endregion

        #region Enums
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Add(System.Windows.Forms.Control aControl)
        {
            base.Add(aControl);
        }
        public void Init(TBOT01 aBOT01)
        {
            for (int i = 0; i < this.Count; i++)
            {
                ((TTextBox06)this[i]).Properties.Init(aBOT01);
            }
        }
        public void SetDSMode(DSFormMode aDSFormMode)
        {
            for (int i = 0; i < this.Count; i++)
            {
                ((TTextBox06)this[i]).Properties.DSFormMode = aDSFormMode;
            }
        }
        #endregion
    }
}
