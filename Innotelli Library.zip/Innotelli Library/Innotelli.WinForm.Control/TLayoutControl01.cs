using System;
using System.Collections.Generic;
using System.Text;
using DevExpress.XtraLayout;
using System.Drawing;
using DevExpress.XtraLayout.Utils;

namespace Innotelli.WinForm.Control
{
    public class TLayoutControl01 : LayoutControl
    {
        public TLayoutControl01()
        {
            Dock = System.Windows.Forms.DockStyle.Fill;
            OptionsItemText.TextAlignMode = TextAlignMode.AlignInGroups;
            OptionsItemText.TextToControlDistance = 2;
            OptionsView.EnableIndentsInGroupsWithoutBorders = true;
        }
        protected override LayoutControlImplementor CreateILayoutControlImplementorCore()
        {
            return new LayoutControlImplementor01(this);
        }
        public override BaseLayoutItem CreateLayoutItem(LayoutGroup parent)
        {
            return new LayoutControlItem01((LayoutControlGroup01)parent);
        }
    }

    public class LayoutControlImplementor01 : LayoutControlImplementor
    {
        public LayoutControlImplementor01(ILayoutControlOwner owner) : base(owner) { }
        public override LayoutGroup CreateLayoutGroup(LayoutGroup parent)
        {
            return new LayoutControlGroup01(parent);
        }
    }

    public class LayoutControlGroup01 : LayoutControlGroup
    {
        //private bool mIsTextVisibleSet = false;
        public LayoutControlGroup01()
            : base(null)
        {
        }
        public LayoutControlGroup01(LayoutGroup parent)
            : base(parent)
        {
            Padding = new Padding(1);
            Spacing = new Padding(1);
            TextVisible = false;
        }
    }

    public class LayoutControlItem01 : LayoutControlItem
    {
        public LayoutControlItem01()
            : base(null)
        {
        }
        public LayoutControlItem01(LayoutControlGroup01 parent)
            : base(parent)
        {
            Padding = new Padding(1, 1, 0, 0);
        }
    }
}
