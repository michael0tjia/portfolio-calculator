using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;
using System.Windows.Forms;
using C1.Win.C1Report;
using C1.Win.C1Preview;
using C1.C1Zip;

namespace Innotelli.Report
{
    public partial class TPreviewFrom : Form
    {
        #region Member
        private C1Report mC1Report = null;
        private PrintDocument mPrintDocument = null;
        #endregion

        #region Constructor
        public TPreviewFrom()
        {
            InitializeComponent();
        }
        public TPreviewFrom(C1Report aC1Report)
        {
            InitializeComponent();
            C1Report=aC1Report;
            Preview();
        }
        public TPreviewFrom(PrintDocument aDocument)
        {
            InitializeComponent();
            PrintDocument = aDocument;
            Preview();
        }
        #endregion

        #region Enum

        #endregion

        #region Properties
        public C1Report C1Report
        {
            get { return mC1Report; }
            set { mC1Report = value; }
        }
        public PrintDocument PrintDocument
        {
            get { return mPrintDocument; }
            set { mPrintDocument = value; }
        }
        #endregion

        #region Event

        #endregion

        #region Functions
        private void Preview()
        {
            try
            {
                if (C1Report != null)
                {
                    c1PrintPreviewControl1.PreviewPane.Document = C1Report.Document;
                }
                else
                {
                    c1PrintPreviewControl1.PreviewPane.Document = PrintDocument;
                }                
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
        #endregion
    }
}