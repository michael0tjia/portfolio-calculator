using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Reflection;
using DevExpress.XtraEditors;
using DevExpress.Utils;
using Innotelli.BO;
using Innotelli.Report1;
using Innotelli.Utilities;


namespace Innotelli.WinForm.Control
{
    public partial class TForm02 : DevExpress.XtraEditors.XtraForm
    {
        #region Enums
        protected enum DSAFormAction
        {
            DSAInsert,
            DSAEdit,
            DSASave,
            DSACancel,
            DSADelete,
            DSAPrintPreview,
            DSAPrint,
            DSAExit,
            DSAFirst,
            DSAPrev,
            DSANext,
            DSALast,
            DSAQuickFind,
        }
        #endregion

        #region Members
        private int mRowLockRefreshInterval01 = 60000;
        //private Form mParentForm;

        #region Form Reuse
        //private Size mOriginalSize = new Size();
        //private string mLayoutStr = null;
        #endregion

        private string mAskifCancel = string.Empty;
        private string mAskSaveBeforePrint = string.Empty;
        private string mAskSaveBeforeExit = string.Empty;
        private string mAskifDelete = string.Empty;
        private string mAskSaveBeforeNew = string.Empty;

        #region Control Collections
        private TCheckBox03Collection mCheckBox03Collection = new TCheckBox03Collection();
        private TCheckBox04Collection mCheckBox04Collection = new TCheckBox04Collection();
        private TCurrencyTextBox03Collection mCurrencyTextBox03Collection = new TCurrencyTextBox03Collection();
        private TCurrencyTextBox04Collection mCurrencyTextBox04Collection = new TCurrencyTextBox04Collection();
        private TDateEditor02Collection mDateEditor02Collection = new TDateEditor02Collection();
        private TDateTextBox02Collection mDateTextBox02Collection = new TDateTextBox02Collection();
        private TDataGrid02Collection mDataGrid02Collection = new TDataGrid02Collection();
        private TDecimalTextBox03Collection mDecimalTextBox03Collection = new TDecimalTextBox03Collection();
        private TDecimalTextBox04Collection mDecimalTextBox04Collection = new TDecimalTextBox04Collection();
        private TIntegerTextBox03Collection mIntegerTextBox03Collection = new TIntegerTextBox03Collection();
        private TIntegerTextBox04Collection mIntegerTextBox04Collection = new TIntegerTextBox04Collection();
        private TLookUpCombo02Collection mLookUpCombo02Collection = new TLookUpCombo02Collection();
        private TLookUpTextBox01Collection mLookUpTextBox01Collection = new TLookUpTextBox01Collection();
        private TMemoBox01Collection mMemoBox01Collection = new TMemoBox01Collection();
        private TMemoBox02Collection mMemoBox02Collection = new TMemoBox02Collection();
        private TMemoBoxEx01Collection mMemoBoxEx01Collection = new TMemoBoxEx01Collection();
        private TPercentTextBox03Collection mPercentTextBox03Collection = new TPercentTextBox03Collection();
        private TPercentTextBox04Collection mPercentTextBox04Collection = new TPercentTextBox04Collection();
        private TRadioButton03Collection mRadioButton03Collection = new TRadioButton03Collection();
        private TRadioButton04Collection mRadioButton04Collection = new TRadioButton04Collection();
        private TTextBox04Collection mTextBox04Collection = new TTextBox04Collection();
        private TTextBox05Collection mTextBox05Collection = new TTextBox05Collection();
        private TTextBox06Collection mTextBox06Collection = new TTextBox06Collection();
        private TTextBox08Collection mTextBox08Collection = new TTextBox08Collection();
        private TTimeEditor02Collection mTimeEditor02Collection = new TTimeEditor02Collection();
        private TTimeTextBox02Collection mTimeTextBox02Collection = new TTimeTextBox02Collection();
        private TValueListCombo02Collection mValueListCombo02Collection = new TValueListCombo02Collection();
        private TValueListTextBox01Collection mValueListTextBox01Collection = new TValueListTextBox01Collection();
        private Dictionary<Guid, TRptLaunch> mRptLaunchs = new Dictionary<Guid, TRptLaunch>();
        #endregion

        private string mFormCaption = "";
        private string mReadOnlyMsg = "";
        #endregion

        #region Constructors
        public TForm02()
        {
            InitImageCollection();
            InitializeComponent();
            bmgBase.Images = ImageCollection;
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                mAskifCancel = Innotelli.Utilities.TSingletons.StrResx.GetStr(108);
                mAskSaveBeforePrint = Innotelli.Utilities.TSingletons.StrResx.GetStr(109);
                mAskSaveBeforeExit = Innotelli.Utilities.TSingletons.StrResx.GetStr(110);
                mAskifDelete = Innotelli.Utilities.TSingletons.StrResx.GetStr(111);
                mAskSaveBeforeNew = Innotelli.Utilities.TSingletons.StrResx.GetStr(112);
            }
        }
        #endregion

        #region Properties
        ImageCollection mImageCollection = new ImageCollection();
        public ImageCollection ImageCollection
        {
            get
            {
                return mImageCollection;
            }
            set
            {
                mImageCollection = value;
            }
        }
        public DSFormMode mDsMode = DSFormMode.DSBrowse;
        public DSFormMode DsMode
        {
            get
            {
                return mDsMode;
            }
            set
            {
                mDsMode = value;
                SetAllControlCollectionsDSModeVal(mDsMode);
            }
        }
        private TBOT01 mBOT01 = null;
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
            }
        }
        private TLayoutControl01 mLyt01Base = null;
        public TLayoutControl01 Lyt01Base
        {
            get
            {
                return mLyt01Base;
            }
            set
            {
                mLyt01Base = value;
            }
        }
        private BindingSource mBdsMaster = null;
        public BindingSource BdsMaster
        {
            get
            {
                return mBdsMaster;
            }
            set
            {
                if (mBdsMaster == value)
                    return;
                mBdsMaster = value;
            }
        }
        public TLookUpCombo02Collection LookUpCombo02Collection
        {
            get
            {
                return mLookUpCombo02Collection;
            }
            set
            {
                mLookUpCombo02Collection = value;
            }
        }
        TDataGrid02 mParentGrid02 = null;
        public TDataGrid02 ParentGrid02
        {
            get
            {
                return mParentGrid02;
            }
            set
            {
                mParentGrid02 = value;
            }
        }
        public string DefaultRptNm
        {
            get
            {
                return "rpt" + BOT01.BOID.Substring(4);
            }
        }
        public string DefaultCriteria
        {
            get
            {
                return Utilities.TGC.PKeyName + " = " + BOT01.PrmyKey;
            }
        }
        #endregion

        #region Event Handlers
        private void bbi01New_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DSGoToState(DSAFormAction.DSAInsert);
        }
        private void bbi01Edit_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DSGoToState(DSAFormAction.DSAEdit);
        }
        private void bbi01Save_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DSGoToState(DSAFormAction.DSASave);
        }
        private void bbi01Cancel_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DSGoToState(DSAFormAction.DSACancel);
        }
        private void bbi01PrintPreview_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DSGoToState(DSAFormAction.DSAPrintPreview);
        }
        private void bbi01Print_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DSGoToState(DSAFormAction.DSAPrint);
        }
        private void bbi01Delete_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DSGoToState(DSAFormAction.DSADelete);
        }
        private void bbi01First_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DSGoToState(DSAFormAction.DSAFirst);
        }
        private void bbi01Prev_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DSGoToState(DSAFormAction.DSAPrev);
        }
        private void bbi01Next_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DSGoToState(DSAFormAction.DSANext);
        }
        private void bbi01Last_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            DSGoToState(DSAFormAction.DSALast);
        }
        private void bbi01QuickFind_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            TFrmFindDialog lFrmFindDialog = new TFrmFindDialog();
            lFrmFindDialog.ShowDialog();
            if (lFrmFindDialog.DialogResult == DialogResult.OK)
            {
                if (lFrmFindDialog.txtID.EditValue != null)
                {
                    QuickFind(lFrmFindDialog.txtID.EditValue.ToString());
                }
            }
        }
        private void BOT01_OnBOIsDirty(object sender, System.EventArgs e)
        {
            DSUpdateFormState();
            UpdateAllControlsStatus();
        }
        private void TForm02_FormClosing(object sender, FormClosingEventArgs e)
        {

            //TODO: Need to handle Mid Closing
            if (e.CloseReason == CloseReason.UserClosing)
            {
                if (DSFExit())
                {
                    if (mDataGrid02Collection.OpenedChildForms.Count == 0)
                    {
                        // Need to handle mRptLaunchs.Count != 0 if form is really closed.
                        // i.e.: mRptLaunchs.Count != 0 -> Hidden, mRptLaunchs.Count != 0 -> Close
                        CloseAndReturnToPool();
                    }
                    else
                    {
                        TMessageBox.ShowWarning(mDataGrid02Collection.OpenedChildForms.Count + " child form(s) is still opening");
                        foreach (TForm02 form02 in mDataGrid02Collection.OpenedChildForms)
                        {
                            form02.Focus();
                            form02.WindowState = FormWindowState.Normal;
                        }
                    }
                }
                else
                {
                }
                e.Cancel = true;
            }
        }
        private void TForm02_KeyDown(object sender, KeyEventArgs e)
        {
            //#check! - carol commented on 2008/03/05
            //if (e.KeyCode == Keys.Home)
            //{
            //    //#check!
            //    //bbi01QuickFind_ItemClick(this, null);
            //    //AddQuickFindForm();
            //    e.Handled = true;
            //}
            if (e.KeyCode == Keys.S && e.Control)
            {
                for (int i = 0; i < mDataGrid02Collection.Count; i++)
                {
                    ((DevExpress.XtraGrid.Views.Base.ColumnView)((TDataGrid02)mDataGrid02Collection[i]).MainView).SaveLayoutToXml("D:\\" + ((TDataGrid02)mDataGrid02Collection[i]).Name + ".xml", DevExpress.Utils.OptionsLayoutBase.FullLayout);
                }
                e.Handled = true;
            }
        }
        private void TForm02_Load(object sender, EventArgs e)
        {
            this.KeyPreview = true;
        }
        private void tmrRowLock_Tick(object sender, EventArgs e)
        {
            //string lRowLockPK = null;

            //if (BOT01 != null && !BOT01.IsNoRow() && !string.IsNullOrEmpty(BOT01.PrmyKey) && BOT01.RowLockPK != null)
            //{
            //TRowLock.RefreshLock(BOT01.SPrps.TblName, BOT01.prmykey2, ref lRowLockPK);
            //BOT01.RowLockPK = lRowLockPK;
            //}
        }
        #endregion

        #region Functions

        #region Form Status

        #region Status Ask Questions
        private DialogResult DSFAskifCancel()
        {
            DialogResult lReturnValue;

            lReturnValue = TMessageBox.AskQuestion(mAskifCancel, MessageBoxButtons.OKCancel, MessageBoxDefaultButton.Button1);
            return lReturnValue;
        }
        private DialogResult DSFAskSaveBeforePrint()
        {
            DialogResult lReturnValue;

            lReturnValue = TMessageBox.AskQuestion(mAskSaveBeforePrint, MessageBoxButtons.OKCancel, MessageBoxDefaultButton.Button1);
            return lReturnValue;
        }
        private DialogResult DSFAskSaveBeforeExit()
        {
            DialogResult lReturnValue;

            lReturnValue = TMessageBox.AskQuestion(mAskSaveBeforeExit, MessageBoxButtons.YesNoCancel, MessageBoxDefaultButton.Button1);
            return lReturnValue;
        }
        private DialogResult DSFAskifDelete()
        {
            DialogResult lReturnValue;

            lReturnValue = TMessageBox.AskQuestion(mAskifDelete, MessageBoxButtons.OKCancel, MessageBoxDefaultButton.Button1);
            return lReturnValue;
        }
        private DialogResult DSFAskSaveBeforeNew()
        {
            DialogResult lReturnValue;

            lReturnValue = TMessageBox.AskQuestion(mAskSaveBeforeNew, MessageBoxButtons.YesNoCancel, MessageBoxDefaultButton.Button1);
            return lReturnValue;
        }
        #endregion

        #region Status Action Functions
        //protected virtual bool DSFTemplate()
        //{
        //bool lReturnValue = false;

        //switch (mDsMode)
        //{
        //    case DSFormMode.DSInsert:
        //        if (BOT01.IsDirty)
        //        {
        //        }
        //        else
        //        {
        //        }
        //        break;
        //    case DSFormMode.DSEditable:
        //        if (BOT01.IsDirty)
        //        {
        //        }
        //        else
        //        {
        //        }
        //        break;
        //    case DSFormMode.DSBrowse:
        //        break;
        //    default:
        //        break;
        //}
        //return lReturnValue;
        //}
        protected virtual bool DSFInsert()
        {
            bool lReturnValue = false;
            DialogResult lDialogResult;

            switch (DsMode)
            {
                case DSFormMode.DSInsert:
                    break;
                case DSFormMode.DSEditable:
                    if (BOT01.IsDirty)
                    {
                        lDialogResult = DSFAskSaveBeforeNew();
                        if (lDialogResult == DialogResult.Yes)
                        {
                            if (Save())
                            {
                                lReturnValue = AddNew();
                            }
                            else
                            {
                            }
                        }
                        else if (lDialogResult == DialogResult.No)
                        {
                            // ignore changes
                            lReturnValue = AddNew();
                        }
                    }
                    else
                    {
                        lReturnValue = AddNew();
                    }
                    break;
                case DSFormMode.DSBrowse:
                    lReturnValue = AddNew();
                    break;
                default:
                    break;
            }
            return lReturnValue;
        }
        protected virtual bool DSFEdit()
        {
            bool lReturnValue = false;
            //string lRowLockPK = null;
            //string lUserID = "";

            switch (DsMode)
            {
                case DSFormMode.DSInsert:
                    break;
                case DSFormMode.DSEditable:
                    break;
                case DSFormMode.DSBrowse:
                    mReadOnlyMsg = "";

                    //#check!
                    //need to be done in one transaction
                    //if (TRowLock.CreateLock(BOT01.SPrps.TblName, BOT01.prmykey2, ref lRowLockPK, ref lUserID))
                    //{
                    //    BOT01.RowLockPK = lRowLockPK;
                    lReturnValue = true;
                    //}
                    //else
                    //{
                    //    BOT01.RowLockPK = null;
                    //    BOT01.LockedByUserID = lUserID;
                    //    mReadOnlyMsg = "Locked, Record being edited by " + lUserID;
                    //}
                    break;
                default:
                    break;
            }
            return lReturnValue;
        }
        protected virtual bool DSFSave()
        {
            bool lReturnValue = false;

            switch (DsMode)
            {
                case DSFormMode.DSInsert:
                    if (BOT01.IsDirty)
                    {
                        if (Save())
                        {
                            lReturnValue = true;
                        }
                    }
                    break;
                case DSFormMode.DSEditable:
                    if (BOT01.IsDirty)
                    {
                        if (Save())
                        {
                            lReturnValue = true;
                        }
                    }
                    break;
                case DSFormMode.DSBrowse:
                    break;
                default:
                    break;
            }
            if (lReturnValue)
            {
                //if (BOT01.RowLockPK != null)
                //{
                //    TRowLock.DeleteRowLock(BOT01.RowLockPK);
                //}
            }
            return lReturnValue;
        }
        protected virtual bool DSFCancel()
        {
            bool lReturnValue = false;
            DialogResult lDialogResult;

            switch (DsMode)
            {
                case DSFormMode.DSInsert:
                    if (BOT01.IsDirty)
                    {
                        lDialogResult = DSFAskifCancel();
                        if (lDialogResult == DialogResult.OK)
                        {
                            if (!string.IsNullOrEmpty(BOT01.PreviousPKBeforeAddNew))
                            {
                                LoadByPK(BOT01.PreviousPKBeforeAddNew);
                            }
                            else
                            {
                                CloseAndReturnToPool();
                            }
                        }
                    }
                    break;
                case DSFormMode.DSEditable:
                    if (BOT01.IsDirty)
                    {
                        lDialogResult = DSFAskifCancel();
                        if (lDialogResult == DialogResult.OK)
                        {
                            CancelSave();
                            lReturnValue = true;
                        }
                    }
                    break;
                case DSFormMode.DSBrowse:
                    break;
                default:
                    break;
            }
            return lReturnValue;
        }
        protected virtual bool DSFDelete()
        {
            bool lReturnValue = false;
            DialogResult lDialogResult;

            switch (DsMode)
            {
                case DSFormMode.DSInsert:
                    break;
                case DSFormMode.DSEditable:
                    if (!BOT01.IsDirty)
                    {
                        lDialogResult = DSFAskifDelete();
                        if (lDialogResult == DialogResult.OK)
                        {
                            Delete();
                            lReturnValue = true;
                        }
                    }
                    break;
                case DSFormMode.DSBrowse:
                    break;
                default:
                    break;
            }
            return lReturnValue;
        }
        protected virtual bool DSFPrintPreview()
        {
            bool lReturnValue = false;
            DialogResult lDialogResult;

            switch (DsMode)
            {
                case DSFormMode.DSInsert:
                    if (BOT01.IsDirty)
                    {
                        lDialogResult = DSFAskSaveBeforePrint();
                        if (lDialogResult == DialogResult.OK)
                        {
                            if (Save())
                            {
                                Preview();
                                lReturnValue = true;
                            }
                        }
                    }
                    break;
                case DSFormMode.DSEditable:
                    if (BOT01.IsDirty)
                    {
                        lDialogResult = DSFAskSaveBeforePrint();
                        if (lDialogResult == DialogResult.OK)
                        {
                            if (Save())
                            {
                                Preview();
                                lReturnValue = true;
                            }
                        }
                    }
                    else
                    {
                        Preview();
                        lReturnValue = true;
                    }
                    break;
                case DSFormMode.DSBrowse:
                    Preview();
                    lReturnValue = true;
                    break;
                default:
                    break;
            }
            return lReturnValue;
        }
        protected virtual bool DSFPrint()
        {
            bool lReturnValue = false;
            DialogResult lDialogResult;

            switch (DsMode)
            {
                case DSFormMode.DSInsert:
                    if (BOT01.IsDirty)
                    {
                        lDialogResult = DSFAskSaveBeforePrint();
                        if (lDialogResult == DialogResult.OK)
                        {
                            if (Save())
                            {
                                Print();
                                lReturnValue = true;
                            }
                        }
                    }
                    break;
                case DSFormMode.DSEditable:
                    if (BOT01.IsDirty)
                    {
                        lDialogResult = DSFAskSaveBeforePrint();
                        if (lDialogResult == DialogResult.OK)
                        {
                            if (Save())
                            {
                                Print();
                                lReturnValue = true;
                            }
                        }
                    }
                    else
                    {
                        Print();
                        lReturnValue = true;
                    }
                    break;
                case DSFormMode.DSBrowse:
                    Print();
                    lReturnValue = true;
                    break;
                default:
                    break;
            }
            return lReturnValue;
        }
        protected virtual bool DSFExit()
        {
            bool lReturnValue = false;
            DialogResult lDialogResult;

            switch (DsMode)
            {
                case DSFormMode.DSInsert:
                    if (BOT01.IsDirty)
                    {
                        lDialogResult = DSFAskSaveBeforeExit();
                        if (lDialogResult == DialogResult.Yes)
                        {
                            if (Save())
                            {
                                lReturnValue = true;
                            }
                            else
                            {
                                lReturnValue = false;
                            }
                        }
                        else if (lDialogResult == DialogResult.No)
                        {
                            lReturnValue = true;
                        }
                    }
                    else
                    {
                        lReturnValue = true;
                    }
                    break;
                case DSFormMode.DSEditable:
                    if (BOT01.IsDirty)
                    {
                        lDialogResult = DSFAskSaveBeforeExit();
                        if (lDialogResult == DialogResult.Yes)
                        {
                            if (Save())
                            {
                                lReturnValue = true;
                            }
                            else
                            {
                                lReturnValue = false;
                            }
                        }
                        else if (lDialogResult == DialogResult.No)
                        {
                            lReturnValue = true;
                        }
                    }
                    else
                    {
                        lReturnValue = true;
                    }
                    break;
                case DSFormMode.DSBrowse:
                    lReturnValue = true;
                    break;
                default:
                    break;
            }
            return lReturnValue;
        }
        protected virtual bool DSFFirst()
        {
            bool lReturnValue = false;

            switch (DsMode)
            {
                case DSFormMode.DSInsert:
                    if (!BOT01.IsDirty)
                    {
                        Nav("F");
                    }
                    break;
                case DSFormMode.DSEditable:
                    if (!BOT01.IsDirty)
                    {
                        Nav("F");
                    }
                    break;
                case DSFormMode.DSBrowse:
                    Nav("F");
                    break;
                default:
                    break;
            }
            return lReturnValue;
        }
        protected virtual bool DSFPrev()
        {
            bool lReturnValue = false;

            switch (DsMode)
            {
                case DSFormMode.DSInsert:
                    if (!BOT01.IsDirty)
                    {
                        Nav("P");
                    }
                    break;
                case DSFormMode.DSEditable:
                    if (!BOT01.IsDirty)
                    {
                        Nav("P");
                    }
                    break;
                case DSFormMode.DSBrowse:
                    Nav("P");
                    break;
                default:
                    break;
            }
            return lReturnValue;
        }
        protected virtual bool DSFNext()
        {
            bool lReturnValue = false;

            switch (DsMode)
            {
                case DSFormMode.DSInsert:
                    break;
                case DSFormMode.DSEditable:
                    if (!BOT01.IsDirty)
                    {
                        Nav("N");
                    }
                    break;
                case DSFormMode.DSBrowse:
                    Nav("N");
                    break;
                default:
                    break;
            }
            return lReturnValue;
        }
        protected virtual bool DSFLast()
        {
            bool lReturnValue = false;

            switch (DsMode)
            {
                case DSFormMode.DSInsert:
                    break;
                case DSFormMode.DSEditable:
                    if (!BOT01.IsDirty)
                    {
                        Nav("L");
                    }
                    break;
                case DSFormMode.DSBrowse:
                    Nav("L");
                    break;
                default:
                    break;
            }
            return lReturnValue;
        }
        protected virtual bool DSFQuickFind()
        {
            bool lReturnValue = false;

            switch (DsMode)
            {
                case DSFormMode.DSInsert:
                    break;
                case DSFormMode.DSEditable:
                    if (!BOT01.IsDirty)
                    {
                        Nav("Q");
                    }
                    break;
                case DSFormMode.DSBrowse:
                    Nav("Q");
                    break;
                default:
                    break;
            }
            return lReturnValue;
        }
        #endregion

        //TODO: Debug when ActiveControl is DBGrid
        private void EnforceActiveEditorDoValidate()
        {
            System.Windows.Forms.Control lActiveControl = null;
            TLayoutControl01 lLayoutControl01 = null;
            BaseEdit lBaseEdit = null;

            lActiveControl = ActiveControl;
            if (lActiveControl.GetType().Name == "TLayoutControl01")
            {
                lLayoutControl01 = (TLayoutControl01)lActiveControl;
                lActiveControl = lLayoutControl01.ActiveControl;
                if (lActiveControl != null && lActiveControl is BaseEdit)
                {
                    lBaseEdit = (BaseEdit)lActiveControl;
                    lBaseEdit.DoValidate();
                }
                else
                {
                    lActiveControl = lActiveControl.Parent;
                    if (lActiveControl != null && lActiveControl is BaseEdit)
                    {
                        lBaseEdit = (BaseEdit)lActiveControl;
                        lBaseEdit.DoValidate();
                    }
                }
            }
        }
        protected bool DSGoToState(DSAFormAction aAction)
        {
            bool lReturnValue = false;
            bool lActionSuccess = false;
            DSFormMode lDstMode = DSFormMode.DSBrowse;
            string lRtrnMsg = null;


            if (DSIsValid(aAction, ref lDstMode, ref lRtrnMsg))
            {
                switch (aAction)
                {
                    case DSAFormAction.DSAInsert:
                        lActionSuccess = DSFInsert();
                        break;
                    case DSAFormAction.DSAEdit:
                        lActionSuccess = DSFEdit();
                        break;
                    case DSAFormAction.DSASave:
                        lActionSuccess = DSFSave();
                        break;
                    case DSAFormAction.DSACancel:
                        lActionSuccess = DSFCancel();
                        break;
                    case DSAFormAction.DSADelete:
                        lActionSuccess = DSFDelete();
                        break;
                    case DSAFormAction.DSAPrintPreview:
                        lActionSuccess = DSFPrintPreview();
                        break;
                    case DSAFormAction.DSAPrint:
                        lActionSuccess = DSFPrint();
                        break;
                    case DSAFormAction.DSAExit:
                        lActionSuccess = DSFExit();
                        break;
                    case DSAFormAction.DSAFirst:
                        lActionSuccess = DSFFirst();
                        break;
                    case DSAFormAction.DSAPrev:
                        lActionSuccess = DSFPrev();
                        break;
                    case DSAFormAction.DSANext:
                        lActionSuccess = DSFNext();
                        break;
                    case DSAFormAction.DSALast:
                        lActionSuccess = DSFLast();
                        break;
                    case DSAFormAction.DSAQuickFind:
                        lActionSuccess = DSFQuickFind();
                        break;
                }
                if (lActionSuccess && (aAction != DSAFormAction.DSADelete && aAction != DSAFormAction.DSAExit))
                {
                    DsMode = lDstMode;
                    DSUpdateFormState();
                    UpdateAllControlsStatus();

                }
                lReturnValue = true;
            }
            else
            {
                TMessageBox.ShowWarning(lRtrnMsg);
            }
            return lReturnValue;
        }
        protected bool DSIsValid(DSAFormAction aAction, ref DSFormMode aDstMode, ref string aRtrnMsg)
        {
            bool lReturnValue = false;
            aDstMode = DsMode;
            aRtrnMsg = "";

            switch (DsMode)
            {
                case DSFormMode.DSBrowse:
                    #region Browse
                    switch (aAction)
                    {
                        case DSAFormAction.DSAInsert:
                            lReturnValue = true;
                            aDstMode = DSFormMode.DSInsert;
                            break;
                        case DSAFormAction.DSAEdit:
                            lReturnValue = true;
                            aDstMode = DSFormMode.DSEditable;
                            break;
                        case DSAFormAction.DSASave:
                            lReturnValue = false;
                            aRtrnMsg = "Browse mode. Cannot save.";
                            break;
                        case DSAFormAction.DSACancel:
                            lReturnValue = false;
                            aRtrnMsg = "Browse mode. Cannot cancel.";
                            break;
                        case DSAFormAction.DSADelete:
                            lReturnValue = false;
                            aRtrnMsg = "Browse mode. Cannot delete.";
                            break;
                        case DSAFormAction.DSAPrintPreview:
                            lReturnValue = true;
                            break;
                        case DSAFormAction.DSAPrint:
                            lReturnValue = true;
                            break;
                        case DSAFormAction.DSAExit:
                            lReturnValue = true;
                            break;
                        case DSAFormAction.DSAPrev:
                            lReturnValue = true;
                            break;
                        case DSAFormAction.DSANext:
                            lReturnValue = true;
                            break;
                        case DSAFormAction.DSAFirst:
                            lReturnValue = true;
                            break;
                        case DSAFormAction.DSALast:
                            lReturnValue = true;
                            break;
                        case DSAFormAction.DSAQuickFind:
                            lReturnValue = true;
                            break;
                        default:
                            lReturnValue = false;
                            break;
                    }
                    break;
                    #endregion
                case DSFormMode.DSEditable:
                    #region Edit
                    if (BOT01.IsDirty)
                    {
                        switch (aAction)
                        {
                            case DSAFormAction.DSAInsert:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSInsert;
                                break;
                            case DSAFormAction.DSAEdit:
                                lReturnValue = false;
                                aRtrnMsg = "Already in editable mode.";
                                break;
                            case DSAFormAction.DSASave:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSEditable;
                                break;
                            case DSAFormAction.DSACancel:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSEditable;
                                break;
                            case DSAFormAction.DSADelete:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSAPrintPreview:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSEditable;
                                break;
                            case DSAFormAction.DSAPrint:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSEditable;
                                break;
                            case DSAFormAction.DSAExit:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSEditable;
                                break;
                            case DSAFormAction.DSAPrev:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSANext:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSAFirst:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSALast:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSAQuickFind:
                                lReturnValue = false;
                                break;
                            default:
                                lReturnValue = false;
                                break;
                        }
                    }
                    else
                    {
                        switch (aAction)
                        {
                            case DSAFormAction.DSAInsert:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSInsert;
                                break;
                            case DSAFormAction.DSAEdit:
                                lReturnValue = false;
                                aRtrnMsg = "Already in editable mode.";
                                break;
                            case DSAFormAction.DSASave:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSACancel:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSADelete:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSEditable;
                                break;
                            case DSAFormAction.DSAPrintPreview:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSEditable;
                                break;
                            case DSAFormAction.DSAPrint:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSEditable;
                                break;
                            case DSAFormAction.DSAExit:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSEditable;
                                break;
                            case DSAFormAction.DSAPrev:
                                lReturnValue = true;
                                break;
                            case DSAFormAction.DSANext:
                                lReturnValue = true;
                                break;
                            case DSAFormAction.DSAFirst:
                                lReturnValue = true;
                                break;
                            case DSAFormAction.DSALast:
                                lReturnValue = true;
                                break;
                            case DSAFormAction.DSAQuickFind:
                                lReturnValue = true;
                                break;
                            default:
                                lReturnValue = false;
                                break;
                        }
                    }
                    break;
                    #endregion
                case DSFormMode.DSInsert:
                    #region Insert
                    if (BOT01.IsDirty)
                    {
                        switch (aAction)
                        {
                            case DSAFormAction.DSAInsert:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSAEdit:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSASave:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSEditable;
                                break;
                            case DSAFormAction.DSACancel:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSInsert;
                                break;
                            case DSAFormAction.DSADelete:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSAPrintPreview:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSEditable;
                                break;
                            case DSAFormAction.DSAPrint:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSEditable;
                                break;
                            case DSAFormAction.DSAExit:
                                lReturnValue = true;
                                aDstMode = DSFormMode.DSEditable;
                                break;
                            case DSAFormAction.DSAPrev:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSANext:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSAFirst:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSALast:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSAQuickFind:
                                lReturnValue = false;
                                break;
                            default:
                                lReturnValue = false;
                                break;
                        }
                    }
                    else
                    {
                        switch (aAction)
                        {
                            case DSAFormAction.DSAInsert:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSAEdit:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSASave:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSACancel:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSADelete:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSAPrintPreview:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSAPrint:
                                lReturnValue = false;
                                break;
                            case DSAFormAction.DSAExit:
                                lReturnValue = true;
                                break;
                            case DSAFormAction.DSAPrev:
                                lReturnValue = true;
                                break;
                            case DSAFormAction.DSANext:
                                lReturnValue = true;
                                break;
                            case DSAFormAction.DSAFirst:
                                lReturnValue = true;
                                break;
                            case DSAFormAction.DSALast:
                                lReturnValue = true;
                                break;
                            case DSAFormAction.DSAQuickFind:
                                lReturnValue = false;
                                break;
                            default:
                                lReturnValue = false;
                                break;
                        }
                    }
                    break;
                    #endregion
                default:
                    lReturnValue = false;
                    break;
            }

            return lReturnValue;
        }
        public virtual void DSUpdateFormState()
        {
            DSFormMode lDstMode = DSFormMode.DSBrowse;
            string lRtrnMsg = null;

            bbi01New.Enabled = BOT01.DataRight.AllowAdd && DSIsValid(DSAFormAction.DSAInsert, ref lDstMode, ref lRtrnMsg);
            bbi01Edit.Enabled = DSIsValid(DSAFormAction.DSAEdit, ref lDstMode, ref lRtrnMsg);
            bbi01Save.Enabled = DSIsValid(DSAFormAction.DSASave, ref lDstMode, ref lRtrnMsg);
            bbi01CancelSave.Enabled = DSIsValid(DSAFormAction.DSACancel, ref lDstMode, ref lRtrnMsg);
            bbi01Delete.Enabled = BOT01.DataRight.AllowDelete && DSIsValid(DSAFormAction.DSADelete, ref lDstMode, ref lRtrnMsg);
            bbi01PrintPreview.Enabled = DSIsValid(DSAFormAction.DSAPrint, ref lDstMode, ref lRtrnMsg);
            bbi01Print.Enabled = DSIsValid(DSAFormAction.DSAPrint, ref lDstMode, ref lRtrnMsg);

            if (BOT01.NavEnable)
            {
                bbi01First.Enabled = DSIsValid(DSAFormAction.DSAFirst, ref lDstMode, ref lRtrnMsg) && (BOT01.NavCurPos > 1);
                bbi01Prev.Enabled = DSIsValid(DSAFormAction.DSAPrev, ref lDstMode, ref lRtrnMsg) && (BOT01.NavCurPos > 1);
                bbi01Next.Enabled = DSIsValid(DSAFormAction.DSANext, ref lDstMode, ref lRtrnMsg) && (BOT01.NavCurPos < BOT01.NavRecCount);
                bbi01Last.Enabled = DSIsValid(DSAFormAction.DSALast, ref lDstMode, ref lRtrnMsg) && (BOT01.NavCurPos < BOT01.NavRecCount);
                bbi01QuickFind.Enabled = DSIsValid(DSAFormAction.DSAQuickFind, ref lDstMode, ref lRtrnMsg);
            }
            else
            {
                bbi01First.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
                bbi01Prev.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
                bbi01Next.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
                bbi01Last.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
                bbi01QuickFind.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
                beiCurRec.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
                beiRecCount.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
                bbi01TextOf.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            }

            if (!BOT01.UserDataRight.AllowEdit)
            {
                mReadOnlyMsg = "Read only permission";
            }
            else if (!BOT01.StatusDataRight.AllowEdit)
            {
                mReadOnlyMsg = "Record locked";
            }
            else if (!BOT01.ConsistencyDataRight.AllowEdit)
            {
                mReadOnlyMsg = "Record locked by another user";
            }
            else
            {
                mReadOnlyMsg = "";
            }
            if (!string.IsNullOrEmpty(mReadOnlyMsg))
            {
                Text = mFormCaption + " [" + mReadOnlyMsg + "]";
            }
            else
            {
                Text = mFormCaption;
            }
            mDataGrid02Collection.SetButton05EnableVal(!BOT01.IsDirty);
        }
        private void DSSelectModeAfterLoad()
        {
            if (BOT01.DataRight.AllowEdit)
            {
                DsMode = DSFormMode.DSEditable;
            }
            else
            {
                DsMode = DSFormMode.DSBrowse;
            }
        }

        #endregion

        #region Control Status
        protected virtual void UpdateAllControlsStatus()
        {
        }
        #endregion

        #region Others
        protected virtual void InitImageCollection()
        {
            Image lImage = null;

            lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TForm02.New.png"));
            ImageCollection.AddImage(lImage);
            lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TForm02.Edit.png"));
            ImageCollection.AddImage(lImage);
            lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TForm02.Save.png"));
            ImageCollection.AddImage(lImage);
            lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TForm02.CancelSave.png"));
            ImageCollection.AddImage(lImage);
            lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TForm02.PrintPreview.png"));
            ImageCollection.AddImage(lImage);
            lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TForm02.Print.png"));
            ImageCollection.AddImage(lImage);
            lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TForm02.Delete.png"));
            ImageCollection.AddImage(lImage);
            lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TForm02.QuickFind.png"));
            ImageCollection.AddImage(lImage);
            lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TForm02.First.png"));
            ImageCollection.AddImage(lImage);
            lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TForm02.Prev.png"));
            ImageCollection.AddImage(lImage);
            lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TForm02.Next.png"));
            ImageCollection.AddImage(lImage);
            lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TForm02.Last.png"));
            ImageCollection.AddImage(lImage);
        }
        public virtual void Init()
        {
            if (Utilities.TGC.IsRunTime)
            {
                mFormCaption = Text;

                //#check!
                // check the order of init
                InitTree();
                BOT01.OnBOIsDirty += new BOIsDirtyEventHandler(BOT01_OnBOIsDirty);

                CreateControlCollections();
                AssignBOToGrids();
                InitControlCollections();
            }
        }
        protected virtual void InitTree()
        {
        }
        //#check! 2008/01/23 - carol amended
        public virtual bool AddNew()
        {
            bool lReturnValue = false;

            BOT01.AddNew();
            lReturnValue = true;
            if (lReturnValue)
            {
                Binding();
                DsMode = DSFormMode.DSInsert;
                BOT01.IsDirty = true;
                //#check! 
                if (BOT01.NavEnable)
                {
                    BOT01.SetCurNavInfo("0");
                    beiCurRec.EditValue = BOT01.NavRecCount + 1;
                    beiRecCount.EditValue = BOT01.NavRecCount + 1;
                }
                DSUpdateFormState();
                UpdateAllControlsStatus();
                if (mParentGrid02 != null)
                {
                    mParentGrid02.FocusRowByPK(BOT01.PrmyKey);
                }
            }
            return lReturnValue;
        }
        public virtual bool LoadByPK(string aPK)
        {
            bool lReturnValue = false;

            BOT01.PK = aPK;
            BOT01.LoadDataSet();
            if (!BOT01.IsNoRow())
            {
                Binding();
                DSSelectModeAfterLoad();
                if (BOT01.NavEnable)
                {
                    BOT01.SetCurNavInfo(BOT01.PrmyKey);
                    beiCurRec.EditValue = BOT01.NavCurPos;
                    beiRecCount.EditValue = BOT01.NavRecCount;
                }
                DSUpdateFormState();
                UpdateAllControlsStatus();
                if (mParentGrid02 != null)
                {
                    mParentGrid02.FocusRowByPK(BOT01.PrmyKey);
                }
                lReturnValue = true;
            }
            else
            {
                lReturnValue = false;
            }

            return lReturnValue;
        }
        protected void Binding()
        {
            mBdsMaster.DataSource = BOT01.DefaultView;
            mBdsMaster.ResetBindings(false);

            mDataGrid02Collection.BindData();
            OtherBinding();
        }
        protected virtual void AssignBOToGrids()
        {
        }
        public virtual void OtherBinding()
        {
        }
        public void CloseAndReturnToPool()
        {
            if (mParentGrid02 != null)
            {
                mParentGrid02.RemoveChildForm(this);
            }
            Visible = false;
            FinalizeForReuse();
        }
        #endregion

        #region Collection Functions
        public void CreateControlCollections()
        {
            foreach (System.Windows.Forms.Control lControl in mLyt01Base.Controls)
            {
                switch (lControl.GetType().Name)
                {
                    case "TCheckBox03":
                        mCheckBox03Collection.Add(lControl);
                        break;
                    case "TCheckBox04":
                        mCheckBox04Collection.Add(lControl);
                        break;
                    case "TCurrencyTextBox03":
                        mCurrencyTextBox03Collection.Add(lControl);
                        break;
                    case "TCurrencyTextBox04":
                        mCurrencyTextBox04Collection.Add(lControl);
                        break;
                    case "TDateEditor02":
                        mDateEditor02Collection.Add(lControl);
                        break;
                    case "TDateTextBox02":
                        mDateTextBox02Collection.Add(lControl);
                        break;
                    case "TDataGrid02":
                        mDataGrid02Collection.Add(lControl);
                        break;
                    case "TDecimalTextBox03":
                        mDecimalTextBox03Collection.Add(lControl);
                        break;
                    case "TDecimalTextBox04":
                        mDecimalTextBox04Collection.Add(lControl);
                        break;
                    case "TIntegerTextBox03":
                        mIntegerTextBox03Collection.Add(lControl);
                        break;
                    case "TIntegerTextBox04":
                        mIntegerTextBox04Collection.Add(lControl);
                        break;
                    case "TLookupCombo02":
                        mLookUpCombo02Collection.Add(lControl);
                        break;
                    case "TLookupTextBox01":
                        mLookUpTextBox01Collection.Add(lControl);
                        break;
                    case "TMemoBox01":
                        mMemoBox01Collection.Add(lControl);
                        break;
                    case "TMemoBox02":
                        mMemoBox02Collection.Add(lControl);
                        break;
                    case "TMemoBoxEx01":
                        mMemoBoxEx01Collection.Add(lControl);
                        break;
                    case "TPercentTextBox03":
                        mPercentTextBox03Collection.Add(lControl);
                        break;
                    case "TPercentTextBox04":
                        mPercentTextBox04Collection.Add(lControl);
                        break;
                    case "TRadioButton03":
                        mRadioButton03Collection.Add(lControl);
                        break;
                    case "TRadioButton04":
                        mRadioButton04Collection.Add(lControl);
                        break;
                    case "TTextBox04":
                        mTextBox04Collection.Add(lControl);
                        break;
                    case "TTextBox05":
                        mTextBox05Collection.Add(lControl);
                        break;
                    case "TTextBox06":
                        mTextBox06Collection.Add(lControl);
                        break;
                    case "TTextBox08":
                        mTextBox08Collection.Add(lControl);
                        break;
                    case "TTimeEditor02":
                        mTimeEditor02Collection.Add(lControl);
                        break;
                    case "TTimeTextBox02":
                        mTimeTextBox02Collection.Add(lControl);
                        break;
                    case "TValueListCombo02":
                        mValueListCombo02Collection.Add(lControl);
                        break;
                    case "TValueListTextBox01":
                        mValueListTextBox01Collection.Add(lControl);
                        break;
                    default:
                        break;
                }
            }
        }
        private void InitControlCollections()
        {
            mCheckBox03Collection.Init();
            mCheckBox04Collection.Init();
            mCurrencyTextBox03Collection.Init();
            mCurrencyTextBox04Collection.Init();
            mDateEditor02Collection.Init();
            mDateTextBox02Collection.Init();
            mDataGrid02Collection.Init(this);
            mLookUpCombo02Collection.Init();
            mLookUpCombo02Collection.BindAllLists(mBOT01);
            mLookUpTextBox01Collection.Init();
            mLookUpTextBox01Collection.BindList();
            mDecimalTextBox03Collection.Init();
            mDecimalTextBox04Collection.Init();
            mIntegerTextBox03Collection.Init();
            mIntegerTextBox04Collection.Init();
            mMemoBox01Collection.Init();
            mMemoBox02Collection.Init();
            mMemoBoxEx01Collection.Init();
            mPercentTextBox03Collection.Init();
            mPercentTextBox04Collection.Init();
            mRadioButton03Collection.Init();
            mRadioButton04Collection.Init();
            mTextBox04Collection.Init(mBOT01);
            mTextBox05Collection.Init();
            mTextBox06Collection.Init(mBOT01);
            mTextBox08Collection.Init();
            mTimeEditor02Collection.Init();
            mTimeTextBox02Collection.Init();
            mValueListCombo02Collection.Init(mBOT01.BOID);
            mValueListCombo02Collection.BindList();
            mValueListTextBox01Collection.Init(mBOT01.BOID);
            mValueListTextBox01Collection.BindList();
        }
        private void SetAllControlCollectionsDSModeVal(DSFormMode aDsMode)
        {
            mCheckBox03Collection.SetDSMode(aDsMode);
            mCheckBox04Collection.SetDSMode(aDsMode);
            mCurrencyTextBox03Collection.SetDSMode(aDsMode);
            mCurrencyTextBox04Collection.SetDSMode(aDsMode);
            mDateEditor02Collection.SetDSMode(aDsMode);
            mDateTextBox02Collection.SetDSMode(aDsMode);
            mDataGrid02Collection.SetDSMode(aDsMode);
            mDecimalTextBox03Collection.SetDSMode(aDsMode);
            mDecimalTextBox04Collection.SetDSMode(aDsMode);
            mIntegerTextBox03Collection.SetDSMode(aDsMode);
            mIntegerTextBox04Collection.SetDSMode(aDsMode);
            mLookUpCombo02Collection.SetDSMode(aDsMode);
            mLookUpTextBox01Collection.SetDSMode(aDsMode);
            mMemoBox01Collection.SetDSMode(aDsMode);
            mMemoBox02Collection.SetDSMode(aDsMode);
            mMemoBoxEx01Collection.SetDSMode(aDsMode);
            mPercentTextBox03Collection.SetDSMode(aDsMode);
            mPercentTextBox04Collection.SetDSMode(aDsMode);
            mRadioButton03Collection.SetDSMode(aDsMode);
            mRadioButton04Collection.SetDSMode(aDsMode);
            mTextBox04Collection.SetDSMode(aDsMode);
            mTextBox05Collection.SetDSMode(aDsMode);
            mTextBox06Collection.SetDSMode(aDsMode);
            mTextBox08Collection.SetDSMode(aDsMode);
            mTimeEditor02Collection.SetDSMode(aDsMode);
            mTimeTextBox02Collection.SetDSMode(aDsMode);
            mValueListCombo02Collection.SetDSMode(aDsMode);
            mValueListTextBox01Collection.SetDSMode(aDsMode);
        }
        #endregion

        #region CRUD
        public virtual bool Save()
        {
            bool lReturnValue = false;
            string lErrorMessage = string.Empty;

            EnforceActiveEditorDoValidate();

            mDataGrid02Collection.EnforceDoValidate();
            // Check if data is valid
            // This DataValid is only for this case
            if (BOT01.DataValid(ref lErrorMessage))
            {
                lReturnValue = BOT01.Save();
                if (lReturnValue)
                {
                    if (DsMode == DSFormMode.DSInsert && mParentGrid02 != null)
                    {
                        mParentGrid02.RemoveChildForm(this);
                        mParentGrid02.AddChildForm(this);
                    }
                    ReloadParentForm();
                    Reload();
                }
            }
            else
            {
                TMessageBox.ShowWarning(lErrorMessage);
            }
            return lReturnValue;
        }
        public void CancelSave()
        {
            Reload();
        }
        public virtual void Reload()
        {
            LoadByPK(BOT01.PrmyKey);
        }
        public virtual void Delete()
        {
            BOT01.DeleteByPK(BOT01.PrmyKey);
            CloseAndReturnToPool();
            ReloadParentForm();
        }
        public virtual void Exit()
        {
            Close();
        }
        #endregion

        #region Navigation
        public string Nav(string aDirection)
        {
            string lReturnValue = "";
            long lNavCurPos = 0;
            long lNavRecCount = 0;

            if (BOT01.NavEnable)
            {
                lReturnValue = BOT01.GetNavNewPK(BOT01.PrmyKey, aDirection, ref lNavCurPos, ref lNavRecCount);
                // if success
                if (lReturnValue != "")
                {
                    BOT01.NavCurPos = lNavCurPos;
                    BOT01.NavRecCount = lNavRecCount;
                    if (lReturnValue != BOT01.PrmyKey)
                    {
                        BOT01.PK = lReturnValue;
                        BOT01.LoadDataSet();
                        Binding();

                        DSSelectModeAfterLoad();

                        beiCurRec.EditValue = BOT01.NavCurPos;
                        beiRecCount.EditValue = BOT01.NavRecCount;
                        DSUpdateFormState();
                        UpdateAllControlsStatus();
                        if (mParentGrid02 != null)
                        {
                            mParentGrid02.FocusRowByPK(BOT01.PrmyKey);
                        }
                    }
                }
            }

            return lReturnValue;
        }
        public string QuickFind(string aID)
        {
            string lReturnValue = null;

            lReturnValue = BOT01.GetQuickFindNewPK(aID);
            if (lReturnValue != null)
            {
                LoadByPK(lReturnValue);
            }

            return lReturnValue;
        }
        #endregion

        #region Print and Print Preview
        protected virtual void Print()
        {

            Print(DefaultRptNm, DefaultCriteria);
        }
        protected virtual void Preview()
        {
            Preview(DefaultRptNm, DefaultCriteria);
        }
        protected void Print(string aRptNm, string aCriteria)
        {
            TRptLaunch lRptLaunch = InitRptLaunch();
            lRptLaunch.PrintAsync(aRptNm, aCriteria);
        }
        protected void Preview(string aRptNm, string aCriteria)
        {
            TRptLaunch lRptLaunch = InitRptLaunch();
            lRptLaunch.PreviewAsync(aRptNm, aCriteria);
        }
        protected void Print(string aRptNm, TRptFltr aRptFltr)
        {
            TRptLaunch lRptLaunch = InitRptLaunch();
            lRptLaunch.PrintAsync(aRptNm, aRptFltr);
        }
        protected void Preview(string aRptNm, TRptFltr aRptFltr)
        {
            TRptLaunch lRptLaunch = InitRptLaunch();
            lRptLaunch.PreviewAsync(aRptNm, aRptFltr);
        }
        protected void Print(string aRptNm, DataSet aRptExternalMainDs)
        {
            TRptLaunch lRptLaunch = InitRptLaunch();
            lRptLaunch.PrintAsync(aRptNm, aRptExternalMainDs);
        }
        protected void Preview(string aRptNm, DataSet aRptExternalMainDs)
        {
            TRptLaunch lRptLaunch = InitRptLaunch();
            lRptLaunch.PreviewAsync(aRptNm, aRptExternalMainDs);
        }
        private void mRptLaunch_ReportWorkerProgress(object sender, TReportWorkerProgressEventArgs e)
        {
            mRptLaunchs[e.ID].UpdateRptPreview();
            switch (e.Progress)
            {
                case 77:
                    //label3.Text = "Job Cancelled";
                    if (mRptLaunchs.ContainsKey(e.ID))
                    {
                        mRptLaunchs.Remove(e.ID);
                    }
                    Cursor.Current = Cursors.Default;
                    break;
                default:
                    //label3.Text = e.Progress.ToString();
                    break;
            }
        }
        private void mRptLaunch_WorkerCompleted(object sender, TWorkerCompletedEventArgs e)
        {
            if (mRptLaunchs.ContainsKey(e.ID))
            {
                mRptLaunchs[e.ID].CompleteTask();
                mRptLaunchs.Remove(e.ID);
            }
            Cursor.Current = Cursors.Default;
        }
        private TRptLaunch InitRptLaunch()
        {
            string lDefaultFileName = string.Empty;
            TRptLaunch lRptLaunch = new TRptLaunch(this);

            Cursor.Current = Cursors.WaitCursor;
            lDefaultFileName = BOT01.Dr[BOT01.SPrps.SPrpsBOT01Flds.SKeyFieldName].ToString();
            lDefaultFileName = TStr.ReplaceInvalidFileNameCharWithMinus(lDefaultFileName);
            lRptLaunch.WorkerCompleted += new Innotelli.Utilities.WorkerCompletedEventHandler(mRptLaunch_WorkerCompleted);
            lRptLaunch.ReportWorkerProgress += new Innotelli.Utilities.ReportWorkerProgressEventHandler(mRptLaunch_ReportWorkerProgress);
            lRptLaunch.EmailSubject = BOT01.SPrps.BuObjAls + ": " + BOT01.Dr[BOT01.SPrps.SPrpsBOT01Flds.SKeyFieldName].ToString();
            lRptLaunch.DefaultFileName = lDefaultFileName;
            mRptLaunchs.Add(lRptLaunch.ID, lRptLaunch);

            return lRptLaunch;
        }
        #endregion

        #region Form Reuse
        public virtual void InitForReuse()
        {
            //Lyt01Base.RestoreDefaultLayout();
            //mLookUpCombo02Collection.BindAllLists();
            //mLookUpTextBox01Collection.BindList();
            //mValueListCombo02Collection.BindList();
            //mValueListTextBox01Collection.BindList();
            mLookUpCombo02Collection.InitForReuse();
            tmrRowLock.Interval = mRowLockRefreshInterval01;
            tmrRowLock.Enabled = true;
            BOT01.InitForReuse();
        }
        public virtual void FinalizeForReuse()
        {
            //BdsMaster.DataSource = null;
            tmrRowLock.Enabled = false;
            mParentGrid02 = null;
            BOT01.Dt = null;
        }
        #endregion

        #region Child Forms Handling
        public void ReloadParentForm()
        {
            if (mParentGrid02 != null)
            {
                if (mParentGrid02.ParentForm is TForm02)
                {
                    TForm02 lForm02 = (TForm02)mParentGrid02.ParentForm;
                    lForm02.Reload();
                }
                else if (mParentGrid02.ParentForm is TForm01)
                {
                    TForm01 lForm01 = (TForm01)mParentGrid02.ParentForm;
                    lForm01.Reload();
                }
            }
        }
        #endregion

        #endregion
    }
}