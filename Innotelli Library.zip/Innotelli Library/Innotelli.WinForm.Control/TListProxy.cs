using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Reflection;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    public static class TListProxy
    {
        #region Enums
        #endregion

        #region Members
        private static Hashtable mOslLst = null;
        //private TSysDataRdr mSysDataRdr = new TSysDataRdr();
        #endregion

        #region Constructors
        //public TListProxy()
        //{
        //    try
        //    {
        //        mSysDataRdr.DataFolder = ConfigurationManager.AppSettings["SysData01Folder"];
        //        mSysDataRdr.Format = TAppSettings.DefaultSysDataFormat;
        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }
        //}
        #endregion

        #region Properties
        #endregion

        #region Events
        #endregion

        #region Functions

        #region PreLoad Osl List
        public static void LoadLst()
        {
            IDictionaryEnumerator en = null;
            string lKey = null;
            string lVal = null;
            try
            {
                mOslLst = new Hashtable();

                en = OslList().GetEnumerator();
                while (en.MoveNext())
                {
                    lKey = en.Key.ToString();
                    lVal = en.Value.ToString();
                    if (mOslLst.ContainsKey(lKey))
                    {
                        mOslLst[lKey] = GetOslData(lVal);
                    }
                    else
                    {
                        mOslLst.Add(lKey, GetOslData(lVal));
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private static Hashtable OslList()
        {
            Hashtable lRtrnVal = null;
            DataTable lDt = null;
            int lRwCnt = 0;
            try
            {
                lRtrnVal = new Hashtable();
                //lDt = mSysDataRdr.GetSysData("pgmBuObj").Tables[0];
                lRwCnt = lDt.Rows.Count;
                for (int i = 0; i < lRwCnt; i++)
                {
                    if (lDt.Rows[i]["RowSource"] != DBNull.Value)
                    {
                        lRtrnVal.Add(lDt.Rows[i]["BuObjID"].ToString(), lDt.Rows[i]["RowSource"].ToString());
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return lRtrnVal;
        }
        private static DataTable GetOslData(string aVal)
        {
            TSelCboHndlr lSelCboHndlr = null;
            DataTable lRtrnVal = null;
            try
            {
                lSelCboHndlr = new TSelCboHndlr();
                lRtrnVal = lSelCboHndlr.GetDataSource(aVal, "").Tables[0];
            }
            catch (Exception)
            {
                //Return null datatable
            }
            return lRtrnVal;
        }
        #endregion

        #region Get Loaded Osl List
        public static DataTable GetData(string aKey)
        {
            DataTable lRtrnVal = null;
            try
            {
                if (mOslLst.ContainsKey(aKey))
                {
                    lRtrnVal = mOslLst[aKey] as DataTable;
                }
                else
                {
                    lRtrnVal = GetDataByObjID(aKey);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return lRtrnVal;
        }
        private static DataTable GetDataByObjID(string aKey)
        {
            TSelCboHndlr lSelCboHndlr = null;
            DataTable lRtrnVal = null;
            try
            {
                lSelCboHndlr = new TSelCboHndlr();
                lRtrnVal = lSelCboHndlr.GetDataSource(GetRwSrc(aKey), "").Tables[0];
            }
            catch (Exception)
            {
                throw;
            }
            return lRtrnVal;
        }
        #endregion

        #region Get 1 Row 
        public static DataTable GetValueRow(string aObjNm, string aPK)
        {
            TSelCboHndlr lSelCboHndlr = null;
            DataTable lRtrnVal = null;
            try
            {
                lSelCboHndlr = new TSelCboHndlr();
                lRtrnVal = lSelCboHndlr.GetDataSource(GetRwSrc(aObjNm), "where prmykey=" + aPK).Tables[0];
            }
            catch (Exception)
            {
                throw;
            }
            return lRtrnVal;
        }
        public static DataTable GetFullList(string aObjNm, string aPK)
        {
            TSelCboHndlr lSelCboHndlr = null;
            DataTable lRtrnVal = null;
            try
            {
                lSelCboHndlr = new TSelCboHndlr();
                if (aObjNm != "")
                {
                    if ((aPK == null) || (aPK == ""))
                    {
                        lRtrnVal = lSelCboHndlr.GetDataSource(GetRwSrc(aObjNm), "").Tables[0];
                    }
                    else
                    {
                        lRtrnVal = lSelCboHndlr.GetDataSource(GetRwSrc(aObjNm), "where prmykey<>" + aPK).Tables[0];
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return lRtrnVal;
        }
        #endregion

        #region Others
        private static string GetRwSrc(string aKey)
        {
            TBOT01 lObjInstnc = null;
            Assembly lAssembly = null;
            string lExecuteFile = null;
            string[] lID = null;
            string lDllNm = "BackOffice.BO";
            string lRtrnVal = null;
            try
            {
                lExecuteFile = AppDomain.CurrentDomain.BaseDirectory + lDllNm + ".dll";
                lAssembly = System.Reflection.Assembly.LoadFile(lExecuteFile);

                lID = new string[0];
                lObjInstnc = (TBOT01)lAssembly.CreateInstance(lDllNm + "." + aKey, true, BindingFlags.Default | BindingFlags.InvokeMethod, null, lID, null, null);
                lRtrnVal = lObjInstnc.SPrps.RowSource;
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
            return lRtrnVal;
        }
        //private static string GetBOClssNm(string aKey)
        //{
        //    string lRtrnVal = null;
        //    try
        //    {
        //        lRtrnVal = aKey.Replace("dt", "B01");
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception(ex.Message, ex);
        //    }
        //    return lRtrnVal;
        //}
        #endregion

        #endregion
    }
}
