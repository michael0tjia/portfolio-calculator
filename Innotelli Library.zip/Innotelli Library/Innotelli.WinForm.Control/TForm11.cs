using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Innotelli.WinForm.Control;
using Innotelli.BO;
using System.Reflection;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    public partial class TForm11 : DevExpress.XtraEditors.XtraForm
    {
        #region Members
        List<TBOT01> mBOT01s = new List<TBOT01>();
        List<TDataGrid02> mGrd02s = new List<TDataGrid02>();
        #endregion

        #region Constructors
        public TForm11()
        {
            InitializeComponent();
        }
        #endregion

        #region Properties
        private int mIndex;
        public int Index
        {
            get
            {
                return mIndex;
            }
            set
            {
                mIndex = value;
            }
        }

        public TBOT01 BOT01
        {
            get
            {
                return mBOT01s[mIndex];
            }
        }
        public TDataGrid02 Grd02This
        {
            get
            {
                return mGrd02s[mIndex];
            }

        }
        #endregion

        #region Functions
        public void AddBOT01(TBOT01 aBOT01, TDataGrid02 aDataGrid02 )
        {
            mBOT01s.Add(aBOT01);
            mGrd02s.Add(aDataGrid02);
        }
        protected virtual void Init()
        {
            if (Utilities.TGC.IsRunTime)
            {
                for (int i = 0; i < mGrd02s.Count; i++ )
                {
                    mGrd02s[i].BOT01 = mBOT01s[i];
                    mGrd02s[i].ParentForm = this;
                    mGrd02s[i].Init();
                }
            }
        }
        protected virtual void AssignBOToGrids()
        {
        }
        public virtual void LoadData()
        {
            BOT01.LoadDataSet();
        }
        public void Reload()
        {
            if (Utilities.TGC.IsRunTime)
            {
                LoadData();
                BindData();
            }
        }
        protected virtual void BindData()
        {
            Grd02This.BindData();
            OtherBinding();
        }
        protected virtual void OtherBinding()
        {
        }
        #endregion

        private void TForm11_Load(object sender, EventArgs e)
        {
            if (Utilities.TGC.IsRunTime)
            {
                LoadData();
                BindData();
            }
        }

        private void TForm11_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.S && e.Control)
            {
                ((DevExpress.XtraGrid.Views.Base.ColumnView)Grd02This.MainView).SaveLayoutToXml("D:\\" + Grd02This.Name + ".xml", DevExpress.Utils.OptionsLayoutBase.FullLayout);
                e.Handled = true;
            }
        }
        //((DevExpress.XtraGrid.Views.Base.ColumnView)Grd02This.MainView).SaveLayoutToXml("D:\\" + Grd02This.Name + ".xml", DevExpress.Utils.OptionsLayoutBase.FullLayout);

    }
}