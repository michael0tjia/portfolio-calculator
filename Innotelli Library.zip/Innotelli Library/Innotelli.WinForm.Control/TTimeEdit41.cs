﻿using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.ViewInfo;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterTimeEdit41")]
    public class RepositoryItemTimeEdit41 : RepositoryItemTextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemTimeEdit41() { RegisterTimeEdit41(); }

        //The unique name for the custom editor
        public const string TimeEdit41Name = "TTimeEdit41";

        //Return the unique name
        public override string EditorTypeName { get { return TimeEdit41Name; } }

        //Register the editor
        public static void RegisterTimeEdit41()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.TimeEdit41.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(TimeEdit41Name,
              typeof(TTimeEdit41), typeof(RepositoryItemTimeEdit41),
              typeof(TextEditViewInfo), new TextEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemTimeEdit41 source = item as RepositoryItemTimeEdit41;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }

        #endregion

        #region Members
        #endregion

        #region Constructors
        public RepositoryItemTimeEdit41()
        {
        }
        #endregion

        #region Properties
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        DSFormMode mDSFormMode = DSFormMode.DSEditable;
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        break;
                    case DSFormMode.DSEditable:
                        break;
                    case DSFormMode.DSInsert:
                        break;
                }
                mDSFormMode = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Init()
        {
            AllowFocused = false;
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            Appearance.Options.UseBackColor = true;
            AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            AppearanceReadOnly.Options.UseBackColor = true;
            DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            DisplayFormat.FormatString = TSettings.TimeFormat;
            //EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            //EditFormat.FormatString = TSettings.TimeFormat;
            Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTime;
            Mask.EditMask = TSettings.TimeFormat;
            //Mask.EditMask = resources.GetString("RepositoryItemTimeEdit41.Mask.EditMask");
            //Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("RepositoryItemTimeEdit41.Mask.MaskType")));
            //Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("RepositoryItemTimeEdit41.Mask.UseMaskAsDisplayFormat")));
            ReadOnly = true;
        }

        #endregion
    }

    public class TTimeEdit41 : TextEdit
    {
        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static TTimeEdit41() { RepositoryItemTimeEdit41.RegisterTimeEdit41(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemTimeEdit41.TimeEdit41Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemTimeEdit41 Properties
        {
            get { return base.Properties as RepositoryItemTimeEdit41; }
        }
        #endregion

        #region Members
        private string mFormat = TSettings.TimeFormat;
        #endregion

        #region Constructors


        //Initialize the new instance
        public TTimeEdit41()
        {
            Init();
        }
        #endregion

        #region Properties
        [Bindable(true),
        Category("Behavior"),
        DefaultValue("hh:mm tt"),
        Description("Indicates the time format."),
        Localizable(true)]
        public string Format
        {
            get
            {
                return mFormat;
            }
            set
            {
                mFormat = value;
            }
        }
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(60, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }

        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            EditValue = null;
            Margin = new System.Windows.Forms.Padding(0);
            TabStop = false;
        }
        #endregion
    }
}