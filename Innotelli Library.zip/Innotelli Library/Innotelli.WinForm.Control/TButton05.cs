using System;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.ViewInfo;
using Innotelli.BO;
using Innotelli.Utilities;
using DevExpress.XtraEditors.Controls;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterButton05")]
    public class RepositoryItemButton05 : RepositoryItemButtonEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemButton05() { RegisterButton05(); }

        //The unique name for the custom editor
        public const string Button05Name = "TButton05";

        //Return the unique name
        public override string EditorTypeName { get { return Button05Name; } }

        //Register the editor
        public static void RegisterButton05()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.Button05.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(Button05Name,
              typeof(TButton05), typeof(RepositoryItemButton05),
              typeof(ButtonEditViewInfo), new ButtonEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemButton05 source = item as RepositoryItemButton05;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public RepositoryItemButton05()
        {
        }
        #endregion

        #region Properties
        private string mBOID = "";
        public string BOID
        {
            get
            {
                return mBOID;
            }
            set
            {
                mBOID = value;
                OnPropertiesChanged();
            }
        }

        private TBOT01 mBOT01;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
            }
        }

        private TDataGrid02 mOwnerGrid;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TDataGrid02 OwnerGrid
        {
            get
            {
                return mOwnerGrid;
            }
            set
            {
                mOwnerGrid = value;
            }
        }

        private Form mParentForm;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Form ParentForm
        {
            get
            {
                return mParentForm;
            }
            set
            {
                mParentForm = value;
            }
        }
        #endregion

        #region Event Handlers
        private void RepositoryItemButton05_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            TForm02 lForm02 = null;
            string lPK = string.Empty;
            TDataGrid02 lParentGrid02 = null;

            lParentGrid02 = (TDataGrid02)OwnerGrid;
            // Lok: foucs the child form if child is alredy open
            if (lParentGrid02.BOT01.Dr.Row != null && !TNull.IsValueNull(lParentGrid02.BOT01.Dr[Innotelli.Utilities.TGC.PKeyName]))
            {
                lPK = lParentGrid02.BOT01.Dr[Innotelli.Utilities.TGC.PKeyName].ToString();
                if (lPK != string.Empty)
                {
                    if (!lParentGrid02.ChildForm02s.ContainsKey(lPK))
                    {
                        lForm02 = TSingletons.Form02Pool.GetForm(Innotelli.BO.TSingletons.SPrpsBOT01s[BOID].DefaultForm02Name);
                        if (lForm02 != null)
                        {
                            lForm02.LoadByPK(lPK);
                            lParentGrid02.AddChildForm(lForm02);
                            lForm02.DSUpdateFormState();
                            lForm02.Show();
                            lForm02.Focus();
                            lForm02.WindowState = FormWindowState.Normal;
                        }
                    }
                    else
                    {
                        lParentGrid02.ChildForm02s[lPK].Focus();
                        lParentGrid02.ChildForm02s[lPK].WindowState = FormWindowState.Normal;
                    }
                }
            }
        }
        //private void RepositoryItemButton05_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        //{
        //    TButton05 lButton05 = (sender as TButton05);
        //    TForm02 lForm02 = null;
        //    string lPK = string.Empty;
        //    Type lPrntFrmBsTp = mParentForm.GetType().BaseType;
        //    string lParentFormBasicType = mParentForm.GetType().BaseType.Name;

        //    if (!TNull.IsValueNull(lButton05.EditValue))
        //    {
        //        lPK = lButton05.EditValue.ToString();
        //        if (lPK != string.Empty)
        //        {
        //            if (lParentFormBasicType == "TForm02" && ((TForm02)mParentForm).ChildForm02s.ContainsKey(lPK))
        //            {
        //                lForm02 = ((TForm02)mParentForm).ChildForm02s[lPK];
        //                lForm02.Show();
        //                lForm02.Focus();
        //                lForm02.WindowState = FormWindowState.Normal;
        //            }
        //            else
        //            {
        //                lForm02 = TSingletons.Form02Pool.GetForm(Innotelli.BO.TSingletons.SPrpsBOT01s[BOID].DefaultForm02Name);
        //                if (lForm02 != null)
        //                {
        //                    lForm02.BOT01.Dt = mBOT01.Dt;
        //                    lForm02.BOT01.PK2 = lPK;
        //                    lForm02.BOT01.GotoRowByPK(lPK);
        //                    lForm02.JustShow();
        //                    lForm02.LoadByPK(lPK);
        //                    lForm02.DsMode = ((lPrntFrmBsTp)mParentForm).DsMode;
        //                    lForm02.ShowDialog();
        //                    ((lPrntFrmBsTp)mParentForm).Reload();
        //                    switch (lParentFormBasicType)
        //                    {
        //                        case "TForm02":
        //                            TODO: Button05 Open
        //                            ((TForm02)mParentForm).AddChildForm(lForm02);
        //                            break;
        //                        case "TForm07":
        //                            lForm02.BOT01.FK = ((TForm07)mParentForm).BOT01.PrmyKey;
        //                            lForm02.DsMode = ((TForm07)mParentForm).DsMode;
        //                            break;
        //                        case "TForm12":
        //                            lForm02.BOT01.FK = ((TForm12)mParentForm).BOT01.PrmyKey;
        //                            lForm02.DsMode = ((TForm12)mParentForm).DsMode;
        //                            break;
        //                        case "TForm01":
        //                            lForm02.BOT01.FK = ((TForm01)mParentForm).BOT01.prmykey2;
        //                            lForm02.DsMode = ((TForm01)mParentForm).DsMode;
        //                            break;
        //                        case "TForm06":
        //                            lForm02.BOT01.FK = ((TForm06)mParentForm).BOT01.PrmyKey;
        //                            lForm02.DsMode = ((TForm06)mParentForm).DsMode;
        //                            break;
        //                    }
        //                    lForm02.DSUpdateFormState();
        //                    lForm02.MdiParent = null;
        //                    lForm02.Show();
        //                    lForm02.Focus();
        //                    lForm02.WindowState = FormWindowState.Normal;
        //                    lForm02.ShowDialog();
        //                    if (lForm02.DialogResult == DialogResult.Cancel)
        //                    {
        //                        mOwnerGrid.BOT01.LoadDataSet();
        //                        mOwnerGrid.BindData();
        //                        mOwnerGrid.BOT01.IsDirty = true;
        //                    }
        //                }
        //            }
        //        }
        //    }
        //}
        #endregion

        #region Functions
        public void Init()
        {
            Image img = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TButton05.Button.png"));
            Buttons[0].Kind = DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph;
            Buttons[0].Image = img;
            Buttons[0].IsLeft = true;
            Buttons[0].Width = 10;
            BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            AssignEventHandlers();
        }
        private void AssignEventHandlers()
        {
            ButtonClick += RepositoryItemButton05_ButtonClick;
        }
        public virtual void OpenDetails()
        {
            RepositoryItemButton05_ButtonClick(this, null);
        }
        #endregion
    }

    public class TButton05 : ButtonEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TButton05() { RepositoryItemButton05.RegisterButton05(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemButton05.Button05Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemButton05 Properties
        {
            get { return base.Properties as RepositoryItemButton05; }
        }
        #endregion

        #region Members
        //bool mBorderStyleIsModified = false;
        #endregion

        #region Constructors
        public TButton05()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(19, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(19, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}
