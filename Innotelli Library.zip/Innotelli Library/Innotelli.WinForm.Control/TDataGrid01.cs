using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Registrator;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Base.Handler;
using DevExpress.XtraGrid.Views.Base.ViewInfo;
using DevExpress.XtraGrid.Views.Grid.Handler;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using DevExpress.XtraGrid.Views.BandedGrid;
using DevExpress.XtraGrid.Views.BandedGrid.ViewInfo;
using DevExpress.XtraGrid.Views.BandedGrid.Handler;
using DevExpress.Utils.Serializing;
using Innotelli.BO;
using Innotelli.Utilities;
using DevExpress.Utils.Menu;
using DevExpress.XtraEditors.Repository;
using System.Reflection;
using Innotelli.Db;

namespace Innotelli.WinForm.Control
{
    #region Grid Classes
    public class TDataGrid01 : GridControl
    {
        #region Enums

        #endregion

        #region Members
        //#check! don't know what it is
        private bool mEditable = true;
        private bool mHasOpnDtlCol = false;
        private bool mHasAddNewHdrBtn = false;
        private bool mIsLocked = false;
        private ColumnView mGv = null;
        private DataSet mDs = null;
        private DSFormMode mDSFormMode = DSFormMode.DSEditable;
        private Form mParentForm;
        private string mType = "";
        private TBOT01 mBOT01 = null;
        private TGridView01 mGridView01 = null;
        private TBandedGridView01 mBandedGridView01 = null;
        private TAdvBandedGridView01 mAdvBandedGridView01 = null;
        private DevExpress.Utils.ImageCollection mImageCollection = new DevExpress.Utils.ImageCollection();
        #endregion

        #region Constructors
        public TDataGrid01()
        {
            InitImageCollection();
        }
        #endregion

        #region Properties
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
            }
        }
        // #check!
        // don't know what it is
        public bool Editable
        {
            get
            {
                return mEditable;
            }
            set
            {
                mEditable = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                NewItemRowPosition lNewItemRowPosition = NewItemRowPosition.Bottom;

                if (value)
                {
                    lNewItemRowPosition = NewItemRowPosition.None;
                }
                switch (mType)
                {
                    case "TGridView01":
                        mGridView01.OptionsView.NewItemRowPosition = lNewItemRowPosition;
                        break;
                    case "TBandedGridView01":
                        mBandedGridView01.OptionsView.NewItemRowPosition = lNewItemRowPosition;
                        break;
                    case "TAdvBandedGridView01":
                        mAdvBandedGridView01.OptionsView.NewItemRowPosition = lNewItemRowPosition;
                        break;
                }

                SetAllColumnsIsLockedVal(value);
                this.TabStop = !value;
                mIsLocked = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                NewItemRowPosition lNewItemRowPosition = NewItemRowPosition.None;

                mDSFormMode = value;
                if (!BOT01.DataRight.AllowEdit)
                {
                    mDSFormMode = DSFormMode.DSBrowse;
                }
                if (mDSFormMode != DSFormMode.DSBrowse && BOT01.DataRight.AllowAdd)
                {
                    lNewItemRowPosition = NewItemRowPosition.Bottom;
                }
                switch (mType)
                {
                    case "TGridView01":
                        mGridView01.OptionsView.NewItemRowPosition = lNewItemRowPosition;
                        break;
                    case "TBandedGridView01":
                        mBandedGridView01.OptionsView.NewItemRowPosition = lNewItemRowPosition;
                        break;
                    case "TAdvBandedGridView01":
                        mAdvBandedGridView01.OptionsView.NewItemRowPosition = lNewItemRowPosition;
                        break;
                }
                SetAllColumnsDSFormModeVal(mDSFormMode);
                SetAllColumnsReadOnlyVal();
            }
        }
        public bool HasOpnDtlCol
        {
            get
            {
                return mHasOpnDtlCol;
            }
            set
            {
                mHasOpnDtlCol = value;
            }
        }
        public bool HasAddNewHdrBtn
        {
            get
            {
                return mHasAddNewHdrBtn;
            }
            set
            {
                mHasAddNewHdrBtn = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Form ParentForm
        {
            get
            {
                return mParentForm;
            }
            set
            {
                mParentForm = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions

        #region GridView Related
        protected override BaseView CreateDefaultView()
        {
            return CreateView("TGridView01");
        }
        protected override void RegisterAvailableViewsCore(InfoCollection collection)
        {
            base.RegisterAvailableViewsCore(collection);
            collection.Add(new TGridViewInfoRegistrator01());
            collection.Add(new TBandedGridViewInfoRegistrator01());
            collection.Add(new TAdvBandedGridViewInfoRegistrator01());
        }
        #endregion

        public void Init()
        {

            if (Utilities.TGC.IsRunTime)
            {

                mDs = Innotelli.BO.TSingletons.BOT01FldDs;
                if (mDs != null)
                {
                    mGv = (ColumnView)MainView;
                    mGv.OptionsSelection.MultiSelect = true;
                    mType = MainView.GetType().Name;

                    switch (mType)
                    {
                        case "TGridView01":
                            mGridView01 = (TGridView01)MainView;
                            mGridView01.Init();
                            break;
                        case "TBandedGridView01":
                            mBandedGridView01 = (TBandedGridView01)MainView;
                            mBandedGridView01.Init();
                            break;
                        case "TAdvBandedGridView01":
                            mAdvBandedGridView01 = (TAdvBandedGridView01)MainView;
                            mAdvBandedGridView01.Init();
                            break;
                    }
                    SetAllColumnsReadOnlyVal();
                    SetColumnFormat();
                    AssignInPlaceEditors();
                }
            }
            //LoadLayout();

        }
        public void BindData()
        {
            if (mBOT01 != null)
            {
                DataSource = mBOT01.DefaultView;
            }
        }
        protected virtual void InitImageCollection()
        {
            Image lImage = null;

            lImage = Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TDataGrid01.Button.png"));
            mImageCollection.AddImage(lImage);
        }
        private void SetAllColumnsReadOnlyVal()
        {
            string lFldNm = "";


            for (int i = 0; i < mGv.Columns.Count; i++)
            {
                lFldNm = mGv.Columns[i].FieldName.ToString();
                // The else case should be not done.
                if (IsReadOnly(lFldNm))
                {
                    mGv.Columns[i].OptionsColumn.ReadOnly = true;
                }
                if (mGv.Columns[i].OptionsColumn.ReadOnly)
                {
                    mGv.Columns[i].AppearanceCell.BackColor = Color.FromArgb(255, 255, 192);
                }

            }

        }
        private void SetAllColumnsDSFormModeVal(DSFormMode aDSFormMode)
        {
            RepositoryItem lRepositoryItem = null;
            PropertyInfo lPropertyInfo = null;

            for (int i = 0; i < mGv.Columns.Count; i++)
            {
                // No need to consider "Read Only Data Column"
                if (!mGv.Columns[i].OptionsColumn.ReadOnly && mGv.Columns[i].ColumnEdit != null)
                {
                    // Use reflection
                    lRepositoryItem = mGv.Columns[i].ColumnEdit;
                    lPropertyInfo = lRepositoryItem.GetType().GetProperty("DSFormMode");
                    if (lPropertyInfo != null)
                    {
                        lPropertyInfo.SetValue(lRepositoryItem, aDSFormMode, null);
                    }
                }
            }
        }
        private void SetAllColumnsIsLockedVal(bool aIsLocked)
        {
            RepositoryItem lRepositoryItem = null;
            PropertyInfo lPropertyInfo = null;

            for (int i = 0; i < mGv.Columns.Count; i++)
            {
                if (mGv.Columns[i].ColumnEdit != null)
                {
                    // Use reflection
                    lRepositoryItem = mGv.Columns[i].ColumnEdit;
                    lPropertyInfo = lRepositoryItem.GetType().GetProperty("IsLocked");
                    if (lPropertyInfo != null)
                    {
                        lPropertyInfo.SetValue(lRepositoryItem, aIsLocked, null);
                    }
                }
            }
        }
        private bool IsReadOnly(string aFldNm)
        {
            bool lRtrnVal = false;
            DataView lDv = null;

            lDv = new DataView();

            lDv.Table = mDs.Tables[0];
            lDv.RowFilter = "BuObjID = '" + BOT01.BOID + "' AND FldNm = '" + aFldNm + "'";
            if (lDv.Count != 0)
            {
                if (!(lDv[0]["SelObjID"] != null && lDv[0]["SelObjID"].ToString() != ""))
                {
                    if (lDv[0]["OrgFldType"] != null)
                    {
                        if (lDv[0]["OrgFldType"].ToString() == "ITEM NUMBER")
                        {
                            lRtrnVal = true;
                        }
                        else
                        {
                            if (lDv[0]["Cat4"] != null)
                            {
                                if (lDv[0]["Cat4"].ToString() != "Normal")
                                {
                                    lRtrnVal = true;
                                }
                            }
                        }
                    }
                }
            }

            return lRtrnVal;
        }
        private void SetColumnFormat()
        {
            int lClmnCnt = mGv.Columns.Count;
            string lFldNm = "";
            string lFldTp = "";
            string lOrgFldTp = "";

            for (int i = 0; i < lClmnCnt; i++)
            {
                lFldNm = mGv.Columns[i].FieldName.ToString();
                if (IsNumeric(lFldNm, out lFldTp, out lOrgFldTp))
                {
                    #region Numeric Columns
                    StyleFormatCondition lStyleFormatCondition = new StyleFormatCondition();
                    lStyleFormatCondition.Appearance.ForeColor = Color.Red;
                    lStyleFormatCondition.Appearance.Options.UseForeColor = true;
                    lStyleFormatCondition.Appearance.Options.HighPriority = true;
                    //lStyleFormatCondition.ApplyToRow = false;
                    lStyleFormatCondition.Column = mGv.Columns[i];
                    lStyleFormatCondition.Condition = FormatConditionEnum.Less;
                    lStyleFormatCondition.Value1 = 0;
                    MainView.FormatConditions.Add(lStyleFormatCondition);

                    mGv.Columns[i].AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
                    mGv.Columns[i].DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
                    mGv.Columns[i].RealColumnEdit.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
                    switch (lFldTp)
                    {
                        case "CURRENCY":
                            mGv.Columns[i].DisplayFormat.FormatString = TSettings.CurFormat;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = TSettings.CurFormat;
                            if (mGv.Columns[i].SummaryItem.DisplayFormat == "")
                            {
                                mGv.Columns[i].SummaryItem.DisplayFormat = "{0:" + TSettings.CurFormat + "}";
                            }
                            break;
                        case "DECIMAL":
                        case "DOUBLE":
                        case "SINGLE":
                            mGv.Columns[i].DisplayFormat.FormatString = TSettings.DecFormat;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = TSettings.DecFormat;
                            if (mGv.Columns[i].SummaryItem.DisplayFormat == "")
                            {
                                mGv.Columns[i].SummaryItem.DisplayFormat = "{0:" + TSettings.DecFormat + "}";
                            }
                            break;
                        case "BYTE":
                        case "COUNTER":
                        case "INTEGER":
                        case "LONG":
                        case "SHORT":
                            mGv.Columns[i].DisplayFormat.FormatString = TSettings.IntFormat;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = TSettings.IntFormat;
                            if (mGv.Columns[i].SummaryItem.DisplayFormat == "")
                            {
                                mGv.Columns[i].SummaryItem.DisplayFormat = "{0:" + TSettings.IntFormat + "}";
                            }
                            break;
                        default:
                            break;
                    }
                    #endregion
                }
                else
                {
                    if (lFldTp == "DATETIME")
                    {
                        #region DateTime Columns
                        mGv.Columns[i].DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
                        mGv.Columns[i].RealColumnEdit.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
                        switch (lOrgFldTp)
                        {
                            case "DATE":
                                mGv.Columns[i].DisplayFormat.FormatString = TSettings.DateFormat;
                                mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = TSettings.DateFormat;
                                if (mGv.Columns[i].SummaryItem.DisplayFormat == "")
                                {
                                    mGv.Columns[i].SummaryItem.DisplayFormat = "{0:" + TSettings.DateFormat + "}";
                                }
                                break;
                            case "TIME":
                                mGv.Columns[i].DisplayFormat.FormatString = TSettings.TimeFormat;
                                mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = TSettings.TimeFormat;
                                if (mGv.Columns[i].SummaryItem.DisplayFormat == "")
                                {
                                    mGv.Columns[i].SummaryItem.DisplayFormat = "{0:" + TSettings.TimeFormat + "}";
                                }
                                break;
                            default:
                                mGv.Columns[i].DisplayFormat.FormatString = TSettings.DateFormat + " " + TSettings.TimeFormat;
                                mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = TSettings.DateFormat + " " + TSettings.TimeFormat;
                                if (mGv.Columns[i].SummaryItem.DisplayFormat == "")
                                {
                                    mGv.Columns[i].SummaryItem.DisplayFormat = "{0:" + TSettings.DateFormat + " " + TSettings.TimeFormat + "}";
                                }
                                break;
                        }
                        #endregion
                    }
                }
            }
        }

        #region Inplace Editing
        private bool IsNumeric(string aFldNm, out string aFldTp, out string aOrgFldTp)
        {
            bool lRtrnVal = false;
            aFldTp = "";
            aOrgFldTp = "";
            DataView lDv = null;

            lDv = new DataView();
            lDv.Table = mDs.Tables[0];
            lDv.RowFilter = "BuObjID='" + BOT01.BOID + "' AND FldNm='" + aFldNm + "'";
            if (lDv.Count != 0)
            {
                if (!(lDv[0]["SelObjID"] != null && lDv[0]["SelObjID"].ToString() != ""))
                {
                    if (lDv[0]["OrgFldType"] != null)
                    {
                        aOrgFldTp = lDv[0]["OrgFldType"].ToString();
                    }
                    if (aOrgFldTp != "VALUELIST")
                    {
                        if (lDv[0]["FldType"] != null)
                        {
                            aFldTp = lDv[0]["FldType"].ToString();
                            if (aFldTp == "BYTE" || aFldTp == "COUNTER" || aFldTp == "INTEGER" || aFldTp == "LONG" || aFldTp == "SHORT" || aFldTp == "CURRENCY" || aFldTp == "DECIMAL" || aFldTp == "DOUBLE" || aFldTp == "SINGLE")
                            {
                                lRtrnVal = true;
                            }
                        }
                    }
                }
            }

            return lRtrnVal;
        }
        private bool IsDateTime(string aFldNm, out string aFldTp, out string aOrgFldTp)
        {
            bool lRtrnVal = false;
            aFldTp = "";
            aOrgFldTp = "";
            DataView lDv = null;

            lDv = new DataView();
            lDv.Table = mDs.Tables[0];
            lDv.RowFilter = "BuObjID='" + BOT01.BOID + "' AND FldNm='" + aFldNm + "'";
            if (lDv.Count != 0)
            {
                if (lDv[0]["FldType"] != null)
                {
                    aFldTp = lDv[0]["FldType"].ToString();
                    if (aFldTp == "DATETIME")
                    {
                        if (lDv[0]["OrgFldType"] != null)
                        {
                            aOrgFldTp = lDv[0]["OrgFldType"].ToString();
                        }
                        lRtrnVal = true;
                    }
                }
            }

            return lRtrnVal;
        }
        private void AssignInPlaceEditors()
        {
            int lClmnCnt = mGv.Columns.Count;
            int lIdxOfSemiColon = -1;
            int lValLstBndCol = 1;
            string lCtrlNm = "";
            string lFldNm = "";
            string lFldTp = "";
            string lOrgFldTp = "";
            string lSelObjID = "";
            string lTag = "";

            for (int i = 0; i < lClmnCnt; i++)
            {
                if (mGv.Columns[i].Tag != null)
                {
                    #region By Tag Specified
                    lTag = mGv.Columns[i].Tag.ToString();
                    lIdxOfSemiColon = lTag.IndexOf(";");
                    if (lIdxOfSemiColon == -1)
                    {
                        lCtrlNm = lTag;
                    }
                    else
                    {
                        lCtrlNm = TStr.Left(lTag, lIdxOfSemiColon);
                    }
                    switch (lCtrlNm)
                    {
                        case "TTextBox08":
                            RepositoryItemTextBox08 lRepositoryItemTextBox08 = new RepositoryItemTextBox08();
                            lRepositoryItemTextBox08.Init();
                            lRepositoryItemTextBox08.BOID = lTag.Substring(lIdxOfSemiColon + 1);
                            RepositoryItems.Add(lRepositoryItemTextBox08);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemTextBox08;
                            mGv.Columns[i].ShowButtonMode = ShowButtonModeEnum.ShowAlways;
                            break;
                        case "TMemoBoxEx01":
                            RepositoryItemMemoBoxEx01 lRepositoryItemMemoBoxEx01 = new RepositoryItemMemoBoxEx01();
                            lRepositoryItemMemoBoxEx01.Init();
                            lRepositoryItemMemoBoxEx01.Buttons[0].Visible = false;
                            RepositoryItems.Add(lRepositoryItemMemoBoxEx01);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemMemoBoxEx01;
                            break;
                        default:
                            break;
                    }
                    #endregion
                }
                else
                {
                    lFldNm = mGv.Columns[i].FieldName.ToString();
                    if (IsLookUpComboData(lFldNm, out lSelObjID, out lFldTp, out lOrgFldTp, out lValLstBndCol))
                    {
                        #region LookUpCombo
                        if (mGv.Columns[i].ReadOnly)
                        {
                            RepositoryItemLookupTextBox01 lRepositoryItemLookupTextBox01 = new RepositoryItemLookupTextBox01();
                            lRepositoryItemLookupTextBox01.BndCol = 0;
                            lRepositoryItemLookupTextBox01.BOID = lSelObjID;
                            lRepositoryItemLookupTextBox01.Init();
                            lRepositoryItemLookupTextBox01.BindList();
                            RepositoryItems.Add(lRepositoryItemLookupTextBox01);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemLookupTextBox01;
                        }
                        else
                        {
                            RepositoryItemLookupCombo02 lRepositoryItemLookupCombo02 = new RepositoryItemLookupCombo02();
                            lRepositoryItemLookupCombo02.BndCol = 0;
                            lRepositoryItemLookupCombo02.BOID = lSelObjID;
                            lRepositoryItemLookupCombo02.Init();
                            lRepositoryItemLookupCombo02.BindList();
                            RepositoryItems.Add(lRepositoryItemLookupCombo02);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemLookupCombo02;
                            mGv.Columns[i].ShowButtonMode = ShowButtonModeEnum.ShowAlways;
                        }
                        #endregion
                    }
                    else
                    {
                        #region By Data Type
                        switch (lOrgFldTp)
                        {
                            case "DATE":
                                if (mGv.Columns[i].ReadOnly)
                                {
                                    RepositoryItemDateTextBox02 lRepositoryItemDateTextBox02 = new RepositoryItemDateTextBox02();
                                    lRepositoryItemDateTextBox02.Init();
                                    RepositoryItems.Add(lRepositoryItemDateTextBox02);
                                    mGv.Columns[i].ColumnEdit = lRepositoryItemDateTextBox02;
                                }
                                else
                                {
                                    RepositoryItemDateEditor02 lRepositoryItemDateEditor02 = new RepositoryItemDateEditor02();
                                    lRepositoryItemDateEditor02.Init();
                                    lRepositoryItemDateEditor02.CreateDefaultButton();
                                    RepositoryItems.Add(lRepositoryItemDateEditor02);
                                    mGv.Columns[i].ColumnEdit = lRepositoryItemDateEditor02;
                                }
                                break;
                            case "TIME":
                                if (mGv.Columns[i].ReadOnly)
                                {
                                    RepositoryItemTimeTextBox02 lRepositoryItemTimeTextBox02 = new RepositoryItemTimeTextBox02();
                                    lRepositoryItemTimeTextBox02.Init();
                                    RepositoryItems.Add(lRepositoryItemTimeTextBox02);
                                    mGv.Columns[i].ColumnEdit = lRepositoryItemTimeTextBox02;
                                }
                                else
                                {
                                    RepositoryItemTimeEditor02 lRepositoryItemTimeEditor02 = new RepositoryItemTimeEditor02();
                                    lRepositoryItemTimeEditor02.CreateDefaultButton();
                                    lRepositoryItemTimeEditor02.Init();
                                    RepositoryItems.Add(lRepositoryItemTimeEditor02);
                                    mGv.Columns[i].ColumnEdit = lRepositoryItemTimeEditor02;
                                }
                                break;
                            case "VALUELIST":
                                if (mGv.Columns[i].ReadOnly)
                                {
                                    RepositoryItemValueListTextBox01 lRepositoryItemValueListTextBox01 = new RepositoryItemValueListTextBox01();
                                    lRepositoryItemValueListTextBox01.BndCol = lValLstBndCol - 1;
                                    lRepositoryItemValueListTextBox01.Init(BOT01.BOID);
                                    lRepositoryItemValueListTextBox01.BindList(lFldNm);
                                    RepositoryItems.Add(lRepositoryItemValueListTextBox01);
                                    mGv.Columns[i].ColumnEdit = lRepositoryItemValueListTextBox01;
                                }
                                else
                                {
                                    RepositoryItemValueListCombo02 lRepositoryItemValueListCombo02 = new RepositoryItemValueListCombo02();
                                    lRepositoryItemValueListCombo02.BndCol = lValLstBndCol - 1;
                                    lRepositoryItemValueListCombo02.Init(BOT01.BOID);
                                    lRepositoryItemValueListCombo02.BindList(lFldNm);
                                    RepositoryItems.Add(lRepositoryItemValueListCombo02);
                                    mGv.Columns[i].ColumnEdit = lRepositoryItemValueListCombo02;
                                    mGv.Columns[i].ShowButtonMode = ShowButtonModeEnum.ShowAlways;

                                }
                                break;
                            default:
                                switch (lFldTp)
                                {
                                    case "BIT":
                                        RepositoryItemCheckBox03 lRepositoryItemCheckBox03 = new RepositoryItemCheckBox03();
                                        lRepositoryItemCheckBox03.Init();
                                        RepositoryItems.Add(lRepositoryItemCheckBox03);
                                        mGv.Columns[i].ColumnEdit = lRepositoryItemCheckBox03;
                                        break;
                                    case "CURRENCY":
                                        RepositoryItemCurrencyTextBox03 lRepositoryItemCurrencyTextBox03 = new RepositoryItemCurrencyTextBox03();
                                        lRepositoryItemCurrencyTextBox03.Init();
                                        RepositoryItems.Add(lRepositoryItemCurrencyTextBox03);
                                        mGv.Columns[i].ColumnEdit = lRepositoryItemCurrencyTextBox03;
                                        break;
                                    case "DECIMAL":
                                    case "DOUBLE":
                                    case "SINGLE":
                                        RepositoryItemDecimalTextBox03 lRepositoryItemDecimalTextBox03 = new RepositoryItemDecimalTextBox03();
                                        lRepositoryItemDecimalTextBox03.Init();
                                        RepositoryItems.Add(lRepositoryItemDecimalTextBox03);
                                        mGv.Columns[i].ColumnEdit = lRepositoryItemDecimalTextBox03;
                                        break;
                                    case "BYTE":
                                    case "COUNTER":
                                    case "INTEGER":
                                    case "LONG":
                                    case "SHORT":
                                        RepositoryItemIntegerTextBox03 lRepositoryItemIntegerTextBox03 = new RepositoryItemIntegerTextBox03();
                                        lRepositoryItemIntegerTextBox03.Init();
                                        RepositoryItems.Add(lRepositoryItemIntegerTextBox03);
                                        mGv.Columns[i].ColumnEdit = lRepositoryItemIntegerTextBox03;
                                        break;
                                    case "MEMO":
                                        RepositoryItemMemoBoxEx01 lRepositoryItemMemoBoxEx01 = new RepositoryItemMemoBoxEx01();
                                        lRepositoryItemMemoBoxEx01.Init();
                                        lRepositoryItemMemoBoxEx01.Buttons[0].Visible = false;
                                        RepositoryItems.Add(lRepositoryItemMemoBoxEx01);
                                        mGv.Columns[i].ColumnEdit = lRepositoryItemMemoBoxEx01;
                                        break;
                                    case "TEXT":
                                        RepositoryItemTextBox04 lRepositoryItemTextBox04 = new RepositoryItemTextBox04();
                                        lRepositoryItemTextBox04.Init(mBOT01);
                                        RepositoryItems.Add(lRepositoryItemTextBox04);
                                        mGv.Columns[i].ColumnEdit = lRepositoryItemTextBox04;
                                        break;
                                    default:
                                        break;
                                }
                                break;
                        }
                        #endregion
                    }

                    if (mGv.Columns[i].ColumnEdit != null)
                    {
                        mGv.Columns[i].ColumnEdit.ReadOnly = mGv.Columns[i].ReadOnly;
                    }
                }
            }

            if (mHasOpnDtlCol)
            {
                GridColumn lOpnDtlCol = mGv.Columns.AddField(Utilities.TGC.PKeyName);
                RepositoryItemButton07 lRepositoryItemButton07 = new RepositoryItemButton07();
                lRepositoryItemButton07.Init();
                lRepositoryItemButton07.BOID = BOT01.BOID;
                lRepositoryItemButton07.BOT01 = BOT01;
                lRepositoryItemButton07.OwnerGrid = this;
                lRepositoryItemButton07.ParentForm = mParentForm;
                RepositoryItems.Add(lRepositoryItemButton07);
                lOpnDtlCol.ColumnEdit = lRepositoryItemButton07;
                lOpnDtlCol.Caption = "";
                lOpnDtlCol.CustomizationCaption = "Open Details (Button)";
                lOpnDtlCol.Fixed = FixedStyle.Left;
                lOpnDtlCol.MinWidth = 22;
                lOpnDtlCol.Width = 22;
                lOpnDtlCol.ShowButtonMode = ShowButtonModeEnum.ShowAlways;
                lOpnDtlCol.VisibleIndex = 0;
                //if (mHasAddNewHdrBtn)
                //{
                //Image lImg = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TDataGrid01.Button.png"));
                //lOpnDtlCol.AppearanceHeader.Image = lImg;
                mGv.Images = mImageCollection;
                lOpnDtlCol.ImageIndex = 0;
                lOpnDtlCol.ImageAlignment = StringAlignment.Center;
                //mGv.InvalidateRect(lOpnDtlCol);
                //}
            }
        }
        private bool IsLookUpComboData(string aFldNm, out string aSelObjID, out string aFldTp, out string aOrgFldTp, out int aValLstBndCol)
        {
            bool lRtrnVal = false;
            DataView lDv = null;
            aFldTp = "";
            aOrgFldTp = "";
            aSelObjID = "";
            aValLstBndCol = 1;

            lDv = new DataView();
            lDv.Table = mDs.Tables[0];
            lDv.RowFilter = "BuObjID='" + BOT01.BOID + "' AND FldNm='" + aFldNm + "'";
            if (lDv.Count != 0)
            {
                if (lDv[0]["OrgFldType"] != null)
                {
                    aOrgFldTp = lDv[0]["OrgFldType"].ToString();
                }
                if (lDv[0]["FldType"] != null)
                {
                    aFldTp = lDv[0]["FldType"].ToString();
                }
                if (lDv[0]["SelObjID"] != null && lDv[0]["SelObjID"].ToString() != "")
                {
                    aSelObjID = lDv[0]["SelObjID"].ToString();
                    lRtrnVal = true;
                }
                aValLstBndCol = (int)lDv[0]["ValLstBndCol"];
            }

            return lRtrnVal;
        }
        #endregion

        #region Layout Load and Save
        private void SaveLayout()
        {
            //TGrdLyt02 lGrdLyt02 = null;

            //lGrdLyt02 = new TGrdLyt02();
            //lGrdLyt02.UserPK = "1";
            //lGrdLyt02.SaveLayout(this, true);

        }
        private void LoadLayout()
        {
            //TGrdLyt02 lGrdLyt02 = null;

            //lGrdLyt02 = new TGrdLyt02();
            //lGrdLyt02.UserPK = "1";
            //lGrdLyt02.LoadLayout(this, true);

        }
        #endregion

        #endregion
    }

    #endregion

    #region GridView Classes
    public class TGridViewInfoRegistrator01 : GridInfoRegistrator
    {
        public override string ViewName { get { return "TGridView01"; } }
        public override BaseView CreateView(GridControl grid) { return new TGridView01(grid as GridControl); }
        public override BaseViewInfo CreateViewInfo(BaseView view) { return new TGridViewInfo01(view as TGridView01); }
        public override BaseViewHandler CreateHandler(BaseView view) { return new TGridHandler01(view as TGridView01); }
    }
    public class TGridView01 : GridView
    {
        TDataGrid01 mOwnerGrid = null;

        public TGridView01() : this(null) { }
        public TGridView01(DevExpress.XtraGrid.GridControl grid)
            : base(grid)
        {
            //Init();
        }

        protected override string ViewName { get { return "TGridView01"; } }

        private void TGridView01_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            TBOT01 lBOT01 = null;

            lBOT01 = mOwnerGrid.BOT01;
            if (lBOT01 != null)
            {
                if (e.FocusedRowHandle != GridControl.NewItemRowHandle && e.FocusedRowHandle != GridControl.InvalidRowHandle)
                {
                    lBOT01.Dr = GetDataRow(e.FocusedRowHandle);
                }
                else
                {
                    lBOT01.CurRowIndex = TDataObject.EOFRowIndex;
                }
            }

        }
        private void TGridView01_FocusedColumnChanged(object sender, FocusedColumnChangedEventArgs e)
        {

        }
        private void TGridView01_ShowGridMenu(object sender, GridMenuEventArgs e)
        {
            DXMenuItem lDeleteAllRowsItem = null;
            Image lDeleteAllRowsImage = null;

            //#check!
            // memory leak!

            if (e.MenuType == GridMenuType.User)
            {
                if (e.Menu == null)
                {
                    e.Menu = new DevExpress.XtraGrid.Menu.GridViewMenu(this);
                }
                else
                {
                    e.Menu.Items[0].BeginGroup = true;
                }
                lDeleteAllRowsImage = Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TDataGrid01.DeleteAllRows.png"));
                lDeleteAllRowsItem = new DXMenuItem("Delete All Rows", DeleteAllRowsItem_Click, lDeleteAllRowsImage);
                //#check!
                lDeleteAllRowsItem.Enabled = (DataSource != null && ((DataView)DataSource).Count != 0 && !mOwnerGrid.BOT01.BOT01ParentChildRel.ParentBO.IsDirty &&
                                                mOwnerGrid.DSFormMode != DSFormMode.DSBrowse && mOwnerGrid.BOT01.DataRight.AllowDelete);
                e.Menu.Items.Insert(0, lDeleteAllRowsItem);
            }

        }
        private void DeleteAllRowsItem_Click(object sender, EventArgs e)
        {
            bool lDeletionSucceeded = false;
            string lPKLst = null;
            string lPrntFrmBsTp = mOwnerGrid.ParentForm.GetType().BaseType.Name;

            if (TMessageBox.AskQuestion("Are you certain to delete all rows?", MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                for (int i = 0; i < ((DataView)DataSource).Count; i++)
                {
                    lPKLst += ((DataView)DataSource)[i][Utilities.TGC.PKeyName].ToString() + ",";
                }
                lPKLst = TStr.Left(lPKLst, lPKLst.Length - 1);
                lDeletionSucceeded = mOwnerGrid.BOT01.DeleteByPKList(lPKLst);
                switch (lPrntFrmBsTp)
                {
                    case "TForm02":
                        ((TForm02)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm07":
                        ((TForm07)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm12":
                        ((TForm12)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm01":
                        //((TForm01)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm06":
                        ((TForm06)mOwnerGrid.ParentForm).Reload();
                        break;
                }
                if (lDeletionSucceeded)
                {
                    TMessageBox.ShowInformation("Deletion Succeeded!");
                }
                else
                {
                    TMessageBox.ShowInformation("Deletion Failed!");
                }
            }

        }
        public void Init()
        {
            mOwnerGrid = ((TDataGrid01)GridControl);
            FixedLineWidth = 1;
            //OptionsSelection.EnableAppearanceFocusedCell = false;
            //OptionsSelection.EnableAppearanceFocusedRow = false;
            //OptionsSelection.EnableAppearanceHideSelection = false;
            Appearance.FocusedRow.BackColor = Color.FromArgb(60, 128, 128, 240);
            Appearance.FocusedRow.Options.UseBackColor = true;
            Appearance.SelectedRow.BackColor = Color.FromArgb(30, 128, 128, 240);
            Appearance.SelectedRow.Options.UseBackColor = true;
            OptionsView.NewItemRowPosition = NewItemRowPosition.Bottom;
            OptionsView.ColumnAutoWidth = false;
            OptionsView.ShowGroupPanel = false;
            OptionsCustomization.AllowGroup = false;
            OptionsMenu.EnableFooterMenu = false;
            AssignEventHandlers();
        }
        private void AssignEventHandlers()
        {
            FocusedRowChanged += TGridView01_FocusedRowChanged;
            //FocusedColumnChanged += TGridView01_FocusedColumnChanged;
            ShowGridMenu += TGridView01_ShowGridMenu;
            //GridMenuItemClick += TGridView01_GridMenuItemClick;
        }
    }
    public class TGridViewInfo01 : GridViewInfo
    {
        public TGridViewInfo01(GridView gridView) : base(gridView) { }
    }
    public class TGridHandler01 : GridHandler
    {
        public TGridHandler01(GridView gridView) : base(gridView) { }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            base.OnKeyUp(e);

            if (e.KeyData == Keys.Delete && View.State == GridState.Normal &&
                ((TDataGrid01)View.GridControl).BOT01.DataRight.AllowDelete && ((TDataGrid01)View.GridControl).DSFormMode != DSFormMode.DSBrowse)
            {
                if (View.FocusedRowHandle >= 0)
                {
                    if (TMessageBox.AskQuestion("Delete the selected record?", MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                    {
                        //View.DeleteSelectedRows();
                        View.DeleteRow(View.FocusedRowHandle);
                    }
                }
            }

        }
    }
    #endregion

    #region BandedGridView Classes
    public class TBandedGridViewInfoRegistrator01 : BandedGridInfoRegistrator
    {
        public override string ViewName { get { return "TBandedGridView01"; } }
        public override BaseView CreateView(GridControl grid) { return new TBandedGridView01(grid as GridControl); }
        public override BaseViewInfo CreateViewInfo(BaseView view) { return new TBandedGridViewInfo01(view as TBandedGridView01); }
        public override BaseViewHandler CreateHandler(BaseView view) { return new TBandedGridHandler01(view as TBandedGridView01); }
    }

    public class TBandedGridView01 : BandedGridView
    {
        TDataGrid01 mOwnerGrid = null;

        public TBandedGridView01() : this(null) { }
        public TBandedGridView01(DevExpress.XtraGrid.GridControl grid)
            : base(grid)
        {
            //Init();
        }

        protected override string ViewName { get { return "TBandedGridView01"; } }

        private void TBandedGridView01_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            TBOT01 lBOT01 = null;

            lBOT01 = mOwnerGrid.BOT01;
            if (lBOT01 != null && (e.FocusedRowHandle != GridControl.NewItemRowHandle && e.FocusedRowHandle != GridControl.InvalidRowHandle))
            {
                lBOT01.Dr = GetDataRow(e.FocusedRowHandle);
            }

        }
        private void TBandedGridView01_FocusedColumnChanged(object sender, FocusedColumnChangedEventArgs e)
        {

        }
        private void TBandedGridView01_ShowGridMenu(object sender, GridMenuEventArgs e)
        {
            DXMenuItem lDeleteAllRowsItem = null;
            Image lDeleteAllRowsImage = null;

            if (e.MenuType == GridMenuType.User)
            {
                if (e.Menu == null)
                {
                    e.Menu = new DevExpress.XtraGrid.Menu.GridViewMenu(this);
                }
                else
                {
                    e.Menu.Items[0].BeginGroup = true;
                }
                lDeleteAllRowsImage = Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TDataGrid01.DeleteAllRows.png"));
                lDeleteAllRowsItem = new DXMenuItem("Delete All Rows", DeleteAllRowsItem_Click, lDeleteAllRowsImage);
                lDeleteAllRowsItem.Enabled = (DataSource != null && ((DataView)DataSource).Count != 0 && !mOwnerGrid.BOT01.BOT01ParentChildRel.ParentBO.IsDirty &&
                                                mOwnerGrid.DSFormMode != DSFormMode.DSBrowse && mOwnerGrid.BOT01.DataRight.AllowDelete);
                e.Menu.Items.Insert(0, lDeleteAllRowsItem);
            }

        }
        private void DeleteAllRowsItem_Click(object sender, EventArgs e)
        {
            bool lDeletionSucceeded = false;
            string lPKLst = null;
            string lPrntFrmBsTp = mOwnerGrid.ParentForm.GetType().BaseType.Name;

            if (TMessageBox.AskQuestion("Are you certain to delete all rows?", MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                for (int i = 0; i < ((DataView)DataSource).Count; i++)
                {
                    lPKLst += ((DataView)DataSource)[i][Utilities.TGC.PKeyName].ToString() + ",";
                }
                lPKLst = TStr.Left(lPKLst, lPKLst.Length - 1);
                lDeletionSucceeded = mOwnerGrid.BOT01.DeleteByPKList(lPKLst);
                switch (lPrntFrmBsTp)
                {
                    case "TForm02":
                        ((TForm02)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm07":
                        ((TForm07)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm12":
                        ((TForm12)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm01":
                        //((TForm01)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm06":
                        ((TForm06)mOwnerGrid.ParentForm).Reload();
                        break;
                }
                if (lDeletionSucceeded)
                {
                    TMessageBox.ShowInformation("Deletion Succeeded!");
                }
                else
                {
                    TMessageBox.ShowInformation("Deletion Failed!");
                }
            }

        }

        public void Init()
        {
            mOwnerGrid = ((TDataGrid01)GridControl);
            FixedLineWidth = 1;
            Appearance.FocusedRow.BackColor = Color.FromArgb(60, 128, 128, 240);
            Appearance.FocusedRow.Options.UseBackColor = true;
            Appearance.SelectedRow.BackColor = Color.FromArgb(30, 128, 128, 240);
            Appearance.SelectedRow.Options.UseBackColor = true;
            OptionsView.NewItemRowPosition = NewItemRowPosition.Bottom;
            OptionsView.ColumnAutoWidth = false;
            OptionsView.ShowGroupPanel = false;
            OptionsCustomization.AllowGroup = false;
            OptionsMenu.EnableFooterMenu = false;
            AssignEventHandlers();
        }
        private void AssignEventHandlers()
        {
            FocusedRowChanged += TBandedGridView01_FocusedRowChanged;
            //FocusedColumnChanged += TBandedGridView01_FocusedColumnChanged;
            ShowGridMenu += TBandedGridView01_ShowGridMenu;
            //GridMenuItemClick += TBandedGridView01_GridMenuItemClick;
        }
    }

    public class TBandedGridViewInfo01 : BandedGridViewInfo
    {
        public TBandedGridViewInfo01(BandedGridView gridView) : base(gridView) { }
    }

    public class TBandedGridHandler01 : BandedGridHandler
    {
        public TBandedGridHandler01(BandedGridView gridView) : base(gridView) { }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            base.OnKeyUp(e);
            if (e.KeyData == Keys.Delete && View.State == BandedGridState.Normal &&
                ((TDataGrid01)View.GridControl).BOT01.DataRight.AllowDelete && ((TDataGrid01)View.GridControl).DSFormMode != DSFormMode.DSBrowse)
            {
                if (View.FocusedRowHandle >= 0)
                {
                    if (TMessageBox.AskQuestion("Delete the selected record?", MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                    {
                        //View.DeleteSelectedRows();
                        View.DeleteRow(View.FocusedRowHandle);
                    }
                }
            }
        }
    }
    #endregion

    #region AdvBandedGridView Classes
    public class TAdvBandedGridViewInfoRegistrator01 : AdvBandedGridInfoRegistrator
    {
        public override string ViewName { get { return "TAdvBandedGridView01"; } }
        public override BaseView CreateView(GridControl grid) { return new TAdvBandedGridView01(grid as GridControl); }
        public override BaseViewInfo CreateViewInfo(BaseView view) { return new TAdvBandedGridViewInfo01(view as TAdvBandedGridView01); }
        public override BaseViewHandler CreateHandler(BaseView view) { return new TAdvBandedGridHandler01(view as TAdvBandedGridView01); }
    }

    public class TAdvBandedGridView01 : AdvBandedGridView
    {
        TDataGrid01 mOwnerGrid = null;

        public TAdvBandedGridView01() : this(null) { }
        public TAdvBandedGridView01(DevExpress.XtraGrid.GridControl grid)
            : base(grid)
        {
            //Init();
        }

        protected override string ViewName { get { return "TAdvBandedGridView01"; } }

        private void TAdvBandedGridView01_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            TBOT01 lBOT01 = null;

            lBOT01 = mOwnerGrid.BOT01;
            if (lBOT01 != null && (e.FocusedRowHandle != GridControl.NewItemRowHandle && e.FocusedRowHandle != GridControl.InvalidRowHandle))
            {
                lBOT01.Dr = GetDataRow(e.FocusedRowHandle);
            }
        }
        private void TAdvBandedGridView01_FocusedColumnChanged(object sender, FocusedColumnChangedEventArgs e)
        {

        }
        private void TAdvBandedGridView01_ShowGridMenu(object sender, GridMenuEventArgs e)
        {
            DXMenuItem lDeleteAllRowsItem = null;
            Image lDeleteAllRowsImage = null;

            if (e.MenuType == GridMenuType.User)
            {
                if (e.Menu == null)
                {
                    e.Menu = new DevExpress.XtraGrid.Menu.GridViewMenu(this);
                }
                else
                {
                    e.Menu.Items[0].BeginGroup = true;
                }
                lDeleteAllRowsImage = Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TDataGrid01.DeleteAllRows.png"));
                lDeleteAllRowsItem = new DXMenuItem("Delete All Rows", DeleteAllRowsItem_Click, lDeleteAllRowsImage);
                lDeleteAllRowsItem.Enabled = (DataSource != null && ((DataView)DataSource).Count != 0 && !mOwnerGrid.BOT01.BOT01ParentChildRel.ParentBO.IsDirty &&
                                                mOwnerGrid.DSFormMode != DSFormMode.DSBrowse && mOwnerGrid.BOT01.DataRight.AllowDelete);
                e.Menu.Items.Insert(0, lDeleteAllRowsItem);
            }

        }
        private void DeleteAllRowsItem_Click(object sender, EventArgs e)
        {
            bool lDeletionSucceeded = false;
            string lPKLst = null;
            string lPrntFrmBsTp = mOwnerGrid.ParentForm.GetType().BaseType.Name;

            if (TMessageBox.AskQuestion("Are you certain to delete all rows?", MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                for (int i = 0; i < ((DataView)DataSource).Count; i++)
                {
                    lPKLst += ((DataView)DataSource)[i][Utilities.TGC.PKeyName].ToString() + ",";
                }
                lPKLst = TStr.Left(lPKLst, lPKLst.Length - 1);
                lDeletionSucceeded = mOwnerGrid.BOT01.DeleteByPKList(lPKLst);
                switch (lPrntFrmBsTp)
                {
                    case "TForm02":
                        ((TForm02)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm07":
                        ((TForm07)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm12":
                        ((TForm12)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm01":
                        //((TForm01)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm06":
                        ((TForm06)mOwnerGrid.ParentForm).Reload();
                        break;
                }
                if (lDeletionSucceeded)
                {
                    TMessageBox.ShowInformation("Deletion Succeeded!");
                }
                else
                {
                    TMessageBox.ShowInformation("Deletion Failed!");
                }
            }

        }

        public void Init()
        {
            mOwnerGrid = ((TDataGrid01)GridControl);
            FixedLineWidth = 1;
            Appearance.FocusedRow.BackColor = Color.FromArgb(60, 128, 128, 240);
            Appearance.FocusedRow.Options.UseBackColor = true;
            Appearance.SelectedRow.BackColor = Color.FromArgb(30, 128, 128, 240);
            Appearance.SelectedRow.Options.UseBackColor = true;
            OptionsView.NewItemRowPosition = NewItemRowPosition.Bottom;
            OptionsView.ColumnAutoWidth = false;
            OptionsView.ShowGroupPanel = false;
            OptionsCustomization.AllowGroup = false;
            OptionsMenu.EnableFooterMenu = false;
            AssignEventHandlers();
        }
        private void AssignEventHandlers()
        {
            FocusedRowChanged += TAdvBandedGridView01_FocusedRowChanged;
            //FocusedColumnChanged += TAdvBandedGridView01_FocusedColumnChanged;
            ShowGridMenu += TAdvBandedGridView01_ShowGridMenu;
            //GridMenuItemClick += TAdvBandedGridView01_GridMenuItemClick;
        }
    }

    public class TAdvBandedGridViewInfo01 : AdvBandedGridViewInfo
    {
        public TAdvBandedGridViewInfo01(AdvBandedGridView gridView) : base(gridView) { }
    }

    public class TAdvBandedGridHandler01 : AdvBandedGridHandler
    {
        public TAdvBandedGridHandler01(AdvBandedGridView gridView) : base(gridView) { }

        protected override void OnKeyUp(KeyEventArgs e)
        {
            base.OnKeyUp(e);

            if (e.KeyData == Keys.Delete && View.State == BandedGridState.Normal &&
                ((TDataGrid01)View.GridControl).BOT01.DataRight.AllowDelete && ((TDataGrid01)View.GridControl).DSFormMode != DSFormMode.DSBrowse)
            {
                if (View.FocusedRowHandle >= 0)
                {
                    if (TMessageBox.AskQuestion("Delete the selected record?", MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                    {
                        //View.DeleteSelectedRows();
                        View.DeleteRow(View.FocusedRowHandle);
                    }
                }
            }

        }
    }
    #endregion
}
