using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    public class TLookupCombo04Collection : ArrayList
    {
        #region Members
        #endregion

        #region Constructors
        public TLookupCombo04Collection()
        {
        }
        #endregion

        #region Enums
        #endregion

        #region Properties
        private int mRefreshIndex = 0;
        public int RefreshIndex
        {
            get
            {
                return mRefreshIndex; 
            }
            set 
            { 
                mRefreshIndex = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Add(System.Windows.Forms.Control aControl)
        {
            base.Add(aControl);
        }
        public void Init()
        {

                for (int i = 0; i < this.Count; i++)
                {
                    ((TLookupCombo04)this[i]).Properties.Init();
                }
 
        }
        public void BindAllLists()
        {
            TLookupCombo04 lLookupCombo04 = null;


                for (int i = 0; i < this.Count; i++)
                {
                    lLookupCombo04 = (TLookupCombo04)this[i];
                    if (lLookupCombo04.Properties.NormalMode)
                    {
                        lLookupCombo04.Properties.BindList();
                    }
                }

        }
        public void BindNextList()
        {
            TLookupCombo04 lLookupCombo04 = null;


                if (Count != 0)
                {
                    if (mRefreshIndex < 0 || mRefreshIndex > Count - 1)
                    {
                        mRefreshIndex = 0;
                    }
                    lLookupCombo04 = (TLookupCombo04)this[mRefreshIndex];
                    if (lLookupCombo04.Properties.NormalMode)
                    {
                        lLookupCombo04.Properties.BindList();
                    }
                    mRefreshIndex++;
                    if (mRefreshIndex > Count - 1)
                    {
                        mRefreshIndex = 0;
                    }
                }

        }
        public void InitForReuse()
        {
            TLookupCombo04 lLookupCombo04 = null;


                for (int i = 0; i < this.Count; i++)
                {
                    lLookupCombo04 = (TLookupCombo04)this[i];
                    if (lLookupCombo04.Properties.NormalMode)
                    {
                        lLookupCombo04.EditValue = null;
                    }                    
                }

        }
        public void SetDSMode(DSFormMode aDSFormMode)
        {
            TLookupCombo04 lLookupCombo04 = null;


                for (int i = 0; i < this.Count; i++)
                {
                    lLookupCombo04 = (TLookupCombo04)this[i];
                    if (lLookupCombo04.Properties.NormalMode)
                    {
                        lLookupCombo04.Properties.DSFormMode = aDSFormMode;
                    }
                }
 
        }
        #endregion
    }
}
