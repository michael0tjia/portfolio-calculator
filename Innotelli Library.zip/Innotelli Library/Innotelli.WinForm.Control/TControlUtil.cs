﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Text;
using DevExpress.XtraEditors.Repository;

namespace Innotelli.WinForm.Control
{
    public class TControlUtil
    {
        public static string GetFirstBindingFieldName(System.Windows.Forms.Control aControl)
        {
            string lReturnValue = string.Empty;

            if (aControl.DataBindings.Count > 0)
            {                            
                lReturnValue = aControl.DataBindings[0].BindingMemberInfo.BindingField;                
            }

            return lReturnValue;
        }
        public static string GetFirstBindingFieldNameFromOwnerEdit(RepositoryItem aRepositoryItem)
        {
            string lReturnValue = string.Empty;

            if (aRepositoryItem.OwnerEdit != null)
            {
                lReturnValue = TControlUtil.GetFirstBindingFieldName(aRepositoryItem.OwnerEdit);
            }

            return lReturnValue;
        }
        
    }
}
