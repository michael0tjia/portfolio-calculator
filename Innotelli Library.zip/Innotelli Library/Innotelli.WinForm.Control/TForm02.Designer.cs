namespace Innotelli.WinForm.Control
{
    partial class TForm02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TForm02));
            this.bmgBase = new DevExpress.XtraBars.BarManager(this.components);
            this.barStandard = new DevExpress.XtraBars.Bar();
            this.bbi01New = new DevExpress.XtraBars.BarButtonItem();
            this.bbi01Edit = new DevExpress.XtraBars.BarButtonItem();
            this.bbi01Save = new DevExpress.XtraBars.BarButtonItem();
            this.bbi01CancelSave = new DevExpress.XtraBars.BarButtonItem();
            this.bbi01PrintPreview = new DevExpress.XtraBars.BarButtonItem();
            this.bbi01Print = new DevExpress.XtraBars.BarButtonItem();
            this.bbi01Delete = new DevExpress.XtraBars.BarButtonItem();
            this.barBaseStatus = new DevExpress.XtraBars.Bar();
            this.bbi01QuickFind = new DevExpress.XtraBars.BarButtonItem();
            this.bbi01First = new DevExpress.XtraBars.BarButtonItem();
            this.bbi01Prev = new DevExpress.XtraBars.BarButtonItem();
            this.beiCurRec = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemTextEdit7 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.bbi01TextOf = new DevExpress.XtraBars.BarStaticItem();
            this.beiRecCount = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemTextEdit8 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.bbi01Next = new DevExpress.XtraBars.BarButtonItem();
            this.bbi01Last = new DevExpress.XtraBars.BarButtonItem();
            this.beiBaseSelectOpt = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemComboBox1 = new DevExpress.XtraEditors.Repository.RepositoryItemComboBox();
            this.bsiEmpty2 = new DevExpress.XtraBars.BarStaticItem();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.btn02BaseExit = new DevExpress.XtraBars.BarButtonItem();
            this.barStaticItem6 = new DevExpress.XtraBars.BarStaticItem();
            this.barEditItem7 = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemTextEdit5 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.barButtonItem14 = new DevExpress.XtraBars.BarButtonItem();
            this.bsiEmpty3 = new DevExpress.XtraBars.BarStaticItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemTextEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemTextEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemTextEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemTextEdit6 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.barEditItem2 = new DevExpress.XtraBars.BarEditItem();
            this.tmrRowLock = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.bmgBase)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit6)).BeginInit();
            this.SuspendLayout();
            // 
            // bmgBase
            // 
            this.bmgBase.AllowCustomization = false;
            this.bmgBase.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.barStandard,
            this.barBaseStatus});
            this.bmgBase.DockControls.Add(this.barDockControlTop);
            this.bmgBase.DockControls.Add(this.barDockControlBottom);
            this.bmgBase.DockControls.Add(this.barDockControlLeft);
            this.bmgBase.DockControls.Add(this.barDockControlRight);
            this.bmgBase.Form = this;
            this.bmgBase.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.bbi01New,
            this.bbi01Edit,
            this.bbi01Save,
            this.bbi01Delete,
            this.bbi01CancelSave,
            this.btn02BaseExit,
            this.bbi01First,
            this.bbi01Prev,
            this.bbi01Next,
            this.bbi01Last,
            this.beiBaseSelectOpt,
            this.bsiEmpty2,
            this.barStaticItem6,
            this.barEditItem7,
            this.barButtonItem14,
            this.bsiEmpty3,
            this.bbi01QuickFind,
            this.bbi01Print,
            this.bbi01PrintPreview,
            this.beiCurRec,
            this.beiRecCount,
            this.bbi01TextOf,
            this.barButtonItem1});
            this.bmgBase.MainMenu = this.barStandard;
            this.bmgBase.MaxItemId = 46;
            this.bmgBase.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit1,
            this.repositoryItemTextEdit2,
            this.repositoryItemComboBox1,
            this.repositoryItemTextEdit3,
            this.repositoryItemTextEdit4,
            this.repositoryItemTextEdit5,
            this.repositoryItemTextEdit6,
            this.repositoryItemTextEdit7,
            this.repositoryItemTextEdit8});
            this.bmgBase.StatusBar = this.barBaseStatus;
            // 
            // barStandard
            // 
            this.barStandard.BarItemHorzIndent = 2;
            this.barStandard.BarName = "Standard";
            this.barStandard.DockCol = 0;
            this.barStandard.DockRow = 0;
            this.barStandard.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.barStandard.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.bbi01New, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.bbi01Edit, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.bbi01Save, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.bbi01CancelSave, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbi01PrintPreview),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.bbi01Print, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, this.bbi01Delete, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph)});
            this.barStandard.OptionsBar.AllowQuickCustomization = false;
            this.barStandard.OptionsBar.DrawDragBorder = false;
            this.barStandard.OptionsBar.UseWholeRow = true;
            resources.ApplyResources(this.barStandard, "barStandard");
            // 
            // bbi01New
            // 
            resources.ApplyResources(this.bbi01New, "bbi01New");
            this.bbi01New.Id = 0;
            this.bbi01New.ImageIndex = 0;
            this.bbi01New.Name = "bbi01New";
            this.bbi01New.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbi01New_ItemClick);
            // 
            // bbi01Edit
            // 
            resources.ApplyResources(this.bbi01Edit, "bbi01Edit");
            this.bbi01Edit.Id = 1;
            this.bbi01Edit.ImageIndex = 1;
            this.bbi01Edit.Name = "bbi01Edit";
            this.bbi01Edit.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbi01Edit_ItemClick);
            // 
            // bbi01Save
            // 
            resources.ApplyResources(this.bbi01Save, "bbi01Save");
            this.bbi01Save.Id = 2;
            this.bbi01Save.ImageIndex = 2;
            this.bbi01Save.Name = "bbi01Save";
            this.bbi01Save.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbi01Save_ItemClick);
            // 
            // bbi01CancelSave
            // 
            resources.ApplyResources(this.bbi01CancelSave, "bbi01CancelSave");
            this.bbi01CancelSave.Id = 4;
            this.bbi01CancelSave.ImageIndex = 3;
            this.bbi01CancelSave.Name = "bbi01CancelSave";
            this.bbi01CancelSave.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbi01Cancel_ItemClick);
            // 
            // bbi01PrintPreview
            // 
            resources.ApplyResources(this.bbi01PrintPreview, "bbi01PrintPreview");
            this.bbi01PrintPreview.Id = 41;
            this.bbi01PrintPreview.ImageIndex = 4;
            this.bbi01PrintPreview.Name = "bbi01PrintPreview";
            this.bbi01PrintPreview.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbi01PrintPreview_ItemClick);
            // 
            // bbi01Print
            // 
            resources.ApplyResources(this.bbi01Print, "bbi01Print");
            this.bbi01Print.Id = 40;
            this.bbi01Print.ImageIndex = 5;
            this.bbi01Print.Name = "bbi01Print";
            this.bbi01Print.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbi01Print_ItemClick);
            // 
            // bbi01Delete
            // 
            resources.ApplyResources(this.bbi01Delete, "bbi01Delete");
            this.bbi01Delete.Id = 3;
            this.bbi01Delete.ImageIndex = 6;
            this.bbi01Delete.Name = "bbi01Delete";
            this.bbi01Delete.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbi01Delete_ItemClick);
            // 
            // barBaseStatus
            // 
            this.barBaseStatus.BarItemHorzIndent = 1;
            this.barBaseStatus.BarName = "Status bar";
            this.barBaseStatus.CanDockStyle = DevExpress.XtraBars.BarCanDockStyle.Bottom;
            this.barBaseStatus.DockCol = 0;
            this.barBaseStatus.DockRow = 0;
            this.barBaseStatus.DockStyle = DevExpress.XtraBars.BarDockStyle.Bottom;
            this.barBaseStatus.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.bbi01QuickFind),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbi01First),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbi01Prev),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.Width, this.beiCurRec, "", false, true, true, 53),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbi01TextOf),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.Width, this.beiRecCount, "", false, true, true, 53),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbi01Next),
            new DevExpress.XtraBars.LinkPersistInfo(this.bbi01Last),
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.Width, this.beiBaseSelectOpt, "", true, true, true, 113),
            new DevExpress.XtraBars.LinkPersistInfo(this.bsiEmpty2)});
            this.barBaseStatus.OptionsBar.AllowQuickCustomization = false;
            this.barBaseStatus.OptionsBar.DisableClose = true;
            this.barBaseStatus.OptionsBar.DrawDragBorder = false;
            this.barBaseStatus.OptionsBar.UseWholeRow = true;
            resources.ApplyResources(this.barBaseStatus, "barBaseStatus");
            // 
            // bbi01QuickFind
            // 
            resources.ApplyResources(this.bbi01QuickFind, "bbi01QuickFind");
            this.bbi01QuickFind.Id = 38;
            this.bbi01QuickFind.ImageIndex = 7;
            this.bbi01QuickFind.Name = "bbi01QuickFind";
            this.bbi01QuickFind.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbi01QuickFind_ItemClick);
            // 
            // bbi01First
            // 
            this.bbi01First.Id = 8;
            this.bbi01First.ImageIndex = 8;
            this.bbi01First.Name = "bbi01First";
            this.bbi01First.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbi01First_ItemClick);
            // 
            // bbi01Prev
            // 
            this.bbi01Prev.Id = 9;
            this.bbi01Prev.ImageIndex = 9;
            this.bbi01Prev.Name = "bbi01Prev";
            this.bbi01Prev.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbi01Prev_ItemClick);
            // 
            // beiCurRec
            // 
            this.beiCurRec.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left;
            this.beiCurRec.Edit = this.repositoryItemTextEdit7;
            this.beiCurRec.Id = 42;
            this.beiCurRec.Name = "beiCurRec";
            // 
            // repositoryItemTextEdit7
            // 
            this.repositoryItemTextEdit7.AllowFocused = false;
            this.repositoryItemTextEdit7.Name = "repositoryItemTextEdit7";
            this.repositoryItemTextEdit7.ReadOnly = true;
            // 
            // bbi01TextOf
            // 
            this.bbi01TextOf.Border = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            resources.ApplyResources(this.bbi01TextOf, "bbi01TextOf");
            this.bbi01TextOf.Id = 44;
            this.bbi01TextOf.Name = "bbi01TextOf";
            this.bbi01TextOf.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // beiRecCount
            // 
            resources.ApplyResources(this.beiRecCount, "beiRecCount");
            this.beiRecCount.Edit = this.repositoryItemTextEdit8;
            this.beiRecCount.Id = 43;
            this.beiRecCount.Name = "beiRecCount";
            // 
            // repositoryItemTextEdit8
            // 
            this.repositoryItemTextEdit8.AllowFocused = false;
            this.repositoryItemTextEdit8.Name = "repositoryItemTextEdit8";
            this.repositoryItemTextEdit8.ReadOnly = true;
            // 
            // bbi01Next
            // 
            this.bbi01Next.Id = 15;
            this.bbi01Next.ImageIndex = 10;
            this.bbi01Next.Name = "bbi01Next";
            this.bbi01Next.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbi01Next_ItemClick);
            // 
            // bbi01Last
            // 
            this.bbi01Last.Id = 16;
            this.bbi01Last.ImageIndex = 11;
            this.bbi01Last.Name = "bbi01Last";
            this.bbi01Last.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.bbi01Last_ItemClick);
            // 
            // beiBaseSelectOpt
            // 
            resources.ApplyResources(this.beiBaseSelectOpt, "beiBaseSelectOpt");
            this.beiBaseSelectOpt.Edit = this.repositoryItemComboBox1;
            this.beiBaseSelectOpt.Id = 17;
            this.beiBaseSelectOpt.Name = "beiBaseSelectOpt";
            this.beiBaseSelectOpt.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // repositoryItemComboBox1
            // 
            this.repositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(((DevExpress.XtraEditors.Controls.ButtonPredefines)(resources.GetObject("repositoryItemComboBox1.Buttons"))))});
            this.repositoryItemComboBox1.Name = "repositoryItemComboBox1";
            // 
            // bsiEmpty2
            // 
            this.bsiEmpty2.AutoSize = DevExpress.XtraBars.BarStaticItemSize.None;
            this.bsiEmpty2.Border = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            resources.ApplyResources(this.bsiEmpty2, "bsiEmpty2");
            this.bsiEmpty2.Id = 18;
            this.bsiEmpty2.Name = "bsiEmpty2";
            this.bsiEmpty2.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // btn02BaseExit
            // 
            resources.ApplyResources(this.btn02BaseExit, "btn02BaseExit");
            this.btn02BaseExit.Id = 5;
            this.btn02BaseExit.ImageIndex = 5;
            this.btn02BaseExit.Name = "btn02BaseExit";
            // 
            // barStaticItem6
            // 
            this.barStaticItem6.AutoSize = DevExpress.XtraBars.BarStaticItemSize.None;
            this.barStaticItem6.Border = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            resources.ApplyResources(this.barStaticItem6, "barStaticItem6");
            this.barStaticItem6.Id = 27;
            this.barStaticItem6.Name = "barStaticItem6";
            this.barStaticItem6.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // barEditItem7
            // 
            resources.ApplyResources(this.barEditItem7, "barEditItem7");
            this.barEditItem7.Edit = this.repositoryItemTextEdit5;
            this.barEditItem7.Id = 31;
            this.barEditItem7.Name = "barEditItem7";
            // 
            // repositoryItemTextEdit5
            // 
            this.repositoryItemTextEdit5.Name = "repositoryItemTextEdit5";
            // 
            // barButtonItem14
            // 
            resources.ApplyResources(this.barButtonItem14, "barButtonItem14");
            this.barButtonItem14.Id = 36;
            this.barButtonItem14.Name = "barButtonItem14";
            // 
            // bsiEmpty3
            // 
            this.bsiEmpty3.AutoSize = DevExpress.XtraBars.BarStaticItemSize.None;
            this.bsiEmpty3.Border = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.bsiEmpty3.Id = 37;
            this.bsiEmpty3.Name = "bsiEmpty3";
            this.bsiEmpty3.TextAlignment = System.Drawing.StringAlignment.Near;
            resources.ApplyResources(this.bsiEmpty3, "bsiEmpty3");
            // 
            // barButtonItem1
            // 
            resources.ApplyResources(this.barButtonItem1, "barButtonItem1");
            this.barButtonItem1.Id = 45;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // repositoryItemTextEdit2
            // 
            this.repositoryItemTextEdit2.Name = "repositoryItemTextEdit2";
            // 
            // repositoryItemTextEdit3
            // 
            this.repositoryItemTextEdit3.Name = "repositoryItemTextEdit3";
            // 
            // repositoryItemTextEdit4
            // 
            this.repositoryItemTextEdit4.Name = "repositoryItemTextEdit4";
            // 
            // repositoryItemTextEdit6
            // 
            this.repositoryItemTextEdit6.Name = "repositoryItemTextEdit6";
            // 
            // barEditItem2
            // 
            this.barEditItem2.Edit = this.repositoryItemTextEdit1;
            this.barEditItem2.Id = 10;
            this.barEditItem2.Name = "barEditItem2";
            // 
            // tmrRowLock
            // 
            this.tmrRowLock.Interval = 1000;
            this.tmrRowLock.Tick += new System.EventHandler(this.tmrRowLock_Tick);
            // 
            // TForm02
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.KeyPreview = true;
            this.Name = "TForm02";
            this.Load += new System.EventHandler(this.TForm02_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TForm02_FormClosing);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TForm02_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.bmgBase)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit6)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        protected DevExpress.XtraBars.BarManager bmgBase;
        protected DevExpress.XtraBars.BarButtonItem bbi01New;
        protected DevExpress.XtraBars.BarDockControl barDockControlTop;
        protected DevExpress.XtraBars.BarDockControl barDockControlBottom;
        protected DevExpress.XtraBars.BarDockControl barDockControlLeft;
        protected DevExpress.XtraBars.BarDockControl barDockControlRight;
        protected DevExpress.XtraBars.BarButtonItem bbi01Edit;
        protected DevExpress.XtraBars.BarButtonItem bbi01Save;
        protected DevExpress.XtraBars.BarButtonItem bbi01Delete;
        protected DevExpress.XtraBars.BarButtonItem bbi01CancelSave;
        protected DevExpress.XtraBars.BarButtonItem btn02BaseExit;
        protected DevExpress.XtraBars.BarButtonItem bbi01First;
        protected DevExpress.XtraBars.BarButtonItem bbi01Prev;
        protected DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        protected DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit2;
        protected DevExpress.XtraBars.BarButtonItem bbi01Next;
        protected DevExpress.XtraBars.BarButtonItem bbi01Last;
        protected DevExpress.XtraBars.BarEditItem beiBaseSelectOpt;
        protected DevExpress.XtraEditors.Repository.RepositoryItemComboBox repositoryItemComboBox1;
        protected DevExpress.XtraBars.BarEditItem barEditItem2;
        protected DevExpress.XtraBars.BarStaticItem bsiEmpty2;
        protected DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit3;
        protected DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit4;
        protected DevExpress.XtraBars.BarStaticItem barStaticItem6;
        protected DevExpress.XtraBars.BarEditItem barEditItem7;
        protected DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit5;
        protected DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit6;
        protected DevExpress.XtraBars.BarButtonItem barButtonItem14;
        protected DevExpress.XtraBars.BarStaticItem bsiEmpty3;
        protected DevExpress.XtraBars.BarButtonItem bbi01QuickFind;
        protected DevExpress.XtraBars.Bar barStandard;
        protected DevExpress.XtraBars.Bar barBaseStatus;
        protected DevExpress.XtraBars.BarButtonItem bbi01PrintPreview;
        protected DevExpress.XtraBars.BarButtonItem bbi01Print;
        protected DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit7;
        protected DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit8;
        protected DevExpress.XtraBars.BarStaticItem bbi01TextOf;
        protected DevExpress.XtraBars.BarEditItem beiCurRec;
        protected DevExpress.XtraBars.BarEditItem beiRecCount;
        private System.Windows.Forms.Timer tmrRowLock;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;

    }
}