using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Reflection;
using System.Windows.Forms;
using Innotelli.Utilities;
using Innotelli.BO;
using DevExpress.XtraEditors;


namespace Innotelli.WinForm.Control
{
    public partial class TForm99 : DevExpress.XtraEditors.XtraForm
    {
        #region Enums
        protected enum DSFormMode
        {
            DSUnknown = -1,
            DSBrowse = 1,
            DSEdit = 2,
            DSInsert = 3,
            DSExit = 4,
        }
        protected enum DSAFormAction
        {
            DSAInsert = 1,
            DSAEdit = 2,
            DSASave = 3,
            DSACancel = 4,
        }
        #endregion

        #region Members
        protected DSFormMode mDsMode = DSFormMode.DSBrowse;
        private TBOT01 mBOT001;
        private BindingSource mBdsMaster = null;
        
        protected bool mAskSave = true;
        private bool mAskDelete = true;
        private int mSaveState = 0;
        private int mDeleteState = 0;

        TForm02Tree mForm02Tree = new TForm02Tree();

        #endregion

        #region Constructors
        public TForm99()
        {
            InitializeComponent();
        }
        #endregion

        #region Properties
        protected TBOT01 BOT001
        {
            get { return mBOT001; }
            set { mBOT001 = value; }
        }
        protected DSFormMode DsMode
        {
            get
            {
                return mDsMode;
            }
            set
            {
                mDsMode = value;
            }
        }
        protected bool AskSave
        {
            get { return mAskSave; }
            set { mAskSave = value; }
        }
        protected bool AskDelete
        {
            get { return mAskDelete; }
            set { mAskDelete = value; }
        }
        protected int SaveState
        {
            get { return mSaveState; }
            set { mSaveState = value; }
        }
        public int DeleteState
        {
            get { return mDeleteState; }
            set { mDeleteState = value; }
        }

        public TForm02Tree Form02Tree
        {
            get
            {
                return mForm02Tree;
            }
            set
            {
                if (mForm02Tree == value)
                    return;
                mForm02Tree = value;
            }
        }
        public ITree Tree
        {
            get
            {
                return mForm02Tree.Tree;
            }
            set
            {
                if (mForm02Tree.Tree == value)
                    return;
                mForm02Tree.Tree = value;
            }
        }
        public BindingSource BdsMaster
        {
            get
            {
                return mBdsMaster;
            }
            set
            {
                if (mBdsMaster == value)
                    return;
                mBdsMaster = value;
            }
        }
        #endregion

        #region Events

        protected void Form02_Load(object sender, EventArgs e)
        {
            try
            {
                switch (DsMode)
                {
                    case DSFormMode.DSBrowse:
                        btn02BaseSave.Enabled = false;
                        btn02BaseCancel.Enabled = false;
                        btn02BaseNew.Enabled = true;
                        btn02BaseEdit.Enabled = true;
                        btn02BaseFirst.Enabled = true;
                        btn02BasePrevious.Enabled = true;
                        btn02BaseNext.Enabled = true;
                        btn02BaseLast.Enabled = true;
                        SetLockControl(true);
                        break;
                    case DSFormMode.DSInsert:
                        btn02BaseSave.Enabled = true;
                        btn02BaseCancel.Enabled = true;
                        btn02BaseNew.Enabled = false;
                        btn02BaseEdit.Enabled = false;
                        btn02BaseFirst.Enabled = false;
                        btn02BasePrevious.Enabled = false;
                        btn02BaseNext.Enabled = false;
                        btn02BaseLast.Enabled = false;
                        break;
                }
            }
            catch (Exception ex)
            {
                DevExpress.XtraEditors.XtraMessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        protected virtual void btn02BaseNew_Click(object sender, EventArgs e)
        {
            try
            {
                DsMode = DSFormMode.DSBrowse;
                DSGoToState(DSAFormAction.DSAInsert);
            }
            catch (Exception ex)
            {
                DevExpress.XtraEditors.XtraMessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        protected virtual void btn02BaseSave_Click(object sender, EventArgs e)
        {
            try
            {
                DSGoToState(DSAFormAction.DSASave);
            }
            catch (Exception ex)
            {
                DevExpress.XtraEditors.XtraMessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        protected virtual void btn02BaseEdit_Click(object sender, EventArgs e)
        {
            try
            {
                DSGoToState(DSAFormAction.DSAEdit);
                SetLockControl(false);
            }
            catch (Exception ex)
            {
                DevExpress.XtraEditors.XtraMessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        protected virtual void btn02BaseDelete_Click(object sender, EventArgs e)
        {
            try
            {
                DSFDelete();
            }
            catch (Exception ex)
            {
                DevExpress.XtraEditors.XtraMessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        protected virtual void btn02BaseCancel_Click(object sender, EventArgs e)
        {
            try
            {
                DSGoToState(DSAFormAction.DSACancel);
                SetLockControl(true);
                Reload();
            }
            catch (Exception ex)
            {
                DevExpress.XtraEditors.XtraMessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        protected virtual void btn02BaseFirst_Click(object sender, EventArgs e)
        {
            try
            {
                Nav("F");
            }   
            catch (Exception ex)
            {
                DevExpress.XtraEditors.XtraMessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        protected virtual void btn02BasePrevious_Click(object sender, EventArgs e)
        {
            try
            {
                Nav("P");
            }
            catch (Exception ex)
            {
                DevExpress.XtraEditors.XtraMessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        protected virtual void btn02BaseNext_Click(object sender, EventArgs e)
        {
            try
            {
                Nav("N");
            }
            catch (Exception ex)
            {
                DevExpress.XtraEditors.XtraMessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        protected virtual void btn02BaseLast_Click(object sender, EventArgs e)
        {
            try
            {
                Nav("L");
            }
            catch (Exception ex)
            {
                DevExpress.XtraEditors.XtraMessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        #endregion

        #region Functions

        #region Status
        protected virtual bool DSFInsert()
        {
            //DsMode = DSFormMode.DSInsert; //dup - 2007-12-05 carol removed

            btn02BaseSave.Enabled = true;
            btn02BaseCancel.Enabled = true;
            btn02BaseNew.Enabled = false;
            btn02BaseEdit.Enabled = false;

            btn02BaseFirst.Enabled = false;
            btn02BasePrevious.Enabled = false;
            btn02BaseNext.Enabled = false;
            btn02BaseLast.Enabled = false;

            //InitRcrd();
            AddNew();
            SetLockControl(false);

            return true;
        }
        protected virtual bool DSFEdit()
        {
            DsMode = DSFormMode.DSEdit;

            btn02BaseSave.Enabled = true;
            btn02BaseCancel.Enabled = true;
            btn02BaseNew.Enabled = false;
            btn02BaseEdit.Enabled = false;

            btn02BaseFirst.Enabled = false;
            btn02BasePrevious.Enabled = false;
            btn02BaseNext.Enabled = false;
            btn02BaseLast.Enabled = false;

            SetLockControl(false);

            return true;
        }
        protected virtual bool DSFSave()
        {
            btn02BaseNew.Enabled = true;
            btn02BaseEdit.Enabled = true;
            btn02BaseSave.Enabled = false;
            btn02BaseCancel.Enabled = false;

            btn02BaseFirst.Enabled = true;
            btn02BasePrevious.Enabled = true;
            btn02BaseNext.Enabled = true;
            btn02BaseLast.Enabled = true;

            DSFAskSave();
            SetLockControl(true);

            return true;
        }
        protected virtual bool DSFCancel()
        {
            btn02BaseSave.Enabled = false;
            btn02BaseCancel.Enabled = false;
            btn02BaseNew.Enabled = true;
            btn02BaseEdit.Enabled = true;

            btn02BaseFirst.Enabled = true;
            btn02BasePrevious.Enabled = true;
            btn02BaseNext.Enabled = true;
            btn02BaseLast.Enabled = true;

            SetLockControl(true);

            return true;
        }
        protected virtual bool DSFDelete()
        {
            DSFAskDelete();
            return true;
        }

        protected bool DSGoToState(DSAFormAction aAction)
        {
            bool lIsValid = false;
            bool lActionSuccess = false;
            string lRtrnMsg = null;
            DSFormMode lOrgMode = 0;
            DSFormMode lDstMode = 0;

            lOrgMode = DsMode;

            if (DSEnquiry(lOrgMode, aAction, ref lDstMode, ref lRtrnMsg))
            {
                switch (aAction)
                {
                    case DSAFormAction.DSAInsert:
                        lActionSuccess = DSFInsert();
                        break;
                    case DSAFormAction.DSAEdit:
                        lActionSuccess = DSFEdit();
                        break;
                    case DSAFormAction.DSASave:
                        lActionSuccess = DSFSave();
                        break;
                    case DSAFormAction.DSACancel:
                        lActionSuccess = DSFCancel();
                        break;
                }
                if (lActionSuccess)
                {
                    DsMode = lDstMode;
                    DSUpdateFormState();
                    lIsValid = true;
                }
            }
            else
            {
                DevExpress.XtraEditors.XtraMessageBox.Show(lRtrnMsg);
            }
            return lIsValid;
        }
        protected bool DSEnquiry(DSFormMode aOrgMode, DSAFormAction aAction, ref DSFormMode aDstMode, ref string aRtrnMsg)
        {
            bool lIsValid = false;
            aDstMode = aOrgMode;

            switch (aOrgMode)
            {
                case DSFormMode.DSBrowse:
                    #region Browse
                    switch (aAction)
                    {
                        case DSAFormAction.DSAInsert:
                            lIsValid = true;
                            aDstMode = DSFormMode.DSInsert;
                            break;
                        case DSAFormAction.DSAEdit:
                            lIsValid = true;
                            aDstMode = DSFormMode.DSEdit;
                            break;
                        case DSAFormAction.DSASave:
                            lIsValid = false;
                            aRtrnMsg = "Can't Save";
                            break;
                        case DSAFormAction.DSACancel:
                            lIsValid = false;
                            aRtrnMsg = "Can't Cancel";
                            break;
                        default:
                            lIsValid = false;
                            break;
                    }
                    break;
                    #endregion
                case DSFormMode.DSEdit:
                    #region Edit
                    switch (aAction)
                    {
                        case DSAFormAction.DSAInsert:
                            lIsValid = false;
                            aRtrnMsg = "Can't Insert";
                            break;
                        case DSAFormAction.DSAEdit:
                            lIsValid = false;
                            aRtrnMsg = "Can't Edit";
                            break;
                        case DSAFormAction.DSASave:
                            lIsValid = true;
                            aDstMode = DSFormMode.DSBrowse;
                            break;
                        case DSAFormAction.DSACancel:
                            lIsValid = true;
                            aDstMode = DSFormMode.DSBrowse;
                            break;
                        default:
                            lIsValid = false;
                            break;
                    }
                    break;
                    #endregion
                case DSFormMode.DSInsert:
                    #region Insert
                    switch (aAction)
                    {
                        case DSAFormAction.DSAInsert:
                            lIsValid = false;
                            aRtrnMsg = "Can't Insert ar";
                            break;
                        case DSAFormAction.DSAEdit:
                            lIsValid = false;
                            aRtrnMsg = "Can't Edit ar";
                            break;
                        case DSAFormAction.DSASave:
                            lIsValid = true;
                            aDstMode = DSFormMode.DSBrowse;
                            break;
                        case DSAFormAction.DSACancel:
                            lIsValid = true;
                            aDstMode = DSFormMode.DSBrowse;
                            break;
                        default:
                            lIsValid = false;
                            break;
                    }
                    break;
                    #endregion
                default:
                    lIsValid = false;
                    break;
            }

            return lIsValid;
        }
        protected int DSUpdateFormState()
        {
            int lIntResult = 0;

            switch (DsMode)
            {
                case DSFormMode.DSBrowse:
                    break;
                case DSFormMode.DSEdit:
                    break;
                case DSFormMode.DSInsert:
                    break;
            }
            return lIntResult;
        }
        protected void DSFAskSave()
        {
            bool lIsSaved = false;

            try
            {
                if (AskSave)
                {
                    mSaveState = (int)DevExpress.XtraEditors.XtraMessageBox.Show("Do you want to save this record?", "Save", System.Windows.Forms.MessageBoxButtons.YesNoCancel);
                    if (mSaveState == 6)
                    {
                        lIsSaved = Save();

                        if (!lIsSaved)
                        {
                            DevExpress.XtraEditors.XtraMessageBox.Show("Save is failure", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        protected void DSFAskDelete()
        {
            DataSet lDs = null;
            string lCurID = null;
            int lIsDeleted = -1;
            try
            {
                if (AskDelete)
                {
                    mDeleteState = (int)DevExpress.XtraEditors.XtraMessageBox.Show("Do you want to delete this record?", "Delete", System.Windows.Forms.MessageBoxButtons.YesNoCancel);
                    if (mDeleteState == 6)
                    {
                        lDs = new DataSet();
                        lDs.Tables.Add(((TBOT01)((Element)mForm02Tree.RootNode.Data).BOT01).Dt.Copy());
                        lCurID = BOT001.Dr[BOT001.SPrps.SKFldNm].ToString();
                        lIsDeleted = mForm02Tree.Delete(lDs);
                        if (lIsDeleted == 0)
                        {
                            DevExpress.XtraEditors.XtraMessageBox.Show(lCurID + " has been deleted Successfully", "Delete Successfully", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            this.Close();
                        }
                        else
                        {
                            if (lIsDeleted == -2146232060)
                            {
                                DevExpress.XtraEditors.XtraMessageBox.Show("DELETE action conflicted with xxxx \r\nDELETE action has been terminated.", "Delete has been terminated", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Locking
        private void SetLockControl(bool aLock)
        {
            System.Windows.Forms.Control.ControlCollection lControl = this.Controls;
            try
            {
                for (int i = 0; i < lControl.Count; i++)
                {
                    SetLock(lControl[i], aLock);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void SetLock(System.Windows.Forms.Control aControl, bool aLock)
        {
            bool lAllowLock = true;
            try
            {
                System.Windows.Forms.Control[] lCntrl = new System.Windows.Forms.Control[9];
                lCntrl[0] = btn02BaseNew;
                lCntrl[1] = btn02BaseSave;
                lCntrl[2] = btn02BaseEdit;
                lCntrl[3] = btn02BaseDelete;
                lCntrl[4] = btn02BaseCancel;
                lCntrl[5] = btn02BaseNext;
                lCntrl[6] = btn02BasePrevious;
                lCntrl[7] = btn02BaseFirst;
                lCntrl[8] = btn02BaseLast;
                for (int i = 0; i < lCntrl.Length; i++)
                {
                    if ((aControl.GetType() == typeof(Label)))
                    {
                        lAllowLock = false;
                    }
                    if ((aControl.GetType() == typeof(TTabControl02)))
                    {
                        SrchTabCntrl(aControl, aLock);
                        lAllowLock = false;
                    }
                    if ((aControl.GetType() == typeof(GroupControl)))
                    {
                        SrchGrpBoxCntrl(aControl, aLock);
                        lAllowLock = false;
                    }
                    if ((lCntrl[i] == aControl))
                    {
                        lAllowLock = false;
                    }
                }
                if (lAllowLock)
                {
                    SetReadOnly(aControl, aLock);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void SrchTabCntrl(System.Windows.Forms.Control aControl, bool aLock)
        {
            int lTabCount = 0;
            System.Windows.Forms.Control.ControlCollection lTabContrlCollection = null;
            try
            {
                lTabCount = ((TTabControl02)aControl).TabPages.Count;
                for (int i = 0; i < lTabCount; i++)
                {
                    lTabContrlCollection = ((TTabControl02)aControl).TabPages[i].Controls;
                    for (int j = 0; j < lTabContrlCollection.Count; j++)
                    {
                        //SetReadOnly(lTabContrlCollection[j], aLock);
                        SetLock(lTabContrlCollection[j], aLock);
                    }
                }

                //lTabCount = ((TabControl02)aControl).TabCount;
                //for (int i = 0; i < lTabCount; i++)
                //{
                //    lTabContrlCollection = ((TabControl02)aControl).TabPages[i].Controls;
                //    for (int j = 0; j < lTabContrlCollection.Count; j++)
                //    {
                //        //SetReadOnly(lTabContrlCollection[j], aLock);
                //        SetLock(lTabContrlCollection[j], aLock);
                //    }
                //}
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void SrchGrpBoxCntrl(System.Windows.Forms.Control aControl, bool aLock)
        {
            System.Windows.Forms.Control.ControlCollection lGrpContrlCollection = null;
            try
            {
                lGrpContrlCollection = ((GroupControl)aControl).Controls;
                for (int j = 0; j < lGrpContrlCollection.Count; j++)
                {
                    SetLock(lGrpContrlCollection[j], aLock);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        private void SetReadOnly(System.Windows.Forms.Control aControl, bool aLock)
        {
            PropertyInfo lPrprtyInfoEnbld = null;
            try
            {
                lPrprtyInfoEnbld = aControl.GetType().GetProperty("SetReadOnly");
                if (lPrprtyInfoEnbld != null)
                {
                    lPrprtyInfoEnbld.SetValue(aControl, aLock, null);
                }
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region Others
        protected virtual void Init()
        {
            try
            {
                if (Utilities.TGC.IsRunTime)
                {
                    InitTree();
                    if (mForm02Tree.RootNode != null)
                    {
                        BOT001 = (TBOT01)((Element)mForm02Tree.RootNode.Data).BOT01;
                    }
                    
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
        protected virtual void InitTree()
        {
            try
            {
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
        public void AddNew()
        {
            DsMode = DSFormMode.DSInsert;
            InitRcrd();
            Binding();
        }
        public void LoadByPK(string aMasterPK)
        {
            DsMode = DSFormMode.DSBrowse;
            InitRcrd(aMasterPK);
            Binding();
        }
        protected void InitRcrd()
        {
            TDataSetBuilder lDsBdr = null;
            DataSet lTmpRstDs = null;
            DataSet lDsTmp = null;
            DataTable lDtTmp = null;
            try
            {
                lDsBdr = new TDataSetBuilder();
                lDsBdr.LoadTreeByPK(mForm02Tree.RootNode, null);
                lTmpRstDs = mForm02Tree.AddNew(lDsBdr.Ds);
                foreach (INode lChild in mForm02Tree.Tree.AllChildren)
                {
                    lDsTmp = new DataSet();
                    lDtTmp = lTmpRstDs.Tables[((Element)lChild.Data).TableName].Copy();
                    lDsTmp.Tables.Add(lDtTmp);
                    ((TBOT01)((Element)lChild.Data).BOT01).Ds = lDsTmp;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
        protected void InitRcrd(string aMasterPK)
        {
            TDataSetBuilder lDsBdr = null;
            DataSet lTmpRstDs = null;
            DataSet lDsTmp = null;
            DataTable lDtTmp = null;
            try
            {
                lDsBdr = new TDataSetBuilder();
                lDsBdr.LoadTreeByPK(mForm02Tree.RootNode, aMasterPK);
                lTmpRstDs = mForm02Tree.LoadByPK(lDsBdr.Ds);
                foreach (INode lChild in mForm02Tree.Tree.AllChildren)
                {
                    lDsTmp = new DataSet();
                    lDtTmp = lTmpRstDs.Tables[((Element)lChild.Data).TableName].Copy();
                    lDsTmp.Tables.Add(lDtTmp);
                    ((TBOT01)((Element)lChild.Data).BOT01).Ds = lDsTmp;
                }
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message, ex);
            }
        }
        protected void Binding()
        {
            mBdsMaster.DataSource = BOT001;
            mBdsMaster.ResetBindings(true); //false
            GridBinding();
            OtherBinding();
        }
        protected virtual void GridBinding()
        {
        }
        protected virtual void OtherBinding()
        {
        }
        protected string Nav(string aDirection)
        {
            int lCurPos = 0;
            int lTotal = 0;
            string lRtrnVal = null;
            try
            {
                lRtrnVal = BOT001.Nav(BOT001.Dr[Utilities.TGC.PKeyName].ToString(), aDirection);
                //lRtrnVal = BOT001.Nav(((TBOT001)((Element)mForm02Tree.RootNode.Data).BOT01).Dr[Utilities.TGC.PKeyName].ToString(), aDirection, ref lCurPos, ref lTotal);
                //InitRcrd(lRtrnVal);
                LoadByPK(lRtrnVal);
            }
            catch (Exception)
            {
                throw;
            }
            return lRtrnVal;
        }
        private void Reload()
        {
            try
            {
                //InitRcrd(BOT001.Dr[Utilities.TGC.PKeyName].ToString());
                LoadByPK(BOT001.Dr[Utilities.TGC.PKeyName].ToString());
                //InitRcrd(((TBOT001)((Element)mForm02Tree.RootNode.Data).BOT01).Dr[Utilities.TGC.PKeyName].ToString());
            }
            catch (Exception)
            {
                throw;
            }
        }
        #endregion

        #region CRUD
        protected bool Save()
        {
            bool lRtrnVal = mForm02Tree.Save();

            return lRtrnVal;
        }
        #endregion

        #endregion
    }

}