﻿using System;
using System.Collections.Generic;
using System.Text;
using DevExpress.XtraBars;
using System.Data;
using Innotelli.Utilities;
using Innotelli.BO;
using System.Windows.Forms;

namespace Innotelli.WinForm.Control
{
    public static class TMenu
    {
        #region Delegates
        public delegate void MiscTaskDelegate(string aMenuGUID, string aParam);
        #endregion

        #region Members
        private static TSysDataRdr mSysDataRdr = Innotelli.Utilities.TSingletons.SysData01Rdr;
        #endregion

        #region Constructors
        #endregion

        #region Properties
        private static TForm25 mParentForm = null;
        public static TForm25 ParentForm
        {
            get
            {
                return mParentForm;
            }
            set 
            {
                mParentForm = value;
            }
        }
        public static BarManager BarManager
        {
            get 
            {
                return mParentForm.bmgThis;
            }
        }
        public static Bar MainMenuBar
        {
            get 
            {
                return mParentForm.barMainMenu; 
            }
        }
        public static MiscTaskDelegate MiscTask;
        #endregion

        #region Event Handlers
        private static void ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {
            TMenuItem lMenuItem = (TMenuItem)e.Item.Tag;
            string lUINameSpace = string.Empty;

            if (lMenuItem.BOID != null && lMenuItem.BOID.StartsWith("TB0"))
            {
                switch (lMenuItem.BOID.Substring(3, 1))
                {
                    case "1":
                        lUINameSpace = Innotelli.BO.TSingletons.SPrpsBOT01s[lMenuItem.BOID].UINameSpace;
                        break;
                    case "3":
                        lUINameSpace = Innotelli.BO.TSingletons.SPrpsBOT03s[lMenuItem.BOID].UINameSpace;
                        break;
                    case "4":
                        lUINameSpace = Innotelli.BO.TSingletons.SPrpsBOT04s[lMenuItem.BOID].UINameSpace;
                        break;
                    case "6":
                        lUINameSpace = Innotelli.BO.TSingletons.SPrpsBOT06s[lMenuItem.BOID].UINameSpace;
                        break;
                }
            }


            switch (lMenuItem.MenuActnTp)
            {
                case 1:
                    TFormUtil.CreateFindForm(lMenuItem.BOID);
                    break;
                case 2:
                    TFormUtil.Show(lUINameSpace + ".TF01" + lMenuItem.BOID.Substring(4));
                    break;
                case 3:
                    TFormUtil.OpenReportExplorer(lMenuItem.BOID);
                    break;
                case 4:
                    TFormUtil.Show(lUINameSpace + ".TF05" + lMenuItem.BOID.Substring(4));
                    break;
                case 5:
                    TFormUtil.OpenForm06(lUINameSpace + ".TF06" + lMenuItem.BOID.Substring(4), lMenuItem.BOID);
                    break;
                case 8:
                    TFormUtil.Show(lUINameSpace + ".TF08" + lMenuItem.BOID.Substring(4));
                    break;
                case 11:
                    mParentForm.LogOff();
                    break;
                case 12:
                    mParentForm.Exit();
                    break;
                case 999:
                    mParentForm.mDefaultLookAndFeel.LookAndFeel.SetSkinStyle(lMenuItem.BOID);
                    break;
                default:
                    MiscTask(lMenuItem.MenuGUID, lMenuItem.BOID);
                    break;
            }
        }
        #endregion

        #region Functions
        public static void GenMainMenu()
        {
            bool lIsBeginGroup = false;
            DataTable lMenuLvl1Dt = mSysDataRdr.GetSysData("MenuLvl1").Tables[0];
            DataTable lMenuLvl2Dt = mSysDataRdr.GetSysData("MenuLvl2").Tables[0];
            DataTable lMenuLvl3Dt = mSysDataRdr.GetSysData("MenuLvl3").Tables[0];
            DataView lMenuLvl1Dv = new DataView();
            DataView lMenuLvl2Dv = new DataView();
            DataView lMenuLvl3Dv = new DataView();
            DataRow lDrLvl1 = null;
            DataRow lDrLvl2 = null;
            DataRow lDrLvl3 = null;
            TMenuItem lMenuItem = null;
            DevExpress.XtraBars.BarSubItem lBarSubItemLvl1 = null;
            DevExpress.XtraBars.BarSubItem lBarSubItemLvl2 = null;
            DevExpress.XtraBars.BarButtonItem lBarButtonItem = null;
            int i;
            int j;
            int k;

            lMenuLvl1Dv.Table = lMenuLvl1Dt;
            lMenuLvl2Dv.Table = lMenuLvl2Dt;
            lMenuLvl3Dv.Table = lMenuLvl3Dt;
            lMenuLvl1Dv.Sort = "SeqNo";
            for (i = 0; i < lMenuLvl1Dv.Count; i++)
            {
                lDrLvl1 = lMenuLvl1Dv[i].Row;
                lBarSubItemLvl1 = new DevExpress.XtraBars.BarSubItem();
                lBarSubItemLvl1.Id = BarManager.GetNewItemId(); //Set the bar item's ID to allow the bar's layout to be saved and restored correctly. 
                BarManager.Items.Add(lBarSubItemLvl1);
                MainMenuBar.AddItem(lBarSubItemLvl1);
                lBarSubItemLvl1.Caption = GetLocalizedMenuDisplay(lDrLvl1);

                lMenuLvl2Dv.RowFilter = Innotelli.Utilities.TGC.FKeyName + " = " + lDrLvl1[Innotelli.Utilities.TGC.PKeyName];
                lMenuLvl2Dv.Sort = "SeqNo";

                #region Level 2
                for (j = 0; j < lMenuLvl2Dv.Count; j++)
                {
                    lDrLvl2 = lMenuLvl2Dv[j].Row;
                    if ((bool)lDrLvl2["IsGroupSeparator"])
                    {
                        lIsBeginGroup = true;
                    }
                    else
                    {
                        if (!((bool)lDrLvl2["IsSubItem"]))
                        {
                            if (TCurrentUser.B01UserMMenu.AllwReadBO(lDrLvl2["BOID"].ToString()))
                            {
                                lBarButtonItem = new DevExpress.XtraBars.BarButtonItem();
                                lBarButtonItem.Id = BarManager.GetNewItemId(); //Set the bar item's ID to allow the bar's layout to be saved and restored correctly. 
                                BarManager.Items.Add(lBarButtonItem);
                                if (lIsBeginGroup)
                                {
                                    lBarSubItemLvl1.AddItem(lBarButtonItem).BeginGroup = true;
                                    lIsBeginGroup = false;
                                }
                                else
                                {
                                    lBarSubItemLvl1.AddItem(lBarButtonItem);
                                }
                                lBarButtonItem.Caption = GetLocalizedMenuDisplay(lDrLvl2);
                                lMenuItem = new TMenuItem();
                                lMenuItem.MenuActnTp = (int)lDrLvl2["MenuActnTp"];
                                lMenuItem.BOID = lDrLvl2["BOID"].ToString();
                                lMenuItem.MenuGUID = lDrLvl2["MenuGUID"].ToString();
                                lBarButtonItem.Tag = lMenuItem;
                                lBarButtonItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(ItemClick);
                            }

                        }
                        else
                        {
                            lBarSubItemLvl2 = new DevExpress.XtraBars.BarSubItem();
                            lBarSubItemLvl2.Id = BarManager.GetNewItemId(); //Set the bar item's ID to allow the bar's layout to be saved and restored correctly. 
                            BarManager.Items.Add(lBarSubItemLvl2);
                            if (lIsBeginGroup)
                            {
                                lBarSubItemLvl1.AddItem(lBarSubItemLvl2).BeginGroup = true;
                                lIsBeginGroup = false;
                            }
                            else
                            {
                                lBarSubItemLvl1.AddItem(lBarSubItemLvl2);
                            }

                            lBarSubItemLvl2.Caption = GetLocalizedMenuDisplay(lDrLvl2);
                            lMenuLvl3Dv.RowFilter = Innotelli.Utilities.TGC.FKeyName + " = " + lDrLvl2[Innotelli.Utilities.TGC.PKeyName];
                            lMenuLvl3Dv.Sort = "SeqNo";

                            #region Level 3
                            for (k = 0; k < lMenuLvl3Dv.Count; k++)
                            {
                                lDrLvl3 = lMenuLvl3Dv[k].Row;
                                if ((bool)lDrLvl3["IsGroupSeparator"])
                                {
                                    lIsBeginGroup = true;
                                }
                                else
                                {
                                    if (TCurrentUser.B01UserMMenu.AllwReadBO(lDrLvl2["BOID"].ToString()))
                                    {
                                        // Item
                                        lBarButtonItem = new DevExpress.XtraBars.BarButtonItem();
                                        lBarButtonItem.Id = BarManager.GetNewItemId(); //Set the bar item's ID to allow the bar's layout to be saved and restored correctly. 
                                        BarManager.Items.Add(lBarButtonItem);
                                        if (lIsBeginGroup)
                                        {
                                            lBarSubItemLvl2.AddItem(lBarButtonItem).BeginGroup = true;
                                            lIsBeginGroup = false;
                                        }
                                        else
                                        {
                                            lBarSubItemLvl2.AddItem(lBarButtonItem);
                                        }
                                        lBarButtonItem.Caption = GetLocalizedMenuDisplay(lDrLvl3);
                                        lMenuItem = new TMenuItem();
                                        lMenuItem.MenuActnTp = (int)lDrLvl3["MenuActnTp"];
                                        lMenuItem.BOID = lDrLvl3["BOID"].ToString();
                                        lMenuItem.MenuGUID = lDrLvl3["MenuGUID"].ToString();
                                        lBarButtonItem.Tag = lMenuItem;
                                        lBarButtonItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(ItemClick);
                                    }
                                }
                            }
                            #endregion
                        }
                    }
                }
                #endregion
            }

            string[] lSkinList = new string[] {"Caramel", "Money Twins", "Lilian", "The Asphalt World", "iMaginary",
                                            "Black", "Blue", "Office 2007 Blue", "Office 2007 Black", "Office 2007 Silver", 
                                            "Office 2007 Green", "Office 2007 Pink", "Coffee", "Liquid Sky",
                                            "London Liquid Sky", "Glass Oceans", "Stardust", "Xmas 2008 Blue",
                                            "Valentine", "McSkin", "Summer 2008"};

            BarSubItem lBarSubItemSkin = new DevExpress.XtraBars.BarSubItem();
            lBarSubItemSkin.Id = BarManager.GetNewItemId(); //Set the bar item's ID to allow the bar's layout to be saved and restored correctly. 
            BarManager.Items.Add(lBarSubItemSkin);
            MainMenuBar.AddItem(lBarSubItemSkin);
            lBarSubItemSkin.Caption = "Skins";

            for (int llength = 0; llength < lSkinList.Length; llength++)
            {
                lBarButtonItem = new BarButtonItem();
                lBarButtonItem.Id = BarManager.GetNewItemId(); //Set the bar item's ID to allow the bar's layout to be saved and restored correctly. 
                BarManager.Items.Add(lBarButtonItem);
                lBarButtonItem.Caption = lSkinList[llength];
                lMenuItem = new TMenuItem();
                lMenuItem.MenuActnTp = 999;
                lMenuItem.BOID = lSkinList[llength];
                lBarButtonItem.Tag = lMenuItem;
                lBarSubItemSkin.AddItem(lBarButtonItem);
                lBarButtonItem.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(ItemClick);
            }
        }
        private static string GetLocalizedMenuDisplay(DataRow aDr)
        {
            string lReturnValue = string.Empty;

            switch (Innotelli.Utilities.TAppSettings.SystemLanguage)
            {
                case SystemLanguages.English:
                    lReturnValue = aDr["MenuDisplay"].ToString();
                    break;
                case SystemLanguages.TraditionalChinese:
                    lReturnValue = aDr["MenuDisplayTCh"].ToString();
                    break;
                case SystemLanguages.SimplifiedChinese:
                    lReturnValue = aDr["MenuDisplaySCh"].ToString();
                    break;
            }

            return lReturnValue;
        }
        #endregion
    }
}
