using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Controls;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Grid;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    public partial class TForm04 : DevExpress.XtraEditors.XtraForm
    {
        #region Members
        protected TSysDataRdr mSysDataRdr = Innotelli.Utilities.TSingletons.SysData01Rdr;
        protected DataView mOperatorDv = new DataView();
        protected DataView mFieldNameDv = new DataView();
        private bool IsCrtieriaEnterKeyPressed = false;
        private RepositoryItemLookUpEdit mFieldNameRepositoryItemLookUpEdit = new RepositoryItemLookUpEdit();
        private RepositoryItemLookUpEdit mOperatorRepositoryItemLookUpEdit = new RepositoryItemLookUpEdit();
        private RepositoryItemCheckEdit mValue1RepositoryItemCheckEdit = new RepositoryItemCheckEdit();
        private RepositoryItemDateEdit mValue1RepositoryItemDateEdit = new RepositoryItemDateEdit();
        private RepositoryItemDateEdit mValue2RepositoryItemDateEdit = new RepositoryItemDateEdit();
        private RepositoryItemTextEdit mValue1RepositoryItemTextEdit = new RepositoryItemTextEdit();
        private RepositoryItemTextEdit mValue2RepositoryItemTextEdit = new RepositoryItemTextEdit();
        private TSearchListTask mSearchListTask = null;
        #endregion

        #region Constructors
        public TForm04()
        {
            InitializeComponent();
        }
        #endregion

        #region Properties
        protected string mBOID = string.Empty;
        public string BOID
        {
            get
            {
                return mBOID;
            }
            set
            {
                mBOID = value;
                mSearchList.BOID = BOID;
            }
        }
        private string mSelectedPK = null;
        public string SelectedPK
        {
            get
            {
                return mSelectedPK;
            }
            set
            {
                mSelectedPK = value;
            }
        }
        private bool mShowForm02AfterSelect = true;
        public bool ShowForm02AfterSelect
        {
            get
            {
                return mShowForm02AfterSelect;
            }
            set
            {
                mShowForm02AfterSelect = value;
            }
        }
        private bool mShowAllByDefault = false;
        public bool ShowAllByDefault
        {
            get
            {
                return mShowAllByDefault;
            }
            set
            {
                mShowAllByDefault = value;
            }
        }
        private string mOtherFilter = string.Empty;
        public string OtherFilter
        {
            get
            {
                return mOtherFilter;
            }
            set
            {
                mOtherFilter = value;
                mSearchList.OtherFilter = value;
            }
        }
        protected TSearchList mSearchList = new TSearchList();
        public TSearchList SearchList
        {
            get
            {
                return mSearchList;
            }
            set
            {
                mSearchList = value;
            }
        }
        private bool mSearching = false;
        public bool Searching
        {
            get
            {
                return mSearching;
            }
            set
            {
                mSearching = value;
                if (mSearching)
                {
                    btnSearch.Text = Innotelli.Utilities.TSingletons.StrResx.GetStr(124);
                }
                else
                {
                    btnSearch.Text = Innotelli.Utilities.TSingletons.StrResx.GetStr(114);
                    btnSearch.Enabled = true;
                }
                btnShowAll.Enabled = !mSearching;
            }
        }
        #endregion

        #region Event Handlers
        private void mFieldNameRepositoryItemLookUpEdit_CloseUp(object sender, ClosedEventArgs e)
        {
            gdvCriteria.PostEditor();
        }
        private void mOperatorRepositoryItemLookUpEdit_CloseUp(object sender, ClosedEventArgs e)
        {
            gdvCriteria.PostEditor();
        }
        private void TForm04_Load(object sender, EventArgs e)
        {
            InitializeSearchListTask();
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                GridColumn lColValue1 = gdvCriteria.Columns.ColumnByName("colValue1");
                PrepareDataViews();
                PrepareInPlaceEditors();
                PrepareGrdCriteria();
                AssignInPlaceEditors();
                RefreshValueColumns();
                GenColumns();
                grdCriteria.Select();
                gdvCriteria.FocusedColumn = lColValue1;
                if (mShowAllByDefault)
                {
                    Search(true);
                }
                //try
                //{
                //    grdSearchResults.MainView.RestoreLayoutFromXml(@"C:\test.xml");
                //}
                //catch
                //{
                //}
            }
        }
        private void TForm04_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                Search(false);
                e.Handled = true;
            }
            else if (e.KeyCode == Keys.F3)
            {
                gdvCriteria.Focus();
            }
        }
        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (Searching)
            {
                mSearchListTask.StopSearch = true;
                btnSearch.Enabled = false;
            }
            else
            {
                Search(false);
            }
        }
        private void btnNew_Click(object sender, EventArgs e)
        {
            ShowForm(null);
        }
        private void btnShowAll_Click(object sender, EventArgs e)
        {
            if (TMessageBox.AskQuestion(Innotelli.Utilities.TSingletons.StrResx.GetStr(92), MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                Search(true);
            }
        }
        private void btnOpen_Click(object sender, EventArgs e)
        {
            ProcessSelection();
        }
        private void gdvSearchResults_DoubleClick(object sender, EventArgs e)
        {
            ProcessSelection();
        }
        private void gdvSearchResults_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                ProcessSelection();
                e.Handled = true;
            }
        }
        private void gdvCriteria_CellValueChanged(object sender, CellValueChangedEventArgs e)
        {
            DataRow[] lDrs = null;

            switch (e.Column.FieldName)
            {
                case "FieldName":
                    lDrs = mFieldNameDv.Table.Select("FldNm = '" + e.Value + "'");
                    mSearchList.CriteriaRow["FieldType"] = lDrs[0]["FldType"];
                    AssignValuesInPlaceEditors();
                    break;
                case "Operator":
                    RefreshValueColumns();
                    break;
                default:
                    break;
            }
        }
        public void EnforceDoValidate()
        {
            grdCriteria.MainView.UpdateCurrentRow();
        }

        private void gdvCriteria_KeyUp(object sender, KeyEventArgs e)
        {
            //how to check the active column
            if (gdvCriteria.FocusedColumn.Name == "colValue1" || gdvCriteria.FocusedColumn.Name == "colValue2")
            {
                if (e.KeyCode == Keys.Enter && IsCrtieriaEnterKeyPressed)
                {
                    //EnforceDoValidate();
                    Search(false);
                    e.Handled = true;
                    IsCrtieriaEnterKeyPressed = false;
                }
            }
        }
        private void gdvCriteria_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                IsCrtieriaEnterKeyPressed = true;
            }
        }
        private void mSearchList_WorkerCompleted(object sender, TWorkerCompletedEventArgs e)
        {
            DataTable lDt = null;
            string lPK = string.Empty;

            pgbSearch.EditValue = 0;
            layoutControlItem011.ContentVisible = false;
            if (grdSearchResults.DataSource == null)
            {
                TMessageBox.ShowInformation(Innotelli.Utilities.TSingletons.StrResx.GetStr(93));
            }
            else
            {
                lDt = (DataTable)(grdSearchResults.DataSource);
                if (lDt.Rows.Count == 0)
                {
                    TMessageBox.ShowInformation(Innotelli.Utilities.TSingletons.StrResx.GetStr(94));
                    gdvCriteria.Focus();
                }
                else if (lDt.Rows.Count == 1 && mShowForm02AfterSelect)
                {
                    lPK = lDt.Rows[0][Innotelli.Utilities.TGC.PKeyName].ToString();
                    if (!string.IsNullOrEmpty(lPK))
                    {
                        mSelectedPK = lPK;
                        ShowForm(mSelectedPK);
                    }
                }
                else
                {
                    gdvSearchResults.Focus();
                }
            }
            Cursor.Current = Cursors.Default;
            Searching = false;
        }
        private void mSearchList_ReportWorkerProgress(object sender, TReportWorkerProgressEventArgs e)
        {
            DataTable lDtResult = null;
            DataTable lDtSource = null;
            KeyValuePair<DataTable, int> lKeyValuePair;
            int lCount = 0;

            lKeyValuePair = (KeyValuePair<DataTable, int>)e.PartialResult;
            lDtResult = lKeyValuePair.Key;
            lCount = lKeyValuePair.Value;
            txtTotalSearchedRecord.Text = lCount.ToString();

            if (lCount != 0)
            {
                pgbSearch.EditValue = e.Progress * 100 / lCount;
            }
            if (e.Progress == 0)
            {
                grdSearchResults.DataSource = lDtResult;
            }
            else
            {
                if (e.Progress != lCount)
                {
                    layoutControlItem011.ContentVisible = true;
                }
                lDtSource = (DataTable)(grdSearchResults.DataSource);
                lDtSource.Merge(lDtResult);
            }
        }
        private void TForm04_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (Searching)
            {
                e.Cancel = true;
                TMessageBox.ShowWarning(Innotelli.Utilities.TSingletons.StrResx.GetStr(95));
            }
        }
        #endregion

        #region Functions
        private void InitializeSearchListTask()
        {
            mSearchListTask = new TSearchListTask(SearchList);
            mSearchListTask.InvokeContext = this;
            mSearchListTask.SupportsProgress = true;
            mSearchListTask.WorkerCompleted += new WorkerCompletedEventHandler(mSearchList_WorkerCompleted);
            mSearchListTask.ReportWorkerProgress += new ReportWorkerProgressEventHandler(mSearchList_ReportWorkerProgress);
        }
        protected virtual void PrepareDataViews()
        {
            DataTable lDt = null;

            lDt = mSysDataRdr.GetSysData("SrchCndtn").Tables[0];
            mOperatorDv.Table = lDt;
            mOperatorDv.Sort = "Sort";

            lDt = Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].SPrpsBOT01FindCols.Dt;
            mFieldNameDv.Table = lDt;
            mFieldNameDv.Sort = "Caption";
            mFieldNameDv.RowFilter = "CanSrch = True";

        }
        private void PrepareInPlaceEditors()
        {
            LookUpColumnInfo lLookUpColumnInfo = null;

            lLookUpColumnInfo = new LookUpColumnInfo();
            mFieldNameRepositoryItemLookUpEdit.Columns.Add(lLookUpColumnInfo);
            switch (Innotelli.Utilities.TAppSettings.SystemLanguage)
            {
                case SystemLanguages.English:
                    mFieldNameRepositoryItemLookUpEdit.Columns[0].FieldName = "Caption";
                    mFieldNameRepositoryItemLookUpEdit.DisplayMember = "Caption";
                    break;
                case SystemLanguages.SimplifiedChinese:
                    mFieldNameRepositoryItemLookUpEdit.Columns[0].FieldName = "CaptionSCh";
                    mFieldNameRepositoryItemLookUpEdit.DisplayMember = "CaptionSCh";
                    break;
                case SystemLanguages.TraditionalChinese:
                    mFieldNameRepositoryItemLookUpEdit.Columns[0].FieldName = "CaptionTCh";
                    mFieldNameRepositoryItemLookUpEdit.DisplayMember = "CaptionTCh";
                    break;
            }
            mFieldNameRepositoryItemLookUpEdit.ValueMember = "FldNm";
            mFieldNameRepositoryItemLookUpEdit.NullText = null;
            mFieldNameRepositoryItemLookUpEdit.ShowHeader = false;
            mFieldNameRepositoryItemLookUpEdit.DataSource = mFieldNameDv;
            mFieldNameRepositoryItemLookUpEdit.Closed += mFieldNameRepositoryItemLookUpEdit_CloseUp;

            lLookUpColumnInfo = new LookUpColumnInfo();
            mOperatorRepositoryItemLookUpEdit.Columns.Add(lLookUpColumnInfo);
            switch (Innotelli.Utilities.TAppSettings.SystemLanguage)
            {
                case SystemLanguages.English:
                    lLookUpColumnInfo.FieldName = "Cndtn";
                    mOperatorRepositoryItemLookUpEdit.DisplayMember = "Cndtn";
                    break;
                case SystemLanguages.SimplifiedChinese:
                    lLookUpColumnInfo.FieldName = "CndtnSCh";
                    mOperatorRepositoryItemLookUpEdit.DisplayMember = "CndtnSCh";
                    break;
                case SystemLanguages.TraditionalChinese:
                    lLookUpColumnInfo.FieldName = "CndtnTCh";
                    mOperatorRepositoryItemLookUpEdit.DisplayMember = "CndtnTCh";
                    break;
            }
            mOperatorRepositoryItemLookUpEdit.ValueMember = "Cndtn";
            mOperatorRepositoryItemLookUpEdit.NullText = null;
            mOperatorRepositoryItemLookUpEdit.ShowHeader = false;
            mOperatorRepositoryItemLookUpEdit.DataSource = mOperatorDv;
            mOperatorRepositoryItemLookUpEdit.Closed += mOperatorRepositoryItemLookUpEdit_CloseUp;
        }
        protected virtual void PrepareGrdCriteria()
        {
            grdCriteria.DataSource = mSearchList.CriteriaTable;
            mSearchList.CriteriaRow["FieldName"] = Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].SchFldNm;
            mSearchList.CriteriaRow["FieldType"] = Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].SPrpsBOT01FindCols[Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].SchFldNm].FldType;
            mSearchList.CriteriaRow["Operator"] = Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].DftCndtn;
        }
        private void AssignInPlaceEditors()
        {
            grdCriteria.RepositoryItems.Add(mFieldNameRepositoryItemLookUpEdit);
            colFieldName.ColumnEdit = mFieldNameRepositoryItemLookUpEdit;
            colFieldName.ShowButtonMode = ShowButtonModeEnum.ShowAlways;

            grdCriteria.RepositoryItems.Add(mOperatorRepositoryItemLookUpEdit);
            colOperator.ColumnEdit = mOperatorRepositoryItemLookUpEdit;
            colOperator.ShowButtonMode = ShowButtonModeEnum.ShowAlways;

            grdCriteria.RepositoryItems.Add(mValue1RepositoryItemCheckEdit);
            grdCriteria.RepositoryItems.Add(mValue1RepositoryItemDateEdit);
            grdCriteria.RepositoryItems.Add(mValue2RepositoryItemDateEdit);
            grdCriteria.RepositoryItems.Add(mValue1RepositoryItemTextEdit);
            grdCriteria.RepositoryItems.Add(mValue2RepositoryItemTextEdit);

            AssignValuesInPlaceEditors();
        }
        private void AssignValuesInPlaceEditors()
        {
            string lFldType = string.Empty;

            lFldType = mSearchList.CriteriaRow["FieldType"].ToString();
            switch (lFldType)
            {
                case "BIT":
                    colValue1.ColumnEdit = mValue1RepositoryItemCheckEdit;
                    //colValue1.ShowButtonMode = ShowButtonModeEnum.ShowAlways;
                    break;
                case "DATE":
                    colValue1.ColumnEdit = mValue1RepositoryItemDateEdit;
                    colValue2.ColumnEdit = mValue2RepositoryItemDateEdit;
                    break;
                default:
                    colValue1.ColumnEdit = mValue1RepositoryItemTextEdit;
                    colValue2.ColumnEdit = mValue2RepositoryItemTextEdit;
                    break;
            }
            mSearchList.CriteriaRow["Value1"] = null;
            mSearchList.CriteriaRow["Value2"] = null;
            //this.grdSearchResults.S
        }
        private void RefreshValueColumns()
        {
            string lOperator = string.Empty;

            //colFieldName.OptionsColumn.FixedWidth = true;
            //colOperator.OptionsColumn.FixedWidth = true;
            lOperator = mSearchList.CriteriaRow["Operator"].ToString();
            if (lOperator == "Is between")
            {
                colAnd.Visible = true;
                colValue2.Visible = true;
                //mSearchList.CriteriaRow["And"] = "And";
                //colAnd.OptionsColumn.ReadOnly = false;
                //colAnd.OptionsColumn.AllowEdit = true;
                //colAnd.OptionsColumn.AllowFocus = true;
                //colValue2.OptionsColumn.ReadOnly = false;
                //colValue2.OptionsColumn.AllowEdit = true;
                //colValue2.OptionsColumn.AllowFocus = true;
            }
            else
            {
                colAnd.Visible = false;
                colValue2.Visible = false;
                //mSearchList.CriteriaRow["And"] = null;
                //colAnd.OptionsColumn.ReadOnly = true;
                //colAnd.OptionsColumn.AllowEdit = false;
                //colAnd.OptionsColumn.AllowFocus = false;
                //colValue2.OptionsColumn.ReadOnly = true;
                //colValue2.OptionsColumn.AllowEdit = false;
                //colValue2.OptionsColumn.AllowFocus = false;
            }
            //colFieldName.OptionsColumn.FixedWidth = false;
            //colOperator.OptionsColumn.FixedWidth = false;
        }
        protected virtual void GenColumns()
        {
            GridView lGv = null;
            DataTable lDt = null;
            int lWidth = 0;
            TSPrpsBOT01FindCol lSPrpsBOT01FindCol = null;
            int lVisibleIndex = 0;

            lDt = Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].SPrpsBOT01FindCols.Dt;
            lGv = ((GridView)(grdSearchResults.MainView));
            lGv.OptionsView.ColumnAutoWidth = false;
            grdSearchResults.DataSource = null;
            for (int i = 0; i < Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].SPrpsBOT01FindCols.Count; i++)
            {
                lSPrpsBOT01FindCol = Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].SPrpsBOT01FindCols[i];
                if (lSPrpsBOT01FindCol.Visible)
                {
                    GridColumn lGc = new GridColumn();
                    lGc.Caption = lSPrpsBOT01FindCol.Caption;
                    lGc.FieldName = lSPrpsBOT01FindCol.FldNm;
                    lGc.Visible = lSPrpsBOT01FindCol.Visible;
                    lWidth = int.Parse(lDt.Rows[i]["Width"].ToString());
                    lGc.Width = (int)(lWidth / TGC.TwipsPerPixel) + 26;
                    lGc.VisibleIndex = lVisibleIndex;
                    lGc.OptionsColumn.AllowEdit = false;
                    lGc.OptionsColumn.ReadOnly = true;
                    if (!string.IsNullOrEmpty(lSPrpsBOT01FindCol.Format))
                    {
                        lGc.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
                        lGc.DisplayFormat.FormatString = lSPrpsBOT01FindCol.Format;
                    }
                    lGv.Columns.Add(lGc);
                    lVisibleIndex++;
                }
            }
            Text = Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].FindFormCaption;
        }
        private void Search(bool aShowAll)
        {
            string lCriteriaFromCriteriaRow = string.Empty;
            GridView lGv = null;
            bool lIsValidSearch = false;

            ResetSelectedPK();
            Cursor.Current = Cursors.WaitCursor;
            if (aShowAll)
            {
                lIsValidSearch = true;
            }
            else
            {
                lCriteriaFromCriteriaRow = mSearchList.GetCriteriaFromCriteriaRow();
                if (lCriteriaFromCriteriaRow != string.Empty)
                {
                    lIsValidSearch = true;
                }
            }
            if (lIsValidSearch && !Searching)
            {
                mSearchList.Criteria = lCriteriaFromCriteriaRow;
                mSearchList.DefaultOrderByField = Innotelli.Utilities.TGC.PKeyName;
                mSearchList.OrderByFieldList = string.Empty;
                lGv = ((GridView)(grdSearchResults.MainView));

                if (lGv.SortedColumns.Count != 0)
                {
                    foreach (GridColumn lgc in lGv.SortedColumns)
                    {
                        mSearchList.OrderByFieldList += lgc.FieldName;
                        if (lgc.SortOrder == DevExpress.Data.ColumnSortOrder.Descending)
                        {
                            mSearchList.OrderByFieldList += " DESC";
                        }
                        mSearchList.OrderByFieldList += ",";
                    }
                    mSearchList.OrderByFieldList = TStr.RemoveLastCharacter(mSearchList.OrderByFieldList, ",");
                }
                Searching = true;
                mSearchListTask.Start();
            }
            else
            {
                Cursor.Current = Cursors.Default;
            }
        }
        private void ShowForm(string aPK)
        {
            TForm02 lForm02;
            bool lToBeVisible = false;

            Cursor.Current = Cursors.WaitCursor;
            try
            {
                lForm02 = TSingletons.Form02Pool.GetForm(Innotelli.BO.TSingletons.SPrpsBOT01s[BOID].DefaultForm02Name);
                if (lForm02 != null)
                {
                    lForm02.MdiParent = Innotelli.WinForm.Control.TSingletons.RootMdiParent;
                    if ((aPK != null))
                    {
                        lToBeVisible = lForm02.LoadByPK(aPK);
                    }
                    else
                    {
                        lToBeVisible = lForm02.AddNew();
                    }
                    lForm02.Visible = lToBeVisible;
                }
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }

        }
        private void SetSelectedPK()
        {
            string lPK = null;
            GridView lGv = null;

            if (grdSearchResults.DataSource != null && ((DataTable)grdSearchResults.DataSource).Rows.Count != 0)
            {
                lGv = ((GridView)(grdSearchResults.MainView));
                lPK = lGv.GetRowCellValue(lGv.GetSelectedRows()[0], Utilities.TGC.PKeyName).ToString();
                SelectedPK = lPK;
            }
        }
        private void ResetSelectedPK()
        {
            mSelectedPK = null;
        }
        public static string ShowAndGetSelectedPK(string aBOID, string aOtherFilter, bool aShowAllByDefault)
        {
            string lReturnValue = null;
            TForm04 lForm04 = new TForm04();

            lForm04.BOID = aBOID;
            lForm04.OtherFilter = aOtherFilter;
            lForm04.ShowAllByDefault = aShowAllByDefault;
            lForm04.ShowForm02AfterSelect = false;
            lForm04.btnOpen.Text = Innotelli.Utilities.TSingletons.StrResx.GetStr(123);

            if (lForm04.ShowDialog() == DialogResult.OK)
            {
                lReturnValue = lForm04.SelectedPK;
            }
            else
            {
                lReturnValue = null;
            }
            return lReturnValue;
        }
        private void ProcessSelection()
        {
            SetSelectedPK();
            if (mShowForm02AfterSelect)
            {
                if (mSelectedPK != null)
                {
                    ShowForm(mSelectedPK);
                }
            }
            else
            {
                DialogResult = DialogResult.OK;
            }
        }
        #endregion
    }
}