using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using System;
using DevExpress.Utils;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{

    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterDecimalTextBox04")]
    public class RepositoryItemDecimalTextBox04 : RepositoryItemTextEdit
    {
        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static RepositoryItemDecimalTextBox04() { RegisterDecimalTextBox04(); }

        //The unique name for the custom editor
        public const string DecimalTextBox04Name = "TDecimalTextBox04";

        //Return the unique name
        public override string EditorTypeName { get { return DecimalTextBox04Name; } }

        //Register the editor
        public static void RegisterDecimalTextBox04()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.DecimalTextBox04.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(DecimalTextBox04Name,
              typeof(TDecimalTextBox04), typeof(RepositoryItemDecimalTextBox04),
              typeof(TextEditViewInfo), new TextEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemDecimalTextBox04 source = item as RepositoryItemDecimalTextBox04;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }

        #endregion

        #region Constructors

        //Initialize new properties
        public RepositoryItemDecimalTextBox04()
        {
        }

        #endregion

        #region Properties
        DSFormMode mDSFormMode = DSFormMode.DSEditable;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                TRepositoryItemTextEditUtil.SetDSFormModeReadOnly(this, value);
                mDSFormMode = value;
            }
        }
        #endregion

        #region Functions

        public void Init()
        {
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            Appearance.Options.UseBackColor = true;
            Appearance.Options.UseTextOptions = true;
            Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            AppearanceReadOnly.Options.UseBackColor = true;
            AppearanceReadOnly.Options.UseTextOptions = true;
            AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            MaxLength = 255;
            ReadOnly = true;
            DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            DisplayFormat.FormatString = TSettings.DecFormat;
            EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            EditFormat.FormatString = TSettings.DecFormat;
            Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            Mask.EditMask = TSettings.DecFormat;
        }
        #endregion

    }


    public class TDecimalTextBox04 : TextEdit
    {
        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static TDecimalTextBox04() { RepositoryItemDecimalTextBox04.RegisterDecimalTextBox04(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemDecimalTextBox04.DecimalTextBox04Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemDecimalTextBox04 Properties
        {
            get { return base.Properties as RepositoryItemDecimalTextBox04; }
        }

        #endregion

        #region Constructors
        

        //Initialize the new instance
        public TDecimalTextBox04()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(50, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        private string mFormat = TSettings.DecFormat;
        [Bindable(true),
        Category("Behavior"),
        DefaultValue("n"),
        Description("Indicates the numeric format."),
        Localizable(true)]
        public string Format
        {
            get
            {
                return mFormat;
            }
            set
            {
                mFormat = value;
            }
        }
        #endregion

        #region Event Handlers
        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);

                SelectionStart = 0;
                SelectionLength = 255;

        }
        protected override void OnEditValueChanged()
        {
            base.OnEditValueChanged();
            if (Utilities.TGC.IsRunTime)
            {
                TTextEditUtil.UpdateForeColor(this);
            }
        }
        #endregion

        #region Functions
        private void Init()
        {
            TabStop = false;
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}