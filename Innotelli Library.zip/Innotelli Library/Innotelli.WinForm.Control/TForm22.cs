using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Innotelli.WinForm.Control;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    public partial class TForm22 : DevExpress.XtraEditors.XtraForm
    {
        #region Enums
        #endregion

        #region Members
        private bool mCancel = false;
        #endregion

        #region Constructors
        public TForm22()
        {
            InitializeComponent();
        }
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        private void btnCancel_Click(object sender, EventArgs e)
        {
            mCancel = true;
        }
        #endregion

        #region Functions
        private void PreloadForm02s()
        {
            DataView lBODv = null;
            string lFormName = null;
            
            pgbThis.Visible = true;
            if (Innotelli.Utilities.TAppSettings.PreloadForm02sBeforeLogin)
            {
                lBODv = Innotelli.WinForm.Control.TSingletons.Form02Pool.BODv.ToTable().DefaultView;
                lBODv.RowFilter = "PreLoadFrm02Tp <> 0";
                for (int i = 0; i < lBODv.Count; i++)
                {
                    if (mCancel)
                    {
                        break;
                    }
                    lFormName = "BackOffice.UI" + ".TF02" + lBODv[i]["BOT01ID"].ToString().Substring(4);
                    Innotelli.WinForm.Control.TSingletons.Form02Pool.AddNewFormToList(lFormName);
                    pgbThis.Position = (int)((((decimal)i) / lBODv.Count) * 100);
                    Application.DoEvents();
                }
            }
            if (!mCancel)
            {
                pgbThis.Position = 100;
            }
            if (!mCancel)
            {
                DialogResult = DialogResult.OK;
            }
            else
            {
                DialogResult = DialogResult.Cancel;
            }
        }
        #endregion

        private void TForm22_Activated(object sender, EventArgs e)
        {

        }

        private void TForm22_Load(object sender, EventArgs e)
        {
        }

        private void TForm22_Shown(object sender, EventArgs e)
        {
            tmrForm02Preload.Interval = 500;
            tmrForm02Preload.Enabled = true;
        }

        private void tmrForm02Preload_Tick(object sender, EventArgs e)
        {
            tmrForm02Preload.Enabled = false;
            PreloadForm02s();
        }

    }
}