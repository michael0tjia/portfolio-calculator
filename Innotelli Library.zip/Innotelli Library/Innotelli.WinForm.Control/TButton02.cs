using DevExpress.XtraEditors;

namespace Innotelli.WinForm.Control
{    
    public class TButton02 : SimpleButton
    {
        #region Members
        #endregion

        #region Constructors
        public TButton02()
        {
        }
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}
