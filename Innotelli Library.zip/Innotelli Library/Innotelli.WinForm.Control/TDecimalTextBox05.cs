using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using System;
using DevExpress.Utils;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{

    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterDecimalTextBox05")]
    public class RepositoryItemDecimalTextBox05 : RepositoryItemTextEdit
    {
        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static RepositoryItemDecimalTextBox05() { RegisterDecimalTextBox05(); }

        //The unique name for the custom editor
        public const string DecimalTextBox05Name = "TDecimalTextBox05";

        //Return the unique name
        public override string EditorTypeName { get { return DecimalTextBox05Name; } }

        //Register the editor
        public static void RegisterDecimalTextBox05()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.DecimalTextBox05.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(DecimalTextBox05Name,
              typeof(TDecimalTextBox05), typeof(RepositoryItemDecimalTextBox05),
              typeof(TextEditViewInfo), new TextEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemDecimalTextBox05 source = item as RepositoryItemDecimalTextBox05;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }

        #endregion

        #region Members

        DSFormMode mDSFormMode = DSFormMode.DSEditable;

        #endregion

        #region Constructors

        //Initialize new properties
        public RepositoryItemDecimalTextBox05()
        {
        }

        #endregion

        #region Properties

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        break;
                    case DSFormMode.DSEditable:
                        break;
                    case DSFormMode.DSInsert:
                        break;
                }
                mDSFormMode = value;
            }
        }

        #endregion

        #region Event Handlers
        #endregion

        #region Functions

        public void Init()
        {
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            Appearance.Options.UseBackColor = true;
            Appearance.Options.UseTextOptions = true;
            Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            AppearanceReadOnly.Options.UseBackColor = true;
            AppearanceReadOnly.Options.UseTextOptions = true;
            AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            MaxLength = 255;
            ReadOnly = true;

            DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            DisplayFormat.FormatString = TSettings.DecFormat;
            EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            EditFormat.FormatString = TSettings.DecFormat;
            Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            Mask.EditMask = TSettings.DecFormat;
        }

        #endregion

    }


    public class TDecimalTextBox05 : TextEdit
    {
        #region Enums

        #endregion

        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static TDecimalTextBox05() { RepositoryItemDecimalTextBox05.RegisterDecimalTextBox05(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemDecimalTextBox05.DecimalTextBox05Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemDecimalTextBox05 Properties
        {
            get { return base.Properties as RepositoryItemDecimalTextBox05; }
        }

        #endregion

        #region Members
        private string mFormat = TSettings.DecFormat;
        #endregion

        #region Constructors
        

        //Initialize the new instance
        public TDecimalTextBox05()
        {
            Init();
        }
        #endregion

        #region Properties
        
        //public int DecimalPlaces
        //{
        //    get
        //    {
        //        if (this.Properties.DisplayFormat.FormatString.Length < 2)
        //        {
        //            mFormat = "n2";
        //        }
        //        return int.Parse(TStr.Right(this.Properties.DisplayFormat.FormatString, this.Properties.DisplayFormat.FormatString.Length - 1));
        //    }
        //    set
        //    {
        //        mFormat = "n" + value.ToString();
        //    }
        //}
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(50, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        //DefaultValue("###,###,###,##0.00; -###,###,###,##0.00"),
        [Bindable(true),
        Category("Behavior"),
        DefaultValue("n"),
        Description("Indicates the numeric format."),
        Localizable(true)]
        public string Format
        {
            get
            {
                return mFormat;
            }
            set
            {
                mFormat = value;
            }
        }
        #endregion

        #region Event Handlers
        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);

                SelectionStart = 0;
                SelectionLength = 255;

        }
        protected override void OnEditValueChanged()
        {
            base.OnEditValueChanged();
            if (Utilities.TGC.IsRunTime)
            {
                TTextEditUtil.UpdateForeColor(this);
            }
        }
        #endregion

        #region Functions
        private void Init()
        {
            TabStop = false;
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}