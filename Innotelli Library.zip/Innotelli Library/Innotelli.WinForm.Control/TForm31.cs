using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Innotelli.BO;

namespace Innotelli.WinForm.Control
{
    public partial class TForm31 : DevExpress.XtraEditors.XtraForm
    {
        public TForm31()
        {
            InitializeComponent();
        }

        private void TForm31_Load(object sender, EventArgs e)
        {
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Cancel();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            OK();
        }

        protected virtual void Cancel()
        {
            DialogResult = DialogResult.Cancel;
        }

        protected virtual void OK()
        {
            DialogResult = DialogResult.OK;
        }
    }
}