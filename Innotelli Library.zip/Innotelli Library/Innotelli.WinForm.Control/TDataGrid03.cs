using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Registrator;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Base.Handler;
using DevExpress.XtraGrid.Views.Base.ViewInfo;
using DevExpress.XtraGrid.Views.Grid.Handler;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using DevExpress.XtraGrid.Views.BandedGrid;
using DevExpress.XtraGrid.Views.BandedGrid.ViewInfo;
using DevExpress.XtraGrid.Views.BandedGrid.Handler;
using DevExpress.Utils.Serializing;
using Innotelli.BO;
using Innotelli.Utilities;
using Innotelli.Db;
using System.Reflection;

namespace Innotelli.WinForm.Control
{
    public class TDataGrid03 : GridControl
    {
        #region Members
        private bool mHasOpnDtlCol = false;
        private ColumnView mGv = null;
        private string mType = "";
        private TSysDataRdr mSysDataRdr = Innotelli.Utilities.TSingletons.SysData01Rdr;
        private TGridView03 mGridView03 = null;
        private TBandedGridView03 mBandedGridView03 = null;
        private TAdvBandedGridView03 mAdvBandedGridView03 = null;
        #endregion

        #region Constructors
        public TDataGrid03()
        {
        }
        #endregion

        #region Properties
        private TBOT04 mBOT04 = null;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TBOT04 BOT04
        {
            get
            {
                return mBOT04;
            }
            set
            {
                mBOT04 = value;
            }
        }
        public bool HasOpnDtlCol
        {
            get
            {
                return mHasOpnDtlCol;
            }
            set
            {
                mHasOpnDtlCol = value;
            }
        }
        #endregion

        #region Event Handlers
        private void CheckBox_ColumnEdit_EditValueChanged(object sender, System.EventArgs e)
        {
            ColumnView lGv = (ColumnView)MainView;
            lGv.PostEditor();
        }
        #endregion

        #region Functions

        #region DevExpress Required Part
        protected override BaseView CreateDefaultView()
        {
            return CreateView("TGridView03");
        }
        protected override void RegisterAvailableViewsCore(InfoCollection collection)
        {
            base.RegisterAvailableViewsCore(collection);
            collection.Add(new TGridViewInfoRegistrator03());
            collection.Add(new TBandedGridViewInfoRegistrator03());
            collection.Add(new TAdvBandedGridViewInfoRegistrator03());
        }
        #endregion

        #region Inplace Editing
        private void SetAllColumnsReadOnlyVal()
        {
            string lFldNm = string.Empty;

            for (int i = 0; i < mGv.Columns.Count; i++)
            {
                lFldNm = mGv.Columns[i].FieldName;
                if (lFldNm != string.Empty)
                {
                    // All BOT04 fields are read only
                    if (mBOT04.SPrps.SPrpsBOT04Flds[lFldNm] != null)
                    {
                        mGv.Columns[i].OptionsColumn.ReadOnly = true;
                    }
                    // All BOT04 import fields are NOT read only by default unless it's explicitly specified in the grid design
                    // Therefore, nothing is done

                    if (mGv.Columns[i].OptionsColumn.ReadOnly)
                    {
                        //TODO: tab stop = false;
                        mGv.Columns[i].OptionsColumn.AllowFocus = false;
                        mGv.Columns[i].AppearanceCell.BackColor = Color.FromArgb(255, 255, 192);
                    }
                }
            }
        }
        private void SetColumnFormat()
        {
            string lFieldName = string.Empty;
            TSPrpsBOT04Fld lSPrpsBOT04Fld = null;
            TSPrpsBOT04ImprtFld lSPrpsBOT04ImprtFld = null;

            for (int i = 0; i < mGv.Columns.Count; i++)
            {
                lFieldName = mGv.Columns[i].FieldName.ToString();
                lSPrpsBOT04Fld = mBOT04.SPrps.SPrpsBOT04Flds[lFieldName];
                if (lSPrpsBOT04Fld != null)
                {
                    switch (lSPrpsBOT04Fld.SimpleDataTypeCat1)
                    {
                        case SimpleDataTypeCat1s.Integer:
                        case SimpleDataTypeCat1s.PreciseReal:
                        case SimpleDataTypeCat1s.UnpreciseReal:
                            #region Numeric Columns

                            #region Negative Value Color Setting
                            StyleFormatCondition lStyleFormatCondition = new StyleFormatCondition();
                            lStyleFormatCondition.Appearance.ForeColor = Color.Red;
                            lStyleFormatCondition.Appearance.Options.UseForeColor = true;
                            lStyleFormatCondition.Appearance.Options.HighPriority = true;
                            lStyleFormatCondition.Column = mGv.Columns[i];
                            lStyleFormatCondition.Condition = FormatConditionEnum.Less;
                            lStyleFormatCondition.Value1 = 0;
                            MainView.FormatConditions.Add(lStyleFormatCondition);
                            #endregion

                            mGv.Columns[i].AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
                            mGv.Columns[i].DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
                            mGv.Columns[i].DisplayFormat.FormatString = Innotelli.BO.TSingletons.MetaSimpleDataTypes[lSPrpsBOT04Fld.SimpleDataType].DisplayFormat;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = Innotelli.BO.TSingletons.MetaSimpleDataTypes[lSPrpsBOT04Fld.SimpleDataType].EditFormat;
                            if (mGv.Columns[i].SummaryItem.DisplayFormat == string.Empty)
                            {
                                mGv.Columns[i].SummaryItem.DisplayFormat = "{0:" + Innotelli.BO.TSingletons.MetaSimpleDataTypes[lSPrpsBOT04Fld.SimpleDataType].DisplayFormat + "}";
                            }

                            #endregion
                            break;
                        case SimpleDataTypeCat1s.DateTime:
                            #region DateTime Columns
                            mGv.Columns[i].DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
                            mGv.Columns[i].DisplayFormat.FormatString = Innotelli.BO.TSingletons.MetaSimpleDataTypes[lSPrpsBOT04Fld.SimpleDataType].DisplayFormat;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = Innotelli.BO.TSingletons.MetaSimpleDataTypes[lSPrpsBOT04Fld.SimpleDataType].EditFormat;
                            #endregion
                            break;
                    }
                }
                lSPrpsBOT04ImprtFld = mBOT04.SPrps.SPrpsBOT04ImprtFlds[lFieldName];
                if (lSPrpsBOT04ImprtFld != null)
                {
                    switch (lSPrpsBOT04ImprtFld.SimpleDataTypeCat1)
                    {
                        case SimpleDataTypeCat1s.Integer:
                        case SimpleDataTypeCat1s.PreciseReal:
                        case SimpleDataTypeCat1s.UnpreciseReal:
                            #region Numeric Columns

                            #region Negative Value Color Setting
                            StyleFormatCondition lStyleFormatCondition = new StyleFormatCondition();
                            lStyleFormatCondition.Appearance.ForeColor = Color.Red;
                            lStyleFormatCondition.Appearance.Options.UseForeColor = true;
                            lStyleFormatCondition.Appearance.Options.HighPriority = true;
                            lStyleFormatCondition.Column = mGv.Columns[i];
                            lStyleFormatCondition.Condition = FormatConditionEnum.Less;
                            lStyleFormatCondition.Value1 = 0;
                            MainView.FormatConditions.Add(lStyleFormatCondition);
                            #endregion

                            mGv.Columns[i].AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
                            mGv.Columns[i].DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
                            mGv.Columns[i].DisplayFormat.FormatString = Innotelli.BO.TSingletons.MetaSimpleDataTypes[lSPrpsBOT04ImprtFld.SimpleDataType].DisplayFormat;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = Innotelli.BO.TSingletons.MetaSimpleDataTypes[lSPrpsBOT04ImprtFld.SimpleDataType].EditFormat;
                            if (mGv.Columns[i].SummaryItem.DisplayFormat == string.Empty)
                            {
                                mGv.Columns[i].SummaryItem.DisplayFormat = "{0:" + Innotelli.BO.TSingletons.MetaSimpleDataTypes[lSPrpsBOT04ImprtFld.SimpleDataType].DisplayFormat + "}";
                            }

                            #endregion
                            break;
                        case SimpleDataTypeCat1s.DateTime:
                            #region DateTime Columns
                            mGv.Columns[i].DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
                            mGv.Columns[i].DisplayFormat.FormatString = Innotelli.BO.TSingletons.MetaSimpleDataTypes[lSPrpsBOT04ImprtFld.SimpleDataType].DisplayFormat;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = Innotelli.BO.TSingletons.MetaSimpleDataTypes[lSPrpsBOT04ImprtFld.SimpleDataType].EditFormat;
                            #endregion
                            break;
                    }
                }
            }
        }
        private void AssignInPlaceEditors()
        {
            string lControlName = string.Empty;
            string lFieldName = string.Empty;
            TSPrpsBOT04Fld lSPrpsBOT04Fld = null;
            TSPrpsBOT04ImprtFld lSPrpsBOT04ImprtFld = null;
            string lTag = string.Empty;
            Assembly lAssembly = Assembly.GetExecutingAssembly();

            for (int i = 0; i < mGv.Columns.Count; i++)
            {
                lFieldName = mGv.Columns[i].FieldName;

                if (lFieldName == string.Empty)
                {
                    continue;
                }

                lSPrpsBOT04Fld = mBOT04.SPrps.SPrpsBOT04Flds[lFieldName];
                if (lSPrpsBOT04Fld != null)
                {
                    #region By Data Type
                    switch (lSPrpsBOT04Fld.SimpleDataType)
                    {
                        case SimpleDataType.Date:
                            RepositoryItemDateEdit41 lRepositoryItemDateEdit41 = new RepositoryItemDateEdit41();
                            lRepositoryItemDateEdit41.Init();
                            RepositoryItems.Add(lRepositoryItemDateEdit41);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemDateEdit41;
                            break;
                        case SimpleDataType.Time:
                            RepositoryItemTimeEdit41 lRepositoryItemTimeEdit41 = new RepositoryItemTimeEdit41();
                            lRepositoryItemTimeEdit41.Init();
                            RepositoryItems.Add(lRepositoryItemTimeEdit41);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemTimeEdit41;
                            break;
                        case SimpleDataType.Bool:
                            RepositoryItemCheckEdit41 lRepositoryItemCheckEdit41 = new RepositoryItemCheckEdit41();
                            lRepositoryItemCheckEdit41.Init();
                            RepositoryItems.Add(lRepositoryItemCheckEdit41);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemCheckEdit41;
                            break;
                        case SimpleDataType.Currency:
                            RepositoryItemCurrencyTextEdit41 lRepositoryItemCurrencyTextEdit41 = new RepositoryItemCurrencyTextEdit41();
                            lRepositoryItemCurrencyTextEdit41.Init();
                            RepositoryItems.Add(lRepositoryItemCurrencyTextEdit41);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemCurrencyTextEdit41;
                            break;
                        case SimpleDataType.Decimal:
                        case SimpleDataType.Double:
                        case SimpleDataType.Single:
                            RepositoryItemDecimalTextEdit41 lRepositoryItemDecimalTextEdit41 = new RepositoryItemDecimalTextEdit41();
                            lRepositoryItemDecimalTextEdit41.Init();
                            RepositoryItems.Add(lRepositoryItemDecimalTextEdit41);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemDecimalTextEdit41;
                            break;
                        case SimpleDataType.Byte:
                        case SimpleDataType.Short:
                        case SimpleDataType.Int:
                        case SimpleDataType.Long:
                            RepositoryItemIntegerTextEdit41 lRepositoryItemIntegerTextEdit41 = new RepositoryItemIntegerTextEdit41();
                            lRepositoryItemIntegerTextEdit41.Init();
                            RepositoryItems.Add(lRepositoryItemIntegerTextEdit41);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemIntegerTextEdit41;
                            break;
                        case SimpleDataType.NText:
                            RepositoryItemMemoEdit41 lRepositoryItemMemoEdit41 = new RepositoryItemMemoEdit41();
                            lRepositoryItemMemoEdit41.Init();
                            //lRepositoryItemMemoEdit41.Buttons[0].Visible = false;
                            RepositoryItems.Add(lRepositoryItemMemoEdit41);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemMemoEdit41;
                            break;
                        case SimpleDataType.NVarChar:
                            RepositoryItemTextEdit41 lRepositoryItemTextEdit41 = new RepositoryItemTextEdit41();
                            //lRepositoryItemTextEdit41.Init(mBOT04);
                            //lRepositoryItemTextEdit41.BoundColumnName = lFieldName;
                            RepositoryItems.Add(lRepositoryItemTextEdit41);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemTextEdit41;
                            break;
                        default:
                            break;
                    }
                    #endregion
                }

                lSPrpsBOT04ImprtFld = mBOT04.SPrps.SPrpsBOT04ImprtFlds[lFieldName];
                if (lSPrpsBOT04ImprtFld != null)
                {
                    #region By Data Type
                    switch (lSPrpsBOT04ImprtFld.SimpleDataType)
                    {
                        case SimpleDataType.Date:
                            RepositoryItemDateEdit40 lRepositoryItemDateEdit40 = new RepositoryItemDateEdit40();
                            lRepositoryItemDateEdit40.Init();
                            RepositoryItems.Add(lRepositoryItemDateEdit40);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemDateEdit40;
                            break;
                        case SimpleDataType.Time:
                            RepositoryItemTimeEdit40 lRepositoryItemTimeEdit40 = new RepositoryItemTimeEdit40();
                            lRepositoryItemTimeEdit40.Init();
                            RepositoryItems.Add(lRepositoryItemTimeEdit40);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemTimeEdit40;
                            break;
                        case SimpleDataType.Bool:
                            RepositoryItemCheckEdit40 lRepositoryItemCheckEdit40 = new RepositoryItemCheckEdit40();
                            lRepositoryItemCheckEdit40.Init();
                            RepositoryItems.Add(lRepositoryItemCheckEdit40);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemCheckEdit40;
                            mGv.Columns[i].ColumnEdit.EditValueChanged += new EventHandler(CheckBox_ColumnEdit_EditValueChanged);
                            break;
                        case SimpleDataType.Currency:
                            RepositoryItemCurrencyTextEdit40 lRepositoryItemCurrencyTextEdit40 = new RepositoryItemCurrencyTextEdit40();
                            lRepositoryItemCurrencyTextEdit40.Init();
                            RepositoryItems.Add(lRepositoryItemCurrencyTextEdit40);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemCurrencyTextEdit40;
                            break;
                        case SimpleDataType.Decimal:
                        case SimpleDataType.Double:
                        case SimpleDataType.Single:
                            RepositoryItemDecimalTextEdit40 lRepositoryItemDecimalTextEdit40 = new RepositoryItemDecimalTextEdit40();
                            lRepositoryItemDecimalTextEdit40.Init();
                            RepositoryItems.Add(lRepositoryItemDecimalTextEdit40);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemDecimalTextEdit40;
                            break;
                        case SimpleDataType.Byte:
                        case SimpleDataType.Short:
                        case SimpleDataType.Int:
                        case SimpleDataType.Long:
                            RepositoryItemIntegerTextEdit40 lRepositoryItemIntegerTextEdit40 = new RepositoryItemIntegerTextEdit40();
                            lRepositoryItemIntegerTextEdit40.Init();
                            RepositoryItems.Add(lRepositoryItemIntegerTextEdit40);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemIntegerTextEdit40;
                            break;
                        case SimpleDataType.NText:
                            RepositoryItemMemoEdit40 lRepositoryItemMemoEdit40 = new RepositoryItemMemoEdit40();
                            lRepositoryItemMemoEdit40.Init();
                            //lRepositoryItemMemoEdit40.Buttons[0].Visible = false;
                            RepositoryItems.Add(lRepositoryItemMemoEdit40);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemMemoEdit40;
                            break;
                        case SimpleDataType.NVarChar:
                            RepositoryItemTextEdit40 lRepositoryItemTextEdit40 = new RepositoryItemTextEdit40();
                            //lRepositoryItemTextEdit40.Init(mBOT04);
                            lRepositoryItemTextEdit40.BoundColumnName = lFieldName;
                            RepositoryItems.Add(lRepositoryItemTextEdit40);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemTextEdit40;
                            break;
                        default:
                            break;
                    }
                    #endregion
                }

                if (mGv.Columns[i].ColumnEdit != null)
                {
                    mGv.Columns[i].ColumnEdit.ReadOnly = mGv.Columns[i].ReadOnly;
                }
            }
        }
        #endregion
        public void Init()
        {
            if (Utilities.TGC.IsRunTime)
            {
                mGv = (ColumnView)MainView;
                mGv.OptionsSelection.MultiSelect = true;
                mType = MainView.GetType().Name;

                switch (mType)
                {
                    case "TGridView03":
                        mGridView03 = (TGridView03)MainView;
                        mGridView03.Init();
                        break;
                    case "TBandedGridView03":
                        mBandedGridView03 = (TBandedGridView03)MainView;
                        mBandedGridView03.Init();
                        break;
                    case "TAdvBandedGridView03":
                        mAdvBandedGridView03 = (TAdvBandedGridView03)MainView;
                        mAdvBandedGridView03.Init();
                        break;
                }

                SetAllColumnsReadOnlyVal();
                SetColumnFormat();
                AssignInPlaceEditors();
            }
        }
        private void SaveLayout()
        {
        }
        private void LoadLayout()
        {
        }

        #region Others
        public void BindData()
        {
            if (mBOT04 != null)
            {
                DataSource = mBOT04.Dt;
            }
        }
        #endregion

        #endregion

        #region To Be Deleted
        private string mBOT03ID = null;
        public string BOT03ID
        {
            get
            {
                return mBOT03ID;
            }
            set
            {
                mBOT03ID = value;
            }
        }
        #endregion
    }

    #region GridView Classes
    public class TGridViewInfoRegistrator03 : GridInfoRegistrator
    {
        #region DevExpress Required Part
        public override string ViewName { get { return "TGridView03"; } }
        public override BaseView CreateView(GridControl grid) { return new TGridView03(grid as GridControl); }
        public override BaseViewInfo CreateViewInfo(BaseView view) { return new TGridViewInfo03(view as TGridView03); }
        public override BaseViewHandler CreateHandler(BaseView view) { return new TGridHandler03(view as TGridView03); }
        #endregion
    }
    public class TGridView03 : GridView
    {
        #region Members
        #endregion

        #region Constructors

        #region DevExpress Required Part
        public TGridView03() : this(null) { }
        public TGridView03(DevExpress.XtraGrid.GridControl grid)
            : base(grid)
        {
        }
        #endregion

        #endregion

        #region Properties

        #region DevExpress Required Part
        protected override string ViewName { get { return "TGridView03"; } }
        #endregion

        #endregion

        #region Event Handlers
        private void TGridView03_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            TBOT04 lBOT04 = null;

            lBOT04 = ((TDataGrid03)GridControl).BOT04;
            if (lBOT04 != null)
            {
                if (e.FocusedRowHandle != GridControl.NewItemRowHandle && e.FocusedRowHandle != GridControl.InvalidRowHandle)
                {
                    lBOT04.SetCurrentRow(GetDataRow(e.FocusedRowHandle));
                }
                else
                {
                    lBOT04.CurrentRowIndex = TDataObject.EOFRowIndex;
                }
            }
        }
        #endregion

        #region Functions
        public void Init()
        {
            FixedLineWidth = 1;
            Appearance.FocusedRow.BackColor = Color.FromArgb(60, 128, 128, 240);
            Appearance.FocusedRow.Options.UseBackColor = true;
            Appearance.SelectedRow.BackColor = Color.FromArgb(30, 128, 128, 240);
            Appearance.SelectedRow.Options.UseBackColor = true;
            OptionsView.ColumnAutoWidth = false;
            OptionsView.ShowGroupPanel = false;
            OptionsCustomization.AllowGroup = false;
            OptionsMenu.EnableFooterMenu = false;
            AssignEventHandlers();
        }
        private void AssignEventHandlers()
        {
            FocusedRowChanged += new FocusedRowChangedEventHandler(TGridView03_FocusedRowChanged);
            //this.ValidateEditor
        }
        #endregion
    }
    public class TGridViewInfo03 : GridViewInfo
    {
        #region DevExpress Required Part
        public TGridViewInfo03(GridView gridView) : base(gridView) { }
        #endregion
    }
    public class TGridHandler03 : GridHandler
    {
        #region DevExpress Required Part
        public TGridHandler03(GridView gridView) : base(gridView) { }
        #endregion
    }
    #endregion

    #region BandedGridView Classes
    public class TBandedGridViewInfoRegistrator03 : BandedGridInfoRegistrator
    {
        #region DevExpress Required Part
        public override string ViewName { get { return "TBandedGridView03"; } }
        public override BaseView CreateView(GridControl grid) { return new TBandedGridView03(grid as GridControl); }
        public override BaseViewInfo CreateViewInfo(BaseView view) { return new TBandedGridViewInfo03(view as TBandedGridView03); }
        public override BaseViewHandler CreateHandler(BaseView view) { return new TBandedGridHandler03(view as TBandedGridView03); }
        #endregion
    }
    public class TBandedGridView03 : BandedGridView
    {
        #region Members
        #endregion

        #region Constructors
        public TBandedGridView03() : this(null) { }
        public TBandedGridView03(DevExpress.XtraGrid.GridControl grid)
            : base(grid)
        {
        }
        #endregion

        #region Properties

        #region DevExpress Required Part
        protected override string ViewName { get { return "TBandedGridView03"; } }
        #endregion

        #endregion

        #region Event Handlers
        private void TBandedGridView03_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            TBOT04 lBOT04 = null;

            lBOT04 = ((TDataGrid03)GridControl).BOT04;
            if (lBOT04 != null)
            {
                if (e.FocusedRowHandle != GridControl.NewItemRowHandle && e.FocusedRowHandle != GridControl.InvalidRowHandle)
                {
                    lBOT04.SetCurrentRow(GetDataRow(e.FocusedRowHandle));
                }
                else
                {
                    lBOT04.CurrentRowIndex = TDataObject.EOFRowIndex;
                }
            }
        }
        private void AssignEventHandlers()
        {
            FocusedRowChanged += new FocusedRowChangedEventHandler(TBandedGridView03_FocusedRowChanged);
        }
        #endregion

        #region Functions
        public void Init()
        {
            FixedLineWidth = 1;
            Appearance.FocusedRow.BackColor = Color.FromArgb(60, 128, 128, 240);
            Appearance.FocusedRow.Options.UseBackColor = true;
            Appearance.SelectedRow.BackColor = Color.FromArgb(30, 128, 128, 240);
            Appearance.SelectedRow.Options.UseBackColor = true;
            OptionsView.ColumnAutoWidth = false;
            OptionsView.ShowGroupPanel = false;
            OptionsCustomization.AllowGroup = false;
            OptionsMenu.EnableFooterMenu = false;
            AssignEventHandlers();
        }
        #endregion
    }
    public class TBandedGridViewInfo03 : BandedGridViewInfo
    {
        #region DevExpress Required Part
        public TBandedGridViewInfo03(BandedGridView gridView) : base(gridView) { }
        #endregion
    }
    public class TBandedGridHandler03 : BandedGridHandler
    {
        #region DevExpress Required Part
        public TBandedGridHandler03(BandedGridView gridView) : base(gridView) { }
        #endregion
    }
    #endregion

    #region AdvBandedGridView Classes
    public class TAdvBandedGridViewInfoRegistrator03 : AdvBandedGridInfoRegistrator
    {
        #region DevExpress Required Part
        public override string ViewName { get { return "TAdvBandedGridView03"; } }
        public override BaseView CreateView(GridControl grid) { return new TAdvBandedGridView03(grid as GridControl); }
        public override BaseViewInfo CreateViewInfo(BaseView view) { return new TAdvBandedGridViewInfo03(view as TAdvBandedGridView03); }
        public override BaseViewHandler CreateHandler(BaseView view) { return new TAdvBandedGridHandler03(view as TAdvBandedGridView03); }
        #endregion
    }
    public class TAdvBandedGridView03 : AdvBandedGridView
    {
        #region Members
        #endregion

        #region Constructors

        #region DevExpress Required Part
        public TAdvBandedGridView03() : this(null) { }
        public TAdvBandedGridView03(DevExpress.XtraGrid.GridControl grid)
            : base(grid)
        {
            //Init();
        }
        #endregion

        #endregion

        #region Properties

        #region DevExpress Required Part
        protected override string ViewName { get { return "TAdvBandedGridView03"; } }
        #endregion

        #endregion

        #region Event Handlers
        private void TAdvBandedGridView03_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            TBOT04 lBOT04 = null;

            lBOT04 = ((TDataGrid03)GridControl).BOT04;
            if (lBOT04 != null)
            {
                if (e.FocusedRowHandle != GridControl.NewItemRowHandle && e.FocusedRowHandle != GridControl.InvalidRowHandle)
                {
                    lBOT04.SetCurrentRow(GetDataRow(e.FocusedRowHandle));
                }
                else
                {
                    lBOT04.CurrentRowIndex = TDataObject.EOFRowIndex;
                }
            }
        }
        #endregion

        #region Functions
        public void Init()
        {
            FixedLineWidth = 1;
            Appearance.FocusedRow.BackColor = Color.FromArgb(60, 128, 128, 240);
            Appearance.FocusedRow.Options.UseBackColor = true;
            Appearance.SelectedRow.BackColor = Color.FromArgb(30, 128, 128, 240);
            Appearance.SelectedRow.Options.UseBackColor = true;
            OptionsView.ColumnAutoWidth = false;
            OptionsView.ShowGroupPanel = false;
            OptionsCustomization.AllowGroup = false;
            OptionsMenu.EnableFooterMenu = false;
            AssignEventHandlers();
        }
        private void AssignEventHandlers()
        {
            FocusedRowChanged += new FocusedRowChangedEventHandler(TAdvBandedGridView03_FocusedRowChanged);
        }
        #endregion
    }
    public class TAdvBandedGridViewInfo03 : AdvBandedGridViewInfo
    {
        #region DevExpress Required Part
        public TAdvBandedGridViewInfo03(AdvBandedGridView gridView) : base(gridView) { }
        #endregion
    }
    public class TAdvBandedGridHandler03 : AdvBandedGridHandler
    {
        #region DevExpress Required Part
        public TAdvBandedGridHandler03(AdvBandedGridView gridView) : base(gridView) { }
        #endregion
    }
    #endregion
}