namespace Innotelli.WinForm.Control
{
    partial class TForm25
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TForm25));
            this.bmgThis = new DevExpress.XtraBars.BarManager(this.components);
            this.barStatus = new DevExpress.XtraBars.Bar();
            this.bpb01Stts = new DevExpress.XtraBars.BarEditItem();
            this.repositoryItemProgressBar1 = new DevExpress.XtraEditors.Repository.RepositoryItemProgressBar();
            this.barMainMenu = new DevExpress.XtraBars.Bar();
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.tmrLookUpList = new System.Windows.Forms.Timer(this.components);
            this.mDefaultLookAndFeel = new DevExpress.LookAndFeel.DefaultLookAndFeel(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.bmgThis)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemProgressBar1)).BeginInit();
            this.SuspendLayout();
            // 
            // bmgThis
            // 
            this.bmgThis.Bars.AddRange(new DevExpress.XtraBars.Bar[] {
            this.barStatus,
            this.barMainMenu});
            this.bmgThis.DockControls.Add(this.barDockControlTop);
            this.bmgThis.DockControls.Add(this.barDockControlBottom);
            this.bmgThis.DockControls.Add(this.barDockControlLeft);
            this.bmgThis.DockControls.Add(this.barDockControlRight);
            this.bmgThis.Form = this;
            this.bmgThis.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.bpb01Stts});
            this.bmgThis.MainMenu = this.barMainMenu;
            this.bmgThis.MaxItemId = 105;
            this.bmgThis.MdiMenuMergeStyle = DevExpress.XtraBars.BarMdiMenuMergeStyle.Never;
            this.bmgThis.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemProgressBar1});
            this.bmgThis.StatusBar = this.barStatus;
            // 
            // barStatus
            // 
            this.barStatus.BarName = "Status bar";
            this.barStatus.CanDockStyle = DevExpress.XtraBars.BarCanDockStyle.Bottom;
            this.barStatus.DockCol = 0;
            this.barStatus.DockRow = 0;
            this.barStatus.DockStyle = DevExpress.XtraBars.BarDockStyle.Bottom;
            this.barStatus.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.Width, this.bpb01Stts, "", false, true, true, 343)});
            this.barStatus.OptionsBar.AllowQuickCustomization = false;
            this.barStatus.OptionsBar.DisableClose = true;
            this.barStatus.OptionsBar.DrawDragBorder = false;
            this.barStatus.OptionsBar.UseWholeRow = true;
            resources.ApplyResources(this.barStatus, "barStatus");
            // 
            // bpb01Stts
            // 
            this.bpb01Stts.Edit = this.repositoryItemProgressBar1;
            this.bpb01Stts.Id = 104;
            this.bpb01Stts.Name = "bpb01Stts";
            this.bpb01Stts.Visibility = DevExpress.XtraBars.BarItemVisibility.Never;
            // 
            // repositoryItemProgressBar1
            // 
            this.repositoryItemProgressBar1.Name = "repositoryItemProgressBar1";
            // 
            // barMainMenu
            // 
            this.barMainMenu.BarName = "Main Menu";
            this.barMainMenu.CanDockStyle = DevExpress.XtraBars.BarCanDockStyle.Top;
            this.barMainMenu.DockCol = 0;
            this.barMainMenu.DockRow = 0;
            this.barMainMenu.DockStyle = DevExpress.XtraBars.BarDockStyle.Top;
            this.barMainMenu.OptionsBar.AllowQuickCustomization = false;
            this.barMainMenu.OptionsBar.DisableClose = true;
            this.barMainMenu.OptionsBar.DrawDragBorder = false;
            this.barMainMenu.OptionsBar.UseWholeRow = true;
            resources.ApplyResources(this.barMainMenu, "barMainMenu");
            // 
            // tmrLookUpList
            // 
            this.tmrLookUpList.Interval = 10000;
            this.tmrLookUpList.Tick += new System.EventHandler(this.tmrLookUpList_Tick);
            // 
            // TForm25
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.IsMdiContainer = true;
            this.Name = "TForm25";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMainContainer_Load);
            this.Shown += new System.EventHandler(this.frmMainContainer_Shown);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMainContainer_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.bmgThis)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemProgressBar1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public DevExpress.XtraBars.BarManager bmgThis;
        private DevExpress.XtraBars.Bar barStatus;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        public DevExpress.XtraBars.Bar barMainMenu;
        private DevExpress.XtraBars.BarEditItem bpb01Stts;
        private DevExpress.XtraEditors.Repository.RepositoryItemProgressBar repositoryItemProgressBar1;
        private System.Windows.Forms.Timer tmrLookUpList;
        public DevExpress.LookAndFeel.DefaultLookAndFeel mDefaultLookAndFeel;
    }
}