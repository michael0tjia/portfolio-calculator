using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using System;
using DevExpress.Utils;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterTextBox06")]
    public class RepositoryItemTextBox06 : RepositoryItemButtonEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemTextBox06() { RegisterTextBox06(); }

        //The unique name for the custom editor
        public const string TextBox06Name = "TTextBox06";

        //Return the unique name
        public override string EditorTypeName { get { return TextBox06Name; } }

        //Register the editor
        public static void RegisterTextBox06()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.TextBox06.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(TextBox06Name,
              typeof(TTextBox06), typeof(RepositoryItemTextBox06),
              typeof(ButtonEditViewInfo), new ButtonEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemTextBox06 source = item as RepositoryItemTextBox06;
                if (source == null) return;
                IsAutoNumber = source.IsAutoNumber;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public RepositoryItemTextBox06()
        {
        }
        #endregion

        #region Properties
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        private string BoundColumnName
        {
            get
            {
                string lReturnValue = string.Empty;

                if (mBOT01 != null)
                {
                    //No Need to check OwnerEdit == null because TextBox06 is not used in DataGrid.
                    lReturnValue = TControlUtil.GetFirstBindingFieldName(OwnerEdit);
                }
                return lReturnValue;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        private bool IsEditValueAutoNumber
        {
            get
            {
                bool lReturnValue = false;

                lReturnValue = (mBOT01 != null && BoundColumnName != string.Empty && mBOT01.SPrps.SPrpsBOT01Flds[BoundColumnName].slkDftValType.HasValue);

                return lReturnValue;
            }
        }
        private bool mIsLocked = false;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                if (value)
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                }
                else
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
                }
                if (OwnerEdit != null)
                {
                    OwnerEdit.TabStop = !value;
                }
                for (int i = 0; i < Buttons.Count; i++)
                {
                    Buttons[i].Enabled = !value;
                }
                mIsLocked = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        DSFormMode mDSFormMode = DSFormMode.DSEditable;
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        SetTextAreaLock();
                        for (int i = 0; i < Buttons.Count; i++)
                        {
                            Buttons[i].Enabled = false;
                        }
                        break;
                    case DSFormMode.DSEditable:
                        SetTextAreaLock();
                        for (int i = 0; i < Buttons.Count; i++)
                        {
                            Buttons[i].Enabled = true;
                        }
                        //EndUpdate();
                        break;
                    case DSFormMode.DSInsert:
                        if (IsEditValueAutoNumber)
                        {
                            SetTextAreaLock();
                            for (int i = 0; i < Buttons.Count; i++)
                            {
                                Buttons[i].Enabled = true;
                            }
                            //OwnerEdit.Text = "**NEW**";
                            //BeginUpdate();
                        }
                        else
                        {
                            ClearTextAreaLock();
                            for (int i = 0; i < Buttons.Count; i++)
                            {
                                Buttons[i].Enabled = true;
                            }
                        }
                        break;
                }
                mDSFormMode = value;
            }
        }
        private bool mIsAutoNumber = true;
        public bool IsAutoNumber
        {
            get
            {
                return mIsAutoNumber;
            }
            set
            {
                mIsAutoNumber = value;
                OnPropertiesChanged();
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        TBOT01 mBOT01 = null;
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
            }
        }

        #endregion

        #region Event Handlers
        private void RepositoryItemTextBox06_Validating(object sender, System.ComponentModel.CancelEventArgs e)
        {
            bool lIsValid = false;
            string lNewID = null;
            TTextBox06 lTextBox06 = (sender as TTextBox06);

            if (!lTextBox06.Properties.ReadOnly && lTextBox06.IsModified)
            {
                if (!TNull.IsValueNull(lTextBox06.EditValue))
                {
                    lNewID = lTextBox06.EditValue.ToString();
                    if (!BOT01.IsNewIDDuplicate(lNewID))
                    {
                        lIsValid = true;
                    }
                }
                e.Cancel = !lIsValid;
            }
        }
        private void RepositoryItemTextBox06_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            TFrmChgID lFrmChgID = new TFrmChgID();
            if (TNull.IsValueNull(OwnerEdit.EditValue))
            {
                lFrmChgID.OldVal = null;
            }
            else
            {
                lFrmChgID.OldVal = (string)OwnerEdit.EditValue;
            }
            lFrmChgID.BOT01 = BOT01;
            lFrmChgID.ShowDialog();
            if (lFrmChgID.DialogResult == DialogResult.OK)
            {
                if (TNull.IsValueNull(lFrmChgID.NewVal) || (lFrmChgID.NewVal.Trim() == ""))
                {
                    OwnerEdit.EditValue = lFrmChgID.OldVal;
                }
                else
                {
                    OwnerEdit.EditValue = lFrmChgID.NewVal;
                }
            }
        }
        #endregion

        #region Functions
        public override void CreateDefaultButton()
        {
            // do nothing
        }
        public void Init(TBOT01 aBOT01)
        {
            Image lImg = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TTextBox06.Button.png"));

            BOT01 = aBOT01;
            AppearanceReadOnly.Options.UseBackColor = false;
            NullText = null;
            TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            Buttons.Add(new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", 10, true, true, false, DevExpress.Utils.HorzAlignment.Center, lImg));
            AssignEventHandlers();
        }
        public void SetTextAreaLock()
        {
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            Appearance.Options.UseBackColor = true;
            AppearanceReadOnly.Options.UseBackColor = false;
            ReadOnly = true;
            // If not in-place editor, should not be null. Otherwise, null as documented.
            if (OwnerEdit != null)
            {
                OwnerEdit.TabStop = false;
            }
        }
        public void ClearTextAreaLock()
        {
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            Appearance.Options.UseBackColor = true;
            AppearanceReadOnly.Options.UseBackColor = false;
            ReadOnly = false;
            // If not in-place editor, should not be null. Otherwise, null as documented.
            if (OwnerEdit != null)
            {
                OwnerEdit.TabStop = true;
            }
        }
        public void SetLock()
        {
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            Appearance.Options.UseBackColor = true;
            AppearanceReadOnly.Options.UseBackColor = false;
            ReadOnly = true;
            // If not in-place editor, should not be null. Otherwise, null as documented.
            if (OwnerEdit != null)
            {
                OwnerEdit.TabStop = false;
            }
        }
        public void ClearLock()
        {
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
            Appearance.Options.UseBackColor = true;
            AppearanceReadOnly.Options.UseBackColor = false;
            ReadOnly = false;
            // If not in-place editor, should not be null. Otherwise, null as documented.
            if (OwnerEdit != null)
            {
                OwnerEdit.TabStop = true;
            }
        }
        private void AssignEventHandlers()
        {
            Validating += RepositoryItemTextBox06_Validating;
            ButtonClick += RepositoryItemTextBox06_ButtonClick;
        }
        #endregion

    }
    public class TTextBox06 : ButtonEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TTextBox06() { RepositoryItemTextBox06.RegisterTextBox06(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemTextBox06.TextBox06Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemTextBox06 Properties
        {
            get { return base.Properties as RepositoryItemTextBox06; }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TTextBox06()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(15+20, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}
