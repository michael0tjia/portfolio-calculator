using System;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Threading;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using DevExpress.Utils;
using Innotelli.BO;
using Innotelli.Utilities;
using DevExpress.Utils.Menu;

namespace Innotelli.WinForm.Control
{

    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterLookupCombo03")]
    public class RepositoryItemLookupCombo03 : RepositoryItemGridLookUpEdit
    {
        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static RepositoryItemLookupCombo03() { RegisterLookupCombo03(); }

        //The unique name for the custom editor
        public const string LookupCombo03Name = "TLookupCombo03";

        //Return the unique name
        public override string EditorTypeName { get { return LookupCombo03Name; } }

        //Register the editor
        public static void RegisterLookupCombo03()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.LookupCombo03.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(LookupCombo03Name,
              typeof(TLookupCombo03), typeof(RepositoryItemLookupCombo03),
              typeof(GridLookUpEditBaseViewInfo), new ButtonEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemLookupCombo03 source = item as RepositoryItemLookupCombo03;
                if (source == null) return;
                BndCol = source.BndCol;
                BOID = source.BOID;
            }
            finally
            {
                EndUpdate();
            }
        }

        #endregion

        #region Members

        private bool mIsLocked = false;

        #endregion

        #region Constructors

        //Initialize new properties
        public RepositoryItemLookupCombo03()
        {
        }

        #endregion

        #region Properties

        private TBOT01 mBOT01 = null;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
            }
        }
        private string mBOID = "";
        public string BOID
        {
            get
            {
                return mBOID;
            }
            set
            {
                mBOID = value;
                OnPropertiesChanged();
            }
        }
        private int mBndCol = 0;
        public int BndCol
        {
            get
            {
                return mBndCol;
            }
            set
            {
                mBndCol = value;
                OnPropertiesChanged();
            }
        }
        private int mType = 0;
        public int Type
        {
            get
            {
                return mType;
            }
            set
            {
                mType = value;
                OnPropertiesChanged();
            }
        }

        #endregion

        #region Event Handlers
        #endregion

        #region Functions

        public void Init()
        {
            Image lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TLookupCombo03.Button.png"));
            ImageList lImageList = new ImageList();

            lImageList.Images.Add(lImage);
            AppearanceReadOnly.Options.UseBackColor = false;
            NullText = "";
            AllowNullInput = DefaultBoolean.True;
            TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            View.OptionsView.ShowAutoFilterRow = true;
            Buttons[0].Kind = DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph;
            Buttons[0].Image = lImage;
        }
        public void BindList()
        {
            DataView lDv = null;

            if (mBOID != null && mBOID != "")
            {
                // this is to test instant update
                //if (OwnerEdit != null)
                //{
                //    OwnerEdit.DataBindings[0].DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged;
                //}

                lDv = new DataView();
                lDv.Table = BO.TSingletons.LookUpListProxy.GetList(mBOID);
                if (lDv.Table != null)
                {
                    //#check!
                    if (mType == 2)
                    {
                        if (BndCol == 1)
                        {
                            ValueMember = lDv.Table.Columns[2].ColumnName;
                        }
                        else
                        {
                            ValueMember = lDv.Table.Columns[BndCol].ColumnName;
                        }
                        DisplayMember = lDv.Table.Columns[2].ColumnName;
                    }
                    else
                    {
                        ValueMember = lDv.Table.Columns[BndCol].ColumnName;
                        DisplayMember = lDv.Table.Columns[1].ColumnName;
                    }
                    DataSource = lDv;
                    InitColumns();
                }
            }

        }
        private void InitColumns()
        {
            int lColumnCount = 0;
            double[] lColWidths = new double[10];
            int lListWidth = 0;

            if (mBOID != null && mBOID != "")
            {
                lColumnCount = int.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnCount);
                if (mType == 2)
                {
                    lColWidths[0] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth01);
                    lColWidths[1] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth03);
                    lColWidths[2] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth02);
                    lColWidths[3] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth04);
                    lColWidths[4] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth05);
                    lColWidths[5] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth06);
                    lColWidths[6] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth07);
                    lColWidths[7] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth08);
                    lColWidths[8] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth09);
                    lColWidths[9] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth10);
                    string lTmp = "";
                    lTmp = View.Columns[1].FieldName;
                    View.Columns[1].FieldName = View.Columns[2].FieldName;
                    View.Columns[2].FieldName = lTmp;
                    lTmp = View.Columns[1].Caption;
                    View.Columns[1].Caption = View.Columns[2].Caption;
                    View.Columns[2].Caption = lTmp;
                }
                else //default
                {
                    lColWidths[0] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth01);
                    lColWidths[1] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth02);
                    lColWidths[2] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth03);
                    lColWidths[3] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth04);
                    lColWidths[4] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth05);
                    lColWidths[5] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth06);
                    lColWidths[6] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth07);
                    lColWidths[7] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth08);
                    lColWidths[8] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth09);
                    lColWidths[9] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth10);
                }
                //lListWidth = double.Parse(mSPrpsBOT01.ListWidth);

                View.OptionsView.ColumnAutoWidth = false;
                //PopupFormMinSize = new Size((int)(lListWidth * TGC.PixelPerCm), 0);
                for (int i = 0; i < View.Columns.Count; i++)
                {
                    if (i < lColumnCount)
                    {
                        if (lColWidths[i] != 0)
                        {
                            View.Columns[i].Width = (int)(lColWidths[i] * TGC.PixelPerCm);
                            lListWidth += View.Columns[i].Width;
                        }
                        else
                        {
                            View.Columns[i].Width = 0;
                            View.Columns[i].Visible = false;
                        }
                    }
                    else
                    {
                        View.Columns[i].Width = 0;
                        View.Columns[i].Visible = false;
                    }
                }
                PopupFormMinSize = new Size(lListWidth + 36, 0);
            }
        }

        #endregion

        
   }

    public class TLookupCombo03 : GridLookUpEdit
    {
        #region Enums
        #endregion

        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static TLookupCombo03() { RepositoryItemLookupCombo03.RegisterLookupCombo03(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemLookupCombo03.LookupCombo03Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemLookupCombo03 Properties
        {
            get { return base.Properties as RepositoryItemLookupCombo03; }
        }

        #endregion

        #region Members
        #endregion

        #region Constructors
        

        //Initialize the new instance
        public TLookupCombo03()
        {
            AssignEventHandlers();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(15+20, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        
        #endregion

        #region Event Handlers
        #endregion

        #region Functions

        private void AssignEventHandlers()
        {
            Closed += TLookupCombo03_Closed;
            //EditValueChanging += TLookupCombo03_EditValueChanging;
            //EditValueChanged += TLookupCombo03_EditValueChanged;
            //Validating += TLookupCombo03_Validating;
            //Validated += TLookupCombo03_Validated;
        }
        private void TLookupCombo03_Closed(object sender, DevExpress.XtraEditors.Controls.ClosedEventArgs e)
        {
            if (EditValue != OldEditValue)
            {
                DoValidate();
            }
        }
        private void TLookupCombo03_EditValueChanging(object sender, DevExpress.XtraEditors.Controls.ChangingEventArgs e)
        {
        }
        private void TLookupCombo03_EditValueChanged(object sender, EventArgs e)
        {
        }
        private void TLookupCombo03_Validating(object sender, CancelEventArgs e)
        {
        }
        private void TLookupCombo03_Validated(object sender, EventArgs e)
        {
        }
        protected override void UpdateMenu()
        {
            base.UpdateMenu();
            bool lIsEditValueExisted = (!TNull.IsValueNull(EditValue) && EditValue.ToString() != "");
            Menu.Items[0].Enabled = lIsEditValueExisted;
            Menu.Items[1].Enabled = lIsEditValueExisted;
        }
        protected override DevExpress.Utils.Menu.DXPopupMenu CreateMenu()
        {
            DXPopupMenu lRtrnVal = null;
            bool lIsEditValueExisted = (!TNull.IsValueNull(EditValue) && EditValue.ToString() != "");
            Image lOpenDetailImage = Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TLookupCombo03.OpenDetail.png"));
            Image lAdvSearchImage = Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TLookupCombo03.AdvSearch.png"));


                lRtrnVal = base.CreateMenu();
                lRtrnVal.Items[0].BeginGroup = true;
                DXMenuItem lOpenDetailItem = new DXMenuItem("Open Details", OpenDetailItem_Click, lOpenDetailImage);
                DXMenuItem lAdvSearchItem = new DXMenuItem("Advanced Search", AdvSearchItem_Click, lAdvSearchImage);
                lOpenDetailItem.Enabled = lIsEditValueExisted;
                lAdvSearchItem.Enabled = lIsEditValueExisted;
                lRtrnVal.Items.Insert(0, lOpenDetailItem);
                lRtrnVal.Items.Insert(1, lAdvSearchItem);

            
            return lRtrnVal;
        }
        private void OpenDetailItem_Click(object sender, EventArgs e)
        {
            TForm02 lForm02 = null;
            string lPK = "";


                if (EditValue != null && EditValue != DBNull.Value)
                {
                    lPK = EditValue.ToString();
                    if (lPK != "")
                    {
                        lForm02 = TSingletons.Form02Pool.GetForm("BackOffice.UI.TF02" + Properties.BOID.Substring(4));
                        lForm02.LoadByPK(lPK);
                        lForm02.Visible = true;
                    }
                }

        }
        private void AdvSearchItem_Click(object sender, EventArgs e)
        {
            //TForm04 lForm04 = new TForm04();
            //lForm04.Form02FullName = "BackOffice.UI." + "TF02" + Properties.BOID.Substring(4);
            //lForm04.BOID = Properties.BOID;
            ////lForm04.MainContainer = (Form)this.Parent.Parent;
            //lForm04.Show();
            string lEditValue = TForm04.ShowAndGetSelectedPK(Properties.BOID, "", false);
            if (lEditValue != null)
            {
                EditValue = lEditValue;
                DoValidate();
            }
        }
        #endregion
    }
}
