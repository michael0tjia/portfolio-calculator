using System;
using System.Data;
using System.IO;
using System.Windows.Forms;
using DevExpress.XtraBars;
using Innotelli.BO;
using Innotelli.Db;
using Innotelli.Report1;
using Innotelli.Utilities;
using Innotelli.WinForm.Control;

namespace Innotelli.WinForm.Control
{
    public enum SystemActions
    {
        Logout,
        Exit,
        Unknown
    }
    public partial class TForm25 : DevExpress.XtraEditors.XtraForm
    {
        #region Members
        private int mLookUpListRefreshInterval01 = 1000;
        private TLookUpListCacheUpdateTask mLookUpListCacheUpdateTask = null;
        private string mAskIfLogOff = string.Empty;
        private string mAskIfExit = string.Empty;
        #endregion

        #region Constructors
        public TForm25()
        {
            InitializeComponent();
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                mAskIfLogOff = Innotelli.Utilities.TSingletons.StrResx.GetStr(125);
                mAskIfExit = Innotelli.Utilities.TSingletons.StrResx.GetStr(126);
            }
        }
        #endregion

        #region Properties
        private SystemActions mSystemAction = SystemActions.Unknown;
        public SystemActions SystemAction
        {
            get
            {
                return mSystemAction;
            }
            set
            {
                mSystemAction = value;
            }
        }
        #endregion

        #region Event Handlers
        private void frmMainContainer_Load(object sender, EventArgs e)
        {
            if (!DesignMode)
            {
                Init();
            }
        }
        private void frmMainContainer_Shown(object sender, EventArgs e)
        {
            if (!DesignMode)
            {
                Application.DoEvents();
                Cursor = Cursors.WaitCursor;
                Innotelli.WinForm.Control.TSingletons.Form02Pool.BindAllLookUpListCombo02();
                Cursor = Cursors.Default;
            }
        }
        private void frmMainContainer_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult lReturnValue;

            if (!DesignMode)
            {
                if (SystemAction == SystemActions.Unknown)
                {
                    lReturnValue = Exit();
                    if (lReturnValue == DialogResult.Yes)
                    {
                        e.Cancel = false;
                    }
                    else
                    {
                        e.Cancel = true;
                    }
                }
                else
                {
                    e.Cancel = false;
                }
            }
        }
        private void tmrLookUpList_Tick(object sender, EventArgs e)
        {
            tmrLookUpList.Enabled = false;
            StartUpdatingLookUpCache();
        }
        #endregion

        #region Functions

        #region Misc Functions
        protected virtual void PerformMiscFunc(string aMenuGUID, string aBOID)
        {
        }
        protected virtual void Init()
        {            
            TMenu.ParentForm = this;
            TMenu.MiscTask = new TMenu.MiscTaskDelegate(PerformMiscFunc);
            TMenu.GenMainMenu();

            if (!string.IsNullOrEmpty(TCurrentUser.CompanyName))
            {
                Text = Innotelli.Utilities.TAppSettings.ApplicationTitle + " [" + TCurrentUser.CompanyName + "]";
            }
            else
            {
                Text = Innotelli.Utilities.TAppSettings.ApplicationTitle;
            }

            tmrLookUpList.Interval = mLookUpListRefreshInterval01;
            tmrLookUpList.Enabled = true;
        }
        public void StartUpdatingLookUpCache()
        {
            mLookUpListCacheUpdateTask = new TLookUpListCacheUpdateTask();
            mLookUpListCacheUpdateTask.InvokeContext = this;
            mLookUpListCacheUpdateTask.WorkerCompleted += new Innotelli.Utilities.WorkerCompletedEventHandler(mLookUpListCacheUpdateTask_WorkerCompleted);
            mLookUpListCacheUpdateTask.Start();
        }
        private void mLookUpListCacheUpdateTask_WorkerCompleted(object sender, TWorkerCompletedEventArgs e)
        {
            tmrLookUpList.Enabled = true;
        }
        public DialogResult Exit()
        {
            DialogResult lReturnValue;

            lReturnValue = TMessageBox.AskQuestion(mAskIfExit, MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button2);
            if (lReturnValue == DialogResult.Yes)
            {
                SystemAction = SystemActions.Exit;
                Close();
            }

            return lReturnValue;
        }
        public DialogResult LogOff()
        {
            DialogResult lReturnValue;

            lReturnValue = TMessageBox.AskQuestion(mAskIfLogOff, MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button2);
            if (lReturnValue == DialogResult.Yes)
            {
                SystemAction = SystemActions.Logout;
                Close();                
            }

            return lReturnValue;
        }

        #endregion

        #endregion

    }
}