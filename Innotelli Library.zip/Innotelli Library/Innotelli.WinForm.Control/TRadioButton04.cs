using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.ViewInfo;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterRadioButton04")]
    public class RepositoryItemRadioButton04 : RepositoryItemRadioGroup
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemRadioButton04() { RegisterRadioButton04(); }

        //The unique name for the custom editor
        public const string RadioButton04Name = "TRadioButton04";

        //Return the unique name
        public override string EditorTypeName { get { return RadioButton04Name; } }

        //Register the editor
        public static void RegisterRadioButton04()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.RadioButton04.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(RadioButton04Name,
              typeof(TRadioButton04), typeof(RepositoryItemRadioButton04),
              typeof(RadioGroupViewInfo), new RadioGroupPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemRadioButton04 source = item as RepositoryItemRadioButton04;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public RepositoryItemRadioButton04()
        {
        }

        #endregion

        #region Properties
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        DSFormMode mDSFormMode = DSFormMode.DSEditable;
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        break;
                    case DSFormMode.DSEditable:
                        break;
                    case DSFormMode.DSInsert:
                        break;
                }
                mDSFormMode = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Init()
        {
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            Appearance.Options.UseBackColor = true;
            AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            AppearanceReadOnly.Options.UseBackColor = true;
            ReadOnly = true;
        }
        #endregion
    }
    public class TRadioButton04 : RadioGroup
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TRadioButton04() { RepositoryItemRadioButton04.RegisterRadioButton04(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemRadioButton04.RadioButton04Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemRadioButton04 Properties
        {
            get { return base.Properties as RepositoryItemRadioButton04; }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TRadioButton04()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(19, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(19, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
            TabStop = false;
        }
        #endregion
    }
}