using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using System;
using DevExpress.Utils;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterDateTimeTextBox02")]
    public class RepositoryItemDateTimeTextBox02 : RepositoryItemTextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemDateTimeTextBox02() { RegisterDateTimeTextBox02(); }

        //The unique name for the custom editor
        public const string DateTimeTextBox02Name = "TDateTimeTextBox02";

        //Return the unique name
        public override string EditorTypeName { get { return DateTimeTextBox02Name; } }

        //Register the editor
        public static void RegisterDateTimeTextBox02()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.DateTimeTextBox02.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(DateTimeTextBox02Name,
              typeof(TDateTimeTextBox02), typeof(RepositoryItemDateTimeTextBox02),
              typeof(TextEditViewInfo), new TextEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemDateTimeTextBox02 source = item as RepositoryItemDateTimeTextBox02;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        //Initialize new properties
        public RepositoryItemDateTimeTextBox02()
        {
        }
        #endregion

        #region Properties
        private DSFormMode mDSFormMode = DSFormMode.DSEditable;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        break;
                    case DSFormMode.DSEditable:
                        break;
                    case DSFormMode.DSInsert:
                        break;
                }
                mDSFormMode = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Init()
        {
            AllowFocused = false;
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            Appearance.Options.UseBackColor = true;
            AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            AppearanceReadOnly.Options.UseBackColor = true;
            DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            DisplayFormat.FormatString = TSettings.DateFormat + " " + TSettings.TimeFormat;
            //EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            //EditFormat.FormatString = TSettings.DateFormat + " " + TSettings.TimeFormat;
            Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTime;
            Mask.EditMask = TSettings.DateFormat + " " + TSettings.TimeFormat;
            //Mask.EditMask = resources.GetString("RepositoryItemDateTimeTextBox02.Mask.EditMask");
            //Mask.MaskType = ((DevExpress.XtraEditors.Mask.MaskType)(resources.GetObject("RepositoryItemDateTimeTextBox02.Mask.MaskType")));
            //Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("RepositoryItemDateTimeTextBox02.Mask.UseMaskAsDisplayFormat")));
            ReadOnly = true;
        }
        #endregion
    }


    public class TDateTimeTextBox02 : TextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TDateTimeTextBox02() { RepositoryItemDateTimeTextBox02.RegisterDateTimeTextBox02(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemDateTimeTextBox02.DateTimeTextBox02Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemDateTimeTextBox02 Properties
        {
            get { return base.Properties as RepositoryItemDateTimeTextBox02; }
        }
        #endregion

        #region Members
        private string mFormat = TSettings.DateFormat + " " + TSettings.TimeFormat;
        #endregion

        #region Constructors
        //Initialize the new instance
        public TDateTimeTextBox02()
        {
            Init();
        }
        #endregion

        #region Properties
        [Bindable(true),
        Category("Behavior"),
        DefaultValue("yyyy/MM/dd hh:mm tt"),
        Description("Indicates the date/time format."),
        Localizable(true)]
        public string Format
        {
            get
            {
                return mFormat;
            }
            set
            {
                mFormat = value;
            }
        }
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(130, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(130, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            EditValue = null;
            Margin = new System.Windows.Forms.Padding(0);
            TabStop = false;
        }
        #endregion
    }
}