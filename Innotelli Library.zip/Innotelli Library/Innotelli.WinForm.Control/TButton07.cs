using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using Innotelli.BO;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterButton07")]
    public class RepositoryItemButton07 : RepositoryItemButtonEdit
    {
        //The static constructor which calls the registration method
        static RepositoryItemButton07() { RegisterButton07(); }

        //Initialize new properties
        public RepositoryItemButton07()
        {
        }

        //The unique name for the custom editor
        public const string Button07Name = "TButton07";

        //Return the unique name
        public override string EditorTypeName { get { return Button07Name; } }

        //Register the editor
        public static void RegisterButton07()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.Button07.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(Button07Name,
              typeof(TButton07), typeof(RepositoryItemButton07),
              typeof(ButtonEditViewInfo), new ButtonEditPainter(), true, img));
        }
        private string mBOID = "";
        public string BOID
        {
            get
            {
                return mBOID;
            }
            set
            {
                mBOID = value;
                OnPropertiesChanged();
            }
        }
        
        private TBOT01 mBOT01;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
            }
        }
        private TDataGrid01 mOwnerGrid;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TDataGrid01 OwnerGrid
        {
            get
            {
                return mOwnerGrid;
            }
            set
            {
                mOwnerGrid = value;
            }
        }
        private Form mParentForm;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Form ParentForm
        {
            get
            {
                return mParentForm;
            }
            set
            {
                mParentForm = value;
            }
        }
        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemButton07 source = item as RepositoryItemButton07;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        public void Init()
        {
            Image img = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TButton07.Button.png"));
            Buttons[0].Kind = DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph;
            Buttons[0].Image = img;
            Buttons[0].IsLeft = true;
            Buttons[0].Width = 10;
            BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            AssignEventHandlers();
        }
        private void AssignEventHandlers()
        {
            ButtonClick += RepositoryItemButton07_ButtonClick;
        }
        private void RepositoryItemButton07_ButtonClick(object sender, DevExpress.XtraEditors.Controls.ButtonPressedEventArgs e)
        {
            TButton07 lButton07 = (sender as TButton07);
            TForm02 lForm02 = null;
            string lPK = "";
            //Type lPrntFrmBsTp = mParentForm.GetType().BaseType;
            string lParentFormBasicType = mParentForm.GetType().BaseType.Name;

            if (lButton07.EditValue != null && lButton07.EditValue != DBNull.Value)
            {
                lPK = lButton07.EditValue.ToString();
                if (lPK != "")
                {
                    lForm02 = TSingletons.Form02Pool.GetForm("BackOffice.UI.TF02" + mBOID.Substring(4));
                    if (lForm02 != null)
                    {
                        //lForm02.BOT01.Dt = mBOT01.Dt;
                        //lForm02.BOT01.PK2 = lPK;
                        //lForm02.BOT01.GotoRowByPK(lPK);
                        //lForm02.JustShow();
                        lForm02.LoadByPK(lPK);
                        //lForm02.DsMode = ((lPrntFrmBsTp)mParentForm).DsMode;
                        //lForm02.ShowDialog();
                        //((lPrntFrmBsTp)mParentForm).Reload();
                        switch (lParentFormBasicType)
                        {
                            case "TForm02":
                                lForm02.BOT01.FK = ((TForm02)mParentForm).BOT01.PrmyKey;
                                ((TForm02)mParentForm).DsMode = DSFormMode.DSBrowse;
                                //lForm02.DsMode = ((TForm02)mParentForm).DsMode;
                                break;
                            case "TForm07":
                                lForm02.BOT01.FK = ((TForm07)mParentForm).BOT01.PrmyKey;
                                lForm02.DsMode = ((TForm07)mParentForm).DsMode;
                                break;
                            case "TForm12":
                                lForm02.BOT01.FK = ((TForm12)mParentForm).BOT01.PrmyKey;
                                lForm02.DsMode = ((TForm12)mParentForm).DsMode;
                                break;
                            case "TForm01":
                                //lForm02.BOT01.FK = ((TForm01)mParentForm).BOT01.prmykey2;
                                //lForm02.DsMode = ((TForm01)mParentForm).DsMode;
                                break;
                            case "TForm06":
                                lForm02.BOT01.FK = ((TForm06)mParentForm).BOT01.PrmyKey;
                                lForm02.DsMode = ((TForm06)mParentForm).DsMode;
                                break;
                        }
                        lForm02.DSUpdateFormState();
                        //lForm02.MdiParent = null;
                        lForm02.Show();
                        //lForm02.ShowDialog();
                        //if (lForm02.DialogResult == DialogResult.Cancel)
                        //{
                        //    mOwnerGrid.BOT01.LoadDataSet();
                        //    mOwnerGrid.BindData();
                        //    mOwnerGrid.BOT01.IsDirty = true;
                        //}
                    }
                }
            }
        }
    }
    public class TButton07 : ButtonEdit
    {
        #region Enums
        #endregion

        #region Members
        //bool mBorderStyleIsModified = false;
        #endregion

        #region Constructors
        //The static constructor which calls the registration method
        static TButton07() { RepositoryItemButton07.RegisterButton07(); }

        //Initialize the new instance
        public TButton07()
        {
            Init();
        }
        #endregion
        
        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(19, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(19, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemButton07.Button07Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemButton07 Properties
        {
            get { return base.Properties as RepositoryItemButton07; }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}
