﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.WinForm.Control
{
    public class TMenuItem
    {
        #region Enums
        #endregion

        #region Structures
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TMenuItem()
        {
        }
        #endregion

        #region Properties
        private int mMenuActnTp;
        public int MenuActnTp
        {
            get 
            {
                return mMenuActnTp; 
            }
            set 
            {
                mMenuActnTp = value; 
            }
        }
        private string mMenuGUID;
        public string MenuGUID
        {
            get
            {
                return mMenuGUID; 
            }
            set
            {
                mMenuGUID = value; 
            }
        }
        private string mBOID;
        public string BOID
        {
            get 
            {
                return mBOID; 
            }
            set 
            {
                mBOID = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion

    }
}
