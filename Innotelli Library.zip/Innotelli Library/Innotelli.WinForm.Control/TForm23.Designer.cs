namespace Innotelli.WinForm.Control
{
    partial class TForm23
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TForm23));
            this.lyc01Base = new Innotelli.WinForm.Control.TLayoutControl01();
            this.btnBaseOK = new DevExpress.XtraEditors.SimpleButton();
            this.btnBaseCancel = new DevExpress.XtraEditors.SimpleButton();
            this.lcg01Base1 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.lcg01Base3 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.lci01BaseCancel = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.lci01BaseOK = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.esiBase1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.lcg01Base2 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            ((System.ComponentModel.ISupportInitialize)(this.lyc01Base)).BeginInit();
            this.lyc01Base.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01BaseCancel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01BaseOK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.esiBase1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base2)).BeginInit();
            this.SuspendLayout();
            // 
            // lyc01Base
            // 
            this.lyc01Base.AccessibleDescription = null;
            this.lyc01Base.AccessibleName = null;
            resources.ApplyResources(this.lyc01Base, "lyc01Base");
            this.lyc01Base.Appearance.DisabledLayoutGroupCaption.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lyc01Base.Appearance.DisabledLayoutGroupCaption.Options.UseForeColor = true;
            this.lyc01Base.Appearance.DisabledLayoutItem.ForeColor = System.Drawing.SystemColors.GrayText;
            this.lyc01Base.Appearance.DisabledLayoutItem.Options.UseForeColor = true;
            this.lyc01Base.BackgroundImage = null;
            this.lyc01Base.Controls.Add(this.btnBaseOK);
            this.lyc01Base.Controls.Add(this.btnBaseCancel);
            this.lyc01Base.Font = null;
            this.lyc01Base.Name = "lyc01Base";
            this.lyc01Base.OptionsItemText.TextAlignMode = DevExpress.XtraLayout.TextAlignMode.AlignInGroups;
            this.lyc01Base.OptionsView.EnableIndentsInGroupsWithoutBorders = true;
            this.lyc01Base.Root = this.lcg01Base1;
            // 
            // btnBaseOK
            // 
            this.btnBaseOK.AccessibleDescription = null;
            this.btnBaseOK.AccessibleName = null;
            resources.ApplyResources(this.btnBaseOK, "btnBaseOK");
            this.btnBaseOK.BackgroundImage = null;
            this.btnBaseOK.Name = "btnBaseOK";
            this.btnBaseOK.StyleController = this.lyc01Base;
            // 
            // btnBaseCancel
            // 
            this.btnBaseCancel.AccessibleDescription = null;
            this.btnBaseCancel.AccessibleName = null;
            resources.ApplyResources(this.btnBaseCancel, "btnBaseCancel");
            this.btnBaseCancel.BackgroundImage = null;
            this.btnBaseCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnBaseCancel.Name = "btnBaseCancel";
            this.btnBaseCancel.StyleController = this.lyc01Base;
            // 
            // lcg01Base1
            // 
            resources.ApplyResources(this.lcg01Base1, "lcg01Base1");
            this.lcg01Base1.GroupBordersVisible = false;
            this.lcg01Base1.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lcg01Base3,
            this.lcg01Base2});
            this.lcg01Base1.Location = new System.Drawing.Point(0, 0);
            this.lcg01Base1.Name = "lcg01Base1";
            this.lcg01Base1.OptionsItemText.TextToControlDistance = 2;
            this.lcg01Base1.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base1.Size = new System.Drawing.Size(267, 392);
            this.lcg01Base1.Spacing = new DevExpress.XtraLayout.Utils.Padding(3, 3, 3, 3);
            this.lcg01Base1.TextVisible = false;
            // 
            // lcg01Base3
            // 
            resources.ApplyResources(this.lcg01Base3, "lcg01Base3");
            this.lcg01Base3.GroupBordersVisible = false;
            this.lcg01Base3.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.lci01BaseCancel,
            this.lci01BaseOK,
            this.esiBase1});
            this.lcg01Base3.Location = new System.Drawing.Point(0, 356);
            this.lcg01Base3.Name = "lcg01Base3";
            this.lcg01Base3.Size = new System.Drawing.Size(259, 28);
            this.lcg01Base3.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.lcg01Base3.TextVisible = false;
            // 
            // lci01BaseCancel
            // 
            this.lci01BaseCancel.Control = this.btnBaseCancel;
            resources.ApplyResources(this.lci01BaseCancel, "lci01BaseCancel");
            this.lci01BaseCancel.Location = new System.Drawing.Point(177, 0);
            this.lci01BaseCancel.MaxSize = new System.Drawing.Size(82, 28);
            this.lci01BaseCancel.MinSize = new System.Drawing.Size(82, 28);
            this.lci01BaseCancel.Name = "lci01BaseCancel";
            this.lci01BaseCancel.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01BaseCancel.Size = new System.Drawing.Size(82, 28);
            this.lci01BaseCancel.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lci01BaseCancel.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.lci01BaseCancel.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01BaseCancel.TextSize = new System.Drawing.Size(0, 0);
            this.lci01BaseCancel.TextToControlDistance = 0;
            this.lci01BaseCancel.TextVisible = false;
            // 
            // lci01BaseOK
            // 
            this.lci01BaseOK.Control = this.btnBaseOK;
            resources.ApplyResources(this.lci01BaseOK, "lci01BaseOK");
            this.lci01BaseOK.Location = new System.Drawing.Point(95, 0);
            this.lci01BaseOK.MaxSize = new System.Drawing.Size(82, 28);
            this.lci01BaseOK.MinSize = new System.Drawing.Size(82, 28);
            this.lci01BaseOK.Name = "lci01BaseOK";
            this.lci01BaseOK.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.lci01BaseOK.Size = new System.Drawing.Size(82, 28);
            this.lci01BaseOK.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.lci01BaseOK.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.lci01BaseOK.TextLocation = DevExpress.Utils.Locations.Left;
            this.lci01BaseOK.TextSize = new System.Drawing.Size(0, 0);
            this.lci01BaseOK.TextToControlDistance = 0;
            this.lci01BaseOK.TextVisible = false;
            // 
            // esiBase1
            // 
            resources.ApplyResources(this.esiBase1, "esiBase1");
            this.esiBase1.Location = new System.Drawing.Point(0, 0);
            this.esiBase1.Name = "esiBase1";
            this.esiBase1.Size = new System.Drawing.Size(95, 28);
            this.esiBase1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // lcg01Base2
            // 
            resources.ApplyResources(this.lcg01Base2, "lcg01Base2");
            this.lcg01Base2.Location = new System.Drawing.Point(0, 0);
            this.lcg01Base2.Name = "lcg01Base2";
            this.lcg01Base2.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base2.Size = new System.Drawing.Size(259, 356);
            this.lcg01Base2.Spacing = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.lcg01Base2.TextVisible = false;
            // 
            // TForm23
            // 
            this.AccessibleDescription = null;
            this.AccessibleName = null;
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lyc01Base);
            this.Icon = null;
            this.Name = "TForm23";
            ((System.ComponentModel.ISupportInitialize)(this.lyc01Base)).EndInit();
            this.lyc01Base.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01BaseCancel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lci01BaseOK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.esiBase1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lcg01Base2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        protected TLayoutControl01 lyc01Base;
        protected DevExpress.XtraEditors.SimpleButton btnBaseOK;
        protected DevExpress.XtraEditors.SimpleButton btnBaseCancel;
        protected LayoutControlGroup01 lcg01Base1;
        private LayoutControlGroup01 lcg01Base3;
        protected LayoutControlItem01 lci01BaseCancel;
        protected LayoutControlItem01 lci01BaseOK;
        private DevExpress.XtraLayout.EmptySpaceItem esiBase1;
        protected LayoutControlGroup01 lcg01Base2;
    }
}