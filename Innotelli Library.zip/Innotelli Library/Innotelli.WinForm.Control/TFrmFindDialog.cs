using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Innotelli.WinForm.Control
{
    //michael version on 2008/01/20
    public partial class TFrmFindDialog : DevExpress.XtraEditors.XtraForm
    {
        public TFrmFindDialog()
        {
            InitializeComponent();
        }
        private void frmChgID_Load(object sender, EventArgs e)
        {
        }
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (txtID.EditValue != null)
            {
                DialogResult = DialogResult.OK;
            }
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.Cancel;
        }
    }
}