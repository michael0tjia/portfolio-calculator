using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.ViewInfo;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterTextBox05")]
    public class RepositoryItemTextBox05 : RepositoryItemTextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemTextBox05() { RegisterTextBox05(); }

        //The unique name for the custom editor
        public const string TextBox05Name = "TTextBox05";

        //Return the unique name
        public override string EditorTypeName { get { return TextBox05Name; } }

        //Register the editor
        public static void RegisterTextBox05()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.TextBox05.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(TextBox05Name,
              typeof(TTextBox05), typeof(RepositoryItemTextBox05),
              typeof(TextEditViewInfo), new TextEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemTextBox05 source = item as RepositoryItemTextBox05;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public RepositoryItemTextBox05()
        {
        }
        #endregion

        #region Properties
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        DSFormMode mDSFormMode = DSFormMode.DSEditable;
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        break;
                    case DSFormMode.DSEditable:
                        break;
                    case DSFormMode.DSInsert:
                        break;
                }
                mDSFormMode = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Init()
        {
            Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            Appearance.Options.UseBackColor = true;
            AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            AppearanceReadOnly.Options.UseBackColor = true;
            ReadOnly = true;
        }
        #endregion
    }

    public class TTextBox05 : TextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TTextBox05() { RepositoryItemTextBox05.RegisterTextBox05(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemTextBox05.TextBox05Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemTextBox05 Properties
        {
            get { return base.Properties as RepositoryItemTextBox05; }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TTextBox05()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(15, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }        
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
            TabStop = false;
        }
        #endregion
    }
}
