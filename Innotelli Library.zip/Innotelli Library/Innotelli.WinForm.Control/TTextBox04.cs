using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.ViewInfo;
using Innotelli.BO;
using Innotelli.Utilities;
using System;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterTextBox04")]
    public class RepositoryItemTextBox04 : RepositoryItemTextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemTextBox04() { RegisterTextBox04(); }

        //The unique name for the custom editor
        public const string TextBox04Name = "TTextBox04";

        //Return the unique name
        public override string EditorTypeName { get { return TextBox04Name; } }

        //Register the editor
        public static void RegisterTextBox04()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.TextBox04.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(TextBox04Name,
              typeof(TTextBox04), typeof(RepositoryItemTextBox04),
              typeof(TextEditViewInfo), new TextEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemTextBox04 source = item as RepositoryItemTextBox04;
                if (source == null) return;
                IsLocked = source.IsLocked;
                DSFormMode = source.DSFormMode;
                BOT01 = source.BOT01;
                MaxLengthFromSysData = source.MaxLengthFromSysData;
                BoundColumnName = source.BoundColumnName;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public RepositoryItemTextBox04()
        {
        }
        #endregion

        #region Properties
        private bool mIsLocked = false;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                ReadOnly = value;
                if (value)
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                }
                else
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
                }
                if (OwnerEdit != null)
                {
                    OwnerEdit.TabStop = !value;
                }
                mIsLocked = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        DSFormMode mDSFormMode = DSFormMode.DSEditable;
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        ReadOnly = true;
                        break;
                    case DSFormMode.DSEditable:
                        ReadOnly = false;
                        break;
                    case DSFormMode.DSInsert:
                        ReadOnly = false;
                        break;
                }
                mDSFormMode = value;
            }
        }        
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        TBOT01 mBOT01 = null;
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
            }
        }
        private int mMaxLengthFromSysData = 0;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public int MaxLengthFromSysData
        {
            get 
            {
                if (mMaxLengthFromSysData == 0)
                {
                    mMaxLengthFromSysData = GetMaxLengthFromSysData();
                }
                return mMaxLengthFromSysData; 
            }
            set 
            {
                mMaxLengthFromSysData = value; 
            }
        }
        private string mBoundColumnName = string.Empty;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string BoundColumnName
        {
            get
            {
                if (mBoundColumnName == string.Empty)
                {
                    mBoundColumnName = TControlUtil.GetFirstBindingFieldNameFromOwnerEdit(this);
                }
                return mBoundColumnName;
            }
            set
            {
                mBoundColumnName = value;
            }
        }        
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Init(TBOT01 aBOT01)
        {
            AppearanceReadOnly.Options.UseBackColor = false;
            BOT01 = aBOT01;
        }
        private int GetMaxLengthFromSysData()
        {
            if (BoundColumnName != string.Empty)
            {
                return (int)TNull.Nz(BOT01.SPrps.SPrpsBOT01Flds[BoundColumnName].FldSize, 0);
            }
            else
            {
                return 0;
            }

        }
        #endregion
    }

    public class TTextBox04 : TextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TTextBox04() { RepositoryItemTextBox04.RegisterTextBox04(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemTextBox04.TextBox04Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemTextBox04 Properties
        {
            get { return base.Properties as RepositoryItemTextBox04; }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TTextBox04()
        {
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(15, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {   
                return mDefaultSize;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        protected override void OnGotFocus(EventArgs e)
        {
            base.OnGotFocus(e);
            Properties.MaxLength = Properties.MaxLengthFromSysData;
        }
        #endregion
    }
}
