using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Innotelli.WinForm.Control;
using Innotelli.BO;
using System.Reflection;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    public partial class TForm01 : DevExpress.XtraEditors.XtraForm
    {
        #region Enums

        #endregion

        #region Members
        
        

        private string mAskSaveBeforeExit = String.Empty;
        private bool lSaveBtnClicked = false;

        #endregion

        #region Constructors
        public TForm01()
        {
            InitializeComponent();
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                mAskSaveBeforeExit = Innotelli.Utilities.TSingletons.StrResx.GetStr(127);
            }
        }
        #endregion

        #region Properties
        private TBOT01 mBOT01 = null;
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
            }
        }
        private TDataGrid02 mGrd02This = null;
        public TDataGrid02 Grd02This
        {
            get
            {
                return mGrd02This;
            }
            set
            {
                mGrd02This = value;
            }
        }
        private bool mReadOnly = false;
        public bool ReadOnly
        {
            get
            {
                return mReadOnly;
            }
            set
            {
                mReadOnly = value;
                if (ReadOnly)
                {
                    lcg01Base3.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Never;
                }
                else
                {
                    lcg01Base3.Visibility = DevExpress.XtraLayout.Utils.LayoutVisibility.Always;
                }
            }
        }
        #endregion

        #region Event Handlers
        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveData();
        }
        private void btnCancel_Click(object sender, EventArgs e)
        {

            //((DevExpress.XtraGrid.Views.Base.ColumnView)Grd02This.MainView).SaveLayoutToXml("D:\\" + mBOT01.BOID + ".xml");
            CancelSave();

        }

        private void TForm01_Load(object sender, EventArgs e)
        {
            if (Utilities.TGC.IsRunTime)
            {
                LoadData();
                BindData();
            }
        }

        private void TForm01_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.S && e.Control)
            {
                ((DevExpress.XtraGrid.Views.Base.ColumnView)Grd02This.MainView).SaveLayoutToXml("D:\\" + Grd02This.Name + ".xml", DevExpress.Utils.OptionsLayoutBase.FullLayout);
                e.Handled = true;
            }
        }

        private void TForm01_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult lDialogResult;
            if (!lSaveBtnClicked && !mReadOnly)
            {
                lDialogResult = DSFAskSaveBeforeExit();
                if (lDialogResult == DialogResult.Yes)
                {
                    lSaveBtnClicked = true;
                    BOT01.Save();
                    DialogResult = DialogResult.OK;
                    if (mGrd02This.ChildForm02s.Count == 0)
                    {
                        e.Cancel = false;
                    }
                    else
                    {
                        TMessageBox.ShowWarning(mGrd02This.ChildForm02s.Count + " child form(s) is still opening");
                        foreach (KeyValuePair<TDbRowID, TForm02> keyValuePair in mGrd02This.ChildForm02s)
                        {
                            keyValuePair.Value.Focus();
                            keyValuePair.Value.WindowState = FormWindowState.Normal;
                        }
                        e.Cancel = true;
                    }
                }
                else if (lDialogResult == DialogResult.No)
                {
                    lSaveBtnClicked = true;
                    DialogResult = DialogResult.OK;
                    e.Cancel = false;
                }
                else
                {
                    e.Cancel = true;
                }
            }

            //((DevExpress.XtraGrid.Views.Base.ColumnView)Grd02This.MainView).SaveLayoutToXml("D:\\" + Grd02This.Name + ".xml", DevExpress.Utils.OptionsLayoutBase.FullLayout);

        }
        #endregion

        #region Functions

        private DialogResult DSFAskSaveBeforeExit()
        {
            DialogResult lReturnValue;

            lReturnValue = TMessageBox.AskQuestion(mAskSaveBeforeExit, MessageBoxButtons.YesNoCancel, MessageBoxDefaultButton.Button1);
            return lReturnValue;
        }

        protected virtual void Init()
        {
            if (Utilities.TGC.IsRunTime)
            {
                Grd02This.BOT01 = BOT01;
                Grd02This.ParentForm = this;
                Grd02This.Init();
            }
        }
        protected virtual void AssignBOToGrids()
        {
        }
        public virtual void LoadData()
        {
            BOT01.LoadDataSet();
        }
        public virtual void SaveData()
        {
            lSaveBtnClicked = true;
            BOT01.Save();
            DialogResult = DialogResult.OK;
            Close();
        }
        public virtual void CancelSave()
        {
            DialogResult = DialogResult.Cancel;
            Close();
        }
        public void Reload()
        {
            if (Utilities.TGC.IsRunTime)
            {
                LoadData();
                BindData();
            }
        }
        protected virtual void BindData()
        {
            Grd02This.BindData();
            OtherBinding();
        }
        protected virtual void OtherBinding()
        {
        }
        #endregion
    }
}