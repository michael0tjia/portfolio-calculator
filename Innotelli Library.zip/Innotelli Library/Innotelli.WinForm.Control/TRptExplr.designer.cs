namespace Innotelli.WinForm.Control
{
    partial class TRptExplr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPrint = new System.Windows.Forms.Button();
            this.btnPreview = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.gclFilter = new DevExpress.XtraGrid.GridControl();
            this.gdvFilter = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.FldNm = new DevExpress.XtraGrid.Columns.GridColumn();
            this.FldAls = new DevExpress.XtraGrid.Columns.GridColumn();
            this.FldType = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Condition = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Value1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.Value2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.SelObjID = new DevExpress.XtraGrid.Columns.GridColumn();
            this.BndCol = new DevExpress.XtraGrid.Columns.GridColumn();
            this.RwFltr = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemDateEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemDateEdit();
            this.repositoryItemCheckEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit();
            this.repositoryItemTextEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemTextEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemDateEditor031 = new Innotelli.WinForm.Control.RepositoryItemDateEditor03();
            this.lstRptCat = new System.Windows.Forms.ListBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lstRpt = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gclFilter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdvFilter)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor031)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor031.VistaTimeProperties)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnPrint
            // 
            this.btnPrint.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPrint.Location = new System.Drawing.Point(607, 502);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Size = new System.Drawing.Size(75, 23);
            this.btnPrint.TabIndex = 9;
            this.btnPrint.Text = "Print";
            this.btnPrint.UseVisualStyleBackColor = true;
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // btnPreview
            // 
            this.btnPreview.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnPreview.Location = new System.Drawing.Point(526, 502);
            this.btnPreview.Name = "btnPreview";
            this.btnPreview.Size = new System.Drawing.Size(75, 23);
            this.btnPreview.TabIndex = 8;
            this.btnPreview.Text = "Preview";
            this.btnPreview.UseVisualStyleBackColor = true;
            this.btnPreview.Click += new System.EventHandler(this.btnPreview_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.gclFilter);
            this.groupBox2.Location = new System.Drawing.Point(4, 290);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(679, 209);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            // 
            // gclFilter
            // 
            this.gclFilter.EmbeddedNavigator.Name = "";
            this.gclFilter.Location = new System.Drawing.Point(3, 13);
            this.gclFilter.MainView = this.gdvFilter;
            this.gclFilter.Name = "gclFilter";
            this.gclFilter.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit1,
            this.repositoryItemDateEdit1,
            this.repositoryItemCheckEdit1,
            this.repositoryItemTextEdit2,
            this.repositoryItemTextEdit3,
            this.repositoryItemDateEditor031});
            this.gclFilter.Size = new System.Drawing.Size(673, 190);
            this.gclFilter.TabIndex = 2;
            this.gclFilter.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gdvFilter});
            // 
            // gdvFilter
            // 
            this.gdvFilter.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.FldNm,
            this.FldAls,
            this.FldType,
            this.Condition,
            this.Value1,
            this.Value2,
            this.SelObjID,
            this.BndCol,
            this.RwFltr});
            this.gdvFilter.GridControl = this.gclFilter;
            this.gdvFilter.Name = "gdvFilter";
            this.gdvFilter.OptionsView.ShowColumnHeaders = false;
            this.gdvFilter.OptionsView.ShowGroupPanel = false;
            this.gdvFilter.CustomRowCellEdit += new DevExpress.XtraGrid.Views.Grid.CustomRowCellEditEventHandler(this.gdvFilter_CustomRowCellEdit);
            // 
            // FldNm
            // 
            this.FldNm.Caption = "Field Name";
            this.FldNm.FieldName = "FldNm";
            this.FldNm.Name = "FldNm";
            // 
            // FldAls
            // 
            this.FldAls.Caption = "Field Alias";
            this.FldAls.FieldName = "FldAls";
            this.FldAls.Name = "FldAls";
            this.FldAls.Visible = true;
            this.FldAls.VisibleIndex = 0;
            // 
            // FldType
            // 
            this.FldType.Caption = "Field Type";
            this.FldType.FieldName = "FldType";
            this.FldType.Name = "FldType";
            // 
            // Condition
            // 
            this.Condition.Caption = "Condition";
            this.Condition.FieldName = "Condition";
            this.Condition.Name = "Condition";
            this.Condition.Visible = true;
            this.Condition.VisibleIndex = 1;
            // 
            // Value1
            // 
            this.Value1.Caption = "Value1";
            this.Value1.FieldName = "Value1";
            this.Value1.Name = "Value1";
            this.Value1.Visible = true;
            this.Value1.VisibleIndex = 2;
            // 
            // Value2
            // 
            this.Value2.Caption = "Value2";
            this.Value2.FieldName = "Value2";
            this.Value2.Name = "Value2";
            this.Value2.Visible = true;
            this.Value2.VisibleIndex = 3;
            // 
            // SelObjID
            // 
            this.SelObjID.Caption = "SelObjID";
            this.SelObjID.FieldName = "SelObjID";
            this.SelObjID.Name = "SelObjID";
            // 
            // BndCol
            // 
            this.BndCol.Caption = "BndCol";
            this.BndCol.FieldName = "BndCol";
            this.BndCol.Name = "BndCol";
            // 
            // RwFltr
            // 
            this.RwFltr.Caption = "RwFltr";
            this.RwFltr.FieldName = "RwFltr";
            this.RwFltr.Name = "RwFltr";
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // repositoryItemDateEdit1
            // 
            this.repositoryItemDateEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEdit1.Name = "repositoryItemDateEdit1";
            this.repositoryItemDateEdit1.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // repositoryItemCheckEdit1
            // 
            this.repositoryItemCheckEdit1.Name = "repositoryItemCheckEdit1";
            // 
            // repositoryItemTextEdit2
            // 
            this.repositoryItemTextEdit2.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.repositoryItemTextEdit2.Appearance.Options.UseBackColor = true;
            this.repositoryItemTextEdit2.Name = "repositoryItemTextEdit2";
            this.repositoryItemTextEdit2.ReadOnly = true;
            // 
            // repositoryItemTextEdit3
            // 
            this.repositoryItemTextEdit3.Name = "repositoryItemTextEdit3";
            // 
            // repositoryItemDateEditor031
            // 
            this.repositoryItemDateEditor031.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemDateEditor031.Name = "repositoryItemDateEditor031";
            this.repositoryItemDateEditor031.VistaTimeProperties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            // 
            // lstRptCat
            // 
            this.lstRptCat.FormattingEnabled = true;
            this.lstRptCat.Location = new System.Drawing.Point(6, 32);
            this.lstRptCat.Name = "lstRptCat";
            this.lstRptCat.Size = new System.Drawing.Size(161, 238);
            this.lstRptCat.TabIndex = 6;
            this.lstRptCat.SelectedIndexChanged += new System.EventHandler(this.lstRptCat_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(170, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Reports";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.lstRptCat);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.lstRpt);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(4, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(679, 281);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            // 
            // lstRpt
            // 
            this.lstRpt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.lstRpt.FormattingEnabled = true;
            this.lstRpt.Location = new System.Drawing.Point(173, 32);
            this.lstRpt.Name = "lstRpt";
            this.lstRpt.ScrollAlwaysVisible = true;
            this.lstRpt.Size = new System.Drawing.Size(500, 238);
            this.lstRpt.TabIndex = 4;
            this.lstRpt.SelectedIndexChanged += new System.EventHandler(this.lstRpt_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Categories";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(10, 506);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(0, 13);
            this.label3.TabIndex = 13;
            // 
            // TRptExplr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 528);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnPrint);
            this.Controls.Add(this.btnPreview);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "TRptExplr";
            this.Text = "Report Explorer";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TRptExplr_FormClosing);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gclFilter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gdvFilter)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemCheckEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor031.VistaTimeProperties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemDateEditor031)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnPrint;
        private System.Windows.Forms.Button btnPreview;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lstRptCat;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ListBox lstRpt;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraGrid.GridControl gclFilter;
        private DevExpress.XtraGrid.Views.Grid.GridView gdvFilter;
        private DevExpress.XtraGrid.Columns.GridColumn FldNm;
        private DevExpress.XtraGrid.Columns.GridColumn FldAls;
        private DevExpress.XtraGrid.Columns.GridColumn FldType;
        private DevExpress.XtraGrid.Columns.GridColumn Condition;
        private DevExpress.XtraGrid.Columns.GridColumn Value1;
        private DevExpress.XtraGrid.Columns.GridColumn Value2;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemDateEdit repositoryItemDateEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemCheckEdit repositoryItemCheckEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit2;
        private DevExpress.XtraGrid.Columns.GridColumn SelObjID;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit3;
        private DevExpress.XtraGrid.Columns.GridColumn BndCol;
        private Innotelli.WinForm.Control.RepositoryItemDateEditor03 repositoryItemDateEditor031;
        private DevExpress.XtraGrid.Columns.GridColumn RwFltr;
        private System.Windows.Forms.Label label3;
    
    }
}