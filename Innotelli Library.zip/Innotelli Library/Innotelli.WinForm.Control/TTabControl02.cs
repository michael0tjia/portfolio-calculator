using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraTab;

namespace Innotelli.WinForm.Control
{
    //[System.Drawing.ToolboxBitmap(typeof(XtraTabControl)), DefaultProperty("")]
    public partial class TTabControl02 : XtraTabControl
    {
        #region Enums

        #endregion

        #region Members
        #endregion

        #region Constructors
        public TTabControl02()
        {
            //#check!
            //InitializeComponent();
        }
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        //private void InitializeComponent()
        //{
        //    System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TTabControl02));
        //    ((System.ComponentModel.ISupportInitialize)(this)).BeginInit();
        //    this.SuspendLayout();
        //    // 
        //    // TabControl02
        //    // 
        //    resources.ApplyResources(this, "$this");
        //    ((System.ComponentModel.ISupportInitialize)(this)).EndInit();
        //    this.ResumeLayout(false);

        //}
        #endregion
    }
}
