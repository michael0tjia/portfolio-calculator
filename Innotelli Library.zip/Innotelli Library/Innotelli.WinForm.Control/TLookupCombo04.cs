using System;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Threading;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using DevExpress.Utils;
using Innotelli.BO;
using Innotelli.Utilities;
using DevExpress.Utils.Menu;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterLookupCombo04")]
    public class RepositoryItemLookupCombo04 : RepositoryItemGridLookUpEdit
    {
        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static RepositoryItemLookupCombo04() { RegisterLookupCombo04(); }

        //The unique name for the custom editor
        public const string LookupCombo04Name = "TLookupCombo04";

        //Return the unique name
        public override string EditorTypeName { get { return LookupCombo04Name; } }

        //Register the editor
        public static void RegisterLookupCombo04()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.LookupCombo04.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(LookupCombo04Name,
              typeof(TLookupCombo04), typeof(RepositoryItemLookupCombo04),
              typeof(GridLookUpEditBaseViewInfo), new ButtonEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemLookupCombo04 source = item as RepositoryItemLookupCombo04;
                if (source == null) return;
                BndCol = source.BndCol;
                BOID = source.BOID;
            }
            finally
            {
                EndUpdate();
            }
        }

        #endregion

        #region Members

        private bool mIsLocked = false;
        DSFormMode mDSFormMode = DSFormMode.DSEditable;

        #endregion

        #region Constructors

        //Initialize new properties
        public RepositoryItemLookupCombo04()
        {
        }

        #endregion

        #region Properties

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                ReadOnly = value;
                if (value)
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                }
                else
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
                }
                if (OwnerEdit != null)
                {
                    OwnerEdit.TabStop = !value;
                }
                for (int i = 0; i < Buttons.Count; i++)
                {
                    Buttons[i].Enabled = !value;
                }
                mIsLocked = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        ReadOnly = true;
                        break;
                    case DSFormMode.DSEditable:
                        ReadOnly = false;
                        break;
                    case DSFormMode.DSInsert:
                        ReadOnly = false;
                        break;
                }
                for (int i = 0; i < Buttons.Count; i++)
                {
                    Buttons[i].Enabled = !ReadOnly;
                }
                mDSFormMode = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string RowFilter
        {
            get
            {
                if (DataSource != null)
                {
                    return ((DataView)DataSource).RowFilter;
                }
                else
                {
                    return "";
                }
            }
            set
            {
                if (value != null && DataSource != null)
                {
                    ((DataView)DataSource).RowFilter = value;
                }
            }
        }
        private bool mNormalMode = true;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool NormalMode
        {
            get
            {
                return mNormalMode;
            }
            set
            {
                mNormalMode = value;
            }
        }
        private TBOT01 mBOT01 = null;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
            }
        }
        private string mCnnStr = string.Empty;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public string CnnStr
        {
            get
            {
                return mCnnStr;
            }
            set
            {
                mCnnStr = value;
            }
        }
        private string mBOID = "";
        public string BOID
        {
            get
            {
                return mBOID;
            }
            set
            {
                mBOID = value;
                OnPropertiesChanged();
            }
        }
        private int mBndCol = 0;
        public int BndCol
        {
            get
            {
                return mBndCol;
            }
            set
            {
                mBndCol = value;
                OnPropertiesChanged();
            }
        }
        private int mType = 0;
        public int Type
        {
            get
            {
                return mType;
            }
            set
            {
                mType = value;
                OnPropertiesChanged();
            }
        }

        #endregion

        #region Event Handlers
        #endregion

        #region Functions

        public void Init()
        {
            Image lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TLookupCombo04.Button.png"));
            ImageList lImageList = new ImageList();

            lImageList.Images.Add(lImage);
            AppearanceReadOnly.Options.UseBackColor = false;
            NullText = "";
            AllowNullInput = DefaultBoolean.True;
            TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.Standard;
            View.OptionsView.ShowAutoFilterRow = true;
            Buttons[0].Kind = DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph;
            Buttons[0].Image = lImage;
        }
        public void BindList()
        {
            DataView lDv = null;
            bool lIsReplace = false;
            if (NormalMode)
            {
                #region Normal Mode
                if (mBOID != null && mBOID != "")
                {
                    // this is to test instant update
                    //if (OwnerEdit != null)
                    //{
                    //    OwnerEdit.DataBindings[0].DataSourceUpdateMode = DataSourceUpdateMode.OnPropertyChanged;
                    //}
                    lDv = new DataView();
                    lDv.Table = BO.TSingletons.LookUpListProxy.GetList(mBOID);
                    if (lDv.Table != null)
                    {
                        //#check!
                        if (mType == 2)
                        {
                            if (BndCol == 1)
                            {
                                ValueMember = lDv.Table.Columns[2].ColumnName;
                            }
                            else
                            {
                                ValueMember = lDv.Table.Columns[BndCol].ColumnName;
                            }
                            DisplayMember = lDv.Table.Columns[2].ColumnName;
                        }
                        else
                        {
                            ValueMember = lDv.Table.Columns[BndCol].ColumnName;
                            DisplayMember = lDv.Table.Columns[1].ColumnName;
                        }
                        DataSource = lDv;

                    }
                }
                #endregion
            }
            else
            {
                #region Normal Mode
                TLookUpList lLookUpList = new TLookUpList();
                TRowVersion lRowVersion = new TRowVersion();

                lLookUpList.CnnStr = CnnStr;
                lRowVersion.Val = 0;
                lDv = new DataView();
                lDv.Table = lLookUpList.GetList(BOT01.Dr["BOT001ID"].ToString(), lRowVersion, ref lIsReplace);
                if (lDv.Table != null)
                {
                    //#check!
                    if (mType == 2)
                    {
                        if (BndCol == 1)
                        {
                            ValueMember = lDv.Table.Columns[2].ColumnName;
                        }
                        else
                        {
                            ValueMember = lDv.Table.Columns[BndCol].ColumnName;
                        }
                        DisplayMember = lDv.Table.Columns[2].ColumnName;
                    }
                    else
                    {
                        ValueMember = lDv.Table.Columns[BndCol].ColumnName;
                        DisplayMember = lDv.Table.Columns[1].ColumnName;
                    }
                    DataSource = lDv;

                }
                #endregion
            }

            InitColumns();

        }
        public void InitColumns()
        {
            int lColumnCount = 0;
            double[] lColWidths = new double[10];
            int lListWidth = 0;


            if (NormalMode)
            {
                #region Normal Mode
                if (mBOID != null && mBOID != "")
                {
                    lColumnCount = Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnCount;
                    if (mType == 2)
                    {
                        lColWidths[0] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth01);
                        lColWidths[1] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth03);
                        lColWidths[2] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth02);
                        lColWidths[3] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth04);
                        lColWidths[4] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth05);
                        lColWidths[5] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth06);
                        lColWidths[6] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth07);
                        lColWidths[7] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth08);
                        lColWidths[8] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth09);
                        lColWidths[9] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth10);
                        string lTmp = "";
                        lTmp = View.Columns[1].FieldName;
                        View.Columns[1].FieldName = View.Columns[2].FieldName;
                        View.Columns[2].FieldName = lTmp;
                        lTmp = View.Columns[1].Caption;
                        View.Columns[1].Caption = View.Columns[2].Caption;
                        View.Columns[2].Caption = lTmp;
                    }
                    else //default
                    {
                        lColWidths[0] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth01);
                        lColWidths[1] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth02);
                        lColWidths[2] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth03);
                        lColWidths[3] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth04);
                        lColWidths[4] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth05);
                        lColWidths[5] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth06);
                        lColWidths[6] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth07);
                        lColWidths[7] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth08);
                        lColWidths[8] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth09);
                        lColWidths[9] = double.Parse(Innotelli.BO.TSingletons.SPrpsBOT01s[mBOID].ColumnWidth10);
                    }
                    //lListWidth = double.Parse(mSPrpsBOT01.ListWidth);

                    View.OptionsView.ColumnAutoWidth = false;
                    //PopupFormMinSize = new Size((int)(lListWidth * TGC.PixelPerCm), 0);
                    for (int i = 0; i < View.Columns.Count; i++)
                    {
                        if (i < lColumnCount)
                        {
                            if (lColWidths[i] != 0)
                            {
                                View.Columns[i].Width = (int)(lColWidths[i] * TGC.PixelPerCm);
                                lListWidth += View.Columns[i].Width;
                            }
                            else
                            {
                                View.Columns[i].Width = 0;
                                View.Columns[i].Visible = false;
                            }
                        }
                        else
                        {
                            View.Columns[i].Width = 0;
                            View.Columns[i].Visible = false;
                        }
                    }
                    PopupFormMinSize = new Size(lListWidth + 36, 0);
                }
                #endregion
            }
            else
            {
                #region Non Normal Mode
                lColumnCount = int.Parse(BOT01.Dr["ColumnCount"].ToString());
                if (mType == 2)
                {
                    lColWidths[0] = double.Parse(BOT01.Dr["ColumnWidth01"].ToString());
                    lColWidths[1] = double.Parse(BOT01.Dr["ColumnWidth03"].ToString());
                    lColWidths[2] = double.Parse(BOT01.Dr["ColumnWidth02"].ToString());
                    lColWidths[3] = double.Parse(BOT01.Dr["ColumnWidth04"].ToString());
                    lColWidths[4] = double.Parse(BOT01.Dr["ColumnWidth05"].ToString());
                    lColWidths[5] = double.Parse(BOT01.Dr["ColumnWidth06"].ToString());
                    lColWidths[6] = double.Parse(BOT01.Dr["ColumnWidth07"].ToString());
                    lColWidths[7] = double.Parse(BOT01.Dr["ColumnWidth08"].ToString());
                    lColWidths[8] = double.Parse(BOT01.Dr["ColumnWidth09"].ToString());
                    lColWidths[9] = double.Parse(BOT01.Dr["ColumnWidth10"].ToString());
                    string lTmp = "";
                    lTmp = View.Columns[1].FieldName;
                    View.Columns[1].FieldName = View.Columns[2].FieldName;
                    View.Columns[2].FieldName = lTmp;
                    lTmp = View.Columns[1].Caption;
                    View.Columns[1].Caption = View.Columns[2].Caption;
                    View.Columns[2].Caption = lTmp;
                }
                else //default
                {
                    lColWidths[0] = double.Parse(BOT01.Dr["ColumnWidth01"].ToString());
                    lColWidths[1] = double.Parse(BOT01.Dr["ColumnWidth02"].ToString());
                    lColWidths[2] = double.Parse(BOT01.Dr["ColumnWidth03"].ToString());
                    lColWidths[3] = double.Parse(BOT01.Dr["ColumnWidth04"].ToString());
                    lColWidths[4] = double.Parse(BOT01.Dr["ColumnWidth05"].ToString());
                    lColWidths[5] = double.Parse(BOT01.Dr["ColumnWidth06"].ToString());
                    lColWidths[6] = double.Parse(BOT01.Dr["ColumnWidth07"].ToString());
                    lColWidths[7] = double.Parse(BOT01.Dr["ColumnWidth08"].ToString());
                    lColWidths[8] = double.Parse(BOT01.Dr["ColumnWidth09"].ToString());
                    lColWidths[9] = double.Parse(BOT01.Dr["ColumnWidth10"].ToString());
                }
                //lListWidth = double.Parse(BOT01.Dr["ListWidth);

                View.OptionsView.ColumnAutoWidth = false;
                //PopupFormMinSize = new Size((int)(lListWidth * TGC.PixelPerCm), 0);
                for (int i = 0; i < View.Columns.Count; i++)
                {
                    if (i < lColumnCount)
                    {
                        if (lColWidths[i] != 0)
                        {
                            View.Columns[i].Width = (int)(lColWidths[i] * TGC.PixelPerCm);
                            lListWidth += View.Columns[i].Width;
                        }
                        else
                        {
                            View.Columns[i].Width = 0;
                            View.Columns[i].Visible = false;
                        }
                    }
                    else
                    {
                        View.Columns[i].Width = 0;
                        View.Columns[i].Visible = false;
                    }
                }
                PopupFormMinSize = new Size(lListWidth + 36, 0);
                #endregion
            }
        }

        #endregion

        
        
        
    }

    public class TLookupCombo04 : GridLookUpEdit
    {
        #region Enums
        #endregion

        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static TLookupCombo04() { RepositoryItemLookupCombo04.RegisterLookupCombo04(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemLookupCombo04.LookupCombo04Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemLookupCombo04 Properties
        {
            get { return base.Properties as RepositoryItemLookupCombo04; }
        }

        #endregion

        #region Members
        #endregion

        #region Constructors
        

        //Initialize the new instance
        public TLookupCombo04()
        {
            AssignEventHandlers();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(15+20, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        
        #endregion

        #region Event Handlers
        #endregion

        #region Functions

        private void AssignEventHandlers()
        {
            Closed += TLookupCombo04_Closed;
            //EditValueChanging += TLookupCombo04_EditValueChanging;
            //EditValueChanged += TLookupCombo04_EditValueChanged;
            //Validating += TLookupCombo04_Validating;
            //Validated += TLookupCombo04_Validated;
        }
        private void TLookupCombo04_Closed(object sender, DevExpress.XtraEditors.Controls.ClosedEventArgs e)
        {
            if (EditValue != OldEditValue)
            {
                DoValidate();
            }
        }
        private void TLookupCombo04_EditValueChanging(object sender, DevExpress.XtraEditors.Controls.ChangingEventArgs e)
        {
        }
        private void TLookupCombo04_EditValueChanged(object sender, EventArgs e)
        {
        }
        private void TLookupCombo04_Validating(object sender, CancelEventArgs e)
        {
        }
        private void TLookupCombo04_Validated(object sender, EventArgs e)
        {
        }
        protected override void UpdateMenu()
        {
            base.UpdateMenu();
            bool lIsEditValueExisted = (!TNull.IsValueNull(EditValue) && EditValue.ToString() != "");
            Menu.Items[0].Enabled = lIsEditValueExisted;
            Menu.Items[1].Enabled = lIsEditValueExisted;
        }
        protected override DevExpress.Utils.Menu.DXPopupMenu CreateMenu()
        {
            DXPopupMenu lRtrnVal = null;
            bool lIsEditValueExisted = (!TNull.IsValueNull(EditValue) && EditValue.ToString() != "");
            Image lOpenDetailImage = Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TLookupCombo04.OpenDetail.png"));
            Image lAdvSearchImage = Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TLookupCombo04.AdvSearch.png"));


                lRtrnVal = base.CreateMenu();
                lRtrnVal.Items[0].BeginGroup = true;
                DXMenuItem lOpenDetailItem = new DXMenuItem("Open Details", OpenDetailItem_Click, lOpenDetailImage);
                DXMenuItem lAdvSearchItem = new DXMenuItem("Advanced Search", AdvSearchItem_Click, lAdvSearchImage);
                lOpenDetailItem.Enabled = lIsEditValueExisted;
                lAdvSearchItem.Enabled = lIsEditValueExisted;
                lRtrnVal.Items.Insert(0, lOpenDetailItem);
                lRtrnVal.Items.Insert(1, lAdvSearchItem);

            
            return lRtrnVal;
        }
        private void OpenDetailItem_Click(object sender, EventArgs e)
        {
            TForm02 lForm02 = null;
            string lPK = "";


                if (!TNull.IsValueNull(EditValue))
                {
                    lPK = EditValue.ToString();
                    if (lPK != "")
                    {
                        lForm02 = TSingletons.Form02Pool.GetForm(Innotelli.BO.TSingletons.SPrpsBOT01s[Properties.BOID].DefaultForm02Name);
                        lForm02.LoadByPK(lPK);
                        lForm02.Visible = true;
                    }
                }

        }
        private void AdvSearchItem_Click(object sender, EventArgs e)
        {
            //TForm04 lForm04 = new TForm04();
            //lForm04.Form02FullName = "BackOffice.UI." + "TF02" + Properties.BOID.Substring(4);
            //lForm04.BOID = Properties.BOID;
            ////lForm04.MainContainer = (Form)this.Parent.Parent;
            //lForm04.Show();
            string lEditValue = TForm04.ShowAndGetSelectedPK(Properties.BOID, "", false);
            if (lEditValue != null)
            {
                EditValue = lEditValue;
                DoValidate();
            }
        }
        #endregion
    }
}
