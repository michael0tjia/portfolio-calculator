using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.ViewInfo;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterMemoBox01")]
    public class RepositoryItemMemoBox01 : RepositoryItemMemoEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemMemoBox01() { RegisterMemoBox01(); }

        //The unique name for the custom editor
        public const string MemoBox01Name = "TMemoBox01";

        //Return the unique name
        public override string EditorTypeName { get { return MemoBox01Name; } }

        //Register the editor
        public static void RegisterMemoBox01()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.MemoBox01.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(MemoBox01Name,
              typeof(TMemoBox01), typeof(RepositoryItemMemoBox01),
              typeof(MemoEditViewInfo), new MemoEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemMemoBox01 source = item as RepositoryItemMemoBox01;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public RepositoryItemMemoBox01()
        {
        }
        #endregion

        #region Properties
        
        private bool mIsLocked = false;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                ReadOnly = value;
                if (value)
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                }
                else
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
                }
                if (OwnerEdit != null)
                {
                    OwnerEdit.TabStop = !value;
                }
                mIsLocked = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        DSFormMode mDSFormMode = DSFormMode.DSEditable;
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        ReadOnly = true;
                        break;
                    case DSFormMode.DSEditable:
                        ReadOnly = false;
                        break;
                    case DSFormMode.DSInsert:
                        ReadOnly = false;
                        break;
                }
                mDSFormMode = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Init()
        {
            AppearanceReadOnly.Options.UseBackColor = false;
        }
        #endregion  
    }

    public class TMemoBox01 : MemoEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TMemoBox01() { RepositoryItemMemoBox01.RegisterMemoBox01(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemMemoBox01.MemoBox01Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemMemoBox01 Properties
        {
            get { return base.Properties as RepositoryItemMemoBox01; }
        }
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TMemoBox01()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMinimumSize = new Size(50, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(200, 39);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }        
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}
