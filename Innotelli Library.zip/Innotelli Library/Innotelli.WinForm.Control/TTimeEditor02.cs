using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using System;
using DevExpress.Utils;
using Innotelli.Utilities;
using Innotelli.Db;

namespace Innotelli.WinForm.Control
{

    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterTimeEditor02")]
    public class RepositoryItemTimeEditor02 : RepositoryItemTimeEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemTimeEditor02() { RegisterTimeEditor02(); }

        //The unique name for the custom editor
        public const string TimeEditor02Name = "TTimeEditor02";

        //Return the unique name
        public override string EditorTypeName { get { return TimeEditor02Name; } }

        //Register the editor
        public static void RegisterTimeEditor02()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.TimeEditor02.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(TimeEditor02Name,
              typeof(TTimeEditor02), typeof(RepositoryItemTimeEditor02),
              typeof(BaseSpinEditViewInfo), new ButtonEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemTimeEditor02 source = item as RepositoryItemTimeEditor02;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Members

        private bool mIsLocked = false;
        DSFormMode mDSFormMode = DSFormMode.DSEditable;

        #endregion

        #region Constructors
        public RepositoryItemTimeEditor02()
        {
        }

        #endregion

        #region Properties
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                ReadOnly = value;
                if (value)
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                }
                else
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
                }
                if (OwnerEdit != null)
                {
                    OwnerEdit.TabStop = !value;
                }
                for (int i = 0; i < Buttons.Count; i++)
                {
                    Buttons[i].Enabled = !value;
                }
                mIsLocked = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        ReadOnly = true;
                        break;
                    case DSFormMode.DSEditable:
                        ReadOnly = false;
                        break;
                    case DSFormMode.DSInsert:
                        ReadOnly = false;
                        break;
                }
                for (int i = 0; i < Buttons.Count; i++)
                {
                    Buttons[i].Enabled = !ReadOnly;
                }
                mDSFormMode = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Init()
        {
            AppearanceReadOnly.Options.UseBackColor = false;
            //Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            //new DevExpress.XtraEditors.Controls.EditorButton()});
            DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            DisplayFormat.FormatString = TSettings.TimeFormat;
            EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
            EditFormat.FormatString = TSettings.TimeFormat;
            EditMask = TSettings.TimeFormat;
            Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTime;
            Mask.EditMask = TSettings.TimeFormat;
            //Mask.UseMaskAsDisplayFormat = ((bool)(resources.GetObject("RepositoryItemTimeEditor02.Mask.UseMaskAsDisplayFormat")));
        }

        public void AddButton()
        {
            this.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
        }
        #endregion
    }


    public class TTimeEditor02 : TimeEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TTimeEditor02() { RepositoryItemTimeEditor02.RegisterTimeEditor02(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemTimeEditor02.TimeEditor02Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemTimeEditor02 Properties
        {
            get { return base.Properties as RepositoryItemTimeEditor02; }
        }
        #endregion

        #region Members
        private string mFormat = TSettings.TimeFormat;
        #endregion

        #region Constructors
        public TTimeEditor02()
        {
            Init();
        }
        #endregion

        #region Properties
        [Bindable(true),
        Category("Behavior"),
        DefaultValue("hh:mm tt"),
        Description("Indicates the time format."),
        Localizable(true)]
        public string Format
        {
            get
            {
                return mFormat;
            }
            set
            {
                mFormat = value;
            }
        }
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(60+20, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(100, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }

        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            EditValue = null;
            Margin = new System.Windows.Forms.Padding(0);
            Properties.NullText = string.Empty;
            Properties.AllowNullInput = DefaultBoolean.True;
        }
        #endregion
    }
}
