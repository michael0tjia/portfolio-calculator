using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using Innotelli.Post;

namespace Innotelli.WinForm.Control
{
    public partial class TForm12 : TForm02
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TForm12()
        {
            InitializeComponent();
        }
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        private void bbi01PostAndUnPost_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e)
        {

                if ((bool)BOT01.Dr["Posted"])
                {
                    DialogResult = TMessageBox.AskQuestion(Innotelli.Utilities.TSingletons.StrResx.GetStr(98), MessageBoxButtons.YesNo,MessageBoxDefaultButton.Button1);
                    if (DialogResult == DialogResult.Yes)
                    {
                        UnPost();
                    }
                }
                else
                {
                    DialogResult = TMessageBox.AskQuestion(Innotelli.Utilities.TSingletons.StrResx.GetStr(99), MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button1); 
                    if (DialogResult == DialogResult.Yes)
                    {
                        Post();
                    }
                }

        }  
        #endregion

        #region Functions
        protected override void InitImageCollection()
        {
            Image lImage = null;

            base.InitImageCollection();
            lImage = (Bitmap)Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TForm02.PostAndUnPost.png"));
            ImageCollection.AddImage(lImage);
            
        }
        protected virtual bool Post()
        {
            TActionProcessor lActionProcessor = new TActionProcessor();            
            string lB02ClassFullName = BOT01.ClassFullName.Replace(".TB01", ".TB02");
            int lPostResult = -1;

            lPostResult = lActionProcessor.DocPost(lB02ClassFullName, BOT01.PrmyKey, "Post");
            if (lPostResult == 1)
            {
                Reload();
            }
            return (lPostResult == 1);
        }
        protected virtual bool UnPost()
        {
            TActionProcessor lActionProcessor = new TActionProcessor();
            string lB02ClassFullName = BOT01.ClassFullName.Replace(".TB01", ".TB02");
            int lPostResult = -1;

            lPostResult = lActionProcessor.DocPost(lB02ClassFullName, BOT01.PrmyKey, "UnPost");
            if (lPostResult == 1)
            {
                Reload();
            }
            return (lPostResult == 1);
        }

        public override void DSUpdateFormState()
        {
            base.DSUpdateFormState();
            bbi01PostAndUnPost.Enabled = (DsMode != DSFormMode.DSInsert) && (!BOT01.IsDirty);

                if ((bool)BOT01.Dr["Posted"])
                {
                    bbi01PostAndUnPost.Caption = Innotelli.Utilities.TSingletons.StrResx.GetStr(128);
                    //bsiPostStatus.Caption = "Posted";
                    beiPostStatus.EditValue = Innotelli.Utilities.TSingletons.StrResx.GetStr(134);
                }
                else
                {
                    bbi01PostAndUnPost.Caption = Innotelli.Utilities.TSingletons.StrResx.GetStr(129);
                    //bsiPostStatus.Caption = "UnPosted";
                    beiPostStatus.EditValue = Innotelli.Utilities.TSingletons.StrResx.GetStr(128);
                }

        }
        #endregion
    }
}