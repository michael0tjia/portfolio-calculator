using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.Data;
using DevExpress.Utils.Menu;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraGrid;
using DevExpress.XtraGrid.Columns;
using DevExpress.XtraGrid.Registrator;
using DevExpress.XtraGrid.Views.BandedGrid;
using DevExpress.XtraGrid.Views.BandedGrid.Handler;
using DevExpress.XtraGrid.Views.BandedGrid.ViewInfo;
using DevExpress.XtraGrid.Views.Base;
using DevExpress.XtraGrid.Views.Base.Handler;
using DevExpress.XtraGrid.Views.Base.ViewInfo;
using DevExpress.XtraGrid.Views.Grid;
using DevExpress.XtraGrid.Views.Grid.Handler;
using DevExpress.XtraGrid.Views.Grid.ViewInfo;
using Innotelli.BO;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    #region Grid Class
    public class TDataGrid02 : GridControl
    {
        #region Members
        private bool mEditable = true;  //TODO: remove
        private bool mHasOpenDetailColumn = false; //TODO: rename
        private bool mHasAddNewHdrBtn = false;  //TODO: rename
        private bool mIsLocked = false; //TODO: rename
        private ColumnView mGv = null;
        private DSFormMode mDSFormMode = DSFormMode.DSEditable;
        private string mMainViewTypeName = string.Empty;
        private TBOT01 mBOT01 = null;
        private TGridView02 mGridView02 = null;
        private TBandedGridView02 mBandedGridView02 = null;
        private TAdvBandedGridView02 mAdvBandedGridView02 = null;
        private DevExpress.Utils.ImageCollection mImageCollection = new DevExpress.Utils.ImageCollection();
        #endregion

        #region Constructors
        public TDataGrid02()
        {
            InitImageCollection();
            AllowDrop = true;
        }
        #endregion

        #region Properties
        public bool HasOpnDtlCol
        {
            get
            {
                return mHasOpenDetailColumn;
            }
            set
            {
                mHasOpenDetailColumn = value;
            }
        }
        public bool HasAddNewHdrBtn
        {
            get
            {
                return mHasAddNewHdrBtn;
            }
            set
            {
                mHasAddNewHdrBtn = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public TBOT01 BOT01
        {
            get
            {
                return mBOT01;
            }
            set
            {
                mBOT01 = value;
            }
        }
        // #check!
        // don't know what it is
        public bool Editable
        {
            get
            {
                return mEditable;
            }
            set
            {
                mEditable = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                NewItemRowPosition lNewItemRowPosition = NewItemRowPosition.Bottom;

                if (value)
                {
                    lNewItemRowPosition = NewItemRowPosition.None;
                }
                switch (mMainViewTypeName)
                {
                    case "TGridView02":
                        mGridView02.OptionsView.NewItemRowPosition = lNewItemRowPosition;
                        break;
                    case "TBandedGridView02":
                        mBandedGridView02.OptionsView.NewItemRowPosition = lNewItemRowPosition;
                        break;
                    case "TAdvBandedGridView02":
                        mAdvBandedGridView02.OptionsView.NewItemRowPosition = lNewItemRowPosition;
                        break;
                }

                SetAllColumnsIsLockedVal(value);
                this.TabStop = !value;
                mIsLocked = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                //TODO: No Good. Michael Follow
                NewItemRowPosition lNewItemRowPosition = NewItemRowPosition.None;

                mDSFormMode = value;

                if (!BOT01.BODataRight.AllowEdit || !BOT01.UserDataRight.AllowEdit)
                {
                    mDSFormMode = DSFormMode.DSBrowse;
                }
                if (mDSFormMode != DSFormMode.DSBrowse && BOT01.BODataRight.AllowAdd && BOT01.UserDataRight.AllowAdd)
                {
                    lNewItemRowPosition = NewItemRowPosition.Bottom;
                }
                switch (mMainViewTypeName)
                {
                    case "TGridView02":
                        mGridView02.OptionsView.NewItemRowPosition = lNewItemRowPosition;
                        break;
                    case "TBandedGridView02":
                        mBandedGridView02.OptionsView.NewItemRowPosition = lNewItemRowPosition;
                        break;
                    case "TAdvBandedGridView02":
                        mAdvBandedGridView02.OptionsView.NewItemRowPosition = lNewItemRowPosition;
                        break;
                }
                SetAllColumnsDSFormModeVal(mDSFormMode);
                SetAllColumnsReadOnlyVal();
            }
        }

        #region Parent and Child Form
        private Form mParentForm;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Form ParentForm
        {
            get
            {
                return mParentForm;
            }
            set
            {
                mParentForm = value;
            }
        }
        private Dictionary<TDbRowID, TForm02> mChildForm02s = new Dictionary<TDbRowID, TForm02>();
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public Dictionary<TDbRowID, TForm02> ChildForm02s
        {
            get
            {
                return mChildForm02s;
            }
        }
        #endregion

        #endregion

        #region Event Handlers
        //TODO: Try to group into Row moving related functions
        #region Drag and Drop
        private void TDataGrid02_DragDrop(object sender, System.Windows.Forms.DragEventArgs e)
        {
            GridControl grid = sender as GridControl;
            GridView view = grid.MainView as GridView;
            GridHitInfo downHitInfo = e.Data.GetData(typeof(GridHitInfo)) as GridHitInfo;
            GridHitInfo hitInfo = view.CalcHitInfo(grid.PointToClient(new Point(e.X, e.Y)));
            int sourceRow = downHitInfo.RowHandle;
            int targetRow = hitInfo.RowHandle;
            MoveRow(sourceRow, targetRow);
        }
        private void TDataGrid02_DragOver(object sender, System.Windows.Forms.DragEventArgs e)
        {
            int lAutoScroll = 0;

            e.Effect = DragDropEffects.None;

            GridHitInfo downHitInfo = e.Data.GetData(typeof(GridHitInfo)) as GridHitInfo;
            if (downHitInfo != null)
            {
                GridControl grid = sender as GridControl;
                GridView view = grid.MainView as GridView;
                Point pt = grid.PointToClient(new Point(e.X, e.Y));
                GridHitInfo hitInfo = view.CalcHitInfo(pt);
                if (hitInfo.HitTest == GridHitTest.RowCell)
                {
                    GridViewInfo gvi = grid.DefaultView.GetViewInfo() as GridViewInfo;
                    if (gvi.RowsLoadInfo.TopVisibleRowIndex == hitInfo.RowHandle && hitInfo.InRow)
                    {
                        lAutoScroll = -1;
                        return;
                    }
                    int max_vi = -1;
                    int max_rh = -1;
                    int pre_max_rh = -1;
                    for (int i = 0; i < gvi.RowsLoadInfo.ResultRows.Count; i++)
                    {
                        if (max_vi < gvi.RowsLoadInfo.ResultRows[i].VisibleIndex)
                        {
                            pre_max_rh = max_rh;
                            max_rh = gvi.RowsLoadInfo.ResultRows[i].RowHandle;
                            max_vi = gvi.RowsLoadInfo.ResultRows[i].VisibleIndex;
                        }
                    }
                    if (pre_max_rh <= hitInfo.RowHandle && hitInfo.InRow)
                    {
                        lAutoScroll = 1;
                        return;
                    }
                }
                if (hitInfo.HitTest == GridHitTest.VScrollBar)
                {
                    Rectangle scrollrect = (view.GetViewInfo() as GridViewInfo).ViewRects.Scroll;
                    lAutoScroll = ((pt.Y - scrollrect.Top) < (scrollrect.Bottom - pt.Y)) ? -1 : 1;
                }
                if (hitInfo.InRow && hitInfo.RowHandle != downHitInfo.RowHandle)
                    e.Effect = DragDropEffects.Move;
            }
        }
        #endregion
        //TODO: Try to group into Row moving related functions    
        private void TDataGrid02_KeyDown(object sender, KeyEventArgs e)
        {
            //int row;
            string lItemNumberFieldName = BOT01.SPrps.SPrpsBOT01Flds.ItemNumberFieldName;
            GridView view = (GridView)this.MainView;
            if (view.FocusedRowHandle >= 0 && System.Windows.Forms.Control.ModifierKeys == Keys.Control && !string.IsNullOrEmpty(lItemNumberFieldName))
            {
                if (e.KeyCode == Keys.Up)
                {
                    view.GridControl.Focus();
                    int index = view.FocusedRowHandle;
                    if (index <= 0) return;

                    DataRow row1 = view.GetDataRow(index);
                    DataRow row2 = view.GetDataRow(index - 1);
                    object val1 = row1[lItemNumberFieldName];
                    object val2 = row2[lItemNumberFieldName];
                    row1[lItemNumberFieldName] = val2;
                    row2[lItemNumberFieldName] = val1;
                    view.MoveNext();
                    //e.Handled = true;
                }
                else if (e.KeyCode == Keys.Down)
                {
                    view.GridControl.Focus();
                    int index = view.FocusedRowHandle;
                    if (index >= view.DataRowCount - 1) return;

                    DataRow row1 = view.GetDataRow(index);
                    DataRow row2 = view.GetDataRow(index + 1);
                    object val1 = row1[lItemNumberFieldName];
                    object val2 = row2[lItemNumberFieldName];
                    row1[lItemNumberFieldName] = val2;
                    row2[lItemNumberFieldName] = val1;
                    view.MovePrev();
                    //e.Handled = true;
                }

            }
        }
        //TODO: Change to KeyDown and move to delete function
        private void TDataGrid02_KeyUp(object sender, KeyEventArgs e)
        {
            GridView lGv = (GridView)this.MainView;
            if (System.Windows.Forms.Control.ModifierKeys == Keys.Control && e.KeyCode == Keys.Delete && lGv.State == GridState.Normal &&
                this.BOT01.DataRight.AllowDelete && this.DSFormMode != DSFormMode.DSBrowse)
            {
                if (lGv.FocusedRowHandle >= 0)
                {
                    if (TMessageBox.AskQuestion(Innotelli.Utilities.TSingletons.StrResx.GetStr(89), MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                    {
                        lGv.DeleteRow(lGv.FocusedRowHandle);
                        e.Handled = true;
                    }
                }
            }
            if (System.Windows.Forms.Control.ModifierKeys == Keys.Control && e.KeyCode == Keys.Insert && lGv.State == GridState.Normal &&
                this.BOT01.DataRight.AllowDelete && this.DSFormMode != DSFormMode.DSBrowse)
            {
                AddNewRow();
                e.Handled = true;
            }
        }
        private void CheckBox_ColumnEdit_EditValueChanged(object sender, System.EventArgs e)
        {
            ColumnView lGv = (ColumnView)MainView;
            lGv.PostEditor();
        }

        #region Header Add Button
        private void DefaultView_MouseUp(object sender, MouseEventArgs e)
        {
            Point lPoint = DefaultView.GridControl.PointToClient(MousePosition);
            GridHitInfo lGridHitInfo = ((GridView)DefaultView).CalcHitInfo(lPoint);

            if (HasAddNewHdrBtn && lGridHitInfo.HitTest == GridHitTest.Column && lGridHitInfo.InColumnPanel && lGridHitInfo.Column.ColumnHandle == 0)
            {
                OnAddHeaderClick();
            }
        }
        #endregion

        #endregion

        #region Functions

        #region DevExpress Required Part
        protected override BaseView CreateDefaultView()
        {
            return CreateView("TGridView02");
        }
        protected override void RegisterAvailableViewsCore(InfoCollection collection)
        {
            base.RegisterAvailableViewsCore(collection);
            collection.Add(new TGridViewInfoRegistrator02());
            collection.Add(new TBandedGridViewInfoRegistrator02());
            collection.Add(new TAdvBandedGridViewInfoRegistrator02());
        }
        #endregion

        #region Initialization
        public void Init()
        {
            if (Utilities.TGC.IsRunTime)
            {
                this.DragOver += new DragEventHandler(TDataGrid02_DragOver);
                this.DragDrop += new DragEventHandler(TDataGrid02_DragDrop);
                this.KeyDown += new KeyEventHandler(TDataGrid02_KeyDown);
                //TGridHandler02 lGridHandler02 = new TGridHandler02((GridView)this.DefaultView);
                this.KeyUp += new KeyEventHandler(TDataGrid02_KeyUp);

                mGv = (ColumnView)MainView;
                mGv.OptionsSelection.MultiSelect = false;
                mMainViewTypeName = MainView.GetType().Name;

                switch (mMainViewTypeName)
                {
                    case "TGridView02":
                        mGridView02 = (TGridView02)MainView;
                        mGridView02.Init();
                        break;
                    case "TBandedGridView02":
                        mBandedGridView02 = (TBandedGridView02)MainView;
                        mBandedGridView02.Init();
                        break;
                    case "TAdvBandedGridView02":
                        mAdvBandedGridView02 = (TAdvBandedGridView02)MainView;
                        mAdvBandedGridView02.Init();
                        break;
                }
                SetAllColumnsReadOnlyVal();
                SetColumnFormat();
                AssignInPlaceEditors();
            }
            //LoadLayout();

        }
        protected virtual void InitImageCollection()
        {
            Image lImage = null;

            lImage = Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TDataGrid02.AddRow.png"));
            mImageCollection.AddImage(lImage);

        }
        #endregion

        #region Row Moving
        private void MoveRow(int sourceRow, int targetRow)
        {
            string lItemNumberFieldName = BOT01.SPrps.SPrpsBOT01Flds.ItemNumberFieldName;
            if (!string.IsNullOrEmpty(lItemNumberFieldName))
            {
                List<DataRow> view = new List<DataRow>(((GridView)MainView).RowCount);
                DataRow tmp = null;
                if (sourceRow == targetRow || sourceRow == targetRow + 1) return;
                if (sourceRow < targetRow) // Move Down
                {

                    for (int i = 0; i < this.DefaultView.RowCount; i++)
                    {
                        if (i != sourceRow && i != targetRow + 1)
                        {
                            view.Add(((GridView)MainView).GetDataRow(i));
                        }
                        else if (i == sourceRow)
                        {
                            tmp = ((GridView)MainView).GetDataRow(i);
                        }
                        else if (i == targetRow + 1)
                        {
                            view.Add(tmp);
                            view.Add(((GridView)MainView).GetDataRow(i + 1));
                        }
                    }
                    for (int i = 0; i < this.DefaultView.RowCount; i++)
                    {
                        view[i][lItemNumberFieldName] = i + 1;
                    }
                }
                else // Move Up
                {
                    for (int i = 0; i < this.DefaultView.RowCount; i++)
                    {
                        if (i != sourceRow && i != targetRow + 1)
                        {
                            view.Add(((GridView)MainView).GetDataRow(i));
                        }
                        else if (i == targetRow + 1)
                        {
                            view.Add(((GridView)MainView).GetDataRow(sourceRow));
                            view.Add(((GridView)MainView).GetDataRow(targetRow + 1));
                        }
                    }
                    for (int i = 0; i < this.DefaultView.RowCount; i++)
                    {
                        view[i][lItemNumberFieldName] = i + 1;
                    }
                }
                view.Clear();
                view = null;
            }
        }
        #endregion

        #region Header Add New Button
        public virtual void OnAddHeaderClick()
        {
            AddNewRow();
        }
        public void AddNewRow()
        {
            TForm02 lForm = null;

            if (!mChildForm02s.ContainsKey("-1"))
            {
                lForm = TSingletons.Form02Pool.GetForm(Innotelli.BO.TSingletons.SPrpsBOT01s[BOT01.BOID].DefaultForm02Name);
                if (lForm != null)
                {
                    mChildForm02s.Add("-1", lForm);
                    lForm.ParentGrid02 = this;
                    if (mParentForm is TForm02)
                    {
                        lForm.BOT01.FK = ((TForm02)mParentForm).BOT01.PrmyKey;
                    }
                    else if (mParentForm is TForm01)
                    {
                        lForm.BOT01.FK = ((TForm01)mParentForm).BOT01.FK;
                    }
                    lForm.AddNew();
                    lForm.DSUpdateFormState();
                    lForm.Show();
                    lForm.Focus();
                    lForm.WindowState = FormWindowState.Normal;
                }
            }
            else
            {
                mChildForm02s["-1"].Focus();
                mChildForm02s["-1"].WindowState = FormWindowState.Normal;
            }
        }
        #endregion

        #region Open Detail Button
        public void SetButton05EnableVal(bool aVal)
        {
            if (mHasOpenDetailColumn)
            {
                ((RepositoryItemButton05)mGv.Columns[Utilities.TGC.PKeyName].ColumnEdit).Buttons[0].Enabled = aVal;
            }
        }
        private void KeyDownOpenDetailHandler(object sender, KeyEventArgs e)
        {
            int i = SearchButton05(RepositoryItems);
            if (i > -1)
            {
                if (System.Windows.Forms.Control.ModifierKeys == Keys.Control && e.KeyCode == Keys.Enter && ((TGridView02)(this.DefaultView)).Columns[Utilities.TGC.PKeyName].ColumnEdit.Editable)
                {
                    ((RepositoryItemButton05)RepositoryItems[i]).OpenDetails();
                    //RepositoryItemButton05 lRepositoryItemButton05 = ((RepositoryItemButton05)mGv.Columns[Utilities.TGC.PKeyName].ColumnEdit);
                    //lRepositoryItemButton05.FireButtonClick();
                    e.Handled = true;
                }
            }
        }
        private int SearchButton05(RepositoryItemCollection aItems)
        {
            bool lFound = false;
            int i = 0;
            while (i < aItems.Count)
            {
                if (aItems[i].GetType() == typeof(RepositoryItemButton05))
                {
                    lFound = true;
                    break;
                }
                else
                {
                    i++;
                }
            }
            if (!lFound)
            {
                i = -1;
            }
            return i;
        }
        #endregion

        #region Child Forms
        public void FocusRowByPK(TDbRowID aPK)
        {
            GridView lGv = (GridView)MainView;
            int lRowIndex = -1;

            if (aPK.HasValue)
            {
                for (int i = 0; i < BOT01.DefaultView.Count; i++)
                {
                    if (BOT01.DefaultView[i].Row[Innotelli.Utilities.TGC.PKeyName].ToString() == (string)aPK)
                    {
                        lRowIndex = i;
                        break;
                    }
                }
                if (lRowIndex >= 0 && lRowIndex < BOT01.DefaultView.Count)
                {
                    lGv.FocusedRowHandle = lGv.GetRowHandle(lRowIndex);
                }
            }
            else
            {
                lGv.FocusedRowHandle = GridControl.NewItemRowHandle;
            }

            //for (int i = 0; i < lGv.Row; i++)
            //{

            //}
        }
        public bool AddChildForm(TForm02 aChildForm)
        {
            TDbRowID lHashKey = aChildForm.BOT01.PrmyKey;
            bool lReturnValue = !mChildForm02s.ContainsKey(lHashKey);

            if (lReturnValue)
            {
                aChildForm.BOT01.BODataRight.AllowAdd = false;
                aChildForm.BOT01.NavEnable = false;
                aChildForm.ParentGrid02 = this;
                mChildForm02s.Add(lHashKey, aChildForm);
                // To handle DsMode of TForm01 later on 
                if (ParentForm is TForm02)
                {
                    // Is commented because no addnew is allowed.
                    //aChildForm.BOT01.FK = ((TForm02)ParentForm).BOT01.PrmyKey;
                    ((TForm02)ParentForm).DsMode = DSFormMode.DSBrowse;
                }

            }
            return lReturnValue;
        }
        public bool RemoveChildForm(TForm02 aChildForm)
        {
            TDbRowID lHashKey = aChildForm.BOT01.PrmyKey;
            bool lReturnValue = mChildForm02s.ContainsKey(lHashKey);

            if (!lReturnValue && mChildForm02s.ContainsValue(aChildForm))
            {
                lReturnValue = true;
                lHashKey = "-1";
            }
            if (lReturnValue)
            {
                mChildForm02s.Remove(lHashKey);
                if (mChildForm02s.Count == 0)
                {
                    // To handle DsMode of TForm01 later on 
                    if (ParentForm is TForm02)
                    {
                        ((TForm02)ParentForm).DsMode = DSFormMode.DSEditable;
                    }
                }
            }
            return lReturnValue;
        }
        #endregion

        #region Inplace Editing
        private void SetAllColumnsReadOnlyVal()
        {
            string lFldNm = string.Empty;

            for (int i = 0; i < mGv.Columns.Count; i++)
            {
                lFldNm = mGv.Columns[i].FieldName;
                if (lFldNm != string.Empty)
                {
                    if (mBOT01.SPrps.SPrpsBOT01Flds[lFldNm] != null)
                    {
                        // The else case should be not done. Enforcement of ReadOnly
                        if (mBOT01.SPrps.SPrpsBOT01Flds[lFldNm].IsReadOnly)
                        {
                            mGv.Columns[i].OptionsColumn.ReadOnly = true;
                        }
                    }
                    if (mGv.Columns[i].OptionsColumn.ReadOnly)
                    {
                        //TODO: tab stop = false;
                        mGv.Columns[i].OptionsColumn.AllowFocus = false;
                        mGv.Columns[i].AppearanceCell.BackColor = Color.FromArgb(255, 255, 192);

                    }
                }
            }
        }
        private void SetColumnFormat()
        {
            string lFieldName = string.Empty;
            TSPrpsBOT01Fld lSPrpsBOT01Fld = null;

            for (int i = 0; i < mGv.Columns.Count; i++)
            {
                lFieldName = mGv.Columns[i].FieldName.ToString();
                lSPrpsBOT01Fld = mBOT01.SPrps.SPrpsBOT01Flds[lFieldName];
                if (lSPrpsBOT01Fld != null)
                {
                    switch (lSPrpsBOT01Fld.SimpleDataTypeCat1)
                    {
                        case SimpleDataTypeCat1s.Integer:
                        case SimpleDataTypeCat1s.PreciseReal:
                        case SimpleDataTypeCat1s.UnpreciseReal:
                            #region Numeric Columns

                            #region Negative Value Color Setting
                            StyleFormatCondition lStyleFormatCondition = new StyleFormatCondition();
                            lStyleFormatCondition.Appearance.ForeColor = Color.Red;
                            lStyleFormatCondition.Appearance.Options.UseForeColor = true;
                            lStyleFormatCondition.Appearance.Options.HighPriority = true;
                            lStyleFormatCondition.Column = mGv.Columns[i];
                            lStyleFormatCondition.Condition = FormatConditionEnum.Less;
                            lStyleFormatCondition.Value1 = 0;
                            MainView.FormatConditions.Add(lStyleFormatCondition);
                            #endregion

                            mGv.Columns[i].AppearanceHeader.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
                            mGv.Columns[i].DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
                            mGv.Columns[i].DisplayFormat.FormatString = Innotelli.BO.TSingletons.MetaSimpleDataTypes[lSPrpsBOT01Fld.SimpleDataType].DisplayFormat;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = Innotelli.BO.TSingletons.MetaSimpleDataTypes[lSPrpsBOT01Fld.SimpleDataType].EditFormat;
                            if (mGv.Columns[i].SummaryItem.DisplayFormat == string.Empty)
                            {
                                mGv.Columns[i].SummaryItem.DisplayFormat = "{0:" + Innotelli.BO.TSingletons.MetaSimpleDataTypes[lSPrpsBOT01Fld.SimpleDataType].DisplayFormat + "}";
                            }

                            #endregion
                            break;
                        case SimpleDataTypeCat1s.DateTime:
                            #region DateTime Columns
                            mGv.Columns[i].DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime;
                            mGv.Columns[i].DisplayFormat.FormatString = Innotelli.BO.TSingletons.MetaSimpleDataTypes[lSPrpsBOT01Fld.SimpleDataType].DisplayFormat;
                            mGv.Columns[i].RealColumnEdit.EditFormat.FormatString = Innotelli.BO.TSingletons.MetaSimpleDataTypes[lSPrpsBOT01Fld.SimpleDataType].EditFormat;
                            #endregion
                            break;
                    }
                }
            }
        }
        private void AssignInPlaceEditors()
        {
            int lIndexOfSemiColon = -1;
            int lValLstBndCol = 1;
            string lControlName = string.Empty;
            string lFieldName = string.Empty;
            TSPrpsBOT01Fld lSPrpsBOT01Fld = null;
            string lTag = string.Empty;
            Assembly lAssembly = Assembly.GetExecutingAssembly();


            for (int i = 0; i < mGv.Columns.Count; i++)
            {
                lFieldName = mGv.Columns[i].FieldName;

                if (lFieldName == string.Empty)
                {
                    continue;
                }
                lSPrpsBOT01Fld = mBOT01.SPrps.SPrpsBOT01Flds[lFieldName];

                if (mGv.Columns[i].Tag != null)
                {
                    #region By Tag Specified
                    lTag = mGv.Columns[i].Tag.ToString();
                    lIndexOfSemiColon = lTag.IndexOf(";");
                    if (lIndexOfSemiColon == -1)
                    {
                        lControlName = lTag;
                    }
                    else
                    {
                        lControlName = TStr.Left(lTag, lIndexOfSemiColon);
                    }
                    switch (lControlName)
                    {
                        case "TTextBox08":
                            RepositoryItemTextBox08 lRepositoryItemTextBox08 = new RepositoryItemTextBox08();
                            lRepositoryItemTextBox08.Init();
                            lRepositoryItemTextBox08.BOID = lTag.Substring(lIndexOfSemiColon + 1);
                            RepositoryItems.Add(lRepositoryItemTextBox08);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemTextBox08;
                            mGv.Columns[i].ShowButtonMode = ShowButtonModeEnum.ShowAlways;
                            break;
                        case "TMemoBoxEx01":
                            RepositoryItemMemoBoxEx01 lRepositoryItemMemoBoxEx01 = new RepositoryItemMemoBoxEx01();
                            lRepositoryItemMemoBoxEx01.Init();
                            lRepositoryItemMemoBoxEx01.Buttons[0].Visible = false;
                            RepositoryItems.Add(lRepositoryItemMemoBoxEx01);
                            mGv.Columns[i].ColumnEdit = lRepositoryItemMemoBoxEx01;
                            break;
                        default:
                            break;
                    }
                    #endregion
                }
                else if (lSPrpsBOT01Fld != null && lSPrpsBOT01Fld.SelObjID != string.Empty)
                {                    
                    #region Selection
                    if (mGv.Columns[i].ReadOnly)
                    {
                        RepositoryItemLookupTextBox01 lRepositoryItemLookupTextBox01 = new RepositoryItemLookupTextBox01();
                        lRepositoryItemLookupTextBox01.BndCol = 0;
                        lRepositoryItemLookupTextBox01.Init();
                        lRepositoryItemLookupTextBox01.BOT01 = BOT01;
                        lRepositoryItemLookupTextBox01.BoundColumnName = lFieldName;
                        lRepositoryItemLookupTextBox01.BindList();
                        RepositoryItems.Add(lRepositoryItemLookupTextBox01);
                        mGv.Columns[i].ColumnEdit = lRepositoryItemLookupTextBox01;
                    }
                    else
                    {
                        RepositoryItemLookupCombo02 lRepositoryItemLookupCombo02 = new RepositoryItemLookupCombo02();
                        lRepositoryItemLookupCombo02.BndCol = 0;
                        lRepositoryItemLookupCombo02.Init();
                        lRepositoryItemLookupCombo02.BOT01 = BOT01;
                        lRepositoryItemLookupCombo02.BoundColumnName = lFieldName;
                        lRepositoryItemLookupCombo02.BindList();
                        RepositoryItems.Add(lRepositoryItemLookupCombo02);
                        mGv.Columns[i].ColumnEdit = lRepositoryItemLookupCombo02;
                        mGv.Columns[i].ShowButtonMode = ShowButtonModeEnum.ShowAlways;
                    }
                    #endregion
                }
                else if (lSPrpsBOT01Fld != null && lSPrpsBOT01Fld.slkValLst.HasValue)
                {
                    #region ValueList
                    if (mGv.Columns[i].ReadOnly)
                    {
                        RepositoryItemValueListTextBox01 lRepositoryItemValueListTextBox01 = new RepositoryItemValueListTextBox01();
                        lRepositoryItemValueListTextBox01.BndCol = lValLstBndCol - 1;
                        lRepositoryItemValueListTextBox01.Init(BOT01.BOID);
                        lRepositoryItemValueListTextBox01.BindList(lFieldName);
                        RepositoryItems.Add(lRepositoryItemValueListTextBox01);
                        mGv.Columns[i].ColumnEdit = lRepositoryItemValueListTextBox01;
                    }
                    else
                    {
                        RepositoryItemValueListCombo02 lRepositoryItemValueListCombo02 = new RepositoryItemValueListCombo02();
                        lRepositoryItemValueListCombo02.BndCol = lValLstBndCol - 1;
                        lRepositoryItemValueListCombo02.Init(BOT01.BOID);
                        lRepositoryItemValueListCombo02.BindList(lFieldName);
                        RepositoryItems.Add(lRepositoryItemValueListCombo02);
                        mGv.Columns[i].ColumnEdit = lRepositoryItemValueListCombo02;
                        mGv.Columns[i].ShowButtonMode = ShowButtonModeEnum.ShowAlways;
                    }
                    #endregion
                }
                else if (lSPrpsBOT01Fld != null)
                {
                    #region By Data Type
                    if (mGv.Columns[i].ReadOnly)
                    {
                        #region Read Only Case
                        switch (lSPrpsBOT01Fld.SimpleDataType)
                        {
                            case SimpleDataType.Date:
                                RepositoryItemDateTextBox02 lRepositoryItemDateTextBox02 = new RepositoryItemDateTextBox02();
                                lRepositoryItemDateTextBox02.Init();
                                RepositoryItems.Add(lRepositoryItemDateTextBox02);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemDateTextBox02;
                                break;
                            case SimpleDataType.Time:
                                RepositoryItemTimeTextBox02 lRepositoryItemTimeTextBox02 = new RepositoryItemTimeTextBox02();
                                lRepositoryItemTimeTextBox02.Init();
                                RepositoryItems.Add(lRepositoryItemTimeTextBox02);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemTimeTextBox02;
                                break;
                            case SimpleDataType.Bool:
                                RepositoryItemCheckBox03 lRepositoryItemCheckBox03 = new RepositoryItemCheckBox03();
                                lRepositoryItemCheckBox03.Init();
                                RepositoryItems.Add(lRepositoryItemCheckBox03);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemCheckBox03;
                                break;
                            case SimpleDataType.Currency:
                                RepositoryItemCurrencyTextBox03 lRepositoryItemCurrencyTextBox03 = new RepositoryItemCurrencyTextBox03();
                                lRepositoryItemCurrencyTextBox03.Init();
                                RepositoryItems.Add(lRepositoryItemCurrencyTextBox03);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemCurrencyTextBox03;
                                break;
                            case SimpleDataType.Decimal:
                            case SimpleDataType.Double:
                            case SimpleDataType.Single:
                                RepositoryItemDecimalTextBox03 lRepositoryItemDecimalTextBox03 = new RepositoryItemDecimalTextBox03();
                                lRepositoryItemDecimalTextBox03.Init();
                                RepositoryItems.Add(lRepositoryItemDecimalTextBox03);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemDecimalTextBox03;
                                break;
                            case SimpleDataType.Byte:
                            case SimpleDataType.Short:
                            case SimpleDataType.Int:
                            case SimpleDataType.Long:
                                RepositoryItemIntegerTextBox03 lRepositoryItemIntegerTextBox03 = new RepositoryItemIntegerTextBox03();
                                lRepositoryItemIntegerTextBox03.Init();
                                RepositoryItems.Add(lRepositoryItemIntegerTextBox03);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemIntegerTextBox03;
                                break;
                            case SimpleDataType.NText:
                                RepositoryItemMemoBoxEx01 lRepositoryItemMemoBoxEx01 = new RepositoryItemMemoBoxEx01();
                                lRepositoryItemMemoBoxEx01.Init();
                                lRepositoryItemMemoBoxEx01.Buttons[0].Visible = false;
                                RepositoryItems.Add(lRepositoryItemMemoBoxEx01);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemMemoBoxEx01;
                                break;
                            case SimpleDataType.NVarChar:
                                RepositoryItemTextBox04 lRepositoryItemTextBox04 = new RepositoryItemTextBox04();
                                lRepositoryItemTextBox04.Init(mBOT01);
                                lRepositoryItemTextBox04.BoundColumnName = lFieldName;
                                RepositoryItems.Add(lRepositoryItemTextBox04);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemTextBox04;
                                break;
                            default:
                                break;
                        }
                        #endregion
                    }
                    else
                    {
                        #region Not Read Only Case
                        switch (lSPrpsBOT01Fld.SimpleDataType)
                        {
                            case SimpleDataType.Date:
                                RepositoryItemDateEditor02 lRepositoryItemDateEditor02 = new RepositoryItemDateEditor02();
                                lRepositoryItemDateEditor02.Init();
                                RepositoryItems.Add(lRepositoryItemDateEditor02);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemDateEditor02;
                                break;
                            case SimpleDataType.Time:
                                RepositoryItemTimeTextBox02 lRepositoryItemTimeTextBox02 = new RepositoryItemTimeTextBox02();
                                lRepositoryItemTimeTextBox02.Init();
                                RepositoryItems.Add(lRepositoryItemTimeTextBox02);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemTimeTextBox02;
                                break;
                            case SimpleDataType.Bool:
                                RepositoryItemCheckBox03 lRepositoryItemCheckBox03 = new RepositoryItemCheckBox03();
                                lRepositoryItemCheckBox03.Init();
                                RepositoryItems.Add(lRepositoryItemCheckBox03);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemCheckBox03;
                                mGv.Columns[i].ColumnEdit.EditValueChanged += new EventHandler(CheckBox_ColumnEdit_EditValueChanged);
                                break;
                            case SimpleDataType.Currency:
                                RepositoryItemCurrencyTextBox03 lRepositoryItemCurrencyTextBox03 = new RepositoryItemCurrencyTextBox03();
                                lRepositoryItemCurrencyTextBox03.Init();
                                RepositoryItems.Add(lRepositoryItemCurrencyTextBox03);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemCurrencyTextBox03;
                                break;
                            case SimpleDataType.Decimal:
                            case SimpleDataType.Double:
                            case SimpleDataType.Single:
                                RepositoryItemDecimalTextBox03 lRepositoryItemDecimalTextBox03 = new RepositoryItemDecimalTextBox03();
                                lRepositoryItemDecimalTextBox03.Init();
                                RepositoryItems.Add(lRepositoryItemDecimalTextBox03);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemDecimalTextBox03;
                                break;
                            case SimpleDataType.Byte:
                            case SimpleDataType.Short:
                            case SimpleDataType.Int:
                            case SimpleDataType.Long:
                                RepositoryItemIntegerTextBox03 lRepositoryItemIntegerTextBox03 = new RepositoryItemIntegerTextBox03();
                                lRepositoryItemIntegerTextBox03.Init();
                                RepositoryItems.Add(lRepositoryItemIntegerTextBox03);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemIntegerTextBox03;
                                break;
                            case SimpleDataType.NText:
                                RepositoryItemMemoBoxEx01 lRepositoryItemMemoBoxEx01 = new RepositoryItemMemoBoxEx01();
                                lRepositoryItemMemoBoxEx01.Init();
                                lRepositoryItemMemoBoxEx01.Buttons[0].Visible = false;
                                RepositoryItems.Add(lRepositoryItemMemoBoxEx01);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemMemoBoxEx01;
                                break;
                            case SimpleDataType.NVarChar:
                                RepositoryItemTextBox04 lRepositoryItemTextBox04 = new RepositoryItemTextBox04();
                                lRepositoryItemTextBox04.Init(mBOT01);
                                lRepositoryItemTextBox04.BoundColumnName = lFieldName;
                                RepositoryItems.Add(lRepositoryItemTextBox04);
                                mGv.Columns[i].ColumnEdit = lRepositoryItemTextBox04;
                                break;
                            default:
                                break;
                        }
                        #endregion
                    }
                    #endregion

                }
                if (mGv.Columns[i].ColumnEdit != null)
                {
                    mGv.Columns[i].ColumnEdit.ReadOnly = mGv.Columns[i].ReadOnly;
                }
            }
            mGv.Images = mImageCollection;
            if (mHasOpenDetailColumn)
            {
                GridColumn lOpnDtlCol = mGv.Columns.AddField(Utilities.TGC.PKeyName);
                RepositoryItemButton05 lRepositoryItemButton05 = new RepositoryItemButton05();
                lRepositoryItemButton05.Init();
                lRepositoryItemButton05.BOID = BOT01.BOID;
                lRepositoryItemButton05.BOT01 = BOT01;
                lRepositoryItemButton05.OwnerGrid = this;
                lRepositoryItemButton05.ParentForm = mParentForm;
                RepositoryItems.Add(lRepositoryItemButton05);
                lOpnDtlCol.ColumnEdit = lRepositoryItemButton05;
                lOpnDtlCol.Caption = string.Empty;
                lOpnDtlCol.CustomizationCaption = "Open Details (Button)";
                lOpnDtlCol.Fixed = FixedStyle.Left;
                lOpnDtlCol.MinWidth = 27;
                lOpnDtlCol.Width = 27;
                lOpnDtlCol.ShowButtonMode = ShowButtonModeEnum.ShowAlways;
                lOpnDtlCol.VisibleIndex = 0;
                lOpnDtlCol.OptionsColumn.AllowGroup = DevExpress.Utils.DefaultBoolean.False;
                lOpnDtlCol.OptionsColumn.AllowIncrementalSearch = false;
                lOpnDtlCol.OptionsColumn.AllowMerge = DevExpress.Utils.DefaultBoolean.False;
                lOpnDtlCol.OptionsColumn.AllowMove = false;
                lOpnDtlCol.OptionsColumn.AllowSize = false;
                lOpnDtlCol.OptionsColumn.AllowSort = DevExpress.Utils.DefaultBoolean.False;
                lOpnDtlCol.OptionsColumn.ShowCaption = false;
                lOpnDtlCol.OptionsFilter.AllowAutoFilter = false;
                lOpnDtlCol.OptionsFilter.AllowFilter = false;

                DefaultView.MouseUp += new MouseEventHandler(DefaultView_MouseUp);
                DefaultView.KeyDown += new KeyEventHandler(KeyDownOpenDetailHandler);

                if (mHasAddNewHdrBtn)
                {

                    lOpnDtlCol.AppearanceHeader.Options.UseImage = true;
                    mGv.Images = mImageCollection;
                    lOpnDtlCol.ImageIndex = 0;
                    lOpnDtlCol.ImageAlignment = StringAlignment.Center;
                }
            }
        }
        #endregion

        #region Layout Load and Save
        private void SaveLayout()
        {
            //TGrdLyt02 lGrdLyt02 = null;

            //lGrdLyt02 = new TGrdLyt02();
            //lGrdLyt02.UserPK = "1";
            //lGrdLyt02.SaveLayout(this, true);

        }
        private void LoadLayout()
        {
            //TGrdLyt02 lGrdLyt02 = null;

            //lGrdLyt02 = new TGrdLyt02();
            //lGrdLyt02.UserPK = "1";
            //lGrdLyt02.LoadLayout(this, true);

        }
        #endregion

        #region Control Read Only Setting
        private void SetAllColumnsDSFormModeVal(DSFormMode aDSFormMode)
        {
            RepositoryItem lRepositoryItem = null;
            PropertyInfo lPropertyInfo = null;

            for (int i = 0; i < mGv.Columns.Count; i++)
            {
                // No need to consider "Read Only Data Column"
                if (!mGv.Columns[i].OptionsColumn.ReadOnly && mGv.Columns[i].ColumnEdit != null)
                {
                    // Use reflection
                    lRepositoryItem = mGv.Columns[i].ColumnEdit;
                    lPropertyInfo = lRepositoryItem.GetType().GetProperty("DSFormMode");
                    if (lPropertyInfo != null)
                    {
                        lPropertyInfo.SetValue(lRepositoryItem, aDSFormMode, null);
                    }
                }
            }
        }
        private void SetAllColumnsIsLockedVal(bool aIsLocked)
        {
            RepositoryItem lRepositoryItem = null;
            PropertyInfo lPropertyInfo = null;

            for (int i = 0; i < mGv.Columns.Count; i++)
            {
                if (mGv.Columns[i].ColumnEdit != null)
                {
                    // Use reflection
                    lRepositoryItem = mGv.Columns[i].ColumnEdit;
                    lPropertyInfo = lRepositoryItem.GetType().GetProperty("IsLocked");
                    if (lPropertyInfo != null)
                    {
                        lPropertyInfo.SetValue(lRepositoryItem, aIsLocked, null);
                    }
                }
            }
        }
        #endregion

        #region Others
        public void BindData()
        {
            if (mBOT01 != null)
            {
                DataSource = null;
                DataSource = mBOT01.DefaultView;
            }
        }
        public void EnforceDoValidate()
        {
            MainView.UpdateCurrentRow();
        }
        #endregion

        #endregion
    }
    #endregion

    #region GridView Classes
    public class TGridViewInfoRegistrator02 : GridInfoRegistrator
    {
        #region DevExpress Required Part
        public override string ViewName { get { return "TGridView02"; } }
        public override BaseView CreateView(GridControl grid) { return new TGridView02(grid as GridControl); }
        public override BaseViewInfo CreateViewInfo(BaseView view) { return new TGridViewInfo02(view as TGridView02); }
        public override BaseViewHandler CreateHandler(BaseView view) { return new TGridHandler02(view as TGridView02); }
        #endregion
    }
    public class TGridView02 : GridView
    {
        #region Members
        TDataGrid02 mOwnerGrid = null;
        GridHitInfo downHitInfo = null;
        #endregion

        #region Constructors

        #region DevExpress Required Part
        public TGridView02()
            : this(null)
        {
        }
        public TGridView02(DevExpress.XtraGrid.GridControl grid)
            : base(grid)
        {
            //TODO: Check if this can be moved to Init()
            if (Innotelli.Utilities.TGC.IsRunTime)
            {
                AssignEventHandlers();
            }
        }
        #endregion

        #endregion

        #region Properties

        #region DevExpress Required Part
        protected override string ViewName { get { return "TGridView02"; } }
        #endregion

        #endregion

        #region Event Handlers
        private void TGridView02_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            TBOT01 lBOT01 = null;

            lBOT01 = ((TDataGrid02)GridControl).BOT01;
            if (lBOT01 != null)
            {
                if (e.FocusedRowHandle == GridControl.NewItemRowHandle)
                {
                    lBOT01.CurrentRowIndex = TDataObject.DetachedRowIndex;
                }
                else if (e.FocusedRowHandle != GridControl.InvalidRowHandle)
                {
                    lBOT01.SetCurrentRow(GetDataRow(e.FocusedRowHandle));
                }
            }
        }
        private void TGridView02_KeyDown(object sender, KeyEventArgs e)
        {
        }
        private void TGridView02_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            GridView view = sender as GridView;
            downHitInfo = null;
            GridHitInfo hitInfo = view.CalcHitInfo(new Point(e.X, e.Y));
            if (System.Windows.Forms.Control.ModifierKeys != Keys.None) return;
            if (e.Button == MouseButtons.Left && hitInfo.InRow)
                downHitInfo = hitInfo;
        }
        private void TGridView02_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            GridView view = sender as GridView;
            if (e.Button == MouseButtons.Left && downHitInfo != null)
            {
                Size dragSize = SystemInformation.DragSize;
                Rectangle dragRect = new Rectangle(new Point(downHitInfo.HitPoint.X - dragSize.Width / 2,
                    downHitInfo.HitPoint.Y - dragSize.Height / 2), dragSize);

                if (!dragRect.Contains(new Point(e.X, e.Y)))
                {
                    view.GridControl.DoDragDrop(downHitInfo, DragDropEffects.All);
                    downHitInfo = null;
                }
            }
        }
        private void TGridView02_ShowGridMenu(object sender, GridMenuEventArgs e)
        {
            DXMenuItem lDeleteAllRowsItem = null;
            Image lDeleteAllRowsImage = null;

            //#check!
            // memory leak!
            if (e.MenuType == GridMenuType.User)
            {
                if (e.Menu == null)
                {
                    e.Menu = new DevExpress.XtraGrid.Menu.GridViewMenu(this);
                }
                else
                {
                    e.Menu.Items[0].BeginGroup = true;
                }
                lDeleteAllRowsImage = Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TDataGrid02.DeleteAllRows.png"));
                lDeleteAllRowsItem = new DXMenuItem("Delete All Rows", DeleteAllRowsItem_Click, lDeleteAllRowsImage);
                //#check!
                //TODO: Michael
                lDeleteAllRowsItem.Enabled = (DataSource != null && ((DataView)DataSource).Count != 0 && !mOwnerGrid.BOT01.BOT01ParentChildRel.ParentBO.IsDirty &&
                                                mOwnerGrid.BOT01.DataRight.AllowDelete);
                e.Menu.Items.Insert(0, lDeleteAllRowsItem);
            }
        }
        private void DeleteAllRowsItem_Click(object sender, EventArgs e)
        {
            bool lDeletionSucceeded = false;
            string lPKLst = null;
            string lPrntFrmBsTp = mOwnerGrid.ParentForm.GetType().BaseType.Name;
            if (TMessageBox.AskQuestion(Innotelli.Utilities.TSingletons.StrResx.GetStr(89), MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                for (int i = 0; i < ((DataView)DataSource).Count; i++)
                {
                    lPKLst += ((DataView)DataSource)[i][Utilities.TGC.PKeyName].ToString() + ",";
                }
                lPKLst = TStr.Left(lPKLst, lPKLst.Length - 1);
                lDeletionSucceeded = mOwnerGrid.BOT01.DeleteByPKList(lPKLst);
                switch (lPrntFrmBsTp)
                {
                    case "TForm02":
                        ((TForm02)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm12":
                        ((TForm12)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm01":
                        //((TForm01)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm06":
                        ((TForm06)mOwnerGrid.ParentForm).Reload();
                        break;
                }
                if (lDeletionSucceeded)
                {
                    TMessageBox.ShowInformation(Innotelli.Utilities.TSingletons.StrResx.GetStr(90));
                }
                else
                {
                    TMessageBox.ShowInformation(Innotelli.Utilities.TSingletons.StrResx.GetStr(91));
                }
            }
        }
        #endregion

        #region Functions
        public void Init()
        {
            mOwnerGrid = ((TDataGrid02)GridControl);
            FixedLineWidth = 1;
            //OptionsSelection.EnableAppearanceFocusedCell = false;
            //OptionsSelection.EnableAppearanceFocusedRow = false;
            //OptionsSelection.EnableAppearanceHideSelection = false;
            Appearance.FocusedRow.BackColor = Color.FromArgb(60, 128, 128, 240);
            Appearance.FocusedRow.Options.UseBackColor = true;
            Appearance.SelectedRow.BackColor = Color.FromArgb(30, 128, 128, 240);
            Appearance.SelectedRow.Options.UseBackColor = true;
            OptionsView.NewItemRowPosition = NewItemRowPosition.Bottom;
            OptionsView.ColumnAutoWidth = false;
            OptionsView.ShowGroupPanel = false;
            OptionsCustomization.AllowGroup = true;
            OptionsMenu.EnableFooterMenu = false;
        }
        private void AssignEventHandlers()
        {
            FocusedRowChanged += new FocusedRowChangedEventHandler(TGridView02_FocusedRowChanged);
            ShowGridMenu += new GridMenuEventHandler(TGridView02_ShowGridMenu);
            MouseDown += new MouseEventHandler(TGridView02_MouseDown);
            MouseMove += new MouseEventHandler(TGridView02_MouseMove);
            //LostFocus += new EventHandler(TGridView02_LostFocus);
        }
        #endregion
    }
    public class TGridViewInfo02 : GridViewInfo
    {
        #region DevExpress Required Part
        public TGridViewInfo02(GridView gridView) : base(gridView) { }
        #endregion
    }
    public class TGridHandler02 : GridHandler
    {
        #region DevExpress Required Part
        public TGridHandler02(GridView gridView) : base(gridView) { }
        #endregion
    }
    #endregion

    #region BandedGridView Classes
    public class TBandedGridViewInfoRegistrator02 : BandedGridInfoRegistrator
    {
        #region DevExpress Required Part
        public override string ViewName { get { return "TBandedGridView02"; } }
        public override BaseView CreateView(GridControl grid) { return new TBandedGridView02(grid as GridControl); }
        public override BaseViewInfo CreateViewInfo(BaseView view) { return new TBandedGridViewInfo02(view as TBandedGridView02); }
        public override BaseViewHandler CreateHandler(BaseView view) { return new TBandedGridHandler02(view as TBandedGridView02); }
        #endregion
    }
    public class TBandedGridView02 : BandedGridView
    {
        #region Members
        TDataGrid02 mOwnerGrid = null;
        #endregion

        #region Constructors

        #region DevExpress Required Part
        public TBandedGridView02() : this(null) { }
        public TBandedGridView02(DevExpress.XtraGrid.GridControl grid)
            : base(grid)
        {
            AssignEventHandlers();
        }
        #endregion

        #endregion

        #region Properties

        #region DevExpress Required Part
        protected override string ViewName { get { return "TBandedGridView02"; } }
        #endregion

        #endregion

        #region Event Handlers
        private void TBandedGridView02_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            TBOT01 lBOT01 = null;

            lBOT01 = ((TDataGrid02)GridControl).BOT01;
            if (lBOT01 != null)
            {
                if (e.FocusedRowHandle == GridControl.NewItemRowHandle)
                {
                    lBOT01.CurrentRowIndex = TDataObject.DetachedRowIndex;
                }
                else if (e.FocusedRowHandle != GridControl.InvalidRowHandle)
                {
                    lBOT01.SetCurrentRow(GetDataRow(e.FocusedRowHandle));
                }
            }
        }
        private void TBandedGridView02_ShowGridMenu(object sender, GridMenuEventArgs e)
        {
            DXMenuItem lDeleteAllRowsItem = null;
            Image lDeleteAllRowsImage = null;

            if (e.MenuType == GridMenuType.User)
            {
                if (e.Menu == null)
                {
                    e.Menu = new DevExpress.XtraGrid.Menu.GridViewMenu(this);
                }
                else
                {
                    e.Menu.Items[0].BeginGroup = true;
                }
                lDeleteAllRowsImage = Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TDataGrid02.DeleteAllRows.png"));
                lDeleteAllRowsItem = new DXMenuItem("Delete All Rows", DeleteAllRowsItem_Click, lDeleteAllRowsImage);
                lDeleteAllRowsItem.Enabled = (DataSource != null && ((DataView)DataSource).Count != 0 && !mOwnerGrid.BOT01.BOT01ParentChildRel.ParentBO.IsDirty &&
                                                mOwnerGrid.DSFormMode != DSFormMode.DSBrowse && mOwnerGrid.BOT01.DataRight.AllowDelete);
                e.Menu.Items.Insert(0, lDeleteAllRowsItem);
            }
        }
        private void DeleteAllRowsItem_Click(object sender, EventArgs e)
        {
            bool lDeletionSucceeded = false;
            string lPKLst = null;
            string lPrntFrmBsTp = mOwnerGrid.ParentForm.GetType().BaseType.Name;

            if (TMessageBox.AskQuestion("Are you certain to delete all rows?", MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                for (int i = 0; i < ((DataView)DataSource).Count; i++)
                {
                    lPKLst += ((DataView)DataSource)[i][Utilities.TGC.PKeyName].ToString() + ",";
                }
                lPKLst = TStr.Left(lPKLst, lPKLst.Length - 1);
                lDeletionSucceeded = mOwnerGrid.BOT01.DeleteByPKList(lPKLst);
                switch (lPrntFrmBsTp)
                {
                    case "TForm02":
                        ((TForm02)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm12":
                        ((TForm12)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm01":
                        //((TForm01)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm06":
                        ((TForm06)mOwnerGrid.ParentForm).Reload();
                        break;
                }
                if (lDeletionSucceeded)
                {
                    TMessageBox.ShowInformation("Deletion Succeeded!");
                }
                else
                {
                    TMessageBox.ShowInformation("Deletion Failed!");
                }
            }
        }
        #endregion

        #region Functions
        public void Init()
        {
            mOwnerGrid = ((TDataGrid02)GridControl);
            FixedLineWidth = 1;
            Appearance.FocusedRow.BackColor = Color.FromArgb(60, 128, 128, 240);
            Appearance.FocusedRow.Options.UseBackColor = true;
            Appearance.SelectedRow.BackColor = Color.FromArgb(30, 128, 128, 240);
            Appearance.SelectedRow.Options.UseBackColor = true;
            OptionsView.NewItemRowPosition = NewItemRowPosition.Bottom;
            OptionsView.ColumnAutoWidth = false;
            OptionsView.ShowGroupPanel = false;
            OptionsCustomization.AllowGroup = false;
            OptionsMenu.EnableFooterMenu = false;
        }
        private void AssignEventHandlers()
        {
            FocusedRowChanged += TBandedGridView02_FocusedRowChanged;
            ShowGridMenu += TBandedGridView02_ShowGridMenu;
        }
        #endregion
    }
    public class TBandedGridViewInfo02 : BandedGridViewInfo
    {
        #region DevExpress Required Part
        public TBandedGridViewInfo02(BandedGridView gridView) : base(gridView) { }
        #endregion
    }
    public class TBandedGridHandler02 : BandedGridHandler
    {
        #region DevExpress Required Part
        public TBandedGridHandler02(BandedGridView gridView) : base(gridView) { }
        #endregion
    }
    #endregion

    #region AdvBandedGridView Classes
    public class TAdvBandedGridViewInfoRegistrator02 : AdvBandedGridInfoRegistrator
    {
        #region DevExpress Required Part
        public override string ViewName { get { return "TAdvBandedGridView02"; } }
        public override BaseView CreateView(GridControl grid) { return new TAdvBandedGridView02(grid as GridControl); }
        public override BaseViewInfo CreateViewInfo(BaseView view) { return new TAdvBandedGridViewInfo02(view as TAdvBandedGridView02); }
        public override BaseViewHandler CreateHandler(BaseView view) { return new TAdvBandedGridHandler02(view as TAdvBandedGridView02); }
        #endregion
    }
    public class TAdvBandedGridView02 : AdvBandedGridView
    {
        #region Members
        TDataGrid02 mOwnerGrid = null;
        #endregion

        #region Constructors

        #region DevExpress Required Part
        public TAdvBandedGridView02() : this(null) { }
        public TAdvBandedGridView02(DevExpress.XtraGrid.GridControl grid)
            : base(grid)
        {
            AssignEventHandlers();
        }
        #endregion

        #endregion

        #region Properties

        #region DevExpress Required Part
        protected override string ViewName { get { return "TAdvBandedGridView02"; } }
        #endregion

        #endregion

        #region Event Handlers
        private void TAdvBandedGridView02_FocusedRowChanged(object sender, FocusedRowChangedEventArgs e)
        {
            TBOT01 lBOT01 = null;

            lBOT01 = ((TDataGrid02)GridControl).BOT01;
            if (lBOT01 != null)
            {
                if (e.FocusedRowHandle == GridControl.NewItemRowHandle)
                {
                    lBOT01.CurrentRowIndex = TDataObject.DetachedRowIndex;
                }
                else if (e.FocusedRowHandle != GridControl.InvalidRowHandle)
                {
                    lBOT01.SetCurrentRow(GetDataRow(e.FocusedRowHandle));
                }
            }
        }
        private void TAdvBandedGridView02_ShowGridMenu(object sender, GridMenuEventArgs e)
        {
            DXMenuItem lDeleteAllRowsItem = null;
            Image lDeleteAllRowsImage = null;

            if (e.MenuType == GridMenuType.User)
            {
                if (e.Menu == null)
                {
                    e.Menu = new DevExpress.XtraGrid.Menu.GridViewMenu(this);
                }
                else
                {
                    e.Menu.Items[0].BeginGroup = true;
                }
                lDeleteAllRowsImage = Bitmap.FromStream(System.Reflection.Assembly.GetExecutingAssembly().GetManifestResourceStream("Innotelli.WinForm.Control.Resources.TDataGrid02.DeleteAllRows.png"));
                lDeleteAllRowsItem = new DXMenuItem("Delete All Rows", DeleteAllRowsItem_Click, lDeleteAllRowsImage);
                lDeleteAllRowsItem.Enabled = (DataSource != null && ((DataView)DataSource).Count != 0 && !mOwnerGrid.BOT01.BOT01ParentChildRel.ParentBO.IsDirty &&
                                                mOwnerGrid.DSFormMode != DSFormMode.DSBrowse && mOwnerGrid.BOT01.DataRight.AllowDelete);
                e.Menu.Items.Insert(0, lDeleteAllRowsItem);
            }
        }
        private void DeleteAllRowsItem_Click(object sender, EventArgs e)
        {
            bool lDeletionSucceeded = false;
            string lPKLst = null;
            string lPrntFrmBsTp = mOwnerGrid.ParentForm.GetType().BaseType.Name;

            if (TMessageBox.AskQuestion("Are you certain to delete all rows?", MessageBoxButtons.YesNo, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
            {
                for (int i = 0; i < ((DataView)DataSource).Count; i++)
                {
                    lPKLst += ((DataView)DataSource)[i][Utilities.TGC.PKeyName].ToString() + ",";
                }
                lPKLst = TStr.Left(lPKLst, lPKLst.Length - 1);
                lDeletionSucceeded = mOwnerGrid.BOT01.DeleteByPKList(lPKLst);
                switch (lPrntFrmBsTp)
                {
                    case "TForm02":
                        ((TForm02)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm12":
                        ((TForm12)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm01":
                        //((TForm01)mOwnerGrid.ParentForm).Reload();
                        break;
                    case "TForm06":
                        ((TForm06)mOwnerGrid.ParentForm).Reload();
                        break;
                }
                if (lDeletionSucceeded)
                {
                    TMessageBox.ShowInformation(Innotelli.Utilities.TSingletons.StrResx.GetStr(90));
                }
                else
                {
                    TMessageBox.ShowInformation(Innotelli.Utilities.TSingletons.StrResx.GetStr(91));
                }
            }
        }
        #endregion

        #region Functions
        public void Init()
        {
            mOwnerGrid = ((TDataGrid02)GridControl);
            FixedLineWidth = 1;
            Appearance.FocusedRow.BackColor = Color.FromArgb(60, 128, 128, 240);
            Appearance.FocusedRow.Options.UseBackColor = true;
            Appearance.SelectedRow.BackColor = Color.FromArgb(30, 128, 128, 240);
            Appearance.SelectedRow.Options.UseBackColor = true;
            OptionsView.NewItemRowPosition = NewItemRowPosition.Bottom;
            OptionsView.ColumnAutoWidth = false;
            OptionsView.ShowGroupPanel = false;
            OptionsCustomization.AllowGroup = false;
            OptionsMenu.EnableFooterMenu = false;
        }
        private void AssignEventHandlers()
        {
            FocusedRowChanged += TAdvBandedGridView02_FocusedRowChanged;
            ShowGridMenu += TAdvBandedGridView02_ShowGridMenu;
        }
        #endregion
    }
    public class TAdvBandedGridViewInfo02 : AdvBandedGridViewInfo
    {
        #region DevExpress Required Part
        public TAdvBandedGridViewInfo02(AdvBandedGridView gridView) : base(gridView) { }
        #endregion
    }
    public class TAdvBandedGridHandler02 : AdvBandedGridHandler
    {
        #region DevExpress Required Part
        public TAdvBandedGridHandler02(AdvBandedGridView gridView) : base(gridView) { }
        #endregion
    }
    #endregion
}