using System;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.ViewInfo;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterPercentTextBox03")]
    public class RepositoryItemPercentTextBox03 : RepositoryItemTextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static RepositoryItemPercentTextBox03() { RegisterPercentTextBox03(); }

        //The unique name for the custom editor
        public const string PercentTextBox03Name = "TPercentTextBox03";

        //Return the unique name
        public override string EditorTypeName { get { return PercentTextBox03Name; } }

        //Register the editor
        public static void RegisterPercentTextBox03()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.PercentTextBox03.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(PercentTextBox03Name,
              typeof(TPercentTextBox03), typeof(RepositoryItemPercentTextBox03),
              typeof(TextEditViewInfo), new TextEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemPercentTextBox03 source = item as RepositoryItemPercentTextBox03;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }
        #endregion

        #region Constructors
        public RepositoryItemPercentTextBox03()
        {
        }
        #endregion

        #region Properties
        
        private bool mIsLocked = false;
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                TRepositoryItemTextEditUtil.SetLocked(this, value);
                mIsLocked = value;
            }
        }
        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        DSFormMode mDSFormMode = DSFormMode.DSEditable;
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                TRepositoryItemTextEditUtil.SetDSFormMode(this, value);
                mDSFormMode = value;
            }
        }
        #endregion

        #region Functions
        public void Init()
        {
            Appearance.Options.UseTextOptions = true;
            Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            AppearanceReadOnly.Options.UseBackColor = false;
            AppearanceReadOnly.Options.UseTextOptions = true;
            AppearanceReadOnly.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Far;
            MaxLength = 255;
            DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            DisplayFormat.FormatString = TSettings.PerFormat;
            EditFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            EditFormat.FormatString = TSettings.PerFormat;
            Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric;
            Mask.EditMask = TSettings.PerFormat;
            Mask.UseMaskAsDisplayFormat = true;
        }
        #endregion
    }

    public class TPercentTextBox03 : TextEdit
    {
        #region DevExpress Required Part
        //The static constructor which calls the registration method
        static TPercentTextBox03() { RepositoryItemPercentTextBox03.RegisterPercentTextBox03(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemPercentTextBox03.PercentTextBox03Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemPercentTextBox03 Properties
        {
            get { return base.Properties as RepositoryItemPercentTextBox03; }
        }
        #endregion

        #region Constructors
        public TPercentTextBox03()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(30, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(50, 19);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        [Bindable(true),
        Category("Behavior"),
        DefaultValue("P0"),
        Description("Indicates the numeric format."),
        Localizable(true)]
        private string mFormat = TSettings.PerFormat;
        public string Format
        {
            get
            {
                return mFormat;
            }
            set
            {
                mFormat = value;
            }
        }
        #endregion

        #region Event Handlers
        protected override void OnClick(EventArgs e)
        {
            base.OnClick(e);
            TTextEditUtil.Highlight(this);
        }
        protected override void OnEditValueChanged()
        {
            base.OnEditValueChanged();
            if (Utilities.TGC.IsRunTime)
            {
                TTextEditUtil.UpdateForeColor(this);
            }
        }
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}