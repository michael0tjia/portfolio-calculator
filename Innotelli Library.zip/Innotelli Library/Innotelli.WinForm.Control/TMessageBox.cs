using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace Innotelli.WinForm.Control
{
    public static class TMessageBox
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public static DialogResult AskQuestion(string aText, MessageBoxButtons aButtons)
        {
            return DevExpress.XtraEditors.XtraMessageBox.Show(aText, Innotelli.Utilities.TAppSettings.ApplicationTitle, aButtons, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
        }
        public static DialogResult AskQuestion(string aText, MessageBoxButtons aButtons, MessageBoxDefaultButton aDefaultButton)
        {
            return DevExpress.XtraEditors.XtraMessageBox.Show(aText, Innotelli.Utilities.TAppSettings.ApplicationTitle, aButtons, MessageBoxIcon.Question, aDefaultButton);
        }
        public static DialogResult ShowInformation(string aText)
        {
            return DevExpress.XtraEditors.XtraMessageBox.Show(aText, Innotelli.Utilities.TAppSettings.ApplicationTitle, MessageBoxButtons.OK, MessageBoxIcon.Information, MessageBoxDefaultButton.Button1);
        }
        public static DialogResult ShowWarning(string aText)
        {
            return DevExpress.XtraEditors.XtraMessageBox.Show(aText, Innotelli.Utilities.TAppSettings.ApplicationTitle, MessageBoxButtons.OK, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button1);
        }
        public static DialogResult ShowError(string aText)
        {
            return DevExpress.XtraEditors.XtraMessageBox.Show(aText, Innotelli.Utilities.TAppSettings.ApplicationTitle, MessageBoxButtons.OK, MessageBoxIcon.Error, MessageBoxDefaultButton.Button1);
        }
        #endregion
    }
}
