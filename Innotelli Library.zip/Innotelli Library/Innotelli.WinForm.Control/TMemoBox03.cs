using System.Drawing;
using System.Reflection;
using System.ComponentModel;
using System.Windows.Forms;
using DevExpress.XtraEditors;
using DevExpress.XtraEditors.Repository;
using DevExpress.XtraEditors.Registrator;
using DevExpress.XtraEditors.Drawing;
using DevExpress.XtraEditors.ViewInfo;
using System;
using DevExpress.Utils;

namespace Innotelli.WinForm.Control
{
    //The attribute that points to the registration method
    [UserRepositoryItem("RegisterMemoBox03")]
    public class RepositoryItemMemoBox03 : RepositoryItemMemoEdit
    {
        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static RepositoryItemMemoBox03() { RegisterMemoBox03(); }

        //The unique name for the custom editor
        public const string MemoBox03Name = "TMemoBox03";

        //Return the unique name
        public override string EditorTypeName { get { return MemoBox03Name; } }

        //Register the editor
        public static void RegisterMemoBox03()
        {
            //Icon representing the editor within a container editor's Designer
            Image img = null;
            try
            {
                img = (Bitmap)Bitmap.FromStream(Assembly.GetExecutingAssembly().
                  GetManifestResourceStream("Innotelli.WinForm.Control.MemoBox03.bmp"));
            }
            catch
            {
            }
            EditorRegistrationInfo.Default.Editors.Add(new EditorClassInfo(MemoBox03Name,
              typeof(TMemoBox03), typeof(RepositoryItemMemoBox03),
              typeof(MemoEditViewInfo), new MemoEditPainter(), true, img));
        }

        //Override the Assign method
        public override void Assign(RepositoryItem item)
        {
            BeginUpdate();
            try
            {
                base.Assign(item);
                RepositoryItemMemoBox03 source = item as RepositoryItemMemoBox03;
                if (source == null) return;
            }
            finally
            {
                EndUpdate();
            }
        }

        #endregion

        #region Members

        private bool mIsLocked = false;
        DSFormMode mDSFormMode = DSFormMode.DSEditable;

        #endregion

        #region Constructors

        //Initialize new properties
        public RepositoryItemMemoBox03()
        {
        }


        #endregion

        #region Properties

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public bool IsLocked
        {
            get
            {
                return mIsLocked;
            }
            set
            {
                ReadOnly = value;
                if (value)
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
                }
                else
                {
                    Appearance.BackColor = System.Drawing.Color.FromArgb(255, 255, 255);
                }
                Appearance.Options.UseBackColor = true;
                AppearanceReadOnly.Options.UseBackColor = false;
                if (OwnerEdit != null)
                {
                    OwnerEdit.TabStop = !value;
                }
                mIsLocked = value;
            }
        }

        [Browsable(false), DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public DSFormMode DSFormMode
        {
            get
            {
                return mDSFormMode;
            }
            set
            {
                switch (value)
                {
                    case DSFormMode.DSBrowse:
                        break;
                    case DSFormMode.DSEditable:
                        break;
                    case DSFormMode.DSInsert:
                        break;
                }
                mDSFormMode = value;
            }
        }

        #endregion

        #region Event Handlers
        #endregion

        #region Functions

        public void Init()
        {
            AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(255, 255, 192);
            AppearanceReadOnly.Options.UseBackColor = true;
            ReadOnly = true;
        }

        #endregion
  
    }


    public class TMemoBox03 : MemoEdit
    {
        #region Enums

        #endregion

        #region DevExpress Required Part

        //The static constructor which calls the registration method
        static TMemoBox03() { RepositoryItemMemoBox03.RegisterMemoBox03(); }

        //Return the unique name
        public override string EditorTypeName { get { return RepositoryItemMemoBox03.MemoBox03Name; } }

        //Override the Properties property
        //Simply type-cast the object to the custom repository item type
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public new RepositoryItemMemoBox03 Properties
        {
            get { return base.Properties as RepositoryItemMemoBox03; }
        }

        #endregion

        #region Members
        #endregion

        #region Constructors
        

        //Initialize the new instance
        public TMemoBox03()
        {
            Init();
        }
        #endregion

        #region Properties
        private Size mDefaultMaximumSize = new Size(TSettings.MaxWidth, 19);
        protected override Size DefaultMaximumSize
        {
            get
            {
                return mDefaultMaximumSize;
            }
        }
        private Size mDefaultMinimumSize = new Size(50, 19);
        protected override Size DefaultMinimumSize
        {
            get
            {
                return mDefaultMinimumSize;
            }
        }
        private Size mDefaultSize = new Size(200, 39);
        protected override Size DefaultSize
        {
            get
            {
                return mDefaultSize;
            }
        }
        
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void Init()
        {
            Margin = new System.Windows.Forms.Padding(0);
        }
        #endregion
    }
}
