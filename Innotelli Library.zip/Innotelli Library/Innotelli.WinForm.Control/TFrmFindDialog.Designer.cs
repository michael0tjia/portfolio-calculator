namespace Innotelli.WinForm.Control
{
    partial class TFrmFindDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TFrmFindDialog));
            this.txtID = new DevExpress.XtraEditors.TextEdit();
            this.tLayoutControl011 = new Innotelli.WinForm.Control.TLayoutControl01();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.btnOK = new DevExpress.XtraEditors.SimpleButton();
            this.btnCancel = new DevExpress.XtraEditors.SimpleButton();
            this.layoutControlGroup011 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.layoutControlItem011 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlItem012 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlGroup012 = new Innotelli.WinForm.Control.LayoutControlGroup01();
            this.layoutControlItem013 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.layoutControlItem014 = new Innotelli.WinForm.Control.LayoutControlItem01();
            this.emptySpaceItem1 = new DevExpress.XtraLayout.EmptySpaceItem();
            this.textBox041 = new Innotelli.WinForm.Control.TTextBox04();
            this.textBox042 = new Innotelli.WinForm.Control.TTextBox04();
            ((System.ComponentModel.ISupportInitialize)(this.txtID.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLayoutControl011)).BeginInit();
            this.tLayoutControl011.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup011)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem011)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem012)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup012)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem013)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem014)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox041.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox042.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // txtID
            // 
            resources.ApplyResources(this.txtID, "txtID");
            this.txtID.Name = "txtID";
            this.txtID.StyleController = this.tLayoutControl011;
            // 
            // tLayoutControl011
            // 
            this.tLayoutControl011.Appearance.DisabledLayoutGroupCaption.ForeColor = System.Drawing.SystemColors.GrayText;
            this.tLayoutControl011.Appearance.DisabledLayoutGroupCaption.Options.UseForeColor = true;
            this.tLayoutControl011.Appearance.DisabledLayoutItem.ForeColor = System.Drawing.SystemColors.GrayText;
            this.tLayoutControl011.Appearance.DisabledLayoutItem.Options.UseForeColor = true;
            this.tLayoutControl011.Controls.Add(this.labelControl1);
            this.tLayoutControl011.Controls.Add(this.txtID);
            this.tLayoutControl011.Controls.Add(this.btnOK);
            this.tLayoutControl011.Controls.Add(this.btnCancel);
            resources.ApplyResources(this.tLayoutControl011, "tLayoutControl011");
            this.tLayoutControl011.Name = "tLayoutControl011";
            this.tLayoutControl011.OptionsItemText.TextAlignMode = DevExpress.XtraLayout.TextAlignMode.AlignInGroups;
            this.tLayoutControl011.OptionsView.EnableIndentsInGroupsWithoutBorders = true;
            this.tLayoutControl011.Root = this.layoutControlGroup011;
            // 
            // labelControl1
            // 
            resources.ApplyResources(this.labelControl1, "labelControl1");
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.StyleController = this.tLayoutControl011;
            // 
            // btnOK
            // 
            resources.ApplyResources(this.btnOK, "btnOK");
            this.btnOK.Name = "btnOK";
            this.btnOK.StyleController = this.tLayoutControl011;
            this.btnOK.Click += new System.EventHandler(this.btnOK_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            resources.ApplyResources(this.btnCancel, "btnCancel");
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.StyleController = this.tLayoutControl011;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // layoutControlGroup011
            // 
            resources.ApplyResources(this.layoutControlGroup011, "layoutControlGroup011");
            this.layoutControlGroup011.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem011,
            this.layoutControlItem012,
            this.layoutControlGroup012,
            this.emptySpaceItem1});
            this.layoutControlGroup011.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup011.Name = "layoutControlGroup011";
            this.layoutControlGroup011.OptionsItemText.TextToControlDistance = 2;
            this.layoutControlGroup011.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup011.Size = new System.Drawing.Size(272, 83);
            this.layoutControlGroup011.Spacing = new DevExpress.XtraLayout.Utils.Padding(0, 0, 0, 0);
            this.layoutControlGroup011.TextVisible = false;
            // 
            // layoutControlItem011
            // 
            this.layoutControlItem011.Control = this.btnOK;
            resources.ApplyResources(this.layoutControlItem011, "layoutControlItem011");
            this.layoutControlItem011.Location = new System.Drawing.Point(104, 51);
            this.layoutControlItem011.MaxSize = new System.Drawing.Size(82, 28);
            this.layoutControlItem011.MinSize = new System.Drawing.Size(82, 28);
            this.layoutControlItem011.Name = "layoutControlItem011";
            this.layoutControlItem011.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem011.Size = new System.Drawing.Size(82, 28);
            this.layoutControlItem011.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem011.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.layoutControlItem011.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem011.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem011.TextToControlDistance = 0;
            this.layoutControlItem011.TextVisible = false;
            // 
            // layoutControlItem012
            // 
            this.layoutControlItem012.Control = this.btnCancel;
            resources.ApplyResources(this.layoutControlItem012, "layoutControlItem012");
            this.layoutControlItem012.Location = new System.Drawing.Point(186, 51);
            this.layoutControlItem012.MaxSize = new System.Drawing.Size(82, 28);
            this.layoutControlItem012.MinSize = new System.Drawing.Size(82, 28);
            this.layoutControlItem012.Name = "layoutControlItem012";
            this.layoutControlItem012.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem012.Size = new System.Drawing.Size(82, 28);
            this.layoutControlItem012.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem012.Spacing = new DevExpress.XtraLayout.Utils.Padding(2, 2, 2, 2);
            this.layoutControlItem012.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem012.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem012.TextToControlDistance = 0;
            this.layoutControlItem012.TextVisible = false;
            // 
            // layoutControlGroup012
            // 
            resources.ApplyResources(this.layoutControlGroup012, "layoutControlGroup012");
            this.layoutControlGroup012.Items.AddRange(new DevExpress.XtraLayout.BaseLayoutItem[] {
            this.layoutControlItem013,
            this.layoutControlItem014});
            this.layoutControlGroup012.Location = new System.Drawing.Point(0, 0);
            this.layoutControlGroup012.Name = "layoutControlGroup012";
            this.layoutControlGroup012.Padding = new DevExpress.XtraLayout.Utils.Padding(3, 3, 3, 3);
            this.layoutControlGroup012.Size = new System.Drawing.Size(268, 51);
            this.layoutControlGroup012.Spacing = new DevExpress.XtraLayout.Utils.Padding(1, 1, 1, 1);
            this.layoutControlGroup012.TextVisible = false;
            // 
            // layoutControlItem013
            // 
            this.layoutControlItem013.Control = this.txtID;
            resources.ApplyResources(this.layoutControlItem013, "layoutControlItem013");
            this.layoutControlItem013.Location = new System.Drawing.Point(0, 20);
            this.layoutControlItem013.Name = "layoutControlItem013";
            this.layoutControlItem013.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 0, 0);
            this.layoutControlItem013.Size = new System.Drawing.Size(258, 21);
            this.layoutControlItem013.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem013.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem013.TextToControlDistance = 0;
            this.layoutControlItem013.TextVisible = false;
            // 
            // layoutControlItem014
            // 
            this.layoutControlItem014.Control = this.labelControl1;
            resources.ApplyResources(this.layoutControlItem014, "layoutControlItem014");
            this.layoutControlItem014.Location = new System.Drawing.Point(0, 0);
            this.layoutControlItem014.MaxSize = new System.Drawing.Size(168, 20);
            this.layoutControlItem014.MinSize = new System.Drawing.Size(168, 20);
            this.layoutControlItem014.Name = "layoutControlItem014";
            this.layoutControlItem014.Padding = new DevExpress.XtraLayout.Utils.Padding(1, 1, 2, 2);
            this.layoutControlItem014.Size = new System.Drawing.Size(258, 20);
            this.layoutControlItem014.SizeConstraintsType = DevExpress.XtraLayout.SizeConstraintsType.Custom;
            this.layoutControlItem014.TextLocation = DevExpress.Utils.Locations.Left;
            this.layoutControlItem014.TextSize = new System.Drawing.Size(0, 0);
            this.layoutControlItem014.TextToControlDistance = 0;
            this.layoutControlItem014.TextVisible = false;
            // 
            // emptySpaceItem1
            // 
            resources.ApplyResources(this.emptySpaceItem1, "emptySpaceItem1");
            this.emptySpaceItem1.Location = new System.Drawing.Point(0, 51);
            this.emptySpaceItem1.Name = "emptySpaceItem1";
            this.emptySpaceItem1.Size = new System.Drawing.Size(104, 28);
            this.emptySpaceItem1.TextSize = new System.Drawing.Size(0, 0);
            // 
            // textBox041
            // 
            resources.ApplyResources(this.textBox041, "textBox041");
            this.textBox041.Name = "textBox041";
            this.textBox041.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBox041.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.textBox041.Properties.BOT01 = null;
            this.textBox041.Properties.DSFormMode = Innotelli.WinForm.Control.DSFormMode.DSEditable;
            // 
            // textBox042
            // 
            resources.ApplyResources(this.textBox042, "textBox042");
            this.textBox042.Name = "textBox042";
            this.textBox042.Properties.AppearanceReadOnly.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBox042.Properties.AppearanceReadOnly.Options.UseBackColor = true;
            this.textBox042.Properties.BOT01 = null;
            this.textBox042.Properties.DSFormMode = Innotelli.WinForm.Control.DSFormMode.DSEditable;
            // 
            // TFrmFindDialog
            // 
            this.AcceptButton = this.btnOK;
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.btnCancel;
            this.ControlBox = false;
            this.Controls.Add(this.tLayoutControl011);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "TFrmFindDialog";
            this.Load += new System.EventHandler(this.frmChgID_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txtID.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tLayoutControl011)).EndInit();
            this.tLayoutControl011.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup011)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem011)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem012)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlGroup012)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem013)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.layoutControlItem014)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.emptySpaceItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox041.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textBox042.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.SimpleButton btnOK;
        private DevExpress.XtraEditors.SimpleButton btnCancel;
        private TTextBox04 textBox041;
        private TTextBox04 textBox042;
        public DevExpress.XtraEditors.TextEdit txtID;
        private TLayoutControl01 tLayoutControl011;
        private LayoutControlGroup01 layoutControlGroup011;
        private LayoutControlItem01 layoutControlItem011;
        private LayoutControlItem01 layoutControlItem012;
        private DevExpress.XtraLayout.EmptySpaceItem emptySpaceItem1;
        private LayoutControlGroup01 layoutControlGroup012;
        private LayoutControlItem01 layoutControlItem013;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private LayoutControlItem01 layoutControlItem014;
    }
}