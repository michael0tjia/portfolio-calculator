using System;
using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using System.Text;
using Innotelli.Utilities;

namespace Innotelli.WinForm.Control
{
    public class TCurrencyTextBox03Collection : ArrayList
    {
        #region Members
        #endregion

        #region Constructors
        public TCurrencyTextBox03Collection()
        {
        }
        #endregion

        #region Enums
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public void Add(System.Windows.Forms.Control aControl)
        {
            base.Add(aControl);
        }
        public void Init()
        {
            //try
            //{
                for (int i = 0; i < this.Count; i++)
                {
                    ((TCurrencyTextBox03)this[i]).Properties.Init();
                }
            //}
            //catch (Exception)
            //{
            //    throw;
            //}
        }
        public void SetDSMode(DSFormMode aDSFormMode)
        {
            //try
            //{
                for (int i = 0; i < this.Count; i++)
                {
                    ((TCurrencyTextBox03)this[i]).Properties.DSFormMode = aDSFormMode;
                }
            //}
            //catch (Exception)
            //{
            //    throw;
            //}
        }
        #endregion
    }
}