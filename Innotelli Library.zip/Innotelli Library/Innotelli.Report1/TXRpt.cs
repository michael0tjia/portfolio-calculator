using System;
using System.Data;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using Innotelli.Db;
using DevExpress.XtraReports.UI;

namespace Innotelli.Report1
{
    public partial class TXRpt : XtraReport, IRpt
    {
        #region Constructors
        public TXRpt()
        {
            MiscDs = null;
        }
        #endregion

        #region Properties
        private string mRptNm = String.Empty;
        public string RptNm
        {
            get
            {
                return mRptNm;
            }
        }
        private DataSet mMiscDs;
        public DataSet MiscDs
        {
            get
            {
                return mMiscDs;
            }
            set
            {
                mMiscDs = value;
            }
        }
        private TRptFltr mRptFltr;
        public TRptFltr RptFltr
        {
            get
            {
                return mRptFltr;
            }
            set
            {
                mRptFltr = value;
            }
        }
        #endregion
    }
}
