﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using DevExpress.XtraReports.UI;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.Report1
{
    public abstract class TRpt01
    {
        #region Constructors
        public TRpt01()
        {

        }
        #endregion

        #region Properties
        private string mRptNm = "";
        public string RptNm
        {
            get
            {
                return mRptNm;
            }
            set
            {
                mRptNm = value;
            }
        }
        private DataSet mMiscDs = null;
        public DataSet MiscDs
        {
            get
            {
                if (mMiscDs == null)
                {
                    mMiscDs = GetMiscDs();
                }
                return mMiscDs;
            }
            set
            {
                mMiscDs = value;
            }
        }

        private TRptFltr mRptFltr = null;
        public TRptFltr RptFltr
        {
            get { return mRptFltr; }
            set { mRptFltr = value; }
        }

        private XtraReport mXRpt = null;
        public XtraReport XRpt
        {
            get { return mXRpt; }
            set { mXRpt = value; }
        }
        #endregion

        #region Functions
        //#check!
        // should rename to PrepareAccessData
        //public abstract void PrepareData();
        public virtual void BeforeRender()
        {
        }
        public virtual void AfterRender()
        {
        }
        protected virtual DataSet GetMiscDs()
        {
            return null;
        }
        #endregion
    }
}
