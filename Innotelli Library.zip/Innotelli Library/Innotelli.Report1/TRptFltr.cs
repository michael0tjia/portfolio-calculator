using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Innotelli.Utilities;
using Innotelli.Db;
using System.Configuration;

namespace Innotelli.Report1
{
    public class TRptFltr
    {
        #region Members
        private DataSet mCriteiraDs = null;
        private DataTable mCriteiraDt;
        private DataView mCriteiraDv = new DataView();
        private string mRptNm = string.Empty;
        private TSysDataRdr mSysDataRdr = Innotelli.Utilities.TSingletons.SysData01Rdr;
        #endregion

        #region Constructors
        public TRptFltr()
        {
            SetSearchDtl();
        }
        ///  Copy Constructors
        public TRptFltr(TRptFltr aRptFltr)
        {
            DataTable lDt = aRptFltr.CriteiraDv.ToTable();
            DataSet lDs = new DataSet();

            lDs.Tables.Add(lDt);
            CriteiraDs = aRptFltr.CriteiraDs;
            RptNm = aRptFltr.RptNm;
        }
        #endregion

        #region Properties
        public string RptNm
        {
            get
            {
                return mRptNm;
            }
            set
            {
                mRptNm = value;
                mCriteiraDv.RowFilter = "Apply = True AND RptNm = '" + mRptNm + "'";
            }
        }
        public DataSet CriteiraDs
        {
            get
            {
                return mCriteiraDs;
            }
            set
            {
                mCriteiraDs = value;
                mCriteiraDt = mCriteiraDs.Tables[0];
                mCriteiraDv.Table = mCriteiraDt;
                mCriteiraDv.Sort = "ItemNo";
            }
        }
        public DataTable CriteiraDt
        {
            get
            {
                return mCriteiraDt;
            }
        }
        public DataView CriteiraDv
        {
            get
            {
                return mCriteiraDv;
            }
        }
        #endregion

        #region Functions
        public string GetCriteria(ref string aCriteriaFullText, ref string aParamFullText)
        {
            string lReturnValue = string.Empty;
            string lValTerminator = string.Empty;
            string lBgnStr = string.Empty;
            string lEndStr = string.Empty;
            string lOptr = string.Empty;
            bool lIsDateTime = false;
            DataSet lDs = new DataSet();
            DataRow[] lDr;
            lDs = mSysDataRdr.GetSysData("SrchCndtn");

            for (int i = 0; i < this.CriteiraDv.Count; i++)
            {
                string lRptNm = this.CriteiraDv[i ]["RptNm"].ToString();
                string lItemNo = this.CriteiraDv[i]["ItemNo"].ToString();
                string lFldAls = this.CriteiraDv[i]["FldAls"].ToString();
                string lFldNm = this.CriteiraDv[i]["FldNm"].ToString();
                string lFldType = this.CriteiraDv[i]["FldType"].ToString();
                string lCondition = this.CriteiraDv[i]["Condition"].ToString();

                string lValue1 = this.CriteiraDv[i]["Value1"].ToString();
                string lValue2 = this.CriteiraDv[i]["Value2"].ToString();

                string lSelObjID = this.CriteiraDv[i]["SelObjID"].ToString();
                string lBndCol = this.CriteiraDv[i]["BndCol"].ToString();
                bool lApply = bool.Parse(this.CriteiraDv[i]["Apply"].ToString());
                bool lIsParam = bool.Parse(this.CriteiraDv[i]["IsParam"].ToString());

                if (!bool.Parse(this.CriteiraDv[i]["IsParam"].ToString()))
                {
                    lDr = lDs.Tables[0].Select("Cndtn = '" + lCondition + "'");
                    lOptr = lDr[0]["Optr"].ToString();
                    lBgnStr = lDr[0]["BgnStr"].ToString();
                    lEndStr = lDr[0]["EndStr"].ToString();

                    if (lApply)
                    {
                        if (lValue1 != string.Empty)
                        {
                            switch (lFldType)
                            {
                                case "BIT":
                                    lValue1 = (lValue1 == "True" ? "1" : "0");
                                    lIsDateTime = false;
                                    break;
                                case "TEXT":
                                    lValTerminator = "'";
                                    lIsDateTime = false;
                                    break;
                                case "DATETIME":
                                    lValTerminator = "'";
                                    lIsDateTime = true;
                                    break;
                                default:
                                    lValTerminator = string.Empty;
                                    lIsDateTime = false;
                                    break;
                            }

                            if (lCondition == "Is between")
                            {
                                if (lValue2 != string.Empty)
                                {
                                    if (!lIsDateTime)
                                    {
                                        lReturnValue += lFldNm + " " + lOptr + " " + lValTerminator + lBgnStr + lValue1 + lEndStr + lValTerminator + " And " + " " + lValTerminator + lBgnStr + lValue2 + lEndStr + lValTerminator + " And ";
                                        aCriteriaFullText += lFldAls + " " + lCondition + " " + lValue1 + " And " + " " + lValue2 + "\r\n";
                                    }
                                    else
                                    {
                                        lReturnValue += lFldNm + " " + lOptr + " " + lValTerminator + lBgnStr + DateTime.Parse(lValue1).ToString("MM/dd/yyyy") + lEndStr + lValTerminator + " And " + " " + lValTerminator + lBgnStr + DateTime.Parse(lValue2).ToString("MM/dd/yyyy") + lEndStr + lValTerminator + " And ";
                                        aCriteriaFullText += lFldAls + " " + lCondition + " " + DateTime.Parse(lValue1).ToString("dd/MM/yyyy") + " And " + " " + DateTime.Parse(lValue2).ToString("dd/MM/yyyy") + "\r\n";
                                    }

                                }
                            }
                            // Alex 11/02/2008
                            else if (lCondition == "Is")
                            {

                                lReturnValue += lFldNm + " " + lOptr + " " + int.Parse(lValue1) + " And ";
                                aCriteriaFullText += lFldAls + " " + lCondition + " " + (lValue1 == "1" ? "True" : "False") + "\r\n";


                            }
                            else
                            {
                                if (!lIsDateTime)
                                {
                                    lReturnValue += lFldNm + " " + lOptr + " " + lValTerminator + lBgnStr + lValue1 + lEndStr + lValTerminator + " And ";
                                    aCriteriaFullText += lFldAls + " " + lCondition + " " + lValue1 + "\r\n";
                                }
                                else
                                {
                                    lReturnValue += lFldNm + " " + lOptr + " " + lValTerminator + lBgnStr + DateTime.Parse(lValue1).ToString("MM/dd/yyyy") + lEndStr + lValTerminator + " And ";
                                    aCriteriaFullText += lFldAls + " " + lCondition + " " + DateTime.Parse(lValue1).ToString("dd/MM/yyyy") + " And " + "\r\n";
                                }

                            }
                        }
                    }
                }
                else
                {
                    if (lApply)
                    {
                        if (lValue1 != string.Empty)
                        {
                            switch (lFldType)
                            {
                                case "TEXT":
                                    lValTerminator = "'";
                                    lIsDateTime = false;
                                    break;
                                case "DATETIME":
                                    lValTerminator = "'";
                                    lIsDateTime = true;
                                    break;
                                default:
                                    lValTerminator = string.Empty;
                                    lIsDateTime = false;
                                    break;
                            }
                            if (!lIsDateTime)
                            {
                                aParamFullText += lFldAls + " " + lCondition + " " + lValue1 + "\r\n";
                            }
                            else
                            {
                                aParamFullText += lFldAls + " " + lCondition + " " + DateTime.Parse(lValue1).ToString("dd/MM/yyyy") + "\r\n";
                            }

                        }
                    }

                }
            }
            return TStr.Left(lReturnValue, lReturnValue.Length - 5);
        }
        public string GetCriteriaFullText()
        {
            string lReturnValue = string.Empty;

            for (int i = 0; i < CriteiraDv.Count; i++)
            {
                if ((bool.Parse(CriteiraDv[i]["Apply"].ToString())) && (CriteiraDv[i]["Value1"] != null))
                {
                    if (CriteiraDv[i]["Optr"].ToString() == "Is between")
                    {
                        lReturnValue = lReturnValue + CriteiraDv[i]["FldAls"].ToString() + " " + CriteiraDv[i]["Condition"].ToString() + " " + CriteiraDv[i]["Value1"].ToString() + " and " + CriteiraDv[i]["Value2"].ToString() + "\r\r";
                    }
                    else
                    {
                        lReturnValue = lReturnValue + CriteiraDv[i]["FldAls"].ToString() + " " + CriteiraDv[i]["Condition"].ToString() + " " + CriteiraDv[i]["Value1"].ToString() + "\r\r";
                    }
                }
            }
            lReturnValue = TStr.Left(lReturnValue, lReturnValue.Length - 2);
            return lReturnValue;
        }
        public object GetParamValue(string aParamName)
        {
            object lReturnValue = null;
            bool IsParam = false;
            string lRptNm = string.Empty;
            string lParamName = string.Empty;

            for (int i = 0; i < CriteiraDv.Count; i++)
            {
                lRptNm = CriteiraDv[i]["RptNm"].ToString();
                IsParam = bool.Parse(CriteiraDv[i]["IsParam"].ToString());
                lParamName = CriteiraDv[i]["FldNm"].ToString();

                if ((lRptNm == mRptNm) && (IsParam) && (lParamName == aParamName))
                {
                    lReturnValue = CriteiraDv[i]["Value1"].ToString();
                    break;
                }
            }
            return lReturnValue;
        }
        public object GetCriteriaValue1(string aCriteriaName)
        {
            object lReturnValue = null;
            bool IsParam = false;
            string lRptNm = string.Empty;
            string lParamName = string.Empty;
            for (int i = 0; i < CriteiraDv.Count; i++)
            {
                lRptNm = CriteiraDv[i]["RptNm"].ToString();
                IsParam = bool.Parse(CriteiraDv[i]["IsParam"].ToString());
                lParamName = CriteiraDv[i]["FldNm"].ToString();

                if ((lRptNm == mRptNm) && (!IsParam) && (lParamName == aCriteriaName))
                {
                    lReturnValue = CriteiraDv[i]["Value1"];
                    break;
                }
            }
            return lReturnValue;
        }
        public object GetCriteriaValue2(string aCriteriaName)
        {
            object lReturnValue = null;
            bool IsParam = false;
            string lRptNm = string.Empty;
            string lParamName = string.Empty;
            for (int i = 0; i < CriteiraDv.Count; i++)
            {
                lRptNm = CriteiraDv[i]["RptNm"].ToString();
                IsParam = bool.Parse(CriteiraDv[i]["IsParam"].ToString());
                lParamName = CriteiraDv[i]["FldNm"].ToString();

                if ((lRptNm == mRptNm) && (!IsParam) && (lParamName == aCriteriaName))
                {
                    lReturnValue = CriteiraDv[i]["Value2"];
                    break;
                }
            }
            return lReturnValue;
        }
        public string GetParamFullText()
        {
            DataSet lDs = null;
            DataTable lDt = null;
            string lReturnValue = string.Empty;

            lDs = mSysDataRdr.GetSysData("RPT01SrchDtl");
            lDt = lDs.Tables[0];
            if (lDt.Rows.Count != 0)
            {
                for (int i = 0; i < lDt.Rows.Count; i++)
                {
                    if ((bool.Parse(lDt.Rows[i]["Apply"].ToString())) && (lDt.Rows[i]["Value1"] != null))
                    {

                        lReturnValue = lReturnValue + lDt.Rows[i]["FldAls"].ToString() + " " + lDt.Rows[i]["Condition"].ToString() + " " + lDt.Rows[i]["Value1"].ToString() + "\r\r";
                    }
                }
            }
            lReturnValue = TStr.Left(lReturnValue, lReturnValue.Length - 2);
            return lReturnValue;
        }
        public void SetSearchDtl()
        {
            mCriteiraDs = mSysDataRdr.GetSysData("RPT01SrchDtl");
            mCriteiraDt = mCriteiraDs.Tables[0];

            mCriteiraDt.Columns.Remove("Value1");
            mCriteiraDt.Columns.Remove("Value2");

            mCriteiraDt.Columns.Add("Value1", typeof(object));
            mCriteiraDt.Columns.Add("Value2", typeof(object));

            mCriteiraDt.Columns["RptNm"].ColumnMapping = MappingType.Hidden;
            mCriteiraDt.Columns["ItemNo"].ColumnMapping = MappingType.Hidden;
            mCriteiraDt.Columns["FldNm"].ColumnMapping = MappingType.Hidden;
            mCriteiraDt.Columns["FldType"].ColumnMapping = MappingType.Hidden;
            mCriteiraDt.Columns["SelObjID"].ColumnMapping = MappingType.Hidden;
            mCriteiraDt.Columns["BndCol"].ColumnMapping = MappingType.Hidden;
            mCriteiraDt.Columns["Apply"].ColumnMapping = MappingType.Hidden;
            mCriteiraDt.Columns["IsParam"].ColumnMapping = MappingType.Hidden;

            mCriteiraDt.Columns["FldAls"].Caption = string.Empty;
            mCriteiraDt.Columns["FldAls"].ReadOnly = true;
            mCriteiraDt.Columns["Condition"].Caption = string.Empty;
            mCriteiraDt.Columns["Condition"].ReadOnly = true;
            mCriteiraDt.Columns["Value1"].Caption = string.Empty;
            mCriteiraDt.Columns["Value2"].Caption = string.Empty;

            mCriteiraDv.Table = mCriteiraDt;
            mCriteiraDv.Sort = "ItemNo";
        }
        public void AddParam(string aFldType, string aFldNm, string aValue)
        {
            DataRowView lDrv =  mCriteiraDv.AddNew();
            lDrv["RptNm"] = mRptNm;
            lDrv["FldType"] = aFldType;
            lDrv["FldNm"] = aFldNm;
            lDrv["Value1"] = aValue;
            lDrv["IsParam"] = "True";
            lDrv["Apply"] = "True";
            lDrv["Condition"] = "Equals";
            lDrv.EndEdit();
        }
        #endregion
    }
}
