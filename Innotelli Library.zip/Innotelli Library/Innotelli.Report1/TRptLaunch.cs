using System;
using System.Data;
using System.Drawing.Imaging;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Innotelli.Utilities;
using DevExpress.XtraPrinting.Control;
using System.IO;

namespace Innotelli.Report1
{
    public enum OutputEnum
    {
        Preview,
        Print,
        Export,
    }
    public class TRptLaunch : TThreadWrapperBase
    {
        #region Enums
        public enum FilterType
        {
            RptFilter,
            RptCriteria,
            RptDataSet,
        }
        #endregion

        #region Members
        private string mRptNm;
        private TRptFltr mRptFltr = new TRptFltr();
        private string mFilePath;
        private FileFormats mFileFormat;
        #endregion

        #region Constructors
        public TRptLaunch(Control aInvokeContext)
        {
            InvokeContext = aInvokeContext;
            SupportsProgress = true;
            CancelWaitTime = TimeSpan.FromSeconds(0);
        }
        public TRptLaunch()
        {
        }
        #endregion

        #region Properties
        private TRptEngine mRptEngine = new TRptEngine();
        public TRptEngine RptEngine
        {
            set
            {
                mRptEngine = value;
            }
            get
            {
                return mRptEngine;
            }
        }
        private TRptPreview mRptPreview = null;
        public TRptPreview RptPreview
        {
            set
            {
                mRptPreview = value;
            }
            get
            {
                return mRptPreview;
            }
        }
        private OutputEnum mOutput;
        public OutputEnum Output
        {
            get
            {
                return mOutput;
            }
            set
            {
                mOutput = value;
            }
        }
        private string mEmailSubject = string.Empty;
        public string EmailSubject
        {
            get
            {
                return mEmailSubject;
            }
            set
            {
                mEmailSubject = value;
            }
        }
        private string mDefaultFileName;
        public string DefaultFileName
        {
            get
            {
                return mDefaultFileName;
            }
            set
            {
                mDefaultFileName = value;
            }
        }
        private Stream mRptLayout;
        public Stream RptLayout
        {
            get
            {
                return mRptLayout;
            }
            set
            {
                mRptLayout = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        private void BeforePreveiew(string aRptNm)
        {
            mRptPreview = new TRptPreview(this);
            mRptEngine.SPrpsRPT01.RptID = aRptNm;
            mRptPreview.FormTitle = mRptEngine.SPrpsRPT01.RptAls;
            mRptPreview.Show();
        }
        public void ExportToFileAsync(string aRptNm, string aCriteria, string aFilePath, FileFormats aFileFormat)
        {
            mRptEngine.Criteria = aCriteria;
            mFilePath = aFilePath;
            mFileFormat = aFileFormat;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Export;
            Start();
        }
        public void ExportToFileAsync(string aRptNm, DataSet aRptExternalMainDs, string aFilePath, FileFormats aFileFormat)
        {
            mRptEngine.RptExternalMainDs = aRptExternalMainDs;
            mFilePath = aFilePath;
            mFileFormat = aFileFormat;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Export;
            Start();
        }
        public void ExportToFileAsync(string aRptNm, TRptFltr aRptFltr, string aFilePath, FileFormats aFileFormat)
        {
            mRptFltr = new TRptFltr(aRptFltr);
            mRptEngine.RptFltr = mRptFltr;
            mFilePath = aFilePath;
            mFileFormat = aFileFormat;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Export;
            Start();
        }
        public void PreviewAsync(string aRptNm, string aCriteria)
        {
            mRptEngine.Criteria = aCriteria;
            BeforePreveiew(aRptNm);
            mRptNm = aRptNm;
            mOutput = OutputEnum.Preview;
            Start();
        }
        public void PreviewAsync(string aRptNm, DataSet aRptExternalMainDs)
        {
            mRptEngine.RptExternalMainDs = aRptExternalMainDs;
            BeforePreveiew(aRptNm);
            mRptNm = aRptNm;
            mOutput = OutputEnum.Preview;
            Start();
        }
        public void PreviewAsync(string aRptNm, TRptFltr aRptFltr)
        {
            mRptFltr = new TRptFltr(aRptFltr);
            mRptEngine.RptFltr = mRptFltr;
            BeforePreveiew(aRptNm);
            mRptNm = aRptNm;
            mOutput = OutputEnum.Preview;
            Start();
        }
        public void PrintAsync(string aRptNm, string aCriteria)
        {
            mRptEngine.Criteria = aCriteria;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Print;
            Start();
        }
        public void PrintAsync(string aRptNm, DataSet aRptExternalMainDs)
        {
            mRptEngine.RptExternalMainDs = aRptExternalMainDs;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Print;
            Start();
        }
        public void PrintAsync(string aRptNm, TRptFltr aRptFltr)
        {
            mRptFltr = new TRptFltr(aRptFltr);
            mRptEngine.RptFltr = mRptFltr;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Print;
            Start();
        }
        public void ExportToFile(string aRptNm, string aCriteria, string aFilePath, FileFormats aFileFormat)
        {
            mRptEngine.Criteria = aCriteria;
            mFilePath = aFilePath;
            mFileFormat = aFileFormat;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Export;
            DoTaskSync();
            CompleteTask();
        }
        public void ExportToFile(string aRptNm, DataSet aRptExternalMainDs, string aFilePath, FileFormats aFileFormat)
        {
            mRptEngine.RptExternalMainDs = aRptExternalMainDs;
            mFilePath = aFilePath;
            mFileFormat = aFileFormat;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Export;
            DoTaskSync();
            CompleteTask();
        }
        public void ExportToFile(string aRptNm, TRptFltr aRptFltr, string aFilePath, FileFormats aFileFormat)
        {
            mRptFltr = new TRptFltr(aRptFltr);
            mRptEngine.RptFltr = mRptFltr;
            mFilePath = aFilePath;
            mFileFormat = aFileFormat;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Export;
            DoTaskSync();
            CompleteTask();
        }
        public void Preview(string aRptNm, string aCriteria)
        {
            mRptEngine.Criteria = aCriteria;
            BeforePreveiew(aRptNm);
            mRptNm = aRptNm;
            mOutput = OutputEnum.Preview;
            DoTaskSync();
            CompleteTask();
        }
        public void Preview(string aRptNm, DataSet aRptExternalMainDs)
        {
            mRptEngine.RptExternalMainDs = aRptExternalMainDs;
            BeforePreveiew(aRptNm);
            mRptNm = aRptNm;
            mOutput = OutputEnum.Preview;
            DoTaskSync();
            CompleteTask();
        }
        public void Preview(string aRptNm, TRptFltr aRptFltr)
        {
            BeforePreveiew(aRptNm);
            mRptFltr = new TRptFltr(aRptFltr);
            mRptEngine.RptFltr = mRptFltr;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Preview;
            DoTaskSync();
            CompleteTask();
        }
        public void Print(string aRptNm, string aCriteria)
        {
            mRptEngine.Criteria = aCriteria;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Print;
            DoTaskSync();
            CompleteTask();
        }
        public void Print(string aRptNm, DataSet aRptExternalMainDs)
        {
            mRptEngine.RptExternalMainDs = aRptExternalMainDs;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Print;
            DoTaskSync();
            CompleteTask();
        }
        public void Print(string aRptNm, TRptFltr aRptFltr)
        {
            mRptFltr = new TRptFltr(aRptFltr);
            mRptEngine.RptFltr = mRptFltr;
            mRptNm = aRptNm;
            mOutput = OutputEnum.Print;
            DoTaskSync();
            CompleteTask();
        }
        public void UpdateRptPreview()
        {
        }
        public void CreateDocument()
        {
            if (mOutput == OutputEnum.Preview)
            {
                mRptEngine.XRpt.CreateDocument();
            }
            else if (mOutput == OutputEnum.Print)
            {
                mRptEngine.XRpt.Print();
            }
            else if (mOutput == OutputEnum.Export)
            {
                mRptEngine.ExportToFile(mFilePath, mFileFormat);
            }
        }
        public void CompleteTask()
        {
            if (mOutput == OutputEnum.Preview)
            {
                mRptPreview.XRpt = mRptEngine.XRpt;
                RptPreview.PrintingSystem = RptEngine.XRpt.PrintingSystem;
                mRptPreview.InProgress = false;
            }
        }
        private void DoTaskSync()
        {
            try
            {
                mRptEngine.RptNm = mRptNm;
                mRptEngine.LoadRptLayout(mRptLayout);
                mRptEngine.ProcessPhase1();
                mRptEngine.ProcessPhase2();
                CreateDocument();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\r\n" + ex.StackTrace);
            }
        }
        protected override void DoTask()
        {
            try
            {
                Progress = 1;//creat report object
                mRptEngine.RptNm = mRptNm;
                Progress = 2;
                mRptEngine.LoadRptLayout(mRptLayout);
                Progress = 3; //process dataset
                mRptEngine.ProcessPhase1();
                Progress = 4; //gen before render data
                mRptEngine.ProcessPhase2();
                Progress = 5; //create document for preview, export or print
                CreateDocument();
                Progress = 6; //complete task
            }
            catch (Exception ex)
            {
                Progress = 77;
                MessageBox.Show(ex.Message + "\r\n" + ex.StackTrace);
            }
        }
        #endregion
    }
}
