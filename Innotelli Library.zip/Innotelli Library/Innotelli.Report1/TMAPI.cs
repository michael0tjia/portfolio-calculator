using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Innotelli.Report1
{
    public class TMAPI
    {

        public TMAPI()
        {

        }

        public void Send(string aProfile, string aRecipients, string aText, string aSubject, string aFilePath)
        {
            //Return a reference to the MAPI layer
            Microsoft.Office.Interop.Outlook.Application lApp = new Microsoft.Office.Interop.Outlook.Application();
            Microsoft.Office.Interop.Outlook._NameSpace lNameSpace = lApp.GetNamespace("MAPI");
            //private Outlook.MAPIFolder lOutboxFolder;

            /***********************************************************************
              * Logs on the user
              * Profile: Set to null if using the currently logged on user, or set 
              *    to an empty string ("") if you wish to use the default Outlook Profile. 
              * Password: Set to null if  using the currently logged on user, or set 
              *    to an empty string ("") if you wish to use the default Outlook Profile
              *    password. 
              * ShowDialog: Set to True to display the Outlook Profile dialog box. 
              * NewSession: Set to True to start a new session. Set to False to 
              *    use the current session. 
              ***********************************************************************/
            if (aProfile == "")
            {
                lNameSpace.Logon("", "", false, true);
            }
            else
            {
                lNameSpace.Logon(aProfile, "", false, true);
            }

            //gets defaultfolder for my Outlook Outbox
            //lOutboxFolder = lNameSpace.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderOutbox);

            //creates a new MailItem object
            Microsoft.Office.Interop.Outlook._MailItem lMailItem = (Microsoft.Office.Interop.Outlook._MailItem)lApp.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);

            lMailItem.To = aRecipients;
            lMailItem.Subject = aSubject;
            lMailItem.Body = aText;

            if (File.Exists(aFilePath))
            {
                int lStart = aFilePath.LastIndexOf("\\");
                int lEnd = aFilePath.LastIndexOf('.');
                string lFlNm = aFilePath.Substring(lStart + 1, lEnd - lStart - 1);
                lMailItem.Attachments.Add(aFilePath, Microsoft.Office.Interop.Outlook.OlAttachmentType.olByValue, 1, lFlNm);
            }

            //lMailItem.SaveSentMessageFolder = lOutboxFolder;
            lMailItem.Display(false);

            lMailItem.Save();
            //lMailItem.Send();

            lApp = null;
            lNameSpace = null;
            //lOutboxFolder = null;
            lMailItem = null;
        }
    }
}
