namespace Innotelli.Report1 {
	partial class TDesignerForm {
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing) {
			if(disposing && (components != null)) {
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            DevExpress.Utils.SuperToolTip superToolTip1 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem1 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem1 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip2 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem2 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem2 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip3 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem3 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem3 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip4 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem4 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem4 = new DevExpress.Utils.ToolTipItem();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TDesignerForm));
            DevExpress.Utils.SuperToolTip superToolTip5 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem5 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem5 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip6 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem6 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem6 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip7 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem7 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem7 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip8 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem8 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem8 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip9 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem9 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem9 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip10 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem10 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem10 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip11 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem11 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem11 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip12 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem12 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem12 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip13 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem13 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem13 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip14 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem14 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem14 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip15 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem15 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem15 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip16 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem16 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem16 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip17 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem17 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem17 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip18 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem18 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem18 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip19 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem19 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem19 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip20 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem20 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem20 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip21 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem21 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem21 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip22 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem22 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem22 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip23 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem23 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem23 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip24 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem24 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem24 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip25 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem25 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem25 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip26 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem26 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem26 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip27 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem27 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem27 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip28 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem28 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem28 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip29 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem29 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem29 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip30 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem30 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem30 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip31 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem31 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem31 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip32 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem32 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem32 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip33 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem33 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem33 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip34 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem34 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem34 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip35 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem35 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem35 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip36 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem36 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem36 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip37 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem37 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem37 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip38 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem38 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem38 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip39 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem39 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem39 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip40 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem40 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem40 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip41 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem41 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem41 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip42 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem42 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem42 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip43 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem43 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem43 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip44 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem44 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem44 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip45 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem45 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem45 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip46 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem46 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem46 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip47 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem47 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem47 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip48 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem48 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem48 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip49 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem49 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem49 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip50 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem50 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem50 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip51 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem51 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem51 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip52 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem52 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem52 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip53 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem53 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem53 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip54 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem54 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem54 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip55 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem55 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem55 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip56 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem56 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem56 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip57 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem57 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem57 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip58 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem58 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem58 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip59 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem59 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem59 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip60 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem60 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem60 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip61 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem61 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem61 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip62 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem62 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem62 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip63 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem63 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem63 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip64 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem64 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem64 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip65 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem65 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem65 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip66 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem66 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem66 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip67 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem67 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem67 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip68 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem68 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem68 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip69 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem69 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem69 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip70 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem70 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem70 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip71 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem71 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem71 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip72 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem72 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem72 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip73 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem73 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem73 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip74 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem74 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem74 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip75 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem75 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem75 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip76 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem76 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem76 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip77 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem77 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem77 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip78 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem78 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem78 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip79 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem79 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem79 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip80 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem80 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem80 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip81 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem81 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem81 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip82 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem82 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem82 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip83 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem83 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem83 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip84 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem84 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem84 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip85 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem85 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem85 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip86 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem86 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem86 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip87 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem87 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem87 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip88 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem88 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem88 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip89 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem89 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem89 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip90 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem90 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem90 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip91 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem91 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem91 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip92 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem92 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem92 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip93 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem93 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem93 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip94 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem94 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem94 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip95 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem95 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem95 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip96 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem96 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem96 = new DevExpress.Utils.ToolTipItem();
            DevExpress.Utils.SuperToolTip superToolTip97 = new DevExpress.Utils.SuperToolTip();
            DevExpress.Utils.ToolTipTitleItem toolTipTitleItem97 = new DevExpress.Utils.ToolTipTitleItem();
            DevExpress.Utils.ToolTipItem toolTipItem97 = new DevExpress.Utils.ToolTipItem();
            this.recentlyUsedItemsComboBox1 = new DevExpress.XtraReports.UserDesigner.RecentlyUsedItemsComboBox();
            this.designRepositoryItemComboBox1 = new DevExpress.XtraReports.UserDesigner.DesignRepositoryItemComboBox();
            this.ribbonControl1 = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.applicationMenu1 = new DevExpress.XtraBars.Ribbon.ApplicationMenu(this.components);
            this.barSubItem3 = new DevExpress.XtraBars.BarSubItem();
            this.commandBarItem33 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem34 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem35 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem32 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonGallerySkins = new DevExpress.XtraBars.RibbonGalleryBarItem();
            this.barStaticItem1 = new DevExpress.XtraBars.BarStaticItem();
            this.commandBarItem1 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem2 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem3 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem4 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem5 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem6 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem7 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem8 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem9 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem10 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem11 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem12 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem13 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem14 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem15 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem16 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem17 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem18 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem19 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem20 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem21 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem22 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem23 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem24 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem25 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem26 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandColorBarItem1 = new DevExpress.XtraReports.UserDesigner.CommandColorBarItem();
            this.commandColorBarItem2 = new DevExpress.XtraReports.UserDesigner.CommandColorBarItem();
            this.commandBarItem27 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem28 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem29 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem30 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem31 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem36 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem37 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem38 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem39 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem40 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem41 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem42 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem43 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem44 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem45 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.barEditItem1 = new DevExpress.XtraBars.BarEditItem();
            this.barEditItem2 = new DevExpress.XtraBars.BarEditItem();
            this.barDockPanelsListItem1 = new DevExpress.XtraReports.UserDesigner.BarDockPanelsListItem();
            this.commandBarItem46 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem47 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem48 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem49 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.commandBarItem50 = new DevExpress.XtraReports.UserDesigner.CommandBarItem();
            this.xrDesignBarButtonGroup1 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup2 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup3 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup4 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup5 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup6 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup7 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup8 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.xrDesignBarButtonGroup9 = new DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup();
            this.printPreviewBarItem1 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem2 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem3 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem4 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem5 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem6 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem7 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem8 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem9 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem10 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem11 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem12 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem13 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem14 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem15 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem16 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem17 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem18 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem19 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem20 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem21 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem22 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem23 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem24 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem25 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem26 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem27 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem28 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem29 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem30 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem31 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem32 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem33 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem34 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem36 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem37 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem38 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem39 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem40 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem41 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem42 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewStaticItem1 = new DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem();
            this.printPreviewStaticItem2 = new DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem();
            this.printPreviewStaticItem3 = new DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem();
            this.printPreviewBarItem35 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewBarItem43 = new DevExpress.XtraPrinting.Preview.PrintPreviewBarItem();
            this.printPreviewRibbonPage1 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPage();
            this.printPreviewRibbonPageGroup7 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup1 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup2 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup3 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup4 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup5 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.printPreviewRibbonPageGroup6 = new DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup();
            this.xrHtmlRibbonPage1 = new DevExpress.XtraReports.UserDesigner.XRHtmlRibbonPage();
            this.xrDesignRibbonPageGroup8 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPage1 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPage();
            this.xrDesignRibbonPageGroup1 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup2 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup3 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup4 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup5 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup6 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.xrDesignRibbonPageGroup7 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemTextEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemTextEdit3 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemTextEdit4 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemTextEdit5 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemTextEdit6 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemTextEdit7 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.repositoryItemTextEdit8 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.ribbonStatusBar1 = new DevExpress.XtraBars.Ribbon.RibbonStatusBar();
            this.defaultLookAndFeel1 = new DevExpress.LookAndFeel.DefaultLookAndFeel(this.components);
            this.xrDesignRibbonController1 = new DevExpress.XtraReports.UserDesigner.XRDesignRibbonController();
            this.xrDesignDockManager1 = new DevExpress.XtraReports.UserDesigner.XRDesignDockManager();
            this.panelContainer1 = new DevExpress.XtraBars.Docking.DockPanel();
            this.panelContainer2 = new DevExpress.XtraBars.Docking.DockPanel();
            this.fieldListDockPanel1 = new DevExpress.XtraReports.UserDesigner.FieldListDockPanel();
            this.fieldListDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            this.xrDesignPanel1 = new DevExpress.XtraReports.UserDesigner.XRDesignPanel();
            this.reportExplorerDockPanel1 = new DevExpress.XtraReports.UserDesigner.ReportExplorerDockPanel();
            this.reportExplorerDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            this.propertyGridDockPanel1 = new DevExpress.XtraReports.UserDesigner.PropertyGridDockPanel();
            this.propertyGridDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            this.toolBoxDockPanel1 = new DevExpress.XtraReports.UserDesigner.ToolBoxDockPanel();
            this.toolBoxDockPanel1_Container = new DevExpress.XtraReports.UserDesigner.DesignControlContainer();
            ((System.ComponentModel.ISupportInitialize)(this.recentlyUsedItemsComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.designRepositoryItemComboBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.applicationMenu1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignRibbonController1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignDockManager1)).BeginInit();
            this.panelContainer1.SuspendLayout();
            this.panelContainer2.SuspendLayout();
            this.fieldListDockPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignPanel1)).BeginInit();
            this.reportExplorerDockPanel1.SuspendLayout();
            this.propertyGridDockPanel1.SuspendLayout();
            this.toolBoxDockPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // recentlyUsedItemsComboBox1
            // 
            this.recentlyUsedItemsComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.recentlyUsedItemsComboBox1.Name = "recentlyUsedItemsComboBox1";
            // 
            // designRepositoryItemComboBox1
            // 
            this.designRepositoryItemComboBox1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.designRepositoryItemComboBox1.Name = "designRepositoryItemComboBox1";
            // 
            // ribbonControl1
            // 
            this.ribbonControl1.ApplicationButtonDropDownControl = this.applicationMenu1;
            this.ribbonControl1.ApplicationButtonKeyTip = "";
            this.ribbonControl1.ApplicationIcon = null;
            this.ribbonControl1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbonGallerySkins,
            this.barStaticItem1,
            this.commandBarItem1,
            this.commandBarItem2,
            this.commandBarItem3,
            this.commandBarItem4,
            this.commandBarItem5,
            this.commandBarItem6,
            this.commandBarItem7,
            this.commandBarItem8,
            this.commandBarItem9,
            this.commandBarItem10,
            this.commandBarItem11,
            this.commandBarItem12,
            this.commandBarItem13,
            this.commandBarItem14,
            this.commandBarItem15,
            this.commandBarItem16,
            this.commandBarItem17,
            this.commandBarItem18,
            this.commandBarItem19,
            this.commandBarItem20,
            this.commandBarItem21,
            this.commandBarItem22,
            this.commandBarItem23,
            this.commandBarItem24,
            this.commandBarItem25,
            this.commandBarItem26,
            this.commandColorBarItem1,
            this.commandColorBarItem2,
            this.commandBarItem27,
            this.commandBarItem28,
            this.commandBarItem29,
            this.commandBarItem30,
            this.commandBarItem31,
            this.commandBarItem32,
            this.commandBarItem33,
            this.commandBarItem34,
            this.commandBarItem35,
            this.commandBarItem36,
            this.commandBarItem37,
            this.commandBarItem38,
            this.commandBarItem39,
            this.commandBarItem40,
            this.commandBarItem41,
            this.commandBarItem42,
            this.commandBarItem43,
            this.commandBarItem44,
            this.commandBarItem45,
            this.barEditItem1,
            this.barEditItem2,
            this.barDockPanelsListItem1,
            this.commandBarItem46,
            this.commandBarItem47,
            this.commandBarItem48,
            this.commandBarItem49,
            this.commandBarItem50,
            this.xrDesignBarButtonGroup1,
            this.xrDesignBarButtonGroup2,
            this.xrDesignBarButtonGroup3,
            this.xrDesignBarButtonGroup4,
            this.xrDesignBarButtonGroup5,
            this.xrDesignBarButtonGroup6,
            this.xrDesignBarButtonGroup7,
            this.xrDesignBarButtonGroup8,
            this.xrDesignBarButtonGroup9,
            this.printPreviewBarItem1,
            this.printPreviewBarItem2,
            this.printPreviewBarItem3,
            this.printPreviewBarItem4,
            this.printPreviewBarItem5,
            this.printPreviewBarItem6,
            this.printPreviewBarItem7,
            this.printPreviewBarItem8,
            this.printPreviewBarItem9,
            this.printPreviewBarItem10,
            this.printPreviewBarItem11,
            this.printPreviewBarItem12,
            this.printPreviewBarItem13,
            this.printPreviewBarItem14,
            this.printPreviewBarItem15,
            this.printPreviewBarItem16,
            this.printPreviewBarItem17,
            this.printPreviewBarItem18,
            this.printPreviewBarItem19,
            this.printPreviewBarItem20,
            this.printPreviewBarItem21,
            this.printPreviewBarItem22,
            this.printPreviewBarItem23,
            this.printPreviewBarItem24,
            this.printPreviewBarItem25,
            this.printPreviewBarItem26,
            this.printPreviewBarItem27,
            this.printPreviewBarItem28,
            this.printPreviewBarItem29,
            this.printPreviewBarItem30,
            this.printPreviewBarItem31,
            this.printPreviewBarItem32,
            this.printPreviewBarItem33,
            this.printPreviewBarItem34,
            this.printPreviewBarItem36,
            this.printPreviewBarItem37,
            this.printPreviewBarItem38,
            this.printPreviewBarItem39,
            this.printPreviewBarItem40,
            this.printPreviewBarItem41,
            this.printPreviewBarItem42,
            this.printPreviewStaticItem1,
            this.printPreviewStaticItem2,
            this.printPreviewStaticItem3,
            this.barButtonItem1,
            this.barSubItem3,
            this.printPreviewBarItem35,
            this.printPreviewBarItem43});
            this.ribbonControl1.Location = new System.Drawing.Point(0, 0);
            this.ribbonControl1.MaxItemId = 31;
            this.ribbonControl1.Name = "ribbonControl1";
            this.ribbonControl1.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.xrDesignRibbonPage1,
            this.printPreviewRibbonPage1,
            this.xrHtmlRibbonPage1,
            this.ribbonPage1});
            this.ribbonControl1.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemTextEdit1,
            this.repositoryItemTextEdit2,
            this.repositoryItemTextEdit3,
            this.repositoryItemTextEdit4,
            this.repositoryItemTextEdit5,
            this.repositoryItemTextEdit6,
            this.repositoryItemTextEdit7,
            this.repositoryItemTextEdit8});
            this.ribbonControl1.SelectedPage = this.xrDesignRibbonPage1;
            this.ribbonControl1.ShowPageHeadersMode = DevExpress.XtraBars.Ribbon.ShowPageHeadersMode.ShowOnMultiplePages;
            this.ribbonControl1.Size = new System.Drawing.Size(1122, 149);
            this.ribbonControl1.StatusBar = this.ribbonStatusBar1;
            this.ribbonControl1.Toolbar.ItemLinks.Add(this.commandBarItem37);
            // 
            // applicationMenu1
            // 
            this.applicationMenu1.BottomPaneControlContainer = null;
            this.applicationMenu1.ItemLinks.Add(this.barSubItem3, true);
            this.applicationMenu1.ItemLinks.Add(this.commandBarItem35);
            this.applicationMenu1.ItemLinks.Add(this.commandBarItem32);
            this.applicationMenu1.ItemLinks.Add(this.barButtonItem1, true);
            this.applicationMenu1.Name = "applicationMenu1";
            this.applicationMenu1.Ribbon = this.ribbonControl1;
            this.applicationMenu1.RightPaneControlContainer = null;
            this.applicationMenu1.RightPaneWidth = 240;
            this.applicationMenu1.ShowRightPane = true;
            // 
            // barSubItem3
            // 
            this.barSubItem3.Caption = "New";
            this.barSubItem3.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_NewReport;
            this.barSubItem3.Id = 28;
            this.barSubItem3.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_NewReportLarge;
            this.barSubItem3.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem33),
            new DevExpress.XtraBars.LinkPersistInfo(this.commandBarItem34)});
            this.barSubItem3.Name = "barSubItem3";
            // 
            // commandBarItem33
            // 
            this.commandBarItem33.Caption = "New Report";
            this.commandBarItem33.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.NewReport;
            this.commandBarItem33.Description = "Create a new blank report so that you can insert fields and controls and design a" +
                " report.";
            this.commandBarItem33.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_NewReport;
            this.commandBarItem33.Id = 34;
            this.commandBarItem33.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N));
            this.commandBarItem33.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_NewReportLarge;
            this.commandBarItem33.Name = "commandBarItem33";
            superToolTip1.FixedTooltipWidth = true;
            toolTipTitleItem1.Text = "New Blank Report (Ctrl+N)";
            toolTipItem1.LeftIndent = 6;
            toolTipItem1.Text = "Create a new blank report so that you can insert fields and controls and design a" +
                " report.";
            superToolTip1.Items.Add(toolTipTitleItem1);
            superToolTip1.Items.Add(toolTipItem1);
            superToolTip1.MaxWidth = 210;
            this.commandBarItem33.SuperTip = superToolTip1;
            // 
            // commandBarItem34
            // 
            this.commandBarItem34.Caption = "New via Wizard...";
            this.commandBarItem34.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.NewReportWizard;
            this.commandBarItem34.Description = "Launch the report wizard which helps you to create simple, customized reports.";
            this.commandBarItem34.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_NewReportWizard;
            this.commandBarItem34.Id = 35;
            this.commandBarItem34.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.W));
            this.commandBarItem34.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_NewReportWizardLarge;
            this.commandBarItem34.Name = "commandBarItem34";
            superToolTip2.FixedTooltipWidth = true;
            toolTipTitleItem2.Text = "New Report via Wizard (Ctrl+W)";
            toolTipItem2.LeftIndent = 6;
            toolTipItem2.Text = "Launch the report wizard which helps you to create simple, customized reports.";
            superToolTip2.Items.Add(toolTipTitleItem2);
            superToolTip2.Items.Add(toolTipItem2);
            superToolTip2.MaxWidth = 210;
            this.commandBarItem34.SuperTip = superToolTip2;
            // 
            // commandBarItem35
            // 
            this.commandBarItem35.Caption = "Open...";
            this.commandBarItem35.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.OpenFile;
            this.commandBarItem35.Description = null;
            this.commandBarItem35.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_OpenFile;
            this.commandBarItem35.Id = 36;
            this.commandBarItem35.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O));
            this.commandBarItem35.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_OpenFileLarge;
            this.commandBarItem35.Name = "commandBarItem35";
            superToolTip3.FixedTooltipWidth = true;
            toolTipTitleItem3.Text = "Open Report (Ctrl+O)";
            toolTipItem3.LeftIndent = 6;
            toolTipItem3.Text = "Open a report.";
            superToolTip3.Items.Add(toolTipTitleItem3);
            superToolTip3.Items.Add(toolTipItem3);
            superToolTip3.MaxWidth = 210;
            this.commandBarItem35.SuperTip = superToolTip3;
            // 
            // commandBarItem32
            // 
            this.commandBarItem32.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem32.Caption = "Save";
            this.commandBarItem32.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SaveFile;
            this.commandBarItem32.Description = null;
            this.commandBarItem32.Enabled = false;
            this.commandBarItem32.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_SaveFile;
            this.commandBarItem32.Id = 33;
            this.commandBarItem32.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_SaveFileLarge;
            this.commandBarItem32.Name = "commandBarItem32";
            superToolTip4.FixedTooltipWidth = true;
            toolTipTitleItem4.Text = "Save Report";
            toolTipItem4.LeftIndent = 6;
            toolTipItem4.Text = "Save a report.";
            superToolTip4.Items.Add(toolTipTitleItem4);
            superToolTip4.Items.Add(toolTipItem4);
            superToolTip4.MaxWidth = 210;
            this.commandBarItem32.SuperTip = superToolTip4;
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "Exit";
            this.barButtonItem1.Description = "Closes this program after prompting you to save unsaved report.";
            this.barButtonItem1.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ClosePreview;
            this.barButtonItem1.Hint = "Closes this program after prompting you to save unsaved report.";
            this.barButtonItem1.Id = 27;
            this.barButtonItem1.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ClosePreviewLarge;
            this.barButtonItem1.Name = "barButtonItem1";
            this.barButtonItem1.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem1_ItemClick);
            // 
            // ribbonGallerySkins
            // 
            this.ribbonGallerySkins.Caption = "Skins";
            this.ribbonGallerySkins.Id = 5;
            this.ribbonGallerySkins.Name = "ribbonGallerySkins";
            // 
            // barStaticItem1
            // 
            this.barStaticItem1.Caption = resources.GetString("barStaticItem1.Caption");
            this.barStaticItem1.Id = 6;
            this.barStaticItem1.Name = "barStaticItem1";
            this.barStaticItem1.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // commandBarItem1
            // 
            this.commandBarItem1.Caption = "Align to Grid";
            this.commandBarItem1.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignToGrid;
            this.commandBarItem1.Description = null;
            this.commandBarItem1.Enabled = false;
            this.commandBarItem1.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_AlignToGrid;
            this.commandBarItem1.Id = 0;
            this.commandBarItem1.Name = "commandBarItem1";
            superToolTip5.FixedTooltipWidth = true;
            toolTipTitleItem5.Text = "Align to Grid";
            toolTipItem5.LeftIndent = 6;
            toolTipItem5.Text = "Align the positions of the selected controls to the grid.";
            superToolTip5.Items.Add(toolTipTitleItem5);
            superToolTip5.Items.Add(toolTipItem5);
            superToolTip5.MaxWidth = 210;
            this.commandBarItem1.SuperTip = superToolTip5;
            // 
            // commandBarItem2
            // 
            this.commandBarItem2.Caption = "Align Lefts";
            this.commandBarItem2.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignLeft;
            this.commandBarItem2.Description = null;
            this.commandBarItem2.Enabled = false;
            this.commandBarItem2.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_AlignLeft;
            this.commandBarItem2.Id = 1;
            this.commandBarItem2.Name = "commandBarItem2";
            superToolTip6.FixedTooltipWidth = true;
            toolTipTitleItem6.Text = "Align Lefts";
            toolTipItem6.LeftIndent = 6;
            toolTipItem6.Text = "Left align the selected controls.";
            superToolTip6.Items.Add(toolTipTitleItem6);
            superToolTip6.Items.Add(toolTipItem6);
            superToolTip6.MaxWidth = 210;
            this.commandBarItem2.SuperTip = superToolTip6;
            // 
            // commandBarItem3
            // 
            this.commandBarItem3.Caption = "Align Centers";
            this.commandBarItem3.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignVerticalCenters;
            this.commandBarItem3.Description = null;
            this.commandBarItem3.Enabled = false;
            this.commandBarItem3.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_AlignVerticalCenters;
            this.commandBarItem3.Id = 2;
            this.commandBarItem3.Name = "commandBarItem3";
            superToolTip7.FixedTooltipWidth = true;
            toolTipTitleItem7.Text = "Align Centers";
            toolTipItem7.LeftIndent = 6;
            toolTipItem7.Text = "Align the centers of the selected controls vertically.";
            superToolTip7.Items.Add(toolTipTitleItem7);
            superToolTip7.Items.Add(toolTipItem7);
            superToolTip7.MaxWidth = 210;
            this.commandBarItem3.SuperTip = superToolTip7;
            // 
            // commandBarItem4
            // 
            this.commandBarItem4.Caption = "Align Rights";
            this.commandBarItem4.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignRight;
            this.commandBarItem4.Description = null;
            this.commandBarItem4.Enabled = false;
            this.commandBarItem4.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_AlignRight;
            this.commandBarItem4.Id = 3;
            this.commandBarItem4.Name = "commandBarItem4";
            superToolTip8.FixedTooltipWidth = true;
            toolTipTitleItem8.Text = "Align Rights";
            toolTipItem8.LeftIndent = 6;
            toolTipItem8.Text = "Right align the selected controls.";
            superToolTip8.Items.Add(toolTipTitleItem8);
            superToolTip8.Items.Add(toolTipItem8);
            superToolTip8.MaxWidth = 210;
            this.commandBarItem4.SuperTip = superToolTip8;
            // 
            // commandBarItem5
            // 
            this.commandBarItem5.Caption = "Align Tops";
            this.commandBarItem5.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignTop;
            this.commandBarItem5.Description = null;
            this.commandBarItem5.Enabled = false;
            this.commandBarItem5.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_AlignTop;
            this.commandBarItem5.Id = 4;
            this.commandBarItem5.Name = "commandBarItem5";
            superToolTip9.FixedTooltipWidth = true;
            toolTipTitleItem9.Text = "Align Tops";
            toolTipItem9.LeftIndent = 6;
            toolTipItem9.Text = "Align the tops of the selected controls.";
            superToolTip9.Items.Add(toolTipTitleItem9);
            superToolTip9.Items.Add(toolTipItem9);
            superToolTip9.MaxWidth = 210;
            this.commandBarItem5.SuperTip = superToolTip9;
            // 
            // commandBarItem6
            // 
            this.commandBarItem6.Caption = "Align Middles";
            this.commandBarItem6.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignHorizontalCenters;
            this.commandBarItem6.Description = null;
            this.commandBarItem6.Enabled = false;
            this.commandBarItem6.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_AlignHorizontalCenters;
            this.commandBarItem6.Id = 5;
            this.commandBarItem6.Name = "commandBarItem6";
            superToolTip10.FixedTooltipWidth = true;
            toolTipTitleItem10.Text = "Align Middles";
            toolTipItem10.LeftIndent = 6;
            toolTipItem10.Text = "Align the centers of the selected controls horizontally.";
            superToolTip10.Items.Add(toolTipTitleItem10);
            superToolTip10.Items.Add(toolTipItem10);
            superToolTip10.MaxWidth = 210;
            this.commandBarItem6.SuperTip = superToolTip10;
            // 
            // commandBarItem7
            // 
            this.commandBarItem7.Caption = "Align Bottoms";
            this.commandBarItem7.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.AlignBottom;
            this.commandBarItem7.Description = null;
            this.commandBarItem7.Enabled = false;
            this.commandBarItem7.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_AlignBottom;
            this.commandBarItem7.Id = 6;
            this.commandBarItem7.Name = "commandBarItem7";
            superToolTip11.FixedTooltipWidth = true;
            toolTipTitleItem11.Text = "Align Bottoms";
            toolTipItem11.LeftIndent = 6;
            toolTipItem11.Text = "Align the bottoms of the selected controls.";
            superToolTip11.Items.Add(toolTipTitleItem11);
            superToolTip11.Items.Add(toolTipItem11);
            superToolTip11.MaxWidth = 210;
            this.commandBarItem7.SuperTip = superToolTip11;
            // 
            // commandBarItem8
            // 
            this.commandBarItem8.Caption = "Make Same Width";
            this.commandBarItem8.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToControlWidth;
            this.commandBarItem8.Description = null;
            this.commandBarItem8.Enabled = false;
            this.commandBarItem8.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_SizeToControlWidth;
            this.commandBarItem8.Id = 7;
            this.commandBarItem8.Name = "commandBarItem8";
            superToolTip12.FixedTooltipWidth = true;
            toolTipTitleItem12.Text = "Make Same Width";
            toolTipItem12.LeftIndent = 6;
            toolTipItem12.Text = "Make the selected controls have the same width.";
            superToolTip12.Items.Add(toolTipTitleItem12);
            superToolTip12.Items.Add(toolTipItem12);
            superToolTip12.MaxWidth = 210;
            this.commandBarItem8.SuperTip = superToolTip12;
            // 
            // commandBarItem9
            // 
            this.commandBarItem9.Caption = "Size to Grid";
            this.commandBarItem9.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToGrid;
            this.commandBarItem9.Description = null;
            this.commandBarItem9.Enabled = false;
            this.commandBarItem9.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_SizeToGrid;
            this.commandBarItem9.Id = 8;
            this.commandBarItem9.Name = "commandBarItem9";
            superToolTip13.FixedTooltipWidth = true;
            toolTipTitleItem13.Text = "Size to Grid";
            toolTipItem13.LeftIndent = 6;
            toolTipItem13.Text = "Size the selected controls to the grid.";
            superToolTip13.Items.Add(toolTipTitleItem13);
            superToolTip13.Items.Add(toolTipItem13);
            superToolTip13.MaxWidth = 210;
            this.commandBarItem9.SuperTip = superToolTip13;
            // 
            // commandBarItem10
            // 
            this.commandBarItem10.Caption = "Make Same Height";
            this.commandBarItem10.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToControlHeight;
            this.commandBarItem10.Description = null;
            this.commandBarItem10.Enabled = false;
            this.commandBarItem10.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_SizeToControlHeight;
            this.commandBarItem10.Id = 9;
            this.commandBarItem10.Name = "commandBarItem10";
            superToolTip14.FixedTooltipWidth = true;
            toolTipTitleItem14.Text = "Make Same Height";
            toolTipItem14.LeftIndent = 6;
            toolTipItem14.Text = "Make the selected controls have the same height.";
            superToolTip14.Items.Add(toolTipTitleItem14);
            superToolTip14.Items.Add(toolTipItem14);
            superToolTip14.MaxWidth = 210;
            this.commandBarItem10.SuperTip = superToolTip14;
            // 
            // commandBarItem11
            // 
            this.commandBarItem11.Caption = "Make Same Size";
            this.commandBarItem11.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SizeToControl;
            this.commandBarItem11.Description = null;
            this.commandBarItem11.Enabled = false;
            this.commandBarItem11.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_SizeToControl;
            this.commandBarItem11.Id = 10;
            this.commandBarItem11.Name = "commandBarItem11";
            superToolTip15.FixedTooltipWidth = true;
            toolTipTitleItem15.Text = "Make Same Size";
            toolTipItem15.LeftIndent = 6;
            toolTipItem15.Text = "Make the selected controls have the same size.";
            superToolTip15.Items.Add(toolTipTitleItem15);
            superToolTip15.Items.Add(toolTipItem15);
            superToolTip15.MaxWidth = 210;
            this.commandBarItem11.SuperTip = superToolTip15;
            // 
            // commandBarItem12
            // 
            this.commandBarItem12.Caption = "Make Horizontal Spacing Equal";
            this.commandBarItem12.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceMakeEqual;
            this.commandBarItem12.Description = null;
            this.commandBarItem12.Enabled = false;
            this.commandBarItem12.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_HorizSpaceMakeEqual;
            this.commandBarItem12.Id = 11;
            this.commandBarItem12.Name = "commandBarItem12";
            superToolTip16.FixedTooltipWidth = true;
            toolTipTitleItem16.Text = "Make Horizontal Spacing Equal";
            toolTipItem16.LeftIndent = 6;
            toolTipItem16.Text = "Make the horizontal spacing between the selected controls equal.";
            superToolTip16.Items.Add(toolTipTitleItem16);
            superToolTip16.Items.Add(toolTipItem16);
            superToolTip16.MaxWidth = 210;
            this.commandBarItem12.SuperTip = superToolTip16;
            // 
            // commandBarItem13
            // 
            this.commandBarItem13.Caption = "Increase Horizontal Spacing";
            this.commandBarItem13.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceIncrease;
            this.commandBarItem13.Description = null;
            this.commandBarItem13.Enabled = false;
            this.commandBarItem13.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_HorizSpaceIncrease;
            this.commandBarItem13.Id = 12;
            this.commandBarItem13.Name = "commandBarItem13";
            superToolTip17.FixedTooltipWidth = true;
            toolTipTitleItem17.Text = "Increase Horizontal Spacing";
            toolTipItem17.LeftIndent = 6;
            toolTipItem17.Text = "Increase the horizontal spacing between the selected controls.";
            superToolTip17.Items.Add(toolTipTitleItem17);
            superToolTip17.Items.Add(toolTipItem17);
            superToolTip17.MaxWidth = 210;
            this.commandBarItem13.SuperTip = superToolTip17;
            // 
            // commandBarItem14
            // 
            this.commandBarItem14.Caption = "Decrease Horizontal Spacing";
            this.commandBarItem14.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceDecrease;
            this.commandBarItem14.Description = null;
            this.commandBarItem14.Enabled = false;
            this.commandBarItem14.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_HorizSpaceDecrease;
            this.commandBarItem14.Id = 13;
            this.commandBarItem14.Name = "commandBarItem14";
            superToolTip18.FixedTooltipWidth = true;
            toolTipTitleItem18.Text = "Decrease Horizontal Spacing";
            toolTipItem18.LeftIndent = 6;
            toolTipItem18.Text = "Decrease the horizontal spacing between the selected controls.";
            superToolTip18.Items.Add(toolTipTitleItem18);
            superToolTip18.Items.Add(toolTipItem18);
            superToolTip18.MaxWidth = 210;
            this.commandBarItem14.SuperTip = superToolTip18;
            // 
            // commandBarItem15
            // 
            this.commandBarItem15.Caption = "Remove Horizontal Spacing";
            this.commandBarItem15.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HorizSpaceConcatenate;
            this.commandBarItem15.Description = null;
            this.commandBarItem15.Enabled = false;
            this.commandBarItem15.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_HorizSpaceConcatenate;
            this.commandBarItem15.Id = 14;
            this.commandBarItem15.Name = "commandBarItem15";
            superToolTip19.FixedTooltipWidth = true;
            toolTipTitleItem19.Text = "Remove Horizontal Spacing";
            toolTipItem19.LeftIndent = 6;
            toolTipItem19.Text = "Remove the horizontal spacing between the selected controls.";
            superToolTip19.Items.Add(toolTipTitleItem19);
            superToolTip19.Items.Add(toolTipItem19);
            superToolTip19.MaxWidth = 210;
            this.commandBarItem15.SuperTip = superToolTip19;
            // 
            // commandBarItem16
            // 
            this.commandBarItem16.Caption = "Make Vertical Spacing Equal";
            this.commandBarItem16.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceMakeEqual;
            this.commandBarItem16.Description = null;
            this.commandBarItem16.Enabled = false;
            this.commandBarItem16.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_VertSpaceMakeEqual;
            this.commandBarItem16.Id = 15;
            this.commandBarItem16.Name = "commandBarItem16";
            superToolTip20.FixedTooltipWidth = true;
            toolTipTitleItem20.Text = "Make Vertical Spacing Equal";
            toolTipItem20.LeftIndent = 6;
            toolTipItem20.Text = "Make the vertical spacing between the selected controls equal.";
            superToolTip20.Items.Add(toolTipTitleItem20);
            superToolTip20.Items.Add(toolTipItem20);
            superToolTip20.MaxWidth = 210;
            this.commandBarItem16.SuperTip = superToolTip20;
            // 
            // commandBarItem17
            // 
            this.commandBarItem17.Caption = "Increase Vertical Spacing";
            this.commandBarItem17.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceIncrease;
            this.commandBarItem17.Description = null;
            this.commandBarItem17.Enabled = false;
            this.commandBarItem17.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_VertSpaceIncrease;
            this.commandBarItem17.Id = 16;
            this.commandBarItem17.Name = "commandBarItem17";
            superToolTip21.FixedTooltipWidth = true;
            toolTipTitleItem21.Text = "Increase Vertical Spacing";
            toolTipItem21.LeftIndent = 6;
            toolTipItem21.Text = "Increase the vertical spacing between the selected controls.";
            superToolTip21.Items.Add(toolTipTitleItem21);
            superToolTip21.Items.Add(toolTipItem21);
            superToolTip21.MaxWidth = 210;
            this.commandBarItem17.SuperTip = superToolTip21;
            // 
            // commandBarItem18
            // 
            this.commandBarItem18.Caption = "Decrease Vertical Spacing";
            this.commandBarItem18.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceDecrease;
            this.commandBarItem18.Description = null;
            this.commandBarItem18.Enabled = false;
            this.commandBarItem18.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_VertSpaceDecrease;
            this.commandBarItem18.Id = 17;
            this.commandBarItem18.Name = "commandBarItem18";
            superToolTip22.FixedTooltipWidth = true;
            toolTipTitleItem22.Text = "Decrease Vertical Spacing";
            toolTipItem22.LeftIndent = 6;
            toolTipItem22.Text = "Decrease the vertical spacing between the selected controls.";
            superToolTip22.Items.Add(toolTipTitleItem22);
            superToolTip22.Items.Add(toolTipItem22);
            superToolTip22.MaxWidth = 210;
            this.commandBarItem18.SuperTip = superToolTip22;
            // 
            // commandBarItem19
            // 
            this.commandBarItem19.Caption = "Remove Vertical Spacing";
            this.commandBarItem19.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.VertSpaceConcatenate;
            this.commandBarItem19.Description = null;
            this.commandBarItem19.Enabled = false;
            this.commandBarItem19.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_VertSpaceConcatenate;
            this.commandBarItem19.Id = 18;
            this.commandBarItem19.Name = "commandBarItem19";
            superToolTip23.FixedTooltipWidth = true;
            toolTipTitleItem23.Text = "Remove Vertical Spacing";
            toolTipItem23.LeftIndent = 6;
            toolTipItem23.Text = "Remove the vertical spacing between the selected controls.";
            superToolTip23.Items.Add(toolTipTitleItem23);
            superToolTip23.Items.Add(toolTipItem23);
            superToolTip23.MaxWidth = 210;
            this.commandBarItem19.SuperTip = superToolTip23;
            // 
            // commandBarItem20
            // 
            this.commandBarItem20.Caption = "Center Horizontally";
            this.commandBarItem20.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.CenterHorizontally;
            this.commandBarItem20.Description = null;
            this.commandBarItem20.Enabled = false;
            this.commandBarItem20.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_CenterHorizontally;
            this.commandBarItem20.Id = 19;
            this.commandBarItem20.Name = "commandBarItem20";
            superToolTip24.FixedTooltipWidth = true;
            toolTipTitleItem24.Text = "Center Horizontally";
            toolTipItem24.LeftIndent = 6;
            toolTipItem24.Text = "Horizontally center the selected controls within a band.";
            superToolTip24.Items.Add(toolTipTitleItem24);
            superToolTip24.Items.Add(toolTipItem24);
            superToolTip24.MaxWidth = 210;
            this.commandBarItem20.SuperTip = superToolTip24;
            // 
            // commandBarItem21
            // 
            this.commandBarItem21.Caption = "Center Vetically";
            this.commandBarItem21.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.CenterVertically;
            this.commandBarItem21.Description = null;
            this.commandBarItem21.Enabled = false;
            this.commandBarItem21.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_CenterVertically;
            this.commandBarItem21.Id = 20;
            this.commandBarItem21.Name = "commandBarItem21";
            superToolTip25.FixedTooltipWidth = true;
            toolTipTitleItem25.Text = "Center Vetically";
            toolTipItem25.LeftIndent = 6;
            toolTipItem25.Text = "Vertically center the selected controls within a band.";
            superToolTip25.Items.Add(toolTipTitleItem25);
            superToolTip25.Items.Add(toolTipItem25);
            superToolTip25.MaxWidth = 210;
            this.commandBarItem21.SuperTip = superToolTip25;
            // 
            // commandBarItem22
            // 
            this.commandBarItem22.Caption = "Bring to Front";
            this.commandBarItem22.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BringToFront;
            this.commandBarItem22.Description = null;
            this.commandBarItem22.Enabled = false;
            this.commandBarItem22.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_BringToFront;
            this.commandBarItem22.Id = 21;
            this.commandBarItem22.Name = "commandBarItem22";
            superToolTip26.FixedTooltipWidth = true;
            toolTipTitleItem26.Text = "Bring to Front";
            toolTipItem26.LeftIndent = 6;
            toolTipItem26.Text = "Bring the selected controls to the front.";
            superToolTip26.Items.Add(toolTipTitleItem26);
            superToolTip26.Items.Add(toolTipItem26);
            superToolTip26.MaxWidth = 210;
            this.commandBarItem22.SuperTip = superToolTip26;
            // 
            // commandBarItem23
            // 
            this.commandBarItem23.Caption = "Send to Back";
            this.commandBarItem23.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SendToBack;
            this.commandBarItem23.Description = null;
            this.commandBarItem23.Enabled = false;
            this.commandBarItem23.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_SendToBack;
            this.commandBarItem23.Id = 22;
            this.commandBarItem23.Name = "commandBarItem23";
            superToolTip27.FixedTooltipWidth = true;
            toolTipTitleItem27.Text = "Send to Back";
            toolTipItem27.LeftIndent = 6;
            toolTipItem27.Text = "Move the selected controls to the back.";
            superToolTip27.Items.Add(toolTipTitleItem27);
            superToolTip27.Items.Add(toolTipItem27);
            superToolTip27.MaxWidth = 210;
            this.commandBarItem23.SuperTip = superToolTip27;
            // 
            // commandBarItem24
            // 
            this.commandBarItem24.Caption = "Bold";
            this.commandBarItem24.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FontBold;
            this.commandBarItem24.Description = null;
            this.commandBarItem24.Enabled = false;
            this.commandBarItem24.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_FontBold;
            this.commandBarItem24.Id = 23;
            this.commandBarItem24.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.B));
            this.commandBarItem24.Name = "commandBarItem24";
            superToolTip28.FixedTooltipWidth = true;
            toolTipTitleItem28.Text = "Bold (Ctrl+B)";
            toolTipItem28.LeftIndent = 6;
            toolTipItem28.Text = "Make the selected text bold.";
            superToolTip28.Items.Add(toolTipTitleItem28);
            superToolTip28.Items.Add(toolTipItem28);
            superToolTip28.MaxWidth = 210;
            this.commandBarItem24.SuperTip = superToolTip28;
            // 
            // commandBarItem25
            // 
            this.commandBarItem25.Caption = "Italic";
            this.commandBarItem25.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FontItalic;
            this.commandBarItem25.Description = null;
            this.commandBarItem25.Enabled = false;
            this.commandBarItem25.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_FontItalic;
            this.commandBarItem25.Id = 24;
            this.commandBarItem25.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.I));
            this.commandBarItem25.Name = "commandBarItem25";
            superToolTip29.FixedTooltipWidth = true;
            toolTipTitleItem29.Text = "Italic (Ctrl+I)";
            toolTipItem29.LeftIndent = 6;
            toolTipItem29.Text = "Italicize the text.";
            superToolTip29.Items.Add(toolTipTitleItem29);
            superToolTip29.Items.Add(toolTipItem29);
            superToolTip29.MaxWidth = 210;
            this.commandBarItem25.SuperTip = superToolTip29;
            // 
            // commandBarItem26
            // 
            this.commandBarItem26.Caption = "Underline";
            this.commandBarItem26.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.FontUnderline;
            this.commandBarItem26.Description = null;
            this.commandBarItem26.Enabled = false;
            this.commandBarItem26.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_FontUnderline;
            this.commandBarItem26.Id = 25;
            this.commandBarItem26.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.U));
            this.commandBarItem26.Name = "commandBarItem26";
            superToolTip30.FixedTooltipWidth = true;
            toolTipTitleItem30.Text = "Underline (Ctrl+U)";
            toolTipItem30.LeftIndent = 6;
            toolTipItem30.Text = "Underline hte selected text.";
            superToolTip30.Items.Add(toolTipTitleItem30);
            superToolTip30.Items.Add(toolTipItem30);
            superToolTip30.MaxWidth = 210;
            this.commandBarItem26.SuperTip = superToolTip30;
            // 
            // commandColorBarItem1
            // 
            this.commandColorBarItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandColorBarItem1.Caption = "Foreground Color";
            this.commandColorBarItem1.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ForeColor;
            this.commandColorBarItem1.Description = null;
            this.commandColorBarItem1.Enabled = false;
            this.commandColorBarItem1.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_ForeColor;
            this.commandColorBarItem1.Id = 26;
            this.commandColorBarItem1.Name = "commandColorBarItem1";
            superToolTip31.FixedTooltipWidth = true;
            toolTipTitleItem31.Text = "Foreground Color";
            toolTipItem31.LeftIndent = 6;
            toolTipItem31.Text = "Change the text foreground color.";
            superToolTip31.Items.Add(toolTipTitleItem31);
            superToolTip31.Items.Add(toolTipItem31);
            superToolTip31.MaxWidth = 210;
            this.commandColorBarItem1.SuperTip = superToolTip31;
            // 
            // commandColorBarItem2
            // 
            this.commandColorBarItem2.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandColorBarItem2.Caption = "Background Color";
            this.commandColorBarItem2.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.BackColor;
            this.commandColorBarItem2.Description = null;
            this.commandColorBarItem2.Enabled = false;
            this.commandColorBarItem2.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_BackColor;
            this.commandColorBarItem2.Id = 27;
            this.commandColorBarItem2.Name = "commandColorBarItem2";
            superToolTip32.FixedTooltipWidth = true;
            toolTipTitleItem32.Text = "Background Color";
            toolTipItem32.LeftIndent = 6;
            toolTipItem32.Text = "Change the text background color.";
            superToolTip32.Items.Add(toolTipTitleItem32);
            superToolTip32.Items.Add(toolTipItem32);
            superToolTip32.MaxWidth = 210;
            this.commandColorBarItem2.SuperTip = superToolTip32;
            // 
            // commandBarItem27
            // 
            this.commandBarItem27.Caption = "Align Text Left";
            this.commandBarItem27.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyLeft;
            this.commandBarItem27.Description = null;
            this.commandBarItem27.Enabled = false;
            this.commandBarItem27.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_JustifyLeft;
            this.commandBarItem27.Id = 28;
            this.commandBarItem27.Name = "commandBarItem27";
            superToolTip33.FixedTooltipWidth = true;
            toolTipTitleItem33.Text = "Align Text Left";
            toolTipItem33.LeftIndent = 6;
            toolTipItem33.Text = "Align text to the left.";
            superToolTip33.Items.Add(toolTipTitleItem33);
            superToolTip33.Items.Add(toolTipItem33);
            superToolTip33.MaxWidth = 210;
            this.commandBarItem27.SuperTip = superToolTip33;
            // 
            // commandBarItem28
            // 
            this.commandBarItem28.Caption = "Center Text";
            this.commandBarItem28.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyCenter;
            this.commandBarItem28.Description = null;
            this.commandBarItem28.Enabled = false;
            this.commandBarItem28.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_JustifyCenter;
            this.commandBarItem28.Id = 29;
            this.commandBarItem28.Name = "commandBarItem28";
            superToolTip34.FixedTooltipWidth = true;
            toolTipTitleItem34.Text = "Center Text";
            toolTipItem34.LeftIndent = 6;
            toolTipItem34.Text = "Center text.";
            superToolTip34.Items.Add(toolTipTitleItem34);
            superToolTip34.Items.Add(toolTipItem34);
            superToolTip34.MaxWidth = 210;
            this.commandBarItem28.SuperTip = superToolTip34;
            // 
            // commandBarItem29
            // 
            this.commandBarItem29.Caption = "Align Text Right";
            this.commandBarItem29.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyRight;
            this.commandBarItem29.Description = null;
            this.commandBarItem29.Enabled = false;
            this.commandBarItem29.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_JustifyRight;
            this.commandBarItem29.Id = 30;
            this.commandBarItem29.Name = "commandBarItem29";
            superToolTip35.FixedTooltipWidth = true;
            toolTipTitleItem35.Text = "Align Text Right";
            toolTipItem35.LeftIndent = 6;
            toolTipItem35.Text = "Align text to the right.";
            superToolTip35.Items.Add(toolTipTitleItem35);
            superToolTip35.Items.Add(toolTipItem35);
            superToolTip35.MaxWidth = 210;
            this.commandBarItem29.SuperTip = superToolTip35;
            // 
            // commandBarItem30
            // 
            this.commandBarItem30.Caption = "Justify";
            this.commandBarItem30.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.JustifyJustify;
            this.commandBarItem30.Description = null;
            this.commandBarItem30.Enabled = false;
            this.commandBarItem30.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_JustifyJustify;
            this.commandBarItem30.Id = 31;
            this.commandBarItem30.Name = "commandBarItem30";
            superToolTip36.FixedTooltipWidth = true;
            toolTipTitleItem36.Text = "Justify";
            toolTipItem36.LeftIndent = 6;
            toolTipItem36.Text = "Align text to both the left and right sides, adding extra space between words as " +
                "necessary.";
            superToolTip36.Items.Add(toolTipTitleItem36);
            superToolTip36.Items.Add(toolTipItem36);
            superToolTip36.MaxWidth = 210;
            this.commandBarItem30.SuperTip = superToolTip36;
            // 
            // commandBarItem31
            // 
            this.commandBarItem31.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem31.Caption = "New Report";
            this.commandBarItem31.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.NewReport;
            this.commandBarItem31.Description = null;
            this.commandBarItem31.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_NewReport;
            this.commandBarItem31.Id = 32;
            this.commandBarItem31.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_NewReportLarge;
            this.commandBarItem31.Name = "commandBarItem31";
            superToolTip37.FixedTooltipWidth = true;
            toolTipTitleItem37.Text = "New Blank Report";
            toolTipItem37.LeftIndent = 6;
            toolTipItem37.Text = "Create a new blank report so that you can insert fields and controls and design a" +
                " report.";
            superToolTip37.Items.Add(toolTipTitleItem37);
            superToolTip37.Items.Add(toolTipItem37);
            superToolTip37.MaxWidth = 210;
            this.commandBarItem31.SuperTip = superToolTip37;
            // 
            // commandBarItem36
            // 
            this.commandBarItem36.Caption = "Save";
            this.commandBarItem36.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SaveFile;
            this.commandBarItem36.Description = "Save a report.";
            this.commandBarItem36.Enabled = false;
            this.commandBarItem36.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_SaveFile;
            this.commandBarItem36.Id = 37;
            this.commandBarItem36.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S));
            this.commandBarItem36.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_SaveFileLarge;
            this.commandBarItem36.Name = "commandBarItem36";
            superToolTip38.FixedTooltipWidth = true;
            toolTipTitleItem38.Text = "Save Report (Ctrl+S)";
            toolTipItem38.LeftIndent = 6;
            toolTipItem38.Text = "Save a report.";
            superToolTip38.Items.Add(toolTipTitleItem38);
            superToolTip38.Items.Add(toolTipItem38);
            superToolTip38.MaxWidth = 210;
            this.commandBarItem36.SuperTip = superToolTip38;
            // 
            // commandBarItem37
            // 
            this.commandBarItem37.Caption = "Save As...";
            this.commandBarItem37.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.SaveFileAs;
            this.commandBarItem37.Description = "Save a report with a new name.";
            this.commandBarItem37.Enabled = false;
            this.commandBarItem37.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_SaveFileAs;
            this.commandBarItem37.Id = 38;
            this.commandBarItem37.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_SaveFileAsLarge;
            this.commandBarItem37.Name = "commandBarItem37";
            superToolTip39.FixedTooltipWidth = true;
            toolTipTitleItem39.Text = "Save Report As";
            toolTipItem39.LeftIndent = 6;
            toolTipItem39.Text = "Save a report with a new name.";
            superToolTip39.Items.Add(toolTipTitleItem39);
            superToolTip39.Items.Add(toolTipItem39);
            superToolTip39.MaxWidth = 210;
            this.commandBarItem37.SuperTip = superToolTip39;
            // 
            // commandBarItem38
            // 
            this.commandBarItem38.Caption = "Cut";
            this.commandBarItem38.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Cut;
            this.commandBarItem38.Description = null;
            this.commandBarItem38.Enabled = false;
            this.commandBarItem38.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_Cut;
            this.commandBarItem38.Id = 39;
            this.commandBarItem38.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.X));
            this.commandBarItem38.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_CutLarge;
            this.commandBarItem38.Name = "commandBarItem38";
            superToolTip40.FixedTooltipWidth = true;
            toolTipTitleItem40.Text = "Cut (Ctrl+X)";
            toolTipItem40.LeftIndent = 6;
            toolTipItem40.Text = "Cut the selected controls from the report and put them on the Clipboard.";
            superToolTip40.Items.Add(toolTipTitleItem40);
            superToolTip40.Items.Add(toolTipItem40);
            superToolTip40.MaxWidth = 210;
            this.commandBarItem38.SuperTip = superToolTip40;
            // 
            // commandBarItem39
            // 
            this.commandBarItem39.Caption = "Copy";
            this.commandBarItem39.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Copy;
            this.commandBarItem39.Description = null;
            this.commandBarItem39.Enabled = false;
            this.commandBarItem39.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_Copy;
            this.commandBarItem39.Id = 40;
            this.commandBarItem39.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.C));
            this.commandBarItem39.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_CopyLarge;
            this.commandBarItem39.Name = "commandBarItem39";
            superToolTip41.FixedTooltipWidth = true;
            toolTipTitleItem41.Text = "Copy (Ctrl+C)";
            toolTipItem41.LeftIndent = 6;
            toolTipItem41.Text = "Copy the selected controls and put them on the Clipboard.";
            superToolTip41.Items.Add(toolTipTitleItem41);
            superToolTip41.Items.Add(toolTipItem41);
            superToolTip41.MaxWidth = 210;
            this.commandBarItem39.SuperTip = superToolTip41;
            // 
            // commandBarItem40
            // 
            this.commandBarItem40.Caption = "Paste";
            this.commandBarItem40.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Paste;
            this.commandBarItem40.Description = null;
            this.commandBarItem40.Enabled = false;
            this.commandBarItem40.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_Paste;
            this.commandBarItem40.Id = 41;
            this.commandBarItem40.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.V));
            this.commandBarItem40.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_PasteLarge;
            this.commandBarItem40.Name = "commandBarItem40";
            superToolTip42.FixedTooltipWidth = true;
            toolTipTitleItem42.Text = "Paste (Ctrl+V)";
            toolTipItem42.LeftIndent = 6;
            toolTipItem42.Text = "Paste the contents of the Clipboard.";
            superToolTip42.Items.Add(toolTipTitleItem42);
            superToolTip42.Items.Add(toolTipItem42);
            superToolTip42.MaxWidth = 210;
            this.commandBarItem40.SuperTip = superToolTip42;
            // 
            // commandBarItem41
            // 
            this.commandBarItem41.Caption = "Undo";
            this.commandBarItem41.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Undo;
            this.commandBarItem41.Description = null;
            this.commandBarItem41.Enabled = false;
            this.commandBarItem41.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_Undo;
            this.commandBarItem41.Id = 42;
            this.commandBarItem41.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z));
            this.commandBarItem41.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_UndoLarge;
            this.commandBarItem41.Name = "commandBarItem41";
            superToolTip43.FixedTooltipWidth = true;
            toolTipTitleItem43.Text = "Undo (Ctrl+Z)";
            toolTipItem43.LeftIndent = 6;
            toolTipItem43.Text = "Undo the last operation.";
            superToolTip43.Items.Add(toolTipTitleItem43);
            superToolTip43.Items.Add(toolTipItem43);
            superToolTip43.MaxWidth = 210;
            this.commandBarItem41.SuperTip = superToolTip43;
            // 
            // commandBarItem42
            // 
            this.commandBarItem42.Caption = "Redo";
            this.commandBarItem42.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Redo;
            this.commandBarItem42.Description = null;
            this.commandBarItem42.Enabled = false;
            this.commandBarItem42.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_Redo;
            this.commandBarItem42.Id = 43;
            this.commandBarItem42.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Y));
            this.commandBarItem42.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_RedoLarge;
            this.commandBarItem42.Name = "commandBarItem42";
            superToolTip44.FixedTooltipWidth = true;
            toolTipTitleItem44.Text = "Redo (Ctrl+Y)";
            toolTipItem44.LeftIndent = 6;
            toolTipItem44.Text = "Redo the last operation.";
            superToolTip44.Items.Add(toolTipTitleItem44);
            superToolTip44.Items.Add(toolTipItem44);
            superToolTip44.MaxWidth = 210;
            this.commandBarItem42.SuperTip = superToolTip44;
            // 
            // commandBarItem43
            // 
            this.commandBarItem43.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.commandBarItem43.Caption = "Zoom";
            this.commandBarItem43.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.Zoom;
            this.commandBarItem43.Description = null;
            this.commandBarItem43.Enabled = false;
            this.commandBarItem43.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_Zoom;
            this.commandBarItem43.Id = 44;
            this.commandBarItem43.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_ZoomLarge;
            this.commandBarItem43.Name = "commandBarItem43";
            superToolTip45.FixedTooltipWidth = true;
            toolTipTitleItem45.Text = "Zoom";
            toolTipItem45.LeftIndent = 6;
            toolTipItem45.Text = "Change the zoom level of the document designer.";
            superToolTip45.Items.Add(toolTipTitleItem45);
            superToolTip45.Items.Add(toolTipItem45);
            superToolTip45.MaxWidth = 210;
            this.commandBarItem43.SuperTip = superToolTip45;
            // 
            // commandBarItem44
            // 
            this.commandBarItem44.Caption = "Zoom In";
            this.commandBarItem44.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ZoomIn;
            this.commandBarItem44.Description = null;
            this.commandBarItem44.Enabled = false;
            this.commandBarItem44.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_ZoomIn;
            this.commandBarItem44.Id = 45;
            this.commandBarItem44.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Add));
            this.commandBarItem44.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_ZoomInLarge;
            this.commandBarItem44.Name = "commandBarItem44";
            superToolTip46.FixedTooltipWidth = true;
            toolTipTitleItem46.Text = "Zoom In (Ctrl+Add)";
            toolTipItem46.LeftIndent = 6;
            toolTipItem46.Text = "Zoom in to get a close-up view of the report.";
            superToolTip46.Items.Add(toolTipTitleItem46);
            superToolTip46.Items.Add(toolTipItem46);
            superToolTip46.MaxWidth = 210;
            this.commandBarItem44.SuperTip = superToolTip46;
            // 
            // commandBarItem45
            // 
            this.commandBarItem45.Caption = "Zoom Out";
            this.commandBarItem45.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.ZoomOut;
            this.commandBarItem45.Description = null;
            this.commandBarItem45.Enabled = false;
            this.commandBarItem45.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_ZoomOut;
            this.commandBarItem45.Id = 46;
            this.commandBarItem45.ItemShortcut = new DevExpress.XtraBars.BarShortcut((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Subtract));
            this.commandBarItem45.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_ZoomOutLarge;
            this.commandBarItem45.Name = "commandBarItem45";
            superToolTip47.FixedTooltipWidth = true;
            toolTipTitleItem47.Text = "Zoom Out (Ctrl+Subtract)";
            toolTipItem47.LeftIndent = 6;
            toolTipItem47.Text = "Zoom out to see more of the report at a reduced size.";
            superToolTip47.Items.Add(toolTipTitleItem47);
            superToolTip47.Items.Add(toolTipItem47);
            superToolTip47.MaxWidth = 210;
            this.commandBarItem45.SuperTip = superToolTip47;
            // 
            // barEditItem1
            // 
            this.barEditItem1.Description = null;
            this.barEditItem1.Edit = this.recentlyUsedItemsComboBox1;
            this.barEditItem1.Id = 47;
            this.barEditItem1.Name = "barEditItem1";
            superToolTip48.FixedTooltipWidth = true;
            toolTipTitleItem48.Text = "Font";
            toolTipItem48.LeftIndent = 6;
            toolTipItem48.Text = "Change the font face.";
            superToolTip48.Items.Add(toolTipTitleItem48);
            superToolTip48.Items.Add(toolTipItem48);
            superToolTip48.MaxWidth = 210;
            this.barEditItem1.SuperTip = superToolTip48;
            this.barEditItem1.Width = 140;
            // 
            // barEditItem2
            // 
            this.barEditItem2.Description = null;
            this.barEditItem2.Edit = this.designRepositoryItemComboBox1;
            this.barEditItem2.Id = 48;
            this.barEditItem2.Name = "barEditItem2";
            superToolTip49.FixedTooltipWidth = true;
            toolTipTitleItem49.Text = "Font Size";
            toolTipItem49.LeftIndent = 6;
            toolTipItem49.Text = "Change the font size.";
            superToolTip49.Items.Add(toolTipTitleItem49);
            superToolTip49.Items.Add(toolTipItem49);
            superToolTip49.MaxWidth = 210;
            this.barEditItem2.SuperTip = superToolTip49;
            // 
            // barDockPanelsListItem1
            // 
            this.barDockPanelsListItem1.Caption = "Windows";
            this.barDockPanelsListItem1.Description = null;
            this.barDockPanelsListItem1.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_Windows;
            this.barDockPanelsListItem1.Id = 49;
            this.barDockPanelsListItem1.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_WindowsLarge;
            this.barDockPanelsListItem1.Name = "barDockPanelsListItem1";
            this.barDockPanelsListItem1.ShowCustomizationItem = false;
            this.barDockPanelsListItem1.ShowDockPanels = true;
            this.barDockPanelsListItem1.ShowToolbars = false;
            superToolTip50.FixedTooltipWidth = true;
            toolTipTitleItem50.Text = "Show/Hide Windows";
            toolTipItem50.LeftIndent = 6;
            toolTipItem50.Text = "Show or hide the Tool Box, Report Explorer, Field List and Property Grid windows." +
                "";
            superToolTip50.Items.Add(toolTipTitleItem50);
            superToolTip50.Items.Add(toolTipItem50);
            superToolTip50.MaxWidth = 210;
            this.barDockPanelsListItem1.SuperTip = superToolTip50;
            // 
            // commandBarItem46
            // 
            this.commandBarItem46.Caption = "Back";
            this.commandBarItem46.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HtmlBackward;
            this.commandBarItem46.Description = null;
            this.commandBarItem46.Enabled = false;
            this.commandBarItem46.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_HtmlBackward;
            this.commandBarItem46.Id = 50;
            this.commandBarItem46.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_HtmlBackwardLarge;
            this.commandBarItem46.Name = "commandBarItem46";
            superToolTip51.FixedTooltipWidth = true;
            toolTipTitleItem51.Text = "Back";
            toolTipItem51.LeftIndent = 6;
            toolTipItem51.Text = "Move back to the previous page.";
            superToolTip51.Items.Add(toolTipTitleItem51);
            superToolTip51.Items.Add(toolTipItem51);
            superToolTip51.MaxWidth = 210;
            this.commandBarItem46.SuperTip = superToolTip51;
            // 
            // commandBarItem47
            // 
            this.commandBarItem47.Caption = "Forward";
            this.commandBarItem47.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HtmlForward;
            this.commandBarItem47.Description = null;
            this.commandBarItem47.Enabled = false;
            this.commandBarItem47.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_HtmlForward;
            this.commandBarItem47.Id = 51;
            this.commandBarItem47.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_HtmlForwardLarge;
            this.commandBarItem47.Name = "commandBarItem47";
            superToolTip52.FixedTooltipWidth = true;
            toolTipTitleItem52.Text = "Forward";
            toolTipItem52.LeftIndent = 6;
            toolTipItem52.Text = "Move forward to the next page.";
            superToolTip52.Items.Add(toolTipTitleItem52);
            superToolTip52.Items.Add(toolTipItem52);
            superToolTip52.MaxWidth = 210;
            this.commandBarItem47.SuperTip = superToolTip52;
            // 
            // commandBarItem48
            // 
            this.commandBarItem48.Caption = "Home";
            this.commandBarItem48.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HtmlHome;
            this.commandBarItem48.Description = null;
            this.commandBarItem48.Enabled = false;
            this.commandBarItem48.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_HtmlHome;
            this.commandBarItem48.Id = 52;
            this.commandBarItem48.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_HtmlHomeLarge;
            this.commandBarItem48.Name = "commandBarItem48";
            superToolTip53.FixedTooltipWidth = true;
            toolTipTitleItem53.Text = "Home";
            toolTipItem53.LeftIndent = 6;
            toolTipItem53.Text = "Display the home page.";
            superToolTip53.Items.Add(toolTipTitleItem53);
            superToolTip53.Items.Add(toolTipItem53);
            superToolTip53.MaxWidth = 210;
            this.commandBarItem48.SuperTip = superToolTip53;
            // 
            // commandBarItem49
            // 
            this.commandBarItem49.Caption = "Refresh";
            this.commandBarItem49.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HtmlRefresh;
            this.commandBarItem49.Description = null;
            this.commandBarItem49.Enabled = false;
            this.commandBarItem49.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_HtmlRefresh;
            this.commandBarItem49.Id = 53;
            this.commandBarItem49.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_HtmlRefreshLarge;
            this.commandBarItem49.Name = "commandBarItem49";
            superToolTip54.FixedTooltipWidth = true;
            toolTipTitleItem54.Text = "Refresh";
            toolTipItem54.LeftIndent = 6;
            toolTipItem54.Text = "Refresh this page.";
            superToolTip54.Items.Add(toolTipTitleItem54);
            superToolTip54.Items.Add(toolTipItem54);
            superToolTip54.MaxWidth = 210;
            this.commandBarItem49.SuperTip = superToolTip54;
            // 
            // commandBarItem50
            // 
            this.commandBarItem50.Caption = "Find";
            this.commandBarItem50.Command = DevExpress.XtraReports.UserDesigner.ReportCommand.HtmlFind;
            this.commandBarItem50.Description = null;
            this.commandBarItem50.Enabled = false;
            this.commandBarItem50.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_HtmlFind;
            this.commandBarItem50.Id = 54;
            this.commandBarItem50.LargeGlyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_HtmlFindLarge;
            this.commandBarItem50.Name = "commandBarItem50";
            superToolTip55.FixedTooltipWidth = true;
            toolTipTitleItem55.Text = "Find";
            toolTipItem55.LeftIndent = 6;
            toolTipItem55.Text = "Find the text on this page.";
            superToolTip55.Items.Add(toolTipTitleItem55);
            superToolTip55.Items.Add(toolTipItem55);
            superToolTip55.MaxWidth = 210;
            this.commandBarItem50.SuperTip = superToolTip55;
            // 
            // xrDesignBarButtonGroup1
            // 
            this.xrDesignBarButtonGroup1.Id = 55;
            this.xrDesignBarButtonGroup1.ItemLinks.Add(this.commandColorBarItem2);
            this.xrDesignBarButtonGroup1.ItemLinks.Add(this.commandColorBarItem1);
            this.xrDesignBarButtonGroup1.Name = "xrDesignBarButtonGroup1";
            // 
            // xrDesignBarButtonGroup2
            // 
            this.xrDesignBarButtonGroup2.Id = 56;
            this.xrDesignBarButtonGroup2.ItemLinks.Add(this.commandBarItem24);
            this.xrDesignBarButtonGroup2.ItemLinks.Add(this.commandBarItem25);
            this.xrDesignBarButtonGroup2.ItemLinks.Add(this.commandBarItem26);
            this.xrDesignBarButtonGroup2.Name = "xrDesignBarButtonGroup2";
            // 
            // xrDesignBarButtonGroup3
            // 
            this.xrDesignBarButtonGroup3.Id = 57;
            this.xrDesignBarButtonGroup3.ItemLinks.Add(this.commandBarItem27);
            this.xrDesignBarButtonGroup3.ItemLinks.Add(this.commandBarItem28);
            this.xrDesignBarButtonGroup3.ItemLinks.Add(this.commandBarItem29);
            this.xrDesignBarButtonGroup3.ItemLinks.Add(this.commandBarItem30);
            this.xrDesignBarButtonGroup3.Name = "xrDesignBarButtonGroup3";
            // 
            // xrDesignBarButtonGroup4
            // 
            this.xrDesignBarButtonGroup4.Id = 58;
            this.xrDesignBarButtonGroup4.ItemLinks.Add(this.commandBarItem1);
            this.xrDesignBarButtonGroup4.ItemLinks.Add(this.commandBarItem2);
            this.xrDesignBarButtonGroup4.ItemLinks.Add(this.commandBarItem3);
            this.xrDesignBarButtonGroup4.ItemLinks.Add(this.commandBarItem4);
            this.xrDesignBarButtonGroup4.Name = "xrDesignBarButtonGroup4";
            // 
            // xrDesignBarButtonGroup5
            // 
            this.xrDesignBarButtonGroup5.Id = 59;
            this.xrDesignBarButtonGroup5.ItemLinks.Add(this.commandBarItem5);
            this.xrDesignBarButtonGroup5.ItemLinks.Add(this.commandBarItem6);
            this.xrDesignBarButtonGroup5.ItemLinks.Add(this.commandBarItem7);
            this.xrDesignBarButtonGroup5.Name = "xrDesignBarButtonGroup5";
            // 
            // xrDesignBarButtonGroup6
            // 
            this.xrDesignBarButtonGroup6.Id = 60;
            this.xrDesignBarButtonGroup6.ItemLinks.Add(this.commandBarItem9);
            this.xrDesignBarButtonGroup6.ItemLinks.Add(this.commandBarItem8);
            this.xrDesignBarButtonGroup6.ItemLinks.Add(this.commandBarItem10);
            this.xrDesignBarButtonGroup6.ItemLinks.Add(this.commandBarItem11);
            this.xrDesignBarButtonGroup6.Name = "xrDesignBarButtonGroup6";
            // 
            // xrDesignBarButtonGroup7
            // 
            this.xrDesignBarButtonGroup7.Id = 61;
            this.xrDesignBarButtonGroup7.ItemLinks.Add(this.commandBarItem12);
            this.xrDesignBarButtonGroup7.ItemLinks.Add(this.commandBarItem13);
            this.xrDesignBarButtonGroup7.ItemLinks.Add(this.commandBarItem14);
            this.xrDesignBarButtonGroup7.ItemLinks.Add(this.commandBarItem15);
            this.xrDesignBarButtonGroup7.Name = "xrDesignBarButtonGroup7";
            // 
            // xrDesignBarButtonGroup8
            // 
            this.xrDesignBarButtonGroup8.Id = 62;
            this.xrDesignBarButtonGroup8.ItemLinks.Add(this.commandBarItem16);
            this.xrDesignBarButtonGroup8.ItemLinks.Add(this.commandBarItem17);
            this.xrDesignBarButtonGroup8.ItemLinks.Add(this.commandBarItem18);
            this.xrDesignBarButtonGroup8.ItemLinks.Add(this.commandBarItem19);
            this.xrDesignBarButtonGroup8.Name = "xrDesignBarButtonGroup8";
            // 
            // xrDesignBarButtonGroup9
            // 
            this.xrDesignBarButtonGroup9.Id = 63;
            this.xrDesignBarButtonGroup9.ItemLinks.Add(this.commandBarItem20);
            this.xrDesignBarButtonGroup9.ItemLinks.Add(this.commandBarItem21);
            this.xrDesignBarButtonGroup9.ItemLinks.Add(this.commandBarItem22);
            this.xrDesignBarButtonGroup9.ItemLinks.Add(this.commandBarItem23);
            this.xrDesignBarButtonGroup9.Name = "xrDesignBarButtonGroup9";
            // 
            // printPreviewBarItem1
            // 
            this.printPreviewBarItem1.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem1.Caption = "Bookmarks";
            this.printPreviewBarItem1.Command = DevExpress.XtraPrinting.PrintingSystemCommand.DocumentMap;
            this.printPreviewBarItem1.Description = null;
            this.printPreviewBarItem1.Enabled = false;
            this.printPreviewBarItem1.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_DocumentMap;
            this.printPreviewBarItem1.Id = 0;
            this.printPreviewBarItem1.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_DocumentMapLarge;
            this.printPreviewBarItem1.Name = "printPreviewBarItem1";
            superToolTip56.FixedTooltipWidth = true;
            toolTipTitleItem56.Text = "Document Map";
            toolTipItem56.LeftIndent = 6;
            toolTipItem56.Text = "Open the Document Map, which allows you to navigate through a structural view of " +
                "the document.";
            superToolTip56.Items.Add(toolTipTitleItem56);
            superToolTip56.Items.Add(toolTipItem56);
            superToolTip56.MaxWidth = 210;
            this.printPreviewBarItem1.SuperTip = superToolTip56;
            // 
            // printPreviewBarItem2
            // 
            this.printPreviewBarItem2.Caption = "Find";
            this.printPreviewBarItem2.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Find;
            this.printPreviewBarItem2.Description = null;
            this.printPreviewBarItem2.Enabled = false;
            this.printPreviewBarItem2.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_Find;
            this.printPreviewBarItem2.Id = 1;
            this.printPreviewBarItem2.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_FindLarge;
            this.printPreviewBarItem2.Name = "printPreviewBarItem2";
            superToolTip57.FixedTooltipWidth = true;
            toolTipTitleItem57.Text = "Find";
            toolTipItem57.LeftIndent = 6;
            toolTipItem57.Text = "Show the Find dialog to find text in the document.";
            superToolTip57.Items.Add(toolTipTitleItem57);
            superToolTip57.Items.Add(toolTipItem57);
            superToolTip57.MaxWidth = 210;
            this.printPreviewBarItem2.SuperTip = superToolTip57;
            // 
            // printPreviewBarItem3
            // 
            this.printPreviewBarItem3.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem3.Caption = "Options";
            this.printPreviewBarItem3.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Customize;
            this.printPreviewBarItem3.Description = null;
            this.printPreviewBarItem3.Enabled = false;
            this.printPreviewBarItem3.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_Customize;
            this.printPreviewBarItem3.Id = 2;
            this.printPreviewBarItem3.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_CustomizeLarge;
            this.printPreviewBarItem3.Name = "printPreviewBarItem3";
            superToolTip58.FixedTooltipWidth = true;
            toolTipTitleItem58.Text = "Options";
            toolTipItem58.LeftIndent = 6;
            toolTipItem58.Text = "Open the Printable Component Editor dialog, in which you can change printing opti" +
                "ons.";
            superToolTip58.Items.Add(toolTipTitleItem58);
            superToolTip58.Items.Add(toolTipItem58);
            superToolTip58.MaxWidth = 210;
            this.printPreviewBarItem3.SuperTip = superToolTip58;
            // 
            // printPreviewBarItem4
            // 
            this.printPreviewBarItem4.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem4.Caption = "Print";
            this.printPreviewBarItem4.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Print;
            this.printPreviewBarItem4.Description = null;
            this.printPreviewBarItem4.Enabled = false;
            this.printPreviewBarItem4.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_Print;
            this.printPreviewBarItem4.Id = 3;
            this.printPreviewBarItem4.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_PrintLarge;
            this.printPreviewBarItem4.Name = "printPreviewBarItem4";
            superToolTip59.FixedTooltipWidth = true;
            toolTipTitleItem59.Text = "Page Setup";
            toolTipItem59.LeftIndent = 6;
            toolTipItem59.Text = "Show the Page Setup dialog.";
            superToolTip59.Items.Add(toolTipTitleItem59);
            superToolTip59.Items.Add(toolTipItem59);
            superToolTip59.MaxWidth = 210;
            this.printPreviewBarItem4.SuperTip = superToolTip59;
            // 
            // printPreviewBarItem5
            // 
            this.printPreviewBarItem5.Caption = "Quick Print";
            this.printPreviewBarItem5.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PrintDirect;
            this.printPreviewBarItem5.Description = null;
            this.printPreviewBarItem5.Enabled = false;
            this.printPreviewBarItem5.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_PrintDirect;
            this.printPreviewBarItem5.Id = 4;
            this.printPreviewBarItem5.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_PrintDirectLarge;
            this.printPreviewBarItem5.Name = "printPreviewBarItem5";
            superToolTip60.FixedTooltipWidth = true;
            toolTipTitleItem60.Text = "Header and Footer";
            toolTipItem60.LeftIndent = 6;
            toolTipItem60.Text = "Edit the header and footer of the document.";
            superToolTip60.Items.Add(toolTipTitleItem60);
            superToolTip60.Items.Add(toolTipItem60);
            superToolTip60.MaxWidth = 210;
            this.printPreviewBarItem5.SuperTip = superToolTip60;
            // 
            // printPreviewBarItem6
            // 
            this.printPreviewBarItem6.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem6.Caption = "Custom Margins...";
            this.printPreviewBarItem6.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PageSetup;
            this.printPreviewBarItem6.Description = null;
            this.printPreviewBarItem6.Enabled = false;
            this.printPreviewBarItem6.Id = 5;
            this.printPreviewBarItem6.Name = "printPreviewBarItem6";
            this.printPreviewBarItem6.SuperTip = superToolTip59;
            // 
            // printPreviewBarItem7
            // 
            this.printPreviewBarItem7.Caption = "Header/Footer";
            this.printPreviewBarItem7.Command = DevExpress.XtraPrinting.PrintingSystemCommand.EditPageHF;
            this.printPreviewBarItem7.Description = null;
            this.printPreviewBarItem7.Enabled = false;
            this.printPreviewBarItem7.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_EditPageHF;
            this.printPreviewBarItem7.Id = 6;
            this.printPreviewBarItem7.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_EditPageHFLarge;
            this.printPreviewBarItem7.Name = "printPreviewBarItem7";
            this.printPreviewBarItem7.SuperTip = superToolTip60;
            // 
            // printPreviewBarItem8
            // 
            this.printPreviewBarItem8.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem8.Caption = "Scale";
            this.printPreviewBarItem8.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Scale;
            this.printPreviewBarItem8.Description = null;
            this.printPreviewBarItem8.Enabled = false;
            this.printPreviewBarItem8.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_Scale;
            this.printPreviewBarItem8.Id = 7;
            this.printPreviewBarItem8.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ScaleLarge;
            this.printPreviewBarItem8.Name = "printPreviewBarItem8";
            superToolTip61.FixedTooltipWidth = true;
            toolTipTitleItem61.Text = "Scale";
            toolTipItem61.LeftIndent = 6;
            toolTipItem61.Text = "Stretch or shrink the printed output to a percentage of its actual size.";
            superToolTip61.Items.Add(toolTipTitleItem61);
            superToolTip61.Items.Add(toolTipItem61);
            superToolTip61.MaxWidth = 210;
            this.printPreviewBarItem8.SuperTip = superToolTip61;
            // 
            // printPreviewBarItem9
            // 
            this.printPreviewBarItem9.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem9.Caption = "Pointer";
            this.printPreviewBarItem9.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Pointer;
            this.printPreviewBarItem9.Description = null;
            this.printPreviewBarItem9.Enabled = false;
            this.printPreviewBarItem9.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_Pointer;
            this.printPreviewBarItem9.GroupIndex = 1;
            this.printPreviewBarItem9.Id = 8;
            this.printPreviewBarItem9.Name = "printPreviewBarItem9";
            this.printPreviewBarItem9.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            superToolTip62.FixedTooltipWidth = true;
            toolTipTitleItem62.Text = "Mouse Pointer";
            toolTipItem62.LeftIndent = 6;
            toolTipItem62.Text = "Show the mouse pointer.";
            superToolTip62.Items.Add(toolTipTitleItem62);
            superToolTip62.Items.Add(toolTipItem62);
            superToolTip62.MaxWidth = 210;
            this.printPreviewBarItem9.SuperTip = superToolTip62;
            // 
            // printPreviewBarItem10
            // 
            this.printPreviewBarItem10.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem10.Caption = "Hand Tool";
            this.printPreviewBarItem10.Command = DevExpress.XtraPrinting.PrintingSystemCommand.HandTool;
            this.printPreviewBarItem10.Description = null;
            this.printPreviewBarItem10.Enabled = false;
            this.printPreviewBarItem10.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_HandTool;
            this.printPreviewBarItem10.GroupIndex = 1;
            this.printPreviewBarItem10.Id = 9;
            this.printPreviewBarItem10.Name = "printPreviewBarItem10";
            this.printPreviewBarItem10.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            superToolTip63.FixedTooltipWidth = true;
            toolTipTitleItem63.Text = "Hand Tool";
            toolTipItem63.LeftIndent = 6;
            toolTipItem63.Text = "Invoke the Hand tool to manually scroll through pages.";
            superToolTip63.Items.Add(toolTipTitleItem63);
            superToolTip63.Items.Add(toolTipItem63);
            superToolTip63.MaxWidth = 210;
            this.printPreviewBarItem10.SuperTip = superToolTip63;
            // 
            // printPreviewBarItem11
            // 
            this.printPreviewBarItem11.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.Check;
            this.printPreviewBarItem11.Caption = "Magnifier";
            this.printPreviewBarItem11.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Magnifier;
            this.printPreviewBarItem11.Description = null;
            this.printPreviewBarItem11.Enabled = false;
            this.printPreviewBarItem11.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_Magnifier;
            this.printPreviewBarItem11.GroupIndex = 1;
            this.printPreviewBarItem11.Id = 10;
            this.printPreviewBarItem11.Name = "printPreviewBarItem11";
            this.printPreviewBarItem11.RibbonStyle = DevExpress.XtraBars.Ribbon.RibbonItemStyles.SmallWithoutText;
            superToolTip64.FixedTooltipWidth = true;
            toolTipTitleItem64.Text = "Magnifier";
            toolTipItem64.LeftIndent = 6;
            toolTipItem64.Text = "Invoke the Magnifier tool.\r\n\r\nClicking once on a document zooms it so that a sing" +
                "le page becomes entirely visible, while clicking another time zooms it to 100% o" +
                "f the normal size.";
            superToolTip64.Items.Add(toolTipTitleItem64);
            superToolTip64.Items.Add(toolTipItem64);
            superToolTip64.MaxWidth = 210;
            this.printPreviewBarItem11.SuperTip = superToolTip64;
            // 
            // printPreviewBarItem12
            // 
            this.printPreviewBarItem12.Caption = "Zoom Out";
            this.printPreviewBarItem12.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ZoomOut;
            this.printPreviewBarItem12.Description = null;
            this.printPreviewBarItem12.Enabled = false;
            this.printPreviewBarItem12.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ZoomOut;
            this.printPreviewBarItem12.Id = 11;
            this.printPreviewBarItem12.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ZoomOutLarge;
            this.printPreviewBarItem12.Name = "printPreviewBarItem12";
            superToolTip65.FixedTooltipWidth = true;
            toolTipTitleItem65.Text = "Zoom Out";
            toolTipItem65.LeftIndent = 6;
            toolTipItem65.Text = "Zoom out to see more of the page at a reduced size.";
            superToolTip65.Items.Add(toolTipTitleItem65);
            superToolTip65.Items.Add(toolTipItem65);
            superToolTip65.MaxWidth = 210;
            this.printPreviewBarItem12.SuperTip = superToolTip65;
            // 
            // printPreviewBarItem13
            // 
            this.printPreviewBarItem13.Caption = "Zoom In";
            this.printPreviewBarItem13.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ZoomIn;
            this.printPreviewBarItem13.Description = null;
            this.printPreviewBarItem13.Enabled = false;
            this.printPreviewBarItem13.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ZoomIn;
            this.printPreviewBarItem13.Id = 12;
            this.printPreviewBarItem13.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ZoomInLarge;
            this.printPreviewBarItem13.Name = "printPreviewBarItem13";
            superToolTip66.FixedTooltipWidth = true;
            toolTipTitleItem66.Text = "Zoom In";
            toolTipItem66.LeftIndent = 6;
            toolTipItem66.Text = "Zoom in to get a close-up view of the document.";
            superToolTip66.Items.Add(toolTipTitleItem66);
            superToolTip66.Items.Add(toolTipItem66);
            superToolTip66.MaxWidth = 210;
            this.printPreviewBarItem13.SuperTip = superToolTip66;
            // 
            // printPreviewBarItem14
            // 
            this.printPreviewBarItem14.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem14.Caption = "Zoom";
            this.printPreviewBarItem14.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Zoom;
            this.printPreviewBarItem14.Description = null;
            this.printPreviewBarItem14.Enabled = false;
            this.printPreviewBarItem14.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_Zoom;
            this.printPreviewBarItem14.Id = 13;
            this.printPreviewBarItem14.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ZoomLarge;
            this.printPreviewBarItem14.Name = "printPreviewBarItem14";
            superToolTip67.FixedTooltipWidth = true;
            toolTipTitleItem67.Text = "Zoom";
            toolTipItem67.LeftIndent = 6;
            toolTipItem67.Text = "Change the zoom level of the document preview.";
            superToolTip67.Items.Add(toolTipTitleItem67);
            superToolTip67.Items.Add(toolTipItem67);
            superToolTip67.MaxWidth = 210;
            this.printPreviewBarItem14.SuperTip = superToolTip67;
            // 
            // printPreviewBarItem15
            // 
            this.printPreviewBarItem15.Caption = "First Page";
            this.printPreviewBarItem15.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowFirstPage;
            this.printPreviewBarItem15.Description = null;
            this.printPreviewBarItem15.Enabled = false;
            this.printPreviewBarItem15.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ShowFirstPage;
            this.printPreviewBarItem15.Id = 14;
            this.printPreviewBarItem15.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ShowFirstPageLarge;
            this.printPreviewBarItem15.Name = "printPreviewBarItem15";
            superToolTip68.FixedTooltipWidth = true;
            toolTipTitleItem68.Text = "First Page (Ctrl+Home)";
            toolTipItem68.LeftIndent = 6;
            toolTipItem68.Text = "Navigate to the first page of the document.";
            superToolTip68.Items.Add(toolTipTitleItem68);
            superToolTip68.Items.Add(toolTipItem68);
            superToolTip68.MaxWidth = 210;
            this.printPreviewBarItem15.SuperTip = superToolTip68;
            // 
            // printPreviewBarItem16
            // 
            this.printPreviewBarItem16.Caption = "Previous Page";
            this.printPreviewBarItem16.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowPrevPage;
            this.printPreviewBarItem16.Description = null;
            this.printPreviewBarItem16.Enabled = false;
            this.printPreviewBarItem16.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ShowPrevPage;
            this.printPreviewBarItem16.Id = 15;
            this.printPreviewBarItem16.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ShowPrevPageLarge;
            this.printPreviewBarItem16.Name = "printPreviewBarItem16";
            superToolTip69.FixedTooltipWidth = true;
            toolTipTitleItem69.Text = "Previous Page (PageUp)";
            toolTipItem69.LeftIndent = 6;
            toolTipItem69.Text = "Navigate to the previous page of the document.";
            superToolTip69.Items.Add(toolTipTitleItem69);
            superToolTip69.Items.Add(toolTipItem69);
            superToolTip69.MaxWidth = 210;
            this.printPreviewBarItem16.SuperTip = superToolTip69;
            // 
            // printPreviewBarItem17
            // 
            this.printPreviewBarItem17.Caption = "Next  Page ";
            this.printPreviewBarItem17.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowNextPage;
            this.printPreviewBarItem17.Description = null;
            this.printPreviewBarItem17.Enabled = false;
            this.printPreviewBarItem17.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ShowNextPage;
            this.printPreviewBarItem17.Id = 16;
            this.printPreviewBarItem17.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ShowNextPageLarge;
            this.printPreviewBarItem17.Name = "printPreviewBarItem17";
            superToolTip70.FixedTooltipWidth = true;
            toolTipTitleItem70.Text = "Next Page (PageDown)";
            toolTipItem70.LeftIndent = 6;
            toolTipItem70.Text = "Navigate to the next page of the document.";
            superToolTip70.Items.Add(toolTipTitleItem70);
            superToolTip70.Items.Add(toolTipItem70);
            superToolTip70.MaxWidth = 210;
            this.printPreviewBarItem17.SuperTip = superToolTip70;
            // 
            // printPreviewBarItem18
            // 
            this.printPreviewBarItem18.Caption = "Last  Page ";
            this.printPreviewBarItem18.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ShowLastPage;
            this.printPreviewBarItem18.Description = null;
            this.printPreviewBarItem18.Enabled = false;
            this.printPreviewBarItem18.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ShowLastPage;
            this.printPreviewBarItem18.Id = 17;
            this.printPreviewBarItem18.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ShowLastPageLarge;
            this.printPreviewBarItem18.Name = "printPreviewBarItem18";
            superToolTip71.FixedTooltipWidth = true;
            toolTipTitleItem71.Text = "Last Page (Ctrl+End)";
            toolTipItem71.LeftIndent = 6;
            toolTipItem71.Text = "Navigate to the last page of the document.";
            superToolTip71.Items.Add(toolTipTitleItem71);
            superToolTip71.Items.Add(toolTipItem71);
            superToolTip71.MaxWidth = 210;
            this.printPreviewBarItem18.SuperTip = superToolTip71;
            // 
            // printPreviewBarItem19
            // 
            this.printPreviewBarItem19.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem19.Caption = "Many Pages";
            this.printPreviewBarItem19.Command = DevExpress.XtraPrinting.PrintingSystemCommand.MultiplePages;
            this.printPreviewBarItem19.Description = null;
            this.printPreviewBarItem19.Enabled = false;
            this.printPreviewBarItem19.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_MultiplePages;
            this.printPreviewBarItem19.Id = 18;
            this.printPreviewBarItem19.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_MultiplePagesLarge;
            this.printPreviewBarItem19.Name = "printPreviewBarItem19";
            superToolTip72.FixedTooltipWidth = true;
            toolTipTitleItem72.Text = "View Many Pages";
            toolTipItem72.LeftIndent = 6;
            toolTipItem72.Text = "Choose the page layout to arrange the document pages in preview.";
            superToolTip72.Items.Add(toolTipTitleItem72);
            superToolTip72.Items.Add(toolTipItem72);
            superToolTip72.MaxWidth = 210;
            this.printPreviewBarItem19.SuperTip = superToolTip72;
            // 
            // printPreviewBarItem20
            // 
            this.printPreviewBarItem20.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem20.Caption = "Page Color";
            this.printPreviewBarItem20.Command = DevExpress.XtraPrinting.PrintingSystemCommand.FillBackground;
            this.printPreviewBarItem20.Description = null;
            this.printPreviewBarItem20.Enabled = false;
            this.printPreviewBarItem20.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_FillBackground;
            this.printPreviewBarItem20.Id = 19;
            this.printPreviewBarItem20.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_FillBackgroundLarge;
            this.printPreviewBarItem20.Name = "printPreviewBarItem20";
            superToolTip73.FixedTooltipWidth = true;
            toolTipTitleItem73.Text = "Background Color";
            toolTipItem73.LeftIndent = 6;
            toolTipItem73.Text = "Choose a color for the background of the document pages.";
            superToolTip73.Items.Add(toolTipTitleItem73);
            superToolTip73.Items.Add(toolTipItem73);
            superToolTip73.MaxWidth = 210;
            this.printPreviewBarItem20.SuperTip = superToolTip73;
            // 
            // printPreviewBarItem21
            // 
            this.printPreviewBarItem21.Caption = "Watermark";
            this.printPreviewBarItem21.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Watermark;
            this.printPreviewBarItem21.Description = null;
            this.printPreviewBarItem21.Enabled = false;
            this.printPreviewBarItem21.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_Watermark;
            this.printPreviewBarItem21.Id = 20;
            this.printPreviewBarItem21.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_WatermarkLarge;
            this.printPreviewBarItem21.Name = "printPreviewBarItem21";
            superToolTip74.FixedTooltipWidth = true;
            toolTipTitleItem74.Text = "Watermark";
            toolTipItem74.LeftIndent = 6;
            toolTipItem74.Text = "Insert ghosted text or image behind the content of a page.\r\n\r\nThis is often used " +
                "to indicate that a document is to be treated specially.";
            superToolTip74.Items.Add(toolTipTitleItem74);
            superToolTip74.Items.Add(toolTipItem74);
            superToolTip74.MaxWidth = 210;
            this.printPreviewBarItem21.SuperTip = superToolTip74;
            // 
            // printPreviewBarItem22
            // 
            this.printPreviewBarItem22.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem22.Caption = "Export To";
            this.printPreviewBarItem22.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportFile;
            this.printPreviewBarItem22.Description = null;
            this.printPreviewBarItem22.Enabled = false;
            this.printPreviewBarItem22.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportFile;
            this.printPreviewBarItem22.Id = 21;
            this.printPreviewBarItem22.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportFileLarge;
            this.printPreviewBarItem22.Name = "printPreviewBarItem22";
            superToolTip75.FixedTooltipWidth = true;
            toolTipTitleItem75.Text = "Export To...";
            toolTipItem75.LeftIndent = 6;
            toolTipItem75.Text = "Export the current document in one of the available formats, and save it to the f" +
                "ile on a disk.";
            superToolTip75.Items.Add(toolTipTitleItem75);
            superToolTip75.Items.Add(toolTipItem75);
            superToolTip75.MaxWidth = 210;
            this.printPreviewBarItem22.SuperTip = superToolTip75;
            // 
            // printPreviewBarItem23
            // 
            this.printPreviewBarItem23.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem23.Caption = "E-Mail As";
            this.printPreviewBarItem23.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendFile;
            this.printPreviewBarItem23.Description = null;
            this.printPreviewBarItem23.Enabled = false;
            this.printPreviewBarItem23.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendFile;
            this.printPreviewBarItem23.Id = 22;
            this.printPreviewBarItem23.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendFileLarge;
            this.printPreviewBarItem23.Name = "printPreviewBarItem23";
            superToolTip76.FixedTooltipWidth = true;
            toolTipTitleItem76.Text = "E-Mail As...";
            toolTipItem76.LeftIndent = 6;
            toolTipItem76.Text = "Export the current document in one of the available formats, and attach it to the" +
                " e-mail.";
            superToolTip76.Items.Add(toolTipTitleItem76);
            superToolTip76.Items.Add(toolTipItem76);
            superToolTip76.MaxWidth = 210;
            this.printPreviewBarItem23.SuperTip = superToolTip76;
            // 
            // printPreviewBarItem24
            // 
            this.printPreviewBarItem24.Caption = "Close Print Preview";
            this.printPreviewBarItem24.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ClosePreview;
            this.printPreviewBarItem24.Description = null;
            this.printPreviewBarItem24.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ClosePreview;
            this.printPreviewBarItem24.Id = 23;
            this.printPreviewBarItem24.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ClosePreviewLarge;
            this.printPreviewBarItem24.Name = "printPreviewBarItem24";
            superToolTip77.FixedTooltipWidth = true;
            toolTipTitleItem77.Text = "Close Print Preview";
            toolTipItem77.LeftIndent = 6;
            toolTipItem77.Text = "Close Print Preview of the document.";
            superToolTip77.Items.Add(toolTipTitleItem77);
            superToolTip77.Items.Add(toolTipItem77);
            superToolTip77.MaxWidth = 210;
            this.printPreviewBarItem24.SuperTip = superToolTip77;
            // 
            // printPreviewBarItem25
            // 
            this.printPreviewBarItem25.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem25.Caption = "Orientation";
            this.printPreviewBarItem25.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PageOrientation;
            this.printPreviewBarItem25.Description = null;
            this.printPreviewBarItem25.Enabled = false;
            this.printPreviewBarItem25.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_PageOrientation;
            this.printPreviewBarItem25.Id = 24;
            this.printPreviewBarItem25.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_PageOrientationLarge;
            this.printPreviewBarItem25.Name = "printPreviewBarItem25";
            superToolTip78.FixedTooltipWidth = true;
            toolTipTitleItem78.Text = "Page Orientation";
            toolTipItem78.LeftIndent = 6;
            toolTipItem78.Text = "Switch the pages between portrait and landscape layouts.";
            superToolTip78.Items.Add(toolTipTitleItem78);
            superToolTip78.Items.Add(toolTipItem78);
            superToolTip78.MaxWidth = 210;
            this.printPreviewBarItem25.SuperTip = superToolTip78;
            // 
            // printPreviewBarItem26
            // 
            this.printPreviewBarItem26.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem26.Caption = "Size";
            this.printPreviewBarItem26.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PaperSize;
            this.printPreviewBarItem26.Description = null;
            this.printPreviewBarItem26.Enabled = false;
            this.printPreviewBarItem26.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_PaperSize;
            this.printPreviewBarItem26.Id = 25;
            this.printPreviewBarItem26.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_PaperSizeLarge;
            this.printPreviewBarItem26.Name = "printPreviewBarItem26";
            superToolTip79.FixedTooltipWidth = true;
            toolTipTitleItem79.Text = "Page Size";
            toolTipItem79.LeftIndent = 6;
            toolTipItem79.Text = "Choose the paper size of the document.";
            superToolTip79.Items.Add(toolTipTitleItem79);
            superToolTip79.Items.Add(toolTipItem79);
            superToolTip79.MaxWidth = 210;
            this.printPreviewBarItem26.SuperTip = superToolTip79;
            // 
            // printPreviewBarItem27
            // 
            this.printPreviewBarItem27.ButtonStyle = DevExpress.XtraBars.BarButtonStyle.DropDown;
            this.printPreviewBarItem27.Caption = "Margins";
            this.printPreviewBarItem27.Command = DevExpress.XtraPrinting.PrintingSystemCommand.PageMargins;
            this.printPreviewBarItem27.Description = null;
            this.printPreviewBarItem27.Enabled = false;
            this.printPreviewBarItem27.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_PageMargins;
            this.printPreviewBarItem27.Id = 26;
            this.printPreviewBarItem27.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_PageMarginsLarge;
            this.printPreviewBarItem27.Name = "printPreviewBarItem27";
            superToolTip80.FixedTooltipWidth = true;
            toolTipTitleItem80.Text = "Page Margins";
            toolTipItem80.LeftIndent = 6;
            toolTipItem80.Text = "Select the margin sizes for the entire document.\r\n\r\nTo apply specific margin size" +
                "s to the document, click Custom Margins.";
            superToolTip80.Items.Add(toolTipTitleItem80);
            superToolTip80.Items.Add(toolTipItem80);
            superToolTip80.MaxWidth = 210;
            this.printPreviewBarItem27.SuperTip = superToolTip80;
            // 
            // printPreviewBarItem28
            // 
            this.printPreviewBarItem28.Caption = "PDF File";
            this.printPreviewBarItem28.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendPdf;
            this.printPreviewBarItem28.Description = "Adobe Portable Document Format";
            this.printPreviewBarItem28.Enabled = false;
            this.printPreviewBarItem28.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendPdf;
            this.printPreviewBarItem28.Id = 27;
            this.printPreviewBarItem28.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendPdfLarge;
            this.printPreviewBarItem28.Name = "printPreviewBarItem28";
            superToolTip81.FixedTooltipWidth = true;
            toolTipTitleItem81.Text = "E-Mail As PDF";
            toolTipItem81.LeftIndent = 6;
            toolTipItem81.Text = "Export the document to PDF and attach it to the e-mail.";
            superToolTip81.Items.Add(toolTipTitleItem81);
            superToolTip81.Items.Add(toolTipItem81);
            superToolTip81.MaxWidth = 210;
            this.printPreviewBarItem28.SuperTip = superToolTip81;
            // 
            // printPreviewBarItem29
            // 
            this.printPreviewBarItem29.Caption = "Text File";
            this.printPreviewBarItem29.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendTxt;
            this.printPreviewBarItem29.Description = "Plain Text";
            this.printPreviewBarItem29.Enabled = false;
            this.printPreviewBarItem29.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendTxt;
            this.printPreviewBarItem29.Id = 28;
            this.printPreviewBarItem29.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendTxtLarge;
            this.printPreviewBarItem29.Name = "printPreviewBarItem29";
            superToolTip82.FixedTooltipWidth = true;
            toolTipTitleItem82.Text = "E-Mail As Text";
            toolTipItem82.LeftIndent = 6;
            toolTipItem82.Text = "Export the document to Text and attach it to the e-mail.";
            superToolTip82.Items.Add(toolTipTitleItem82);
            superToolTip82.Items.Add(toolTipItem82);
            superToolTip82.MaxWidth = 210;
            this.printPreviewBarItem29.SuperTip = superToolTip82;
            // 
            // printPreviewBarItem30
            // 
            this.printPreviewBarItem30.Caption = "CSV File";
            this.printPreviewBarItem30.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendCsv;
            this.printPreviewBarItem30.Description = "Comma-Separated Values Text";
            this.printPreviewBarItem30.Enabled = false;
            this.printPreviewBarItem30.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendCsv;
            this.printPreviewBarItem30.Id = 29;
            this.printPreviewBarItem30.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendCsvLarge;
            this.printPreviewBarItem30.Name = "printPreviewBarItem30";
            superToolTip83.FixedTooltipWidth = true;
            toolTipTitleItem83.Text = "E-Mail As CSV";
            toolTipItem83.LeftIndent = 6;
            toolTipItem83.Text = "Export the document to CSV and attach it to the e-mail.";
            superToolTip83.Items.Add(toolTipTitleItem83);
            superToolTip83.Items.Add(toolTipItem83);
            superToolTip83.MaxWidth = 210;
            this.printPreviewBarItem30.SuperTip = superToolTip83;
            // 
            // printPreviewBarItem31
            // 
            this.printPreviewBarItem31.Caption = "MHT File";
            this.printPreviewBarItem31.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendMht;
            this.printPreviewBarItem31.Description = "Single File Web Page";
            this.printPreviewBarItem31.Enabled = false;
            this.printPreviewBarItem31.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendMht;
            this.printPreviewBarItem31.Id = 30;
            this.printPreviewBarItem31.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendMhtLarge;
            this.printPreviewBarItem31.Name = "printPreviewBarItem31";
            superToolTip84.FixedTooltipWidth = true;
            toolTipTitleItem84.Text = "E-Mail As MHT";
            toolTipItem84.LeftIndent = 6;
            toolTipItem84.Text = "Export the document to MHT and attach it to the e-mail.";
            superToolTip84.Items.Add(toolTipTitleItem84);
            superToolTip84.Items.Add(toolTipItem84);
            superToolTip84.MaxWidth = 210;
            this.printPreviewBarItem31.SuperTip = superToolTip84;
            // 
            // printPreviewBarItem32
            // 
            this.printPreviewBarItem32.Caption = "Excel File";
            this.printPreviewBarItem32.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendXls;
            this.printPreviewBarItem32.Description = "Microsoft Excel Workbook";
            this.printPreviewBarItem32.Enabled = false;
            this.printPreviewBarItem32.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendXls;
            this.printPreviewBarItem32.Id = 31;
            this.printPreviewBarItem32.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendXlsLarge;
            this.printPreviewBarItem32.Name = "printPreviewBarItem32";
            superToolTip85.FixedTooltipWidth = true;
            toolTipTitleItem85.Text = "E-Mail As XLS";
            toolTipItem85.LeftIndent = 6;
            toolTipItem85.Text = "Export the document to XLS and attach it to the e-mail.";
            superToolTip85.Items.Add(toolTipTitleItem85);
            superToolTip85.Items.Add(toolTipItem85);
            superToolTip85.MaxWidth = 210;
            this.printPreviewBarItem32.SuperTip = superToolTip85;
            // 
            // printPreviewBarItem33
            // 
            this.printPreviewBarItem33.Caption = "RTF File";
            this.printPreviewBarItem33.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendRtf;
            this.printPreviewBarItem33.Description = "Rich Text Format";
            this.printPreviewBarItem33.Enabled = false;
            this.printPreviewBarItem33.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendRtf;
            this.printPreviewBarItem33.Id = 32;
            this.printPreviewBarItem33.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendRtfLarge;
            this.printPreviewBarItem33.Name = "printPreviewBarItem33";
            superToolTip86.FixedTooltipWidth = true;
            toolTipTitleItem86.Text = "E-Mail As RTF";
            toolTipItem86.LeftIndent = 6;
            toolTipItem86.Text = "Export the document to RTF and attach it to the e-mail.";
            superToolTip86.Items.Add(toolTipTitleItem86);
            superToolTip86.Items.Add(toolTipItem86);
            superToolTip86.MaxWidth = 210;
            this.printPreviewBarItem33.SuperTip = superToolTip86;
            // 
            // printPreviewBarItem34
            // 
            this.printPreviewBarItem34.Caption = "Image File";
            this.printPreviewBarItem34.Command = DevExpress.XtraPrinting.PrintingSystemCommand.SendGraphic;
            this.printPreviewBarItem34.Description = "BMP, GIF, JPEG, PNG, TIFF, EMF, WMF";
            this.printPreviewBarItem34.Enabled = false;
            this.printPreviewBarItem34.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendGraphic;
            this.printPreviewBarItem34.Id = 33;
            this.printPreviewBarItem34.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SendGraphicLarge;
            this.printPreviewBarItem34.Name = "printPreviewBarItem34";
            superToolTip87.FixedTooltipWidth = true;
            toolTipTitleItem87.Text = "E-Mail As Image";
            toolTipItem87.LeftIndent = 6;
            toolTipItem87.Text = "Export the document to Image and attach it to the e-mail.";
            superToolTip87.Items.Add(toolTipTitleItem87);
            superToolTip87.Items.Add(toolTipItem87);
            superToolTip87.MaxWidth = 210;
            this.printPreviewBarItem34.SuperTip = superToolTip87;
            // 
            // printPreviewBarItem36
            // 
            this.printPreviewBarItem36.Caption = "HTML File";
            this.printPreviewBarItem36.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportHtm;
            this.printPreviewBarItem36.Description = "Web Page";
            this.printPreviewBarItem36.Enabled = false;
            this.printPreviewBarItem36.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportHtm;
            this.printPreviewBarItem36.Id = 35;
            this.printPreviewBarItem36.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportHtmLarge;
            this.printPreviewBarItem36.Name = "printPreviewBarItem36";
            superToolTip88.FixedTooltipWidth = true;
            toolTipTitleItem88.Text = "Export to HTML";
            toolTipItem88.LeftIndent = 6;
            toolTipItem88.Text = "Export the document to HTML and save it to the file on a disk.";
            superToolTip88.Items.Add(toolTipTitleItem88);
            superToolTip88.Items.Add(toolTipItem88);
            superToolTip88.MaxWidth = 210;
            this.printPreviewBarItem36.SuperTip = superToolTip88;
            // 
            // printPreviewBarItem37
            // 
            this.printPreviewBarItem37.Caption = "Text File";
            this.printPreviewBarItem37.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportTxt;
            this.printPreviewBarItem37.Description = "Plain Text";
            this.printPreviewBarItem37.Enabled = false;
            this.printPreviewBarItem37.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportTxt;
            this.printPreviewBarItem37.Id = 36;
            this.printPreviewBarItem37.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportTxtLarge;
            this.printPreviewBarItem37.Name = "printPreviewBarItem37";
            superToolTip89.FixedTooltipWidth = true;
            toolTipTitleItem89.Text = "Export to Text";
            toolTipItem89.LeftIndent = 6;
            toolTipItem89.Text = "Export the document to Text and save it to the file on a disk.";
            superToolTip89.Items.Add(toolTipTitleItem89);
            superToolTip89.Items.Add(toolTipItem89);
            superToolTip89.MaxWidth = 210;
            this.printPreviewBarItem37.SuperTip = superToolTip89;
            // 
            // printPreviewBarItem38
            // 
            this.printPreviewBarItem38.Caption = "CSV File";
            this.printPreviewBarItem38.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportCsv;
            this.printPreviewBarItem38.Description = "Comma-Separated Values Text";
            this.printPreviewBarItem38.Enabled = false;
            this.printPreviewBarItem38.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportCsv;
            this.printPreviewBarItem38.Id = 37;
            this.printPreviewBarItem38.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportCsvLarge;
            this.printPreviewBarItem38.Name = "printPreviewBarItem38";
            superToolTip90.FixedTooltipWidth = true;
            toolTipTitleItem90.Text = "Export to CSV";
            toolTipItem90.LeftIndent = 6;
            toolTipItem90.Text = "Export the document to CSV and save it to the file on a disk.";
            superToolTip90.Items.Add(toolTipTitleItem90);
            superToolTip90.Items.Add(toolTipItem90);
            superToolTip90.MaxWidth = 210;
            this.printPreviewBarItem38.SuperTip = superToolTip90;
            // 
            // printPreviewBarItem39
            // 
            this.printPreviewBarItem39.Caption = "MHT File";
            this.printPreviewBarItem39.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportMht;
            this.printPreviewBarItem39.Description = "Single File Web Page";
            this.printPreviewBarItem39.Enabled = false;
            this.printPreviewBarItem39.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportMht;
            this.printPreviewBarItem39.Id = 38;
            this.printPreviewBarItem39.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportMhtLarge;
            this.printPreviewBarItem39.Name = "printPreviewBarItem39";
            superToolTip91.FixedTooltipWidth = true;
            toolTipTitleItem91.Text = "Export to MHT";
            toolTipItem91.LeftIndent = 6;
            toolTipItem91.Text = "Export the document to MHT and save it to the file on a disk.";
            superToolTip91.Items.Add(toolTipTitleItem91);
            superToolTip91.Items.Add(toolTipItem91);
            superToolTip91.MaxWidth = 210;
            this.printPreviewBarItem39.SuperTip = superToolTip91;
            // 
            // printPreviewBarItem40
            // 
            this.printPreviewBarItem40.Caption = "Excel File";
            this.printPreviewBarItem40.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportXls;
            this.printPreviewBarItem40.Description = "Microsoft Excel Workbook";
            this.printPreviewBarItem40.Enabled = false;
            this.printPreviewBarItem40.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportXls;
            this.printPreviewBarItem40.Id = 39;
            this.printPreviewBarItem40.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportXlsLarge;
            this.printPreviewBarItem40.Name = "printPreviewBarItem40";
            superToolTip92.FixedTooltipWidth = true;
            toolTipTitleItem92.Text = "Export to XLS";
            toolTipItem92.LeftIndent = 6;
            toolTipItem92.Text = "Export the document to XLS and save it to the file on a disk.";
            superToolTip92.Items.Add(toolTipTitleItem92);
            superToolTip92.Items.Add(toolTipItem92);
            superToolTip92.MaxWidth = 210;
            this.printPreviewBarItem40.SuperTip = superToolTip92;
            // 
            // printPreviewBarItem41
            // 
            this.printPreviewBarItem41.Caption = "RTF File";
            this.printPreviewBarItem41.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportRtf;
            this.printPreviewBarItem41.Description = "Rich Text Format";
            this.printPreviewBarItem41.Enabled = false;
            this.printPreviewBarItem41.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportRtf;
            this.printPreviewBarItem41.Id = 40;
            this.printPreviewBarItem41.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportRtfLarge;
            this.printPreviewBarItem41.Name = "printPreviewBarItem41";
            superToolTip93.FixedTooltipWidth = true;
            toolTipTitleItem93.Text = "Export to RTF";
            toolTipItem93.LeftIndent = 6;
            toolTipItem93.Text = "Export the document to RTF and save it to the file on a disk.";
            superToolTip93.Items.Add(toolTipTitleItem93);
            superToolTip93.Items.Add(toolTipItem93);
            superToolTip93.MaxWidth = 210;
            this.printPreviewBarItem41.SuperTip = superToolTip93;
            // 
            // printPreviewBarItem42
            // 
            this.printPreviewBarItem42.Caption = "Image File";
            this.printPreviewBarItem42.Command = DevExpress.XtraPrinting.PrintingSystemCommand.ExportGraphic;
            this.printPreviewBarItem42.Description = "BMP, GIF, JPEG, PNG, TIFF, EMF, WMF";
            this.printPreviewBarItem42.Enabled = false;
            this.printPreviewBarItem42.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportGraphic;
            this.printPreviewBarItem42.Id = 41;
            this.printPreviewBarItem42.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportGraphicLarge;
            this.printPreviewBarItem42.Name = "printPreviewBarItem42";
            superToolTip94.FixedTooltipWidth = true;
            toolTipTitleItem94.Text = "Export to Image";
            toolTipItem94.LeftIndent = 6;
            toolTipItem94.Text = "Export the document to Image and save it to the file on a disk.";
            superToolTip94.Items.Add(toolTipTitleItem94);
            superToolTip94.Items.Add(toolTipItem94);
            superToolTip94.MaxWidth = 210;
            this.printPreviewBarItem42.SuperTip = superToolTip94;
            // 
            // printPreviewStaticItem1
            // 
            this.printPreviewStaticItem1.Caption = "Current Page: none";
            this.printPreviewStaticItem1.Id = 42;
            this.printPreviewStaticItem1.LeftIndent = 1;
            this.printPreviewStaticItem1.Name = "printPreviewStaticItem1";
            this.printPreviewStaticItem1.RightIndent = 1;
            this.printPreviewStaticItem1.TextAlignment = System.Drawing.StringAlignment.Near;
            this.printPreviewStaticItem1.Type = "CurrentPageNo";
            // 
            // printPreviewStaticItem2
            // 
            this.printPreviewStaticItem2.Caption = "Total Pages: 0";
            this.printPreviewStaticItem2.Id = 43;
            this.printPreviewStaticItem2.LeftIndent = 1;
            this.printPreviewStaticItem2.Name = "printPreviewStaticItem2";
            this.printPreviewStaticItem2.RightIndent = 1;
            this.printPreviewStaticItem2.TextAlignment = System.Drawing.StringAlignment.Near;
            this.printPreviewStaticItem2.Type = "TotalPageNo";
            // 
            // printPreviewStaticItem3
            // 
            this.printPreviewStaticItem3.Caption = "Zoom Factor: 100%";
            this.printPreviewStaticItem3.Id = 44;
            this.printPreviewStaticItem3.LeftIndent = 1;
            this.printPreviewStaticItem3.Name = "printPreviewStaticItem3";
            this.printPreviewStaticItem3.RightIndent = 1;
            this.printPreviewStaticItem3.TextAlignment = System.Drawing.StringAlignment.Near;
            this.printPreviewStaticItem3.Type = "ZoomFactor";
            // 
            // printPreviewBarItem35
            // 
            this.printPreviewBarItem35.Caption = "Open";
            this.printPreviewBarItem35.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Open;
            this.printPreviewBarItem35.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_Open;
            this.printPreviewBarItem35.Id = 31;
            this.printPreviewBarItem35.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_OpenLarge;
            this.printPreviewBarItem35.Name = "printPreviewBarItem35";
            superToolTip95.FixedTooltipWidth = true;
            toolTipTitleItem95.Text = "Open (Ctrl + O)";
            toolTipItem95.LeftIndent = 6;
            toolTipItem95.Text = "Open previously saved document.";
            superToolTip95.Items.Add(toolTipTitleItem95);
            superToolTip95.Items.Add(toolTipItem95);
            superToolTip95.MaxWidth = 210;
            this.printPreviewBarItem35.SuperTip = superToolTip95;
            // 
            // printPreviewBarItem43
            // 
            this.printPreviewBarItem43.Caption = "Save";
            this.printPreviewBarItem43.Command = DevExpress.XtraPrinting.PrintingSystemCommand.Save;
            this.printPreviewBarItem43.Enabled = false;
            this.printPreviewBarItem43.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_Save;
            this.printPreviewBarItem43.Id = 32;
            this.printPreviewBarItem43.LargeGlyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_SaveLarge;
            this.printPreviewBarItem43.Name = "printPreviewBarItem43";
            superToolTip96.FixedTooltipWidth = true;
            toolTipTitleItem96.Text = "Save (Ctrl + S)";
            toolTipItem96.LeftIndent = 6;
            toolTipItem96.Text = "Save the document in an application specific file format.";
            superToolTip96.Items.Add(toolTipTitleItem96);
            superToolTip96.Items.Add(toolTipItem96);
            superToolTip96.MaxWidth = 210;
            this.printPreviewBarItem43.SuperTip = superToolTip96;
            // 
            // printPreviewRibbonPage1
            // 
            this.printPreviewRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.printPreviewRibbonPageGroup7,
            this.printPreviewRibbonPageGroup1,
            this.printPreviewRibbonPageGroup2,
            this.printPreviewRibbonPageGroup3,
            this.printPreviewRibbonPageGroup4,
            this.printPreviewRibbonPageGroup5,
            this.printPreviewRibbonPageGroup6});
            this.printPreviewRibbonPage1.KeyTip = "";
            this.printPreviewRibbonPage1.Name = "printPreviewRibbonPage1";
            this.printPreviewRibbonPage1.Text = "Print Preview";
            // 
            // printPreviewRibbonPageGroup7
            // 
            this.printPreviewRibbonPageGroup7.ItemLinks.Add(this.printPreviewBarItem35);
            this.printPreviewRibbonPageGroup7.ItemLinks.Add(this.printPreviewBarItem43);
            this.printPreviewRibbonPageGroup7.KeyTip = "";
            this.printPreviewRibbonPageGroup7.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Document;
            this.printPreviewRibbonPageGroup7.Name = "printPreviewRibbonPageGroup7";
            this.printPreviewRibbonPageGroup7.ShowCaptionButton = false;
            this.printPreviewRibbonPageGroup7.Text = "Document";
            // 
            // printPreviewRibbonPageGroup1
            // 
            this.printPreviewRibbonPageGroup1.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_PrintDirect;
            this.printPreviewRibbonPageGroup1.ItemLinks.Add(this.printPreviewBarItem3);
            this.printPreviewRibbonPageGroup1.ItemLinks.Add(this.printPreviewBarItem4);
            this.printPreviewRibbonPageGroup1.ItemLinks.Add(this.printPreviewBarItem5);
            this.printPreviewRibbonPageGroup1.KeyTip = "";
            this.printPreviewRibbonPageGroup1.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Print;
            this.printPreviewRibbonPageGroup1.Name = "printPreviewRibbonPageGroup1";
            this.printPreviewRibbonPageGroup1.ShowCaptionButton = false;
            this.printPreviewRibbonPageGroup1.Text = "Print";
            // 
            // printPreviewRibbonPageGroup2
            // 
            this.printPreviewRibbonPageGroup2.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_PageMargins;
            this.printPreviewRibbonPageGroup2.ItemLinks.Add(this.printPreviewBarItem7);
            this.printPreviewRibbonPageGroup2.ItemLinks.Add(this.printPreviewBarItem8);
            this.printPreviewRibbonPageGroup2.ItemLinks.Add(this.printPreviewBarItem27);
            this.printPreviewRibbonPageGroup2.ItemLinks.Add(this.printPreviewBarItem25);
            this.printPreviewRibbonPageGroup2.ItemLinks.Add(this.printPreviewBarItem26);
            this.printPreviewRibbonPageGroup2.KeyTip = "";
            this.printPreviewRibbonPageGroup2.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.PageSetup;
            this.printPreviewRibbonPageGroup2.Name = "printPreviewRibbonPageGroup2";
            superToolTip97.FixedTooltipWidth = true;
            toolTipTitleItem97.Text = "Page Setup";
            toolTipItem97.Appearance.Image = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_PageSetupDialog;
            toolTipItem97.Appearance.Options.UseImage = true;
            toolTipItem97.Image = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_PageSetupDialog;
            toolTipItem97.LeftIndent = 6;
            toolTipItem97.Text = "Show the Page Setup dialog.";
            superToolTip97.Items.Add(toolTipTitleItem97);
            superToolTip97.Items.Add(toolTipItem97);
            superToolTip97.MaxWidth = 318;
            this.printPreviewRibbonPageGroup2.SuperTip = superToolTip97;
            this.printPreviewRibbonPageGroup2.Text = "Page Setup";
            // 
            // printPreviewRibbonPageGroup3
            // 
            this.printPreviewRibbonPageGroup3.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_Find;
            this.printPreviewRibbonPageGroup3.ItemLinks.Add(this.printPreviewBarItem2);
            this.printPreviewRibbonPageGroup3.ItemLinks.Add(this.printPreviewBarItem1);
            this.printPreviewRibbonPageGroup3.ItemLinks.Add(this.printPreviewBarItem15, true);
            this.printPreviewRibbonPageGroup3.ItemLinks.Add(this.printPreviewBarItem16);
            this.printPreviewRibbonPageGroup3.ItemLinks.Add(this.printPreviewBarItem17);
            this.printPreviewRibbonPageGroup3.ItemLinks.Add(this.printPreviewBarItem18);
            this.printPreviewRibbonPageGroup3.KeyTip = "";
            this.printPreviewRibbonPageGroup3.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Navigation;
            this.printPreviewRibbonPageGroup3.Name = "printPreviewRibbonPageGroup3";
            this.printPreviewRibbonPageGroup3.ShowCaptionButton = false;
            this.printPreviewRibbonPageGroup3.Text = "Navigation";
            // 
            // printPreviewRibbonPageGroup4
            // 
            this.printPreviewRibbonPageGroup4.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_Zoom;
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem9);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem10);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem11);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem19);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem12);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem14);
            this.printPreviewRibbonPageGroup4.ItemLinks.Add(this.printPreviewBarItem13);
            this.printPreviewRibbonPageGroup4.KeyTip = "";
            this.printPreviewRibbonPageGroup4.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Zoom;
            this.printPreviewRibbonPageGroup4.Name = "printPreviewRibbonPageGroup4";
            this.printPreviewRibbonPageGroup4.ShowCaptionButton = false;
            this.printPreviewRibbonPageGroup4.Text = "Zoom";
            // 
            // printPreviewRibbonPageGroup5
            // 
            this.printPreviewRibbonPageGroup5.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_Watermark;
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem20);
            this.printPreviewRibbonPageGroup5.ItemLinks.Add(this.printPreviewBarItem21);
            this.printPreviewRibbonPageGroup5.KeyTip = "";
            this.printPreviewRibbonPageGroup5.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Background;
            this.printPreviewRibbonPageGroup5.Name = "printPreviewRibbonPageGroup5";
            this.printPreviewRibbonPageGroup5.ShowCaptionButton = false;
            this.printPreviewRibbonPageGroup5.Text = "Page Background";
            // 
            // printPreviewRibbonPageGroup6
            // 
            this.printPreviewRibbonPageGroup6.Glyph = global::Innotelli.Report1.TPrintRibbonControllerResources.RibbonPrintPreview_ExportFile;
            this.printPreviewRibbonPageGroup6.ItemLinks.Add(this.printPreviewBarItem22);
            this.printPreviewRibbonPageGroup6.ItemLinks.Add(this.printPreviewBarItem23);
            this.printPreviewRibbonPageGroup6.ItemLinks.Add(this.printPreviewBarItem24, true);
            this.printPreviewRibbonPageGroup6.KeyTip = "";
            this.printPreviewRibbonPageGroup6.Kind = DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroupKind.Export;
            this.printPreviewRibbonPageGroup6.Name = "printPreviewRibbonPageGroup6";
            this.printPreviewRibbonPageGroup6.ShowCaptionButton = false;
            this.printPreviewRibbonPageGroup6.Text = "Export";
            // 
            // xrHtmlRibbonPage1
            // 
            this.xrHtmlRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup8});
            this.xrHtmlRibbonPage1.KeyTip = "";
            this.xrHtmlRibbonPage1.Name = "xrHtmlRibbonPage1";
            this.xrHtmlRibbonPage1.Text = "HTML View";
            // 
            // xrDesignRibbonPageGroup8
            // 
            this.xrDesignRibbonPageGroup8.ItemLinks.Add(this.commandBarItem46);
            this.xrDesignRibbonPageGroup8.ItemLinks.Add(this.commandBarItem47);
            this.xrDesignRibbonPageGroup8.ItemLinks.Add(this.commandBarItem48, true);
            this.xrDesignRibbonPageGroup8.ItemLinks.Add(this.commandBarItem49);
            this.xrDesignRibbonPageGroup8.ItemLinks.Add(this.commandBarItem50, true);
            this.xrDesignRibbonPageGroup8.KeyTip = "";
            this.xrDesignRibbonPageGroup8.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.HtmlNavigation;
            this.xrDesignRibbonPageGroup8.Name = "xrDesignRibbonPageGroup8";
            this.xrDesignRibbonPageGroup8.ShowCaptionButton = false;
            this.xrDesignRibbonPageGroup8.Text = "Navigation";
            // 
            // xrDesignRibbonPage1
            // 
            this.xrDesignRibbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.xrDesignRibbonPageGroup1,
            this.xrDesignRibbonPageGroup2,
            this.xrDesignRibbonPageGroup3,
            this.xrDesignRibbonPageGroup4,
            this.xrDesignRibbonPageGroup5,
            this.xrDesignRibbonPageGroup6,
            this.xrDesignRibbonPageGroup7});
            this.xrDesignRibbonPage1.KeyTip = "";
            this.xrDesignRibbonPage1.Name = "xrDesignRibbonPage1";
            this.xrDesignRibbonPage1.Text = "Report Designer";
            // 
            // xrDesignRibbonPageGroup1
            // 
            this.xrDesignRibbonPageGroup1.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_Report;
            this.xrDesignRibbonPageGroup1.ItemLinks.Add(this.commandBarItem31);
            this.xrDesignRibbonPageGroup1.ItemLinks.Add(this.commandBarItem35);
            this.xrDesignRibbonPageGroup1.ItemLinks.Add(this.commandBarItem32);
            this.xrDesignRibbonPageGroup1.KeyTip = "";
            this.xrDesignRibbonPageGroup1.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Report;
            this.xrDesignRibbonPageGroup1.Name = "xrDesignRibbonPageGroup1";
            this.xrDesignRibbonPageGroup1.ShowCaptionButton = false;
            this.xrDesignRibbonPageGroup1.Text = "Report";
            // 
            // xrDesignRibbonPageGroup2
            // 
            this.xrDesignRibbonPageGroup2.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_Edit;
            this.xrDesignRibbonPageGroup2.ItemLinks.Add(this.commandBarItem38);
            this.xrDesignRibbonPageGroup2.ItemLinks.Add(this.commandBarItem39);
            this.xrDesignRibbonPageGroup2.ItemLinks.Add(this.commandBarItem40);
            this.xrDesignRibbonPageGroup2.ItemLinks.Add(this.commandBarItem41, true);
            this.xrDesignRibbonPageGroup2.ItemLinks.Add(this.commandBarItem42);
            this.xrDesignRibbonPageGroup2.KeyTip = "";
            this.xrDesignRibbonPageGroup2.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Edit;
            this.xrDesignRibbonPageGroup2.Name = "xrDesignRibbonPageGroup2";
            this.xrDesignRibbonPageGroup2.ShowCaptionButton = false;
            this.xrDesignRibbonPageGroup2.Text = "Edit";
            // 
            // xrDesignRibbonPageGroup3
            // 
            this.xrDesignRibbonPageGroup3.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_Font;
            this.xrDesignRibbonPageGroup3.ItemLinks.Add(this.barEditItem1);
            this.xrDesignRibbonPageGroup3.ItemLinks.Add(this.xrDesignBarButtonGroup1);
            this.xrDesignRibbonPageGroup3.ItemLinks.Add(this.barEditItem2);
            this.xrDesignRibbonPageGroup3.ItemLinks.Add(this.xrDesignBarButtonGroup2);
            this.xrDesignRibbonPageGroup3.ItemLinks.Add(this.xrDesignBarButtonGroup3);
            this.xrDesignRibbonPageGroup3.KeyTip = "";
            this.xrDesignRibbonPageGroup3.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Font;
            this.xrDesignRibbonPageGroup3.Name = "xrDesignRibbonPageGroup3";
            this.xrDesignRibbonPageGroup3.ShowCaptionButton = false;
            this.xrDesignRibbonPageGroup3.Text = "Font";
            // 
            // xrDesignRibbonPageGroup4
            // 
            this.xrDesignRibbonPageGroup4.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_AlignVerticalCenters;
            this.xrDesignRibbonPageGroup4.ItemLinks.Add(this.xrDesignBarButtonGroup4);
            this.xrDesignRibbonPageGroup4.ItemLinks.Add(this.xrDesignBarButtonGroup5);
            this.xrDesignRibbonPageGroup4.KeyTip = "";
            this.xrDesignRibbonPageGroup4.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Alignment;
            this.xrDesignRibbonPageGroup4.Name = "xrDesignRibbonPageGroup4";
            this.xrDesignRibbonPageGroup4.ShowCaptionButton = false;
            this.xrDesignRibbonPageGroup4.Text = "Alignment";
            // 
            // xrDesignRibbonPageGroup5
            // 
            this.xrDesignRibbonPageGroup5.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_SizeToControl;
            this.xrDesignRibbonPageGroup5.ItemLinks.Add(this.xrDesignBarButtonGroup6);
            this.xrDesignRibbonPageGroup5.ItemLinks.Add(this.xrDesignBarButtonGroup7);
            this.xrDesignRibbonPageGroup5.ItemLinks.Add(this.xrDesignBarButtonGroup8);
            this.xrDesignRibbonPageGroup5.ItemLinks.Add(this.xrDesignBarButtonGroup9);
            this.xrDesignRibbonPageGroup5.KeyTip = "";
            this.xrDesignRibbonPageGroup5.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.SizeAndLayout;
            this.xrDesignRibbonPageGroup5.Name = "xrDesignRibbonPageGroup5";
            this.xrDesignRibbonPageGroup5.ShowCaptionButton = false;
            this.xrDesignRibbonPageGroup5.Text = "Layout";
            // 
            // xrDesignRibbonPageGroup6
            // 
            this.xrDesignRibbonPageGroup6.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_Zoom;
            this.xrDesignRibbonPageGroup6.ItemLinks.Add(this.commandBarItem45);
            this.xrDesignRibbonPageGroup6.ItemLinks.Add(this.commandBarItem43);
            this.xrDesignRibbonPageGroup6.ItemLinks.Add(this.commandBarItem44);
            this.xrDesignRibbonPageGroup6.KeyTip = "";
            this.xrDesignRibbonPageGroup6.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.Zoom;
            this.xrDesignRibbonPageGroup6.Name = "xrDesignRibbonPageGroup6";
            this.xrDesignRibbonPageGroup6.ShowCaptionButton = false;
            this.xrDesignRibbonPageGroup6.Text = "Zoom";
            // 
            // xrDesignRibbonPageGroup7
            // 
            this.xrDesignRibbonPageGroup7.Glyph = global::Innotelli.Report1.TXRDesignRibbonControllerResources.RibbonUserDesigner_Windows;
            this.xrDesignRibbonPageGroup7.ItemLinks.Add(this.barDockPanelsListItem1);
            this.xrDesignRibbonPageGroup7.KeyTip = "";
            this.xrDesignRibbonPageGroup7.Kind = DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroupKind.View;
            this.xrDesignRibbonPageGroup7.Name = "xrDesignRibbonPageGroup7";
            this.xrDesignRibbonPageGroup7.ShowCaptionButton = false;
            this.xrDesignRibbonPageGroup7.Text = "View";
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1});
            this.ribbonPage1.KeyTip = "";
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "Appearance";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.ribbonGallerySkins);
            this.ribbonPageGroup1.KeyTip = "";
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.ShowCaptionButton = false;
            this.ribbonPageGroup1.Text = "Skins";
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // repositoryItemTextEdit2
            // 
            this.repositoryItemTextEdit2.Name = "repositoryItemTextEdit2";
            // 
            // repositoryItemTextEdit3
            // 
            this.repositoryItemTextEdit3.Name = "repositoryItemTextEdit3";
            // 
            // repositoryItemTextEdit4
            // 
            this.repositoryItemTextEdit4.Name = "repositoryItemTextEdit4";
            // 
            // repositoryItemTextEdit5
            // 
            this.repositoryItemTextEdit5.Name = "repositoryItemTextEdit5";
            // 
            // repositoryItemTextEdit6
            // 
            this.repositoryItemTextEdit6.Name = "repositoryItemTextEdit6";
            // 
            // repositoryItemTextEdit7
            // 
            this.repositoryItemTextEdit7.Name = "repositoryItemTextEdit7";
            // 
            // repositoryItemTextEdit8
            // 
            this.repositoryItemTextEdit8.Name = "repositoryItemTextEdit8";
            // 
            // ribbonStatusBar1
            // 
            this.ribbonStatusBar1.Location = new System.Drawing.Point(0, 725);
            this.ribbonStatusBar1.Name = "ribbonStatusBar1";
            this.ribbonStatusBar1.Ribbon = this.ribbonControl1;
            this.ribbonStatusBar1.Size = new System.Drawing.Size(1122, 23);
            // 
            // defaultLookAndFeel1
            // 
            //this.defaultLookAndFeel1.LookAndFeel.SkinName = "Office 2007 Blue";
            // 
            // xrDesignRibbonController1
            // 
            this.xrDesignRibbonController1.RibbonControl = this.ribbonControl1;
            this.xrDesignRibbonController1.RibbonStatusBar = null;
            this.xrDesignRibbonController1.XRDesignDockManager = this.xrDesignDockManager1;
            this.xrDesignRibbonController1.XRDesignPanel = this.xrDesignPanel1;
            // 
            // xrDesignDockManager1
            // 
            this.xrDesignDockManager1.Form = this;
            this.xrDesignDockManager1.HiddenPanels.AddRange(new DevExpress.XtraBars.Docking.DockPanel[] {
            this.panelContainer1,
            this.toolBoxDockPanel1});
            this.xrDesignDockManager1.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("xrDesignDockManager1.ImageStream")));
            this.xrDesignDockManager1.TopZIndexControls.AddRange(new string[] {
            "DevExpress.XtraBars.BarDockControl",
            "System.Windows.Forms.StatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonStatusBar",
            "DevExpress.XtraBars.Ribbon.RibbonControl"});
            this.xrDesignDockManager1.XRDesignPanel = this.xrDesignPanel1;
            // 
            // panelContainer1
            // 
            this.panelContainer1.Controls.Add(this.panelContainer2);
            this.panelContainer1.Controls.Add(this.propertyGridDockPanel1);
            this.panelContainer1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Right;
            this.panelContainer1.ID = new System.Guid("4b7f6119-7bfa-472b-990d-23a42b8aacbb");
            this.panelContainer1.Location = new System.Drawing.Point(872, 149);
            this.panelContainer1.Name = "panelContainer1";
            this.panelContainer1.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Right;
            this.panelContainer1.SavedIndex = 0;
            this.panelContainer1.Size = new System.Drawing.Size(250, 576);
            this.panelContainer1.Text = "panelContainer1";
            this.panelContainer1.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Hidden;
            // 
            // panelContainer2
            // 
            this.panelContainer2.ActiveChild = this.fieldListDockPanel1;
            this.panelContainer2.Controls.Add(this.fieldListDockPanel1);
            this.panelContainer2.Controls.Add(this.reportExplorerDockPanel1);
            this.panelContainer2.Dock = DevExpress.XtraBars.Docking.DockingStyle.Bottom;
            this.panelContainer2.ID = new System.Guid("5a9336ca-d218-4d35-9b71-496b23b3883a");
            this.panelContainer2.Location = new System.Drawing.Point(0, 0);
            this.panelContainer2.Name = "panelContainer2";
            this.panelContainer2.Size = new System.Drawing.Size(250, 288);
            this.panelContainer2.Tabbed = true;
            this.panelContainer2.Text = "panelContainer2";
            // 
            // fieldListDockPanel1
            // 
            this.fieldListDockPanel1.Controls.Add(this.fieldListDockPanel1_Container);
            this.fieldListDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.fieldListDockPanel1.ID = new System.Guid("faf69838-a93f-4114-83e8-d0d09cc5ce95");
            this.fieldListDockPanel1.ImageIndex = 0;
            this.fieldListDockPanel1.Location = new System.Drawing.Point(3, 24);
            this.fieldListDockPanel1.Name = "fieldListDockPanel1";
            this.fieldListDockPanel1.Size = new System.Drawing.Size(244, 239);
            this.fieldListDockPanel1.Text = "Field List";
            this.fieldListDockPanel1.XRDesignPanel = this.xrDesignPanel1;
            // 
            // fieldListDockPanel1_Container
            // 
            this.fieldListDockPanel1_Container.Location = new System.Drawing.Point(0, 0);
            this.fieldListDockPanel1_Container.Name = "fieldListDockPanel1_Container";
            this.fieldListDockPanel1_Container.Size = new System.Drawing.Size(244, 239);
            this.fieldListDockPanel1_Container.TabIndex = 0;
            // 
            // xrDesignPanel1
            // 
            this.xrDesignPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.xrDesignPanel1.Location = new System.Drawing.Point(0, 149);
            this.xrDesignPanel1.Name = "xrDesignPanel1";
            this.xrDesignPanel1.Padding = new System.Windows.Forms.Padding(1);
            this.xrDesignPanel1.Size = new System.Drawing.Size(1122, 576);
            this.xrDesignPanel1.TabIndex = 5;
            // 
            // reportExplorerDockPanel1
            // 
            this.reportExplorerDockPanel1.Controls.Add(this.reportExplorerDockPanel1_Container);
            this.reportExplorerDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Fill;
            this.reportExplorerDockPanel1.ID = new System.Guid("fb3ec6cc-3b9b-4b9c-91cf-cff78c1edbf1");
            this.reportExplorerDockPanel1.ImageIndex = 2;
            this.reportExplorerDockPanel1.Location = new System.Drawing.Point(3, 24);
            this.reportExplorerDockPanel1.Name = "reportExplorerDockPanel1";
            this.reportExplorerDockPanel1.Size = new System.Drawing.Size(244, 239);
            this.reportExplorerDockPanel1.Text = "Report Explorer";
            this.reportExplorerDockPanel1.XRDesignPanel = this.xrDesignPanel1;
            // 
            // reportExplorerDockPanel1_Container
            // 
            this.reportExplorerDockPanel1_Container.Location = new System.Drawing.Point(0, 0);
            this.reportExplorerDockPanel1_Container.Name = "reportExplorerDockPanel1_Container";
            this.reportExplorerDockPanel1_Container.Size = new System.Drawing.Size(244, 239);
            this.reportExplorerDockPanel1_Container.TabIndex = 0;
            // 
            // propertyGridDockPanel1
            // 
            this.propertyGridDockPanel1.Controls.Add(this.propertyGridDockPanel1_Container);
            this.propertyGridDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Bottom;
            this.propertyGridDockPanel1.FloatVertical = true;
            this.propertyGridDockPanel1.ID = new System.Guid("b38d12c3-cd06-4dec-b93d-63a0088e495a");
            this.propertyGridDockPanel1.ImageIndex = 1;
            this.propertyGridDockPanel1.Location = new System.Drawing.Point(0, 288);
            this.propertyGridDockPanel1.Name = "propertyGridDockPanel1";
            this.propertyGridDockPanel1.Size = new System.Drawing.Size(250, 288);
            this.propertyGridDockPanel1.Text = "Property Grid";
            this.propertyGridDockPanel1.XRDesignPanel = this.xrDesignPanel1;
            // 
            // propertyGridDockPanel1_Container
            // 
            this.propertyGridDockPanel1_Container.Location = new System.Drawing.Point(3, 24);
            this.propertyGridDockPanel1_Container.Name = "propertyGridDockPanel1_Container";
            this.propertyGridDockPanel1_Container.Size = new System.Drawing.Size(244, 261);
            this.propertyGridDockPanel1_Container.TabIndex = 0;
            // 
            // toolBoxDockPanel1
            // 
            this.toolBoxDockPanel1.Controls.Add(this.toolBoxDockPanel1_Container);
            this.toolBoxDockPanel1.Dock = DevExpress.XtraBars.Docking.DockingStyle.Left;
            this.toolBoxDockPanel1.ID = new System.Guid("161a5a1a-d9b9-4f06-9ac4-d0c3e507c54f");
            this.toolBoxDockPanel1.ImageIndex = 3;
            this.toolBoxDockPanel1.Location = new System.Drawing.Point(0, 149);
            this.toolBoxDockPanel1.Name = "toolBoxDockPanel1";
            this.toolBoxDockPanel1.SavedDock = DevExpress.XtraBars.Docking.DockingStyle.Left;
            this.toolBoxDockPanel1.SavedIndex = 0;
            this.toolBoxDockPanel1.Size = new System.Drawing.Size(165, 576);
            this.toolBoxDockPanel1.Text = "Tool Box";
            this.toolBoxDockPanel1.Visibility = DevExpress.XtraBars.Docking.DockVisibility.Hidden;
            this.toolBoxDockPanel1.XRDesignPanel = this.xrDesignPanel1;
            // 
            // toolBoxDockPanel1_Container
            // 
            this.toolBoxDockPanel1_Container.Location = new System.Drawing.Point(3, 24);
            this.toolBoxDockPanel1_Container.Name = "toolBoxDockPanel1_Container";
            this.toolBoxDockPanel1_Container.Size = new System.Drawing.Size(159, 549);
            this.toolBoxDockPanel1_Container.TabIndex = 0;
            // 
            // TDesignerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1122, 748);
            this.Controls.Add(this.xrDesignPanel1);
            this.Controls.Add(this.ribbonStatusBar1);
            this.Controls.Add(this.ribbonControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "TDesignerForm";
            this.Ribbon = this.ribbonControl1;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.StatusBar = this.ribbonStatusBar1;
            this.Text = "XtraReports End-User Designer Ribbon Demo (C# code)";
            ((System.ComponentModel.ISupportInitialize)(this.recentlyUsedItemsComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.designRepositoryItemComboBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.applicationMenu1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignRibbonController1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignDockManager1)).EndInit();
            this.panelContainer1.ResumeLayout(false);
            this.panelContainer2.ResumeLayout(false);
            this.fieldListDockPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.xrDesignPanel1)).EndInit();
            this.reportExplorerDockPanel1.ResumeLayout(false);
            this.propertyGridDockPanel1.ResumeLayout(false);
            this.toolBoxDockPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

		}

		#endregion

		private DevExpress.XtraBars.Ribbon.RibbonControl ribbonControl1;
		private DevExpress.XtraBars.Ribbon.RibbonStatusBar ribbonStatusBar1;
		private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
		private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit2;
		private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit3;
		private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit4;
		private DevExpress.XtraBars.Ribbon.ApplicationMenu applicationMenu1;
		private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit5;
		private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit6;
		private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit7;
		private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit8;
		private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
		private DevExpress.XtraBars.RibbonGalleryBarItem ribbonGallerySkins;
		private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
		private DevExpress.XtraBars.BarStaticItem barStaticItem1;
		private DevExpress.LookAndFeel.DefaultLookAndFeel defaultLookAndFeel1;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem1;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem2;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem3;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem4;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem5;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem6;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem7;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem8;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem9;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem10;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem11;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem12;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem13;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem14;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem15;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem16;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem17;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem18;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem19;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem20;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem21;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem22;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem23;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem24;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem25;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem26;
		private DevExpress.XtraReports.UserDesigner.CommandColorBarItem commandColorBarItem1;
		private DevExpress.XtraReports.UserDesigner.CommandColorBarItem commandColorBarItem2;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem27;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem28;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem29;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem30;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem31;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem32;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem33;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem34;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem35;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem36;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem37;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem38;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem39;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem40;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem41;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem42;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem43;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem44;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem45;
		private DevExpress.XtraBars.BarEditItem barEditItem1;
		private DevExpress.XtraBars.BarEditItem barEditItem2;
		private DevExpress.XtraReports.UserDesigner.BarDockPanelsListItem barDockPanelsListItem1;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem46;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem47;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem48;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem49;
		private DevExpress.XtraReports.UserDesigner.CommandBarItem commandBarItem50;
		private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup1;
		private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup2;
		private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup3;
		private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup4;
		private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup5;
		private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup6;
		private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup7;
		private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup8;
		private DevExpress.XtraReports.UserDesigner.XRDesignBarButtonGroup xrDesignBarButtonGroup9;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem1;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem2;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem3;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem4;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem5;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem6;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem7;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem8;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem9;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem10;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem11;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem12;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem13;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem14;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem15;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem16;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem17;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem18;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem19;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem20;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem21;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem22;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem23;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem24;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem25;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem26;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem27;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem28;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem29;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem30;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem31;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem32;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem33;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem34;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem36;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem37;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem38;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem39;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem40;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem41;
		private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem42;
		private DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem printPreviewStaticItem1;
		private DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem printPreviewStaticItem2;
		private DevExpress.XtraPrinting.Preview.PrintPreviewStaticItem printPreviewStaticItem3;
		private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPage xrDesignRibbonPage1;
		private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup1;
		private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup2;
		private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup3;
		private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup4;
		private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup5;
		private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup6;
		private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup7;
		private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPage printPreviewRibbonPage1;
		private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup1;
		private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup2;
		private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup3;
		private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup4;
		private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup5;
		private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup6;
		private DevExpress.XtraReports.UserDesigner.XRHtmlRibbonPage xrHtmlRibbonPage1;
		private DevExpress.XtraReports.UserDesigner.XRDesignRibbonPageGroup xrDesignRibbonPageGroup8;
		private DevExpress.XtraReports.UserDesigner.XRDesignRibbonController xrDesignRibbonController1;
		private DevExpress.XtraReports.UserDesigner.XRDesignPanel xrDesignPanel1;
		private DevExpress.XtraReports.UserDesigner.RecentlyUsedItemsComboBox recentlyUsedItemsComboBox1;
		private DevExpress.XtraReports.UserDesigner.DesignRepositoryItemComboBox designRepositoryItemComboBox1;
		private DevExpress.XtraBars.BarButtonItem barButtonItem1;
		private DevExpress.XtraBars.BarSubItem barSubItem3;
		private DevExpress.XtraReports.UserDesigner.XRDesignDockManager xrDesignDockManager1;
		private DevExpress.XtraReports.UserDesigner.ToolBoxDockPanel toolBoxDockPanel1;
		private DevExpress.XtraReports.UserDesigner.DesignControlContainer toolBoxDockPanel1_Container;
		private DevExpress.XtraReports.UserDesigner.ReportExplorerDockPanel reportExplorerDockPanel1;
		private DevExpress.XtraReports.UserDesigner.DesignControlContainer reportExplorerDockPanel1_Container;
		private DevExpress.XtraReports.UserDesigner.FieldListDockPanel fieldListDockPanel1;
		private DevExpress.XtraReports.UserDesigner.DesignControlContainer fieldListDockPanel1_Container;
		private DevExpress.XtraReports.UserDesigner.PropertyGridDockPanel propertyGridDockPanel1;
		private DevExpress.XtraReports.UserDesigner.DesignControlContainer propertyGridDockPanel1_Container;
		private DevExpress.XtraBars.Docking.DockPanel panelContainer1;
		private DevExpress.XtraBars.Docking.DockPanel panelContainer2;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem35;
        private DevExpress.XtraPrinting.Preview.PrintPreviewBarItem printPreviewBarItem43;
        private DevExpress.XtraPrinting.Preview.PrintPreviewRibbonPageGroup printPreviewRibbonPageGroup7;
	}
}

