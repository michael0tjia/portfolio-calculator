using System;
using System.Data;
using System.Collections.Generic;
using System.Text;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.Report1
{
    public interface IRpt
    {
        #region Properties
        string RptNm
        {
            get;
        }

        DataSet MiscDs
        {
            get;
            set;
        }
        TRptFltr RptFltr
        {
            get;
            set;
        }
        #endregion

        #region Functions
        #endregion
    }
}
