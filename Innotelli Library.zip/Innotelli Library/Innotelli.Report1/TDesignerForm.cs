using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraBars.Ribbon;
using DevExpress.XtraEditors;
using DevExpress.Skins;
using DevExpress.Utils.Drawing;

namespace Innotelli.Report1 {
	public partial class TDesignerForm : RibbonForm {
		RibbonDemos.TSkinGalleryHelper skinGalleryHelper;
		public TDesignerForm() {
			InitializeComponent();
			skinGalleryHelper = new RibbonDemos.TSkinGalleryHelper(ribbonGallerySkins);	
        }

		private void barButtonItem1_ItemClick(object sender, DevExpress.XtraBars.ItemClickEventArgs e) {
			Close();
		}
	}
}
