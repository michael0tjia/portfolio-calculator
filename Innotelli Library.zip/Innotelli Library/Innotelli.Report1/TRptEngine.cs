using System;
using System.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Drawing.Imaging;
using System.Drawing.Printing;
using System.Reflection;
using System.Text;
using DevExpress.XtraReports.UI;
using DevExpress.XtraReports.UserDesigner;
using Innotelli.BO;
using Innotelli.Db;
using Innotelli.Utilities;
using System.IO;

namespace Innotelli.Report1
{
    public class TRptEngine
    {
        #region Members
        private TRpt01 mRpt01;
        #endregion

        #region Constructors
        public TRptEngine()
        {
        }
        #endregion

        #region Enums
        public enum DBType
        {
            MsAccess = 0,
            MsSQLSvr = 1
        }
        #endregion

        #region Properties
        public string DLLFolder
        {
            get
            {
                return Innotelli.Utilities.TGC.BaseDirectory.EndsWith("\\") ? Innotelli.Utilities.TGC.BaseDirectory : Innotelli.Utilities.TGC.BaseDirectory + "\\"; ;
            }
        }
        public string RptPackNameSpace
        {
            get
            {
                return SPrpsRPT01.RptNameSpace;
            }
        }
        private DBType mDBVndr = DBType.MsSQLSvr;
        public DBType DBVndr
        {
            get
            {
                return mDBVndr;
            }
            set
            {
                mDBVndr = value;
            }
        }
        private string mCriteria = string.Empty;
        public string Criteria
        {
            get
            {
                return mCriteria;
            }
            set
            {
                mCriteria = value;
            }
        }
        private string mCriteriaFullTxt = string.Empty;
        public string CriteriaFullTxt
        {
            get
            {
                return mCriteriaFullTxt;
            }
            set
            {
                if (mCriteriaFullTxt == value)
                    return;
                mCriteriaFullTxt = value;
            }
        }
        private string mParamFullText = string.Empty;
        public string ParamFullText
        {
            get
            {
                return mParamFullText;
            }
            set
            {
                if (mParamFullText == value)
                    return;
                mParamFullText = value;
            }
        }
        private string mOrderByFieldList = string.Empty;
        public string OrderByFieldList
        {
            get
            {
                return mOrderByFieldList;
            }
            set
            {
                if (mOrderByFieldList == value)
                    return;
                mOrderByFieldList = value;
            }
        }
        private string mRptFullText = string.Empty;
        public string RptFullText
        {
            get
            {
                return mRptFullText;
            }
            set
            {
                if (mRptFullText == value)
                    return;
                mRptFullText = value;
            }
        }
        private string mRptNm = string.Empty;
        public string RptNm
        {
            get
            {
                return mRptNm;
            }
            set
            {
                if (mRptNm == value)
                    return;
                mRptNm = value;

                SPrpsRPT01.RptID = mRptNm;

                CreateRptObj();
            }
        }
        private TSPrpsRPT01 mSPrpsRPT01 = new TSPrpsRPT01();
        //#check!
        public TSPrpsRPT01 SPrpsRPT01
        {
            get
            {
                return mSPrpsRPT01;
            }
            set
            {
                if (mSPrpsRPT01 == value)
                    return;
                mSPrpsRPT01 = value;
            }
        }
        private TRptFltr mRptFltr = null;
        public TRptFltr RptFltr
        {
            get
            {
                return mRptFltr;
            }
            set
            {
                if (mRptFltr == value)
                    return;
                mRptFltr = value;
            }
        }
        private Object mRptObj;
        public XtraReport XRpt
        {
            get
            {
                return (XtraReport)mRptObj;
            }
        }
        public IRpt IRpt
        {
            get
            {
                if (mRptObj is IRpt)
                {
                    return (IRpt)mRptObj;
                }
                else
                {
                    return null;
                }
            }
        }
        private DataSet mRptMainDs = null;
        public DataSet RptMainDs
        {
            get
            {
                return mRptMainDs;
            }
            set
            {
                if (mRptMainDs == value)
                    return;
                mRptMainDs = value;
            }
        }
        private DataSet mCmnMiscDs = null;
        public DataSet CmnMiscDs
        {
            get
            {
                return mCmnMiscDs;
            }
            set
            {
                if (mCmnMiscDs == value)
                    return;
                mCmnMiscDs = value;
            }
        }
        private DataSet mRptMiscDs = null;
        public DataSet RptMiscDs
        {
            get
            {
                return mRptMiscDs;
            }
            set
            {
                if (mRptMiscDs == value)
                    return;
                mRptMiscDs = value;
            }
        }
        private bool mUseRptExternalMainDs = false;
        public bool UseRptExternalMainDs
        {
            get
            {
                return mUseRptExternalMainDs;
            }
            set
            {
                mUseRptExternalMainDs = value;
            }
        }

        private DataSet mRptExternalMainDs = null;
        public DataSet RptExternalMainDs
        {
            get
            {
                return mRptExternalMainDs;
            }
            set
            {
                mUseRptExternalMainDs = (value != null);
                mRptExternalMainDs = value;
            }
        }
        #endregion

        #region Event Handlers
        void PrintingSystem_StartPrint(object sender, DevExpress.XtraPrinting.PrintDocumentEventArgs e)
        {
            e.PrintDocument.PrintController = new StandardPrintController();
        }
        #endregion

        #region Functions

        #region Flow
        public void ProcessPhase1()
        {
            InitCriteria();
            LoadDataSets();
            LoadRptMiscData();
            BindData();
        }
        public void ProcessPhase2()
        {
            BeforeRender();
            XRpt.PrintingSystem.ShowMarginsWarning = false;
            XRpt.PrintingSystem.StartPrint += new DevExpress.XtraPrinting.PrintDocumentEventHandler(PrintingSystem_StartPrint);
        }
        private TRpt01 CreateRpt01(Object aRptObj, string aRptNm)
        {
            Object lObjRpt01 = null;
            string lRptNm = "T" + aRptNm.Substring(0, 1).ToUpper() + aRptNm.Substring(1);
            TRpt01 lRpt01 = null;
            Assembly lAssembly = System.Reflection.Assembly.LoadFile(DLLFolder + RptPackNameSpace + ".dll");
            Object[] lParm = new Object[0];

            lObjRpt01 = lAssembly.CreateInstance(RptPackNameSpace + "." + lRptNm, true, BindingFlags.Default | BindingFlags.InvokeMethod, null, lParm, null, null);
            if (lObjRpt01 != null)
            {
                lRpt01 = (TRpt01)lObjRpt01;
                lRpt01.RptNm = aRptNm;
                lRpt01.XRpt = (XtraReport)aRptObj;
            }
            return lRpt01;
        }
        private void CreateRptObj()
        {
            Assembly lAssembly = null;
            Object[] lParm = null;
            MemoryStream lMemoryStream = null;
            string lXRptNm = "TX" + mRptNm.Substring(0, 1).ToUpper() + mRptNm.Substring(1);
            
            // comment it to force it load report from class NOT repx file
            //lMemoryStream = Innotelli.Utilities.TSingletons.SysData02Rdr.GetSysDataMemoryStreamByZip(lTXRptNm);
            if (lMemoryStream == null)
            {
                lAssembly = System.Reflection.Assembly.LoadFile(DLLFolder + RptPackNameSpace + ".dll");
                lParm = new Object[0];
                mRptObj = lAssembly.CreateInstance(RptPackNameSpace + "." + lXRptNm, true, BindingFlags.Default | BindingFlags.InvokeMethod, null, lParm, null, null);
            }
            else
            {
                mRptObj = new XtraReport();
                XRpt.LoadLayout(lMemoryStream);
            }

            mRpt01 = CreateRpt01(mRptObj, mRptNm);
        }
        private void PrepareTmpData()
        {
            if (DBVndr == DBType.MsAccess)
            {
                PrepareMSAccessData();
            }
        }
        private void ClearTmpData()
        {
            if (DBVndr == DBType.MsAccess)
            {
                ClearMSAccessData();
            }
        }
        private void InitCriteria()
        {
            string lCriteriaFullText = string.Empty;
            string lParamFullText = string.Empty;
            if (RptFltr != null)
            {
                Criteria = RptFltr.GetCriteria(ref lCriteriaFullText, ref lParamFullText);
                CriteriaFullTxt = lCriteriaFullText;
                ParamFullText = lParamFullText;
                RptFullText = CriteriaFullTxt + "\r\n" + ParamFullText;
            }
        }
        private void LoadDataSets()
        {
            DataSet lRptMainDs = new DataSet();
            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                PrepareTmpData();
                if (!mUseRptExternalMainDs)
                {
                    if (DBVndr == DBType.MsAccess)
                    {
                        LoadDtFromMSAccess();
                    }
                    else if (DBVndr == DBType.MsSQLSvr)
                    {
                        LoadDtFromMSSQLSvr();
                    }
                }
                else
                {
                    mRptMainDs = mRptExternalMainDs;
                }
                LoadCmnMiscData();
                LoadRptMiscData();
                ClearTmpData();
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();

                lReflectionParams["aRptNm"] = RptNm;
                if (RptFltr != null)
                {
                    lReflectionParams["aRptFltrDs"] = RptFltr.CriteiraDs;
                }
                else
                {
                    lReflectionParams["aRptFltrDs"] = new DataSet();
                }
                lReflectionParams["aCriteria"] = Criteria;
                lReflectionParams["aOrderByFieldList"] = OrderByFieldList;
                lReflectionParams["aUseRptExternalMainDs"] = mUseRptExternalMainDs;
                lReflectionParams["aCmnMiscDs"] = new DataSet();
                lReflectionParams["aRptMiscDs"] = new DataSet();
                lRptMainDs = (DataSet)TReflectionClient.ExecuteMethod(this.GetType().FullName, "WSGetRptDataSets", lReflectionParams);
                if (!mUseRptExternalMainDs)
                {
                    mRptMainDs = (DataSet)lRptMainDs;
                }
                else
                {
                    mRptMainDs = mRptExternalMainDs;
                }
                mCmnMiscDs = (DataSet)lReflectionParams["aCmnMiscDs"];
                mRptMiscDs = (DataSet)lReflectionParams["aRptMiscDs"];
            }
        }
        public DataSet WSGetRptDataSets(string aRptNm, DataSet aRptFltrDs, string aCriteria, string aOrderByFieldList, bool aUseRptExternalMainDs, ref DataSet aCmnMiscDs, ref DataSet aRptMiscDs)
        {
            DataSet lReturnValue = null;
            RptNm = aRptNm;
            OrderByFieldList = aOrderByFieldList;
            Criteria = aCriteria;
            // Empty DataSet?
            if (aRptFltrDs.Tables.Count != 0)
            {
                RptFltr = new TRptFltr();
                RptFltr.CriteiraDs = aRptFltrDs;
                RptFltr.RptNm = aRptNm;
            }
            mUseRptExternalMainDs = aUseRptExternalMainDs;
            LoadDataSets();
            lReturnValue = RptMainDs;
            aCmnMiscDs = CmnMiscDs;
            aRptMiscDs = RptMiscDs;
            if (aCmnMiscDs == null)
            {
                aCmnMiscDs = new DataSet();
            }
            if (aRptMiscDs == null)
            {
                aRptMiscDs = new DataSet();
            }
            return lReturnValue;
        }
        private void BindData()
        {
            //mRptMainDs.WriteXml("29.xml", XmlWriteMode.WriteSchema);
            XRpt.DataSource = mRptMainDs.Tables[RptNm];
            if (Utilities.TSingletons.Rpt01SubRptDs != null)
            {
                XRpt.Tag = mRptMainDs;
                // list of Master Report Name & Detail Report Name, Make a Copy to edit
                DataTable lRpt01SubRptDt = Utilities.TSingletons.Rpt01SubRptDs.Tables[0].Copy();
                //Get the Filtering Table
                lRpt01SubRptDt.DefaultView.RowFilter = "RptNm = " + TSQL.SqlText(RptNm);
                lRpt01SubRptDt = lRpt01SubRptDt.DefaultView.ToTable();

                int lCountSb = lRpt01SubRptDt.DefaultView.Count;
                for (int i = 0; i < lCountSb; i++)
                {
                    string lLnkMstrFldNm = lRpt01SubRptDt.Rows[i]["LnkMstrFldNm"].ToString();
                    string lSubRptNm = lRpt01SubRptDt.Rows[i]["SubRptNm"].ToString();
                    string lBandNm = lRpt01SubRptDt.Rows[i]["BandNm"].ToString();
                    // get subreport
                    XRControl lband = (XRpt.Bands[lBandNm]);
                    XRSubreport lXRSubreport = (XRSubreport)lband.Controls[lSubRptNm];
                    if (!string.IsNullOrEmpty(lLnkMstrFldNm))
                    {
                        // bind data to subreport
                        lXRSubreport.Scripts.OnBeforePrint =
                              "private void OnBeforePrint(object sender, System.Drawing.Printing.PrintEventArgs e)"
                            + "{"
                            + "XRSubreport lSubreport = (XRSubreport)sender;"
                            + "XtraReport lParentReport = (XtraReport)(lSubreport.Report);"
                            + "System.Data.DataSet lDs = (System.Data.DataSet)(lParentReport.Tag);"
                            + string.Format("object lCurrentColumnValue = GetCurrentColumnValue(\"{0}\");", lLnkMstrFldNm)
                            + "if(lCurrentColumnValue != null)"
                            + "{"
                            + "string lTableName = lSubreport.Name + \".\" + lCurrentColumnValue.ToString();"
                            + "lSubreport.ReportSource.DataSource = lDs.Tables[lTableName];"
                            + "}"
                            + "}";
                    }
                    else
                    {
                        lXRSubreport.ReportSource.DataSource = XRpt.DataSource;
                    }
                }
            }
        }
        public void BeforeRender()
        {
            GenRptHeading();
            GenRptCmpyLogos();
            ExecRptBeforeRender();
        }
        #endregion

        #region Others

        #region Load Data

        #region Access
        private void PrepareMSAccessData()
        {
            switch (SPrpsRPT01.DataPrepType)
            {
                case 1:
                    break;
                case 2:
                    ExecAccessSPrc();
                    break;
                case 3:
                    ExceRptPrepareData();
                    break;
            }
        }
        private void ClearMSAccessData()
        {
        }
        private void ExecAccessSPrc()
        {
            TAccessSPrc lAccessSPrc = null;
            long lDataPrepType = -1;
            string lAccessSPrcNm = string.Empty;
            lAccessSPrc = new TAccessSPrc();
            lDataPrepType = SPrpsRPT01.DataPrepType;
            lAccessSPrcNm = SPrpsRPT01.AccessSPrcNm;
            if ((lDataPrepType == 2) && (lAccessSPrcNm != string.Empty))
            {
                lAccessSPrc.Name = lAccessSPrcNm;
                for (int i = 0; i < RptFltr.CriteiraDv.Count; i++)
                {
                    if (bool.Parse(RptFltr.CriteiraDv[i]["IsParam"].ToString()))
                    {
                        lAccessSPrc.Params.AddWithValue("FldNm", RptFltr.CriteiraDv[i]["Value1"]);
                    }
                }
                lAccessSPrc.Process();
            }
        }
        private void ExceRptPrepareData()
        {
            if (mRpt01 != null)
            {
                mRpt01.RptFltr = RptFltr;
            }
            if (IRpt != null)
            {
                IRpt.RptFltr = RptFltr;
            }
        }
        private void LoadDtFromMSAccess()
        {
            DataSet lRptMainDs = new DataSet();
            TDataObject lDao = new TDataObject();

            lDao.SQL.Stmt = "SELECT " + SPrpsRPT01.RrdSrc + ".* FROM " + SPrpsRPT01.RrdSrc;
            if (Criteria != string.Empty)
            {
                lDao.SQL.AddToWhereClause(Criteria);
            }
            lDao.OpenTable();
            lRptMainDs.Tables.Add(lDao.Dt);
            RptMainDs = lRptMainDs;
        }
        #endregion

        #region SQL Server
        private void LoadDtFromMSSQLSvr()
        {
            DataSet lRptMainDs = new DataSet();
            TDataObject lDao = null;


            string lValue1 = String.Empty;
            DateTime lDate;
            lDao = new TDataObject();
            lDao.SQL.Stmt = SPrpsRPT01.RrdSrc;
            lDao.CmdType = CommandType.StoredProcedure;

            if (Criteria != string.Empty)
            {
                lDao.Params.AddWithValue("@Where", "WHERE (" + Criteria + ")");
            }
            else
            {
                lDao.Params.AddWithValue("@Where", string.Empty);
            }
            if (OrderByFieldList != string.Empty)
            {
                lDao.Params.AddWithValue("@OrderBy", "ORDER BY (" + OrderByFieldList + ")");
            }
            else
            {
                lDao.Params.AddWithValue("@OrderBy", string.Empty);
            }
            if (RptFltr != null)
            {
                for (int i = 0; i < RptFltr.CriteiraDv.Count; i++)
                {
                    if (bool.Parse(RptFltr.CriteiraDv[i]["IsParam"].ToString()))
                    {
                        if (RptFltr.CriteiraDv[i]["FldType"].ToString() == "DATETIME")
                        {
                            lValue1 = RptFltr.CriteiraDv[i]["Value1"].ToString();
                            lDate = DateTime.Parse(lValue1);
                            lDao.Params.AddWithValue(RptFltr.CriteiraDv[i]["FldNm"].ToString(), lDate);
                        }
                        else
                        {
                            lDao.Params.AddWithValue(RptFltr.CriteiraDv[i]["FldNm"].ToString(), RptFltr.CriteiraDv[i]["Value1"]);
                        }
                    }
                }
            }
            lDao.OpenTable();
            lDao.Dt.TableName = RptNm;
            lRptMainDs.Tables.Add(lDao.Dt);

            // Master Report Data
            DataTable lMstrDt = lRptMainDs.Tables[RptNm];

            // list of Report Name & Data Source Name
            DataTable lRptT01Dt = Utilities.TSingletons.RptT01Ds.Tables[0];
            lRptT01Dt.PrimaryKey = new DataColumn[] { lRptT01Dt.Columns["RptNm"] };

            if (Utilities.TSingletons.Rpt01SubRptDs != null)
            {
                // list of Master Report Name & Detail Report Name, Make a Copy to edit
                DataTable lRpt01SubRptDt = Utilities.TSingletons.Rpt01SubRptDs.Tables[0].Copy();

                //Get the Filtering Table
                lRpt01SubRptDt.DefaultView.RowFilter = "RptNm = " + TSQL.SqlText(RptNm);
                lRpt01SubRptDt = lRpt01SubRptDt.DefaultView.ToTable();


                // Load Subreport Data
                int lCountSb = lRpt01SubRptDt.DefaultView.Count;
                for (int i = 0; i < lCountSb; i++)
                {
                    string lLnkChldFldNm = lRpt01SubRptDt.Rows[i]["LnkChldFldNm"].ToString();
                    string lLnkMstrFldNm = lRpt01SubRptDt.Rows[i]["LnkMstrFldNm"].ToString();
                    string lDataType = lRpt01SubRptDt.Rows[i]["DataType"].ToString();
                    string lSubRptNm = lRpt01SubRptDt.Rows[i]["SubRptNm"].ToString();
                    string lRrdSrc = lRptT01Dt.Rows.Find(lSubRptNm)["RrdSrc"].ToString();
                    int lCount = lMstrDt.DefaultView.Count;
                    List<object> lList = new List<object>();
                    string lCriteria = string.Empty;
                    for (int j = 0; j < lCount; j++)
                    {
                        if (!string.IsNullOrEmpty(lLnkMstrFldNm))
                        {
                            object lMstrFld = lMstrDt.Rows[j][lLnkMstrFldNm];
                            if (!(lList.Contains(lMstrFld)))
                            {
                                lCriteria = " WHERE " + lLnkChldFldNm + " = ";
                                switch (lDataType)
                                {
                                    case "text":
                                        lCriteria += TSQL.SqlText(lMstrFld.ToString());
                                        break;
                                    case "date":
                                        lCriteria += TSQL.SqlDate((DateTime)(lMstrFld));
                                        break;
                                    case "time":
                                        lCriteria += TSQL.SqlTime((DateTime)(lMstrFld));
                                        break;
                                    case "bool":
                                        lCriteria += TSQL.SqlBool((bool)(lMstrFld));
                                        break;
                                    case "int":
                                    case "float":
                                        lCriteria += lMstrFld.ToString();
                                        break;
                                    default:
                                        lCriteria = String.Empty;
                                        break;
                                }
                                lDao.SQL.Stmt = lRrdSrc;
                                lDao.CmdType = CommandType.StoredProcedure;
                                lDao.Params.AddWithValue("@OrderBy", String.Empty);
                                lDao.Params.AddWithValue("@Where", lCriteria);
                                lDao.OpenTable();
                                lDao.Dt.TableName = lSubRptNm + "." + lMstrFld;
                                lRptMainDs.Tables.Add(lDao.Dt);
                                lList.Add(lMstrFld);
                            }
                        }
                    }
                }
            }
            mRptMainDs = lRptMainDs;
        }
        private void LoadCmnMiscData()
        {
            DataTable lDt = null;
            DataRow lDr = null;
            lDt = new DataTable();
            lDt.TableName = "Cmpny";
            lDt.Columns.Add("Cmpny");
            lDr = lDt.NewRow();
            lDr["Cmpny"] = GetCmpny();
            lDt.Rows.Add(lDr);

            CmnMiscDs = new DataSet();
            CmnMiscDs.Tables.Add(lDt);
        }
        private void LoadRptMiscData()
        {
            if (mRpt01 != null)
            {
                mRpt01.RptFltr = RptFltr;
                mRptMiscDs = mRpt01.MiscDs;
            }
            if (IRpt != null)
            {
                IRpt.RptFltr = RptFltr;
                mRptMiscDs = IRpt.MiscDs;
            }
        }
        private string GetCmpny()
        {
            string lReturnValue = string.Empty;
            //TODO: Michael
            try
            {
                TDomain.Lookup("Cmpny", "Cmpny", string.Empty, out lReturnValue);
            }
            catch
            {
            }
            if (lReturnValue == string.Empty)
            {
                try
                {
                    TDomain.Lookup("Company", "Company", string.Empty, out lReturnValue);
                }
                catch
                {
                }
            }
            return lReturnValue;
        }
        #endregion

        #endregion

        #region BeforeRender
        private void GenRptHeading()
        {
            string lCmpny = string.Empty;

            if (mCmnMiscDs != null)
            {
                lCmpny = mCmnMiscDs.Tables["Cmpny"].Rows[0]["Cmpny"].ToString();
            }
            Band lPageHeader = XRpt.Bands[BandKind.PageHeader];
            if (lPageHeader != null)
            {
                if (lPageHeader.Controls["lblTitle"] != null)
                {
                    lPageHeader.Controls["lblTitle"].Text = SPrpsRPT01.RptAls;
                }
                if (lPageHeader.Controls["txtCriteriaFullText"] != null)
                {
                    lPageHeader.Controls["txtCriteriaFullText"].Text = RptFullText;
                }
                if (lPageHeader.Controls["lblCompanyNameHeader"] != null)
                {
                    lPageHeader.Controls["lblCompanyNameHeader"].Text = lCmpny;
                }
            }
        }
        public void ExportToFile(string aFilePath, FileFormats aFileFormat)
        {
            switch (aFileFormat)
            {
                case FileFormats.Pdf:
                    XRpt.ExportToPdf(aFilePath);
                    break;
                case FileFormats.Rtf:
                    XRpt.ExportToRtf(aFilePath);
                    break;
                case FileFormats.Xls:
                    XRpt.ExportToXls(aFilePath);
                    break;
                case FileFormats.Tiff:
                    XRpt.ExportToImage(aFilePath, ImageFormat.Tiff);
                    break;
                default:
                    XRpt.ExportToText(aFilePath);
                    break;
            }
        }
        public void LoadRptLayout(Stream aRptLayout)
        {
            if (aRptLayout != null)
            {
                XRpt.LoadLayout(aRptLayout);
            }
        }
        private void GenRptCmpyLogos()
        {
            Band lPageHeader = XRpt.Bands[BandKind.PageHeader];
            if (lPageHeader != null)
            {
                XRControl lXRPictureBox1 = lPageHeader.Controls["imgLogo01"];
                XRControl lXRPictureBox2 = lPageHeader.Controls["imgLogo02"];
                if (lXRPictureBox1 != null)
                {
                    ((XRPictureBox)lXRPictureBox1).ImageUrl = Innotelli.Utilities.TGC.BaseDirectory + Innotelli.Utilities.TGC.SYSDATA04_FOLDER_NAME + @"\Logo01.jpg";
                }
                if (lXRPictureBox2 != null)
                {
                    ((XRPictureBox)lXRPictureBox2).ImageUrl = Innotelli.Utilities.TGC.BaseDirectory + Innotelli.Utilities.TGC.SYSDATA04_FOLDER_NAME + @"\Logo02.jpg";
                }
            }
        }
        //use reflection to run report object's beforerender
        private void ExecRptBeforeRender()
        {
            DataTable lRpt001SubRptDt = Utilities.TSingletons.Rpt01SubRptDs.Tables[0].Copy();

            //Get the Filtering Table
            lRpt001SubRptDt.DefaultView.RowFilter = "RptNm = " + TSQL.SqlText(RptNm);
            lRpt001SubRptDt = lRpt001SubRptDt.DefaultView.ToTable();

            int lCountSb = lRpt001SubRptDt.DefaultView.Count;
            for (int i = 0; i < lCountSb; i++)
            {
                string lSubRptNm = lRpt001SubRptDt.Rows[i]["SubRptNm"].ToString();
                string lBandNm = lRpt001SubRptDt.Rows[i]["BandNm"].ToString();

                XtraReport lXRpt = ((XRSubreport) XRpt.Bands[lBandNm].Controls[lSubRptNm]).ReportSource;
                TRpt01 lRpt01 = CreateRpt01(lXRpt, lSubRptNm);
                if (lRpt01 != null)
                {
                    lRpt01.BeforeRender();
                }
            }

            if (mRpt01 != null)
            {
                mRpt01.RptFltr = RptFltr;
                mRpt01.BeforeRender();
            }
            if (IRpt != null)
            {
                IRpt.RptFltr = RptFltr;
                //IRpt.BeforeRender();
            }
        }
        #endregion

        #region AfterRender

        #endregion

        #endregion

        #endregion
    }
}
