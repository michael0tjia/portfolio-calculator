﻿using System.Collections;
using System.Data;

namespace Innotelli.BO
{
    public class TSPrpsBOT06s
    {
        #region Enums
        #endregion

        #region Members
        private DataTable mDt = null;
        private Hashtable[] mSPrpsBOT06HTs = null;
        public object mLocker = new object();
        #endregion

        #region Constructors
        public TSPrpsBOT06s()
        {
            mSPrpsBOT06HTs = new Hashtable[2];
            mSPrpsBOT06HTs[0] = new Hashtable();
            mSPrpsBOT06HTs[1] = new Hashtable();
            mDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("BOT06").Tables[0];
        }
        #endregion

        #region Properties
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }
        public int Count
        {
            get
            {
                return mDt.Rows.Count;
            }
        }
        public TSPrpsBOT06 this[int aRowIndex]
        {
            get
            {
                TSPrpsBOT06 lReturnValue = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT06HTs[0][aRowIndex] == null)
                    {
                        mSPrpsBOT06HTs[0][aRowIndex] = new TSPrpsBOT06(mDt.Rows[aRowIndex]);
                    }
                }
                lReturnValue = (TSPrpsBOT06)mSPrpsBOT06HTs[0][aRowIndex];

                return lReturnValue;
            }
        }
        public TSPrpsBOT06 this[string aBOID]
        {
            get
            {
                TSPrpsBOT06 lReturnValue = null;
                DataRow[] lDrs = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT06HTs[1][aBOID] == null)
                    {
                        lDrs = mDt.Select("BOT06ID = '" + aBOID + "'");
                        if (lDrs.Length != 0)
                        {
                            mSPrpsBOT06HTs[1][aBOID] = new TSPrpsBOT06(lDrs[0]);
                        }
                    }
                }
                lReturnValue = (TSPrpsBOT06)mSPrpsBOT06HTs[1][aBOID];

                return lReturnValue;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}