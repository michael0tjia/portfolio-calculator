﻿using System.Collections;
using System.Data;

namespace Innotelli.BO
{
    public class TMetaSecurityPermissions
    {
        #region Enums
        #endregion

        #region Members
        private DataTable mDt = null;
        private DataView mDv = null;
        #endregion

        #region Constructors
        public TMetaSecurityPermissions()
        {
            mDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("SecurityPermission").Tables[0];
            mDv = new DataView();
            mDv.Table = mDt;
        }
        #endregion

        #region Properties
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }
        public int Count
        {
            get
            {
                return mDt.Rows.Count;
            }
        }
        public DataView Dv
        {
            get
            {
                return mDv;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}