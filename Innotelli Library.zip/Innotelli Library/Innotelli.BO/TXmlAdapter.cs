using System;
using System.Collections.Generic;
using System.Text;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public class ServerTreeXmlAdapter
    {
	    public string DataTypeName = null;
	    public ServerNodeXmlAdapter Child = null;

	    public ServerTreeXmlAdapter(){}

        public ServerTreeXmlAdapter(ITree t)
	    {
		    DataTypeName = t.DataType.FullName;

		    Child = new ServerNodeXmlAdapter( t.Root.Child );
	    }
    }

    public class ServerNodeXmlAdapter
    {
	    public object Data = null;
	    public ServerNodeXmlAdapter Child = null;
	    public ServerNodeXmlAdapter Next  = null;

	    public ServerNodeXmlAdapter(){}

        public ServerNodeXmlAdapter(INode n)
	    {
		    Data = n.Data;

		    if ( n.Child != null )
			    Child = new ServerNodeXmlAdapter( n.Child );

		    if ( n.Next != null )
			    Next = new ServerNodeXmlAdapter( n.Next );
	    }
    }

    internal class ClientTreeXmlAdapter
	{
		ServerTreeXmlAdapter _Server = null;

		public ClientTreeXmlAdapter( ServerTreeXmlAdapter server )
		{
			_Server = server;
		}

		public ITree CreateTree()
		{
			ITree t = NodeTree.NewTree( Type.GetType( _Server.DataTypeName ) );

			ClientNodeXmlAdapter child = new ClientNodeXmlAdapter( _Server.Child );

			t.AddChild( child.CreateTree() );

			return t;
		}
	}

	internal class ClientNodeXmlAdapter
	{
		private ServerNodeXmlAdapter _Server = null;

		public ClientNodeXmlAdapter( ServerNodeXmlAdapter server )
		{
			_Server = server;
		}

		public ITree CreateTree()
		{
			ITree tree = NodeTree.NewTree();

			tree.AddChild( _Server.Data );

			if ( _Server.Child != null )
			{
				ClientNodeXmlAdapter child = new ClientNodeXmlAdapter( _Server.Child );
				tree.Root.Child.AddChild( child.CreateTree() );
			}

			if ( _Server.Next != null )
			{
				ClientNodeXmlAdapter next = new ClientNodeXmlAdapter( _Server.Next );
				tree.Root.Child.Add( next.CreateTree() );
			}

			return tree;
		}
	}
}
