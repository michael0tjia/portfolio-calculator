using System.Data;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public class TFndFrmHndlr
    {
        #region Members
        #endregion

        #region Constructors
        public TFndFrmHndlr()
        {
        }
        #endregion

        #region Enums

        #endregion

        #region Properties

        public string SvrObjNm
        {
            get { return this.GetType().Namespace + "." + this.GetType().Name; }
        }

        #endregion

        #region Event Handlers

        #endregion

        #region Functions
        public DataSet GetDataSource(string aRowSource)
        {
            DataSet lReturnValue = null;

            lReturnValue = new DataSet();
            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                TDataObject lDataObject = new TDataObject();
                lDataObject.OpenTable("SELECT " + aRowSource + ".* FROM " + aRowSource);
                lReturnValue = new DataSet();
                lReturnValue.Tables.Add(lDataObject.Dt);
            }
            else
            {

                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["aRowSource"] = aRowSource;
                lReturnValue = (DataSet)TReflectionClient.ExecuteMethod(SvrObjNm, "GetDataSource", lReflectionParams);
            }
            return lReturnValue;
        }
        public DataSet Search(string aRowSource, string aWhereClause)
        {
            DataSet lReturnValue = null;

            lReturnValue = new DataSet();
            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                TDataObject lDataObject = new TDataObject();
                lDataObject.OpenTable("SELECT " + aRowSource + ".* FROM " + aRowSource + " WHERE " + aWhereClause);
                lReturnValue = new DataSet();
                lReturnValue.Tables.Add(lDataObject.Dt);
            }
            else
            {

                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["aRowSource"] = aRowSource;
                lReflectionParams["aWhereClause"] = aWhereClause;
                lReturnValue = (DataSet)TReflectionClient.ExecuteMethod(SvrObjNm, "Search", lReflectionParams);
            }
            return lReturnValue;
        }
        #endregion
    }
}
