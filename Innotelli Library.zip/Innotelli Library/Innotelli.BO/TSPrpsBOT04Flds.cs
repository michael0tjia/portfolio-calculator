﻿using System.Collections;
using System.Data;
using Innotelli.Db;

namespace Innotelli.BO
{
    public class TSPrpsBOT04Flds
    {
        #region Enums
        #endregion

        #region Members
        private string mBOID = string.Empty;
        private DataTable mDt = null;
        private Hashtable[] mSPrpsBOT04FldHTs = null;
        public object mLocker = new object();
        #endregion

        #region Constructors
        public TSPrpsBOT04Flds(string aBOID)
        {
            DataView lDv = new DataView();

            mBOID = aBOID;
            mSPrpsBOT04FldHTs = new Hashtable[2];
            mSPrpsBOT04FldHTs[0] = new Hashtable();
            mSPrpsBOT04FldHTs[1] = new Hashtable();
            lDv.Table = BOT04FldDt;
            lDv.RowFilter = "BOT04ID =  '" + mBOID + "'";
            mDt = lDv.ToTable();
        }
        #endregion

        #region Properties
        private static DataTable mBOT04FldDt = null;
        public static DataTable BOT04FldDt
        {
            get
            {
                if (mBOT04FldDt == null)
                {
                    mBOT04FldDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("BOT04Fld").Tables[0];
                }
                return mBOT04FldDt;
            }
        }
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }
        public int Count
        {
            get
            {
                return mDt.Rows.Count;
            }
        }
        public TSPrpsBOT04Fld this[int aRowIndex]
        {
            get
            {
                TSPrpsBOT04Fld lReturnValue = null;
                TSPrpsBOT04Fld lSPrpsBOT04Fld = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT04FldHTs[0][aRowIndex] == null)
                    {
                        mSPrpsBOT04FldHTs[0][aRowIndex] = new TSPrpsBOT04Fld();
                    }
                }
                lSPrpsBOT04Fld = (TSPrpsBOT04Fld)mSPrpsBOT04FldHTs[0][aRowIndex];
                lSPrpsBOT04Fld.Dr = mDt.Rows[aRowIndex];
                lReturnValue = lSPrpsBOT04Fld;

                return lReturnValue;
            }
        }
        public TSPrpsBOT04Fld this[string aFldNm]
        {
            get
            {
                TSPrpsBOT04Fld lReturnValue = null;
                TSPrpsBOT04Fld lSPrpsBOT04Fld = null;
                DataRow[] lDrs = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT04FldHTs[1][aFldNm] == null)
                    {
                        mSPrpsBOT04FldHTs[1][aFldNm] = new TSPrpsBOT04Fld();
                    }
                }
                lSPrpsBOT04Fld = (TSPrpsBOT04Fld)mSPrpsBOT04FldHTs[1][aFldNm];
                lDrs = mDt.Select("FldNm = '" + aFldNm + "'");
                if (lDrs.Length != 0)
                {
                    lSPrpsBOT04Fld.Dr = lDrs[0];
                    lReturnValue = lSPrpsBOT04Fld;
                }

                return lReturnValue;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}
