﻿using System.Collections;
using System.Data;
using Innotelli.Db;

namespace Innotelli.BO
{
    public class TSPrpsBOT06Flds
    {
        #region Enums
        #endregion

        #region Members
        private string mBOID = string.Empty;
        private DataTable mDt = null;
        private Hashtable[] mSPrpsBOT06FldHTs = null;
        public object mLocker = new object();
        #endregion

        #region Constructors
        public TSPrpsBOT06Flds(string aBOID)
        {
            DataView lDv = new DataView();

            mBOID = aBOID;
            mSPrpsBOT06FldHTs = new Hashtable[2];
            mSPrpsBOT06FldHTs[0] = new Hashtable();
            mSPrpsBOT06FldHTs[1] = new Hashtable();
            lDv.Table = BOT06FldDt;
            lDv.RowFilter = "BOT06ID =  '" + mBOID + "'";
            mDt = lDv.ToTable();
        }
        #endregion

        #region Properties
        private static DataTable mBOT06FldDt = null;
        public static DataTable BOT06FldDt
        {
            get
            {
                if (mBOT06FldDt == null)
                {
                    mBOT06FldDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("BOT06Fld").Tables[0];
                }
                return mBOT06FldDt;
            }
        }
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }
        public int Count
        {
            get
            {
                return mDt.Rows.Count;
            }
        }
        public TSPrpsBOT06Fld this[int aRowIndex]
        {
            get
            {
                TSPrpsBOT06Fld lReturnValue = null;
                TSPrpsBOT06Fld lSPrpsBOT06Fld = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT06FldHTs[0][aRowIndex] == null)
                    {
                        mSPrpsBOT06FldHTs[0][aRowIndex] = new TSPrpsBOT06Fld();
                    }
                }
                lSPrpsBOT06Fld = (TSPrpsBOT06Fld)mSPrpsBOT06FldHTs[0][aRowIndex];
                lSPrpsBOT06Fld.Dr = mDt.Rows[aRowIndex];
                lReturnValue = lSPrpsBOT06Fld;

                return lReturnValue;
            }
        }
        public TSPrpsBOT06Fld this[string aFldNm]
        {
            get
            {
                TSPrpsBOT06Fld lReturnValue = null;
                TSPrpsBOT06Fld lSPrpsBOT06Fld = null;
                DataRow[] lDrs = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT06FldHTs[1][aFldNm] == null)
                    {
                        mSPrpsBOT06FldHTs[1][aFldNm] = new TSPrpsBOT06Fld();
                    }
                }
                lSPrpsBOT06Fld = (TSPrpsBOT06Fld)mSPrpsBOT06FldHTs[1][aFldNm];
                lDrs = mDt.Select("FldNm = '" + aFldNm + "'");
                if (lDrs.Length != 0)
                {
                    lSPrpsBOT06Fld.Dr = lDrs[0];
                    lReturnValue = lSPrpsBOT06Fld;
                }

                return lReturnValue;
            }
        }
        public string ItemNumberFieldName
        {
            get
            {
                string lReturnValue = string.Empty;
                DataRow lDr = null;

                lDr = TDomain.DataTableGetDataRow(mDt, "slkFldType = 108");
                if (lDr != null)
                {
                    lReturnValue = lDr["FldNm"].ToString();
                }
                return lReturnValue;
            }
        }
        public string SKeyFieldName
        {
            get
            {
                string lReturnValue = string.Empty;
                DataRow lDr = null;

                lDr = TDomain.DataTableGetDataRow(mDt, "SKey = " + TSQL.SqlBool(true));
                if (lDr != null)
                {
                    lReturnValue = lDr["FldNm"].ToString();
                }
                return lReturnValue;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}
