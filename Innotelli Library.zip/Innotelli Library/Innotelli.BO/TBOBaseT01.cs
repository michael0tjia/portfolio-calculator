﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public class TBOActiveRowChangedEventArgs : EventArgs
    {
        private int mActiveRowIndex;
        public int ActiveRowIndex
        {
            get
            {
                return mActiveRowIndex;
            }
            set
            {
                mActiveRowIndex = value;
            }
        }
        public TBOActiveRowChangedEventArgs(int aActiveRowIndex)
        {
            ActiveRowIndex = aActiveRowIndex;
        }
    }
    public class TBORowUpdatedEventArgs : EventArgs
    {
        private DataRow mRow;
        public DataRow Row
        {
            get
            {
                return mRow;
            }
            set
            {
                mRow = value;
            }
        }
        private DataColumn mColumn;
        public DataColumn Column
        {
            get
            {
                return mColumn;
            }
            set
            {
                mColumn = value;
            }
        }
        private object mProposedValue;
        public object ProposedValue
        {
            get
            {
                return mProposedValue;
            }
            set
            {
                mProposedValue = value;
            }
        }
        public TBORowUpdatedEventArgs(DataRow aRow, DataColumn aColumn, object aProposedValue)
        {
            mRow = aRow;
            mColumn = aColumn;
            mProposedValue = aProposedValue;
        }
    }
    public class TBORowInsertedEventArgs : EventArgs
    {
        private DataRow mRow;
        public DataRow Row
        {
            get
            {
                return mRow;
            }
            set
            {
                mRow = value;
            }
        }
        public TBORowInsertedEventArgs(DataRow aRow)
        {
            mRow = aRow;
        }
    }
    public class TBORowDeletedEventArgs : EventArgs
    {
        private DataRow mRow;
        public DataRow Row
        {
            get
            {
                return mRow;
            }
            set
            {
                mRow = value;
            }
        }
        public TBORowDeletedEventArgs(DataRow aRow)
        {
            mRow = aRow;
        }
    }
    public delegate void BOIsDirtyEventHandler(object sender, System.EventArgs e);
    public delegate void BOActiveRowChangedEventHandler(object sender, TBOActiveRowChangedEventArgs e);
    public delegate void BORowUpdatedEventEventHandler(object sender, TBORowUpdatedEventArgs e);
    public delegate void BORowInsertedEventEventHandler(object sender, TBORowInsertedEventArgs e);
    public delegate void BORowDeletedEventEventHandler(object sender, TBORowDeletedEventArgs e);

    public abstract class TBOBaseT01
    {
        #region Structures
        #endregion

        #region Members
        public event BOActiveRowChangedEventHandler OnBOActiveRowChanged;
        public event BORowUpdatedEventEventHandler OnBORowUpdated;
        public event BORowInsertedEventEventHandler OnBORowInserted;
        public event BORowDeletedEventEventHandler OnBORowDeleted;
        #endregion

        #region Constructors
        #endregion

        #region Properties

        #region Namespace
        public string ClassFullName
        {
            get
            {
                return GetType().FullName;
            }
        }
        public string BOID
        {
            get
            {
                return GetType().Name;
            }
        }
        #endregion

        #region In Memory Data
        private DataRow mDetachedDataRow = null;
        public DataRow DetachedDataRow
        {
            get
            {
                return mDetachedDataRow;
            }
            set
            {
                mDetachedDataRow = value;
            }
        }
        private TDataObject mDao = new TDataObject();
        public TDataObject Dao
        {
            get
            {
                return mDao;
            }
            set
            {
                mDao = value;
            }
        }
        public DataTable Dt
        {
            get
            {
                return mDao.Dt;
            }
            set
            {
                mDao.Dt = value;
                if (value != null)
                {
                    CreateVirtualPrimaryKeyColumn();
                    CreateVirtualParentKeyColumn();
                    // Assume the column value has nothing
                    FillVirtualPrimaryKeyColumn();
                    if (!mDao.IsNoRow())
                    {
                        mDao.MoveFirst();
                    }
                    AssignDtEventHandlers();
                }
            }
        }
        public DataView DefaultView
        {
            get
            {
                return mDao.Dt.DefaultView;
            }
        }
        public int CurrentRowIndex
        {
            get
            {
                return mDao.CurrentRowIndex;
            }
            set
            {
                mDao.CurrentRowIndex = value;
                if (OnBOActiveRowChanged != null)
                {
                    TBOActiveRowChangedEventArgs lBOActiveRowChangedEventArgs = new TBOActiveRowChangedEventArgs(value);
                    OnBOActiveRowChanged(this, lBOActiveRowChangedEventArgs);
                }
            }
        }
        public TDataRow Dr
        {
            get
            {
                if (CurrentRowIndex == TDataObject.DetachedRowIndex)
                {
                    return mDetachedDataRow;
                }
                else if (CurrentRowIndex >= 0 && CurrentRowIndex < DefaultView.Count)
                {
                    return DefaultView[CurrentRowIndex].Row;
                }
                else
                {
                    throw new TBOException("Current index is out of range.");
                }
            }
        }
        #endregion

        #endregion

        #region Event Handlers
        private void Dt_RowChanged(object sender, DataRowChangeEventArgs e)
        {
            if (OnBORowInserted != null && e.Action == DataRowAction.Add)
            {
                OnBORowInserted(this, new TBORowInsertedEventArgs(e.Row));
            }
            else if (OnBORowDeleted != null && e.Action == DataRowAction.Delete)
            {
                OnBORowDeleted(this, new TBORowDeletedEventArgs(e.Row));
            }
        }
        private void Dt_ColumnChanged(object sender, DataColumnChangeEventArgs e)
        {
            if (OnBORowUpdated != null)
            {
                OnBORowUpdated(this, new TBORowUpdatedEventArgs(e.Row, e.Column, e.ProposedValue));
            }
        }
        #endregion

        #region Functions

        #region Data Row Operations
        public void MoveFirst()
        {
            Dao.MoveFirst();
            if (OnBOActiveRowChanged != null)
            {
                TBOActiveRowChangedEventArgs lBOActiveRowChangedEventArgs = new TBOActiveRowChangedEventArgs(mDao.CurrentRowIndex);
                OnBOActiveRowChanged(this, lBOActiveRowChangedEventArgs);
            }
        }
        public void MovePrevious()
        {
            Dao.MovePrevious();
            if (OnBOActiveRowChanged != null)
            {
                TBOActiveRowChangedEventArgs lBOActiveRowChangedEventArgs = new TBOActiveRowChangedEventArgs(mDao.CurrentRowIndex);
                OnBOActiveRowChanged(this, lBOActiveRowChangedEventArgs);
            }
        }
        public void MoveNext()
        {
            Dao.MoveNext();
            if (OnBOActiveRowChanged != null)
            {
                TBOActiveRowChangedEventArgs lBOActiveRowChangedEventArgs = new TBOActiveRowChangedEventArgs(mDao.CurrentRowIndex);
                OnBOActiveRowChanged(this, lBOActiveRowChangedEventArgs);
            }
        }
        public void MoveLast()
        {
            Dao.MoveLast();
            if (OnBOActiveRowChanged != null)
            {
                TBOActiveRowChangedEventArgs lBOActiveRowChangedEventArgs = new TBOActiveRowChangedEventArgs(mDao.CurrentRowIndex);
                OnBOActiveRowChanged(this, lBOActiveRowChangedEventArgs);
            }
        }
        public void SetCurrentRow(DataRow aDr)
        {
            int lRowIndex = -1;
            DataRow lDr = aDr;

            if (aDr.RowState == DataRowState.Detached)
            {
                mDao.CurrentRowIndex = TDataObject.DetachedRowIndex;
                mDetachedDataRow = aDr;
            }
            else
            {
                for (int i = 0; i < DefaultView.Count; i++)
                {
                    if (DefaultView[i].Row == lDr)
                    {
                        lRowIndex = i;
                        break;
                    }
                }
                if (lRowIndex >= 0 && lRowIndex <= DefaultView.Count - 1)
                {
                    mDao.CurrentRowIndex = lRowIndex;
                }
                else
                {
                    throw new TBOException("Cannot locate the data row.");
                }
            }
            if (OnBOActiveRowChanged != null)
            {
                TBOActiveRowChangedEventArgs lBOActiveRowChangedEventArgs = new TBOActiveRowChangedEventArgs(mDao.CurrentRowIndex);
                OnBOActiveRowChanged(this, lBOActiveRowChangedEventArgs);
            }
        }

        public bool IsNoRow()
        {
            return Dao.IsNoRow();
        }
        public bool EOF()
        {
            return Dao.EOF();
        }
        public bool BOF()
        {
            return Dao.BOF();
        }
        #endregion

        #region Virtual Keys
        public void CreateVirtualPrimaryKeyColumn()
        {
            DataColumn lDc = null;

            if (!Dt.Columns.Contains(Innotelli.BO.TGC.VIRTUAL_PRIMARY_KEY_FIELD_NAME))
            {
                lDc = new DataColumn(Innotelli.BO.TGC.VIRTUAL_PRIMARY_KEY_FIELD_NAME, typeof(int));
                lDc.ExtendedProperties["ISVIRTUALKEY"] = true;
                lDc.AutoIncrement = true;
                lDc.AutoIncrementSeed = 0;
                lDc.AutoIncrementStep = 1;
                Dt.Columns.Add(lDc);
            }
        }
        public void FillVirtualPrimaryKeyColumn()
        {
            DataColumn lDc = null;

            if (Dt.Columns.Contains(Innotelli.BO.TGC.VIRTUAL_PRIMARY_KEY_FIELD_NAME))
            {
                lDc = Dt.Columns[Innotelli.BO.TGC.VIRTUAL_PRIMARY_KEY_FIELD_NAME];
                for (int i = 0; i < DefaultView.Count; i++)
                {
                    DefaultView[i].Row[lDc] = i;
                }
            }
        }
        public void CreateVirtualParentKeyColumn()
        {
            DataColumn lDc = null;

            if (!Dt.Columns.Contains(Innotelli.BO.TGC.VIRTUAL_PARENT_KEY_FIELD_NAME))
            {
                lDc = new DataColumn(Innotelli.BO.TGC.VIRTUAL_PARENT_KEY_FIELD_NAME, typeof(int));
                lDc.ExtendedProperties["ISVIRTUALKEY"] = true;
                Dt.Columns.Add(lDc);
            }
        }
        #endregion

        protected virtual void AssignDtEventHandlers()
        {
            Dt.RowChanged += new DataRowChangeEventHandler(Dt_RowChanged);
            Dt.ColumnChanged += new DataColumnChangeEventHandler(Dt_ColumnChanged);
        }
        #endregion
    }
}
