﻿using System.Collections;
using System.Data;

namespace Innotelli.BO
{
    public class TSPrpsValLsts
    {
        #region Enums
        #endregion

        #region Members
        private DataTable mDt = null;
        private Hashtable[] mSPrpsValLstHTs = null;
        public object mLocker = new object();
        #endregion

        #region Constructors
        public TSPrpsValLsts()
        {
            mSPrpsValLstHTs = new Hashtable[1];
            mSPrpsValLstHTs[0] = new Hashtable();
            mDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("ValLst").Tables[0];
        }
        #endregion

        #region Properties
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }
        public int Count
        {
            get
            {
                return mDt.Rows.Count;
            }
        }
        public TSPrpsValLst this[string aPK]
        {
            get
            {
                TSPrpsValLst lReturnValue = null;
                DataRow[] lDrs = null;

                lock (mLocker)
                {
                    if (mSPrpsValLstHTs[0][aPK] == null)
                    {
                        lDrs = mDt.Select(Innotelli.Utilities.TGC.PKeyName + " = " +  aPK);
                        if (lDrs.Length != 0)
                        {
                            mSPrpsValLstHTs[0][aPK] = new TSPrpsValLst(lDrs[0]);
                        }
                    }
                }
                lReturnValue = (TSPrpsValLst)mSPrpsValLstHTs[0][aPK];

                return lReturnValue;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}