﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public class TSearchListTask : TThreadWrapperBase
    {
        #region Members
        private const int RECORD_PER_WS = 5000;
        private TSearchList mSearchList = null;
        #endregion

        #region Constructors
        public TSearchListTask(TSearchList aSearchList)
        {
            mSearchList = aSearchList;
        }
        #endregion

        #region Properties
        private bool mStopSearch = false;
        public bool StopSearch
        {
            get
            {
                return mStopSearch;
            }
            set
            {
                mStopSearch = value;
            }
        }
        #endregion

        #region Functions
        protected override void DoTask()
        {
            TDataObject lDao = null;
            TDbObj lDbObj = null;

            int lNumOfRecord = 0;
            string lBOName = string.Empty;
            string lCriteria = string.Empty;
            TSQL lSubSQL = new TSQL();
            KeyValuePair<DataTable, int> lKeyValuePair;

            mStopSearch = false;
            lBOName = "A_" + mSearchList.BOID + "_GetSearchResult";

            if (string.IsNullOrEmpty(mSearchList.CnnStr))
            {
                lDao = new TDataObject();
            }
            else
            {
                lDbObj = new TDbObj(mSearchList.CnnStr);
                lDao = new TDataObject(lDbObj);
            }
            lDao.CmdType = CommandType.Text;

            lDao.SQL.Stmt = "SELECT COUNT(*) FROM " + lBOName;
            lDao.SQL.AddToWhereClause(mSearchList.Criteria);
            lDao.SQL.AddToWhereClause(mSearchList.OtherFilter);
            lDao.OpenTable();
            lNumOfRecord = (int)lDao.Dr[0];

            lDao.SQL.Stmt = "SELECT * FROM " + lBOName;
            lDao.SQL.AddToWhereClause(Innotelli.Utilities.TGC.PKeyName + " IS NULL");
            lDao.OpenTable();
            lDao.Dt.TableName = mSearchList.BOID;
            //without indexing, performance of merging is better
            lDao.Dt.PrimaryKey = null;
            lKeyValuePair = new KeyValuePair<DataTable, int>(lDao.Dt, lNumOfRecord);
            PartialResult = lKeyValuePair;
            Progress = 0;

            for (int i = 0; i < lNumOfRecord && !mStopSearch; i += RECORD_PER_WS)
            {
                lSubSQL.Stmt = string.Format("SELECT TOP {0} {1} FROM {2}", i, mSearchList.DefaultOrderByField, lBOName);
                lSubSQL.AddToWhereClause(mSearchList.Criteria);
                lSubSQL.AddToWhereClause(mSearchList.OtherFilter);
                lSubSQL.AddToOrderByClause(mSearchList.OrderByFieldList);

                lDao.SQL.Stmt = string.Format("SELECT TOP {0} * FROM {1}", RECORD_PER_WS, lBOName);
                lDao.SQL.AddToWhereClause(mSearchList.Criteria);
                lDao.SQL.AddToWhereClause(mSearchList.OtherFilter);
                lDao.SQL.AddToOrderByClause(mSearchList.OrderByFieldList);
                lDao.SQL.AddToWhereClause(string.Format("{0} NOT IN({1})", mSearchList.DefaultOrderByField, lSubSQL.Stmt));
                lDao.OpenTable();

                //without indexing, performance of merging is better
                lDao.Dt.PrimaryKey = null;
                lKeyValuePair = new KeyValuePair<DataTable, int>(lDao.Dt, lNumOfRecord);
                PartialResult = lKeyValuePair;
                Progress = i + lDao.Dt.DefaultView.Count;
            }
        }
        #endregion
    }
}
