﻿namespace Innotelli.BO
{
    public class TBOT01ParentChildRel
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        #endregion

        #region Properties
        TBOT01 mParentBO = null;
        public TBOT01 ParentBO
        {
            get
            {
                return mParentBO;
            }
            set
            {
                mParentBO = value;
            }
        }
        string mParentLinkFieldName = string.Empty;
        public string ParentLinkFieldName
        {
            get
            {
                return mParentLinkFieldName;
            }
            set
            {
                mParentLinkFieldName = value;
            }
        }
        string mChildLinkFieldName = string.Empty;
        public string ChildLinkFieldName
        {
            get
            {
                return mChildLinkFieldName;
            }
            set
            {
                mChildLinkFieldName = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}
