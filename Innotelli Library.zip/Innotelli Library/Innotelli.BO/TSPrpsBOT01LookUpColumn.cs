﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public class TSPrpsBOT01LookUpColumn
    {
        private TDataRow mDr;
        public TDataRow Dr
        {
            get
            {
                return mDr;
            }
            set
            {
                mDr = value;
            }
        }

        #region Generated
        public int ColumnIndex
        {
            get
            {
                return (int)Dr["ColumnIndex"];
            }
        }
        public string FieldName
        {
            get
            {
                return (string)Dr["FieldName"];
            }
        }
        public string Caption
        {
            get
            {
                string lReturnValue = string.Empty;

                switch (Innotelli.Utilities.TAppSettings.SystemLanguage)
                {
                    case SystemLanguages.English:
                        lReturnValue = (string)Dr["Caption"];
                        break;
                    case SystemLanguages.SimplifiedChinese:
                        lReturnValue = (string)Dr["CaptionSCh"];
                        break;
                    case SystemLanguages.TraditionalChinese:
                        lReturnValue = (string)Dr["CaptionTCh"];
                        break;
                }

                return lReturnValue;
            }
        }
        public int ColumnWidth
        {
            get
            {
                return (int)Dr["ColumnWidth"];
            }
        }
        public SimpleDataType SimpleDataType
        {
            get
            {
                return (SimpleDataType)(Dr["slkFldType"]);
            }
        }
        public SimpleDataTypeCat1s SimpleDataTypeCat1
        {
            get
            {
                return TSimpleDataType.GetCat1(SimpleDataType);
            }
        }
        #endregion
    }
}
