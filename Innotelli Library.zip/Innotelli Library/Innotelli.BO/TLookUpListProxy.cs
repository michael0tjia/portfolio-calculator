using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Text;
using Innotelli.Db;
using Innotelli.Utilities;
using System.Collections;
using System.Threading;
using System.Timers;

namespace Innotelli.BO
{

    // 1. empty table handling

    public class TLookUpListProxy
    {
        #region Constants
        private const string ROW_VERSION_LIST_TABLENAME = "RowVersionList";
        private const int ROW_VERSION_CHECKING_INTERVAL = 5000;
        private const int ROW_VERSION_CHECKING_LIFE_CYCLE = 9 * 60 * 1000;
        #endregion

        #region Classes
        private class TCache
        {
            public DataSet LookUpListDs;
            //public string Version;
            public TRowVersion RowVersion;
            public bool Available;
            public object Locker = new object();
        }
        #endregion

        #region Members
        private const string cNewTimeStamp = "NewTimeStamp";
        private const string cLookUpListProxyXMLFileName = "LookUpListProxyCache";
        private const string cRowVersionFldNm = "RowVersion";
        private const string cAvailableFldNm = "Available";

        private TLookUpList mLookUpList = new TLookUpList();
        private TSysDataRdr mSysDataRdr = Innotelli.Utilities.TSingletons.SysData03Rdr;

        ManualResetEvent mManaulResetEvent = null;
        private System.Timers.Timer mTimer = null;
        private Hashtable mOldRowVersionHT = null;
        private Hashtable mNewRowVersionHT = null;

        //this variable will be used to
        //synchronization among raised events by timer intervally
        //in order to prevent Race Condition
        private int mTmSynVar = 0;
        private string mCnnStr = TAppSettings.DftCnnStr;

        #endregion

        #region Constructors
        public TLookUpListProxy()
        {
            mBODv.Table = Innotelli.BO.TSingletons.SPrpsBOT01s.Dt;
            mBODv.RowFilter = "CanLookUp = True";
            mBODv.Sort = "BOT01ID ASC";
        }
        #endregion

        #region Properties
        public string ClassFullName
        {
            get
            {
                return this.GetType().FullName;
            }
        }
        private Hashtable mCacheList = new Hashtable();
        public Hashtable CacheList
        {
            get
            {
                return mCacheList;
            }
            set
            {
                mCacheList = value;
            }
        }
        private DataView mBODv = new DataView();
        public DataView BODv
        {
            get 
            { 
                return mBODv; 
            }
            set 
            { 
                mBODv = value;
            }
        }
        #endregion

        #region Event Handlers

        #endregion

        #region Functions
        
        #region Load and Save
        public void LoadCacheFromSysData()
        {
            string lBOID = null;

            for (int i = 0; i < mBODv.Count; i++)
            {
                lBOID = mBODv[i]["BOT01ID"].ToString();
                LoadCacheFromSysDataForOneBO(lBOID);
            }
        }
        public void LoadCacheFromSysDataForOneBO(string aBOID)
        {
            DataSet lLookUpListDs = null;
            DataTable lDtLookUpListInfo = null;
            TCache lCache = null;

            //Don't remove try catch. If load cache fail, get from server again.
            try
            {
                lLookUpListDs = mSysDataRdr.GetSysData(LookUpListProxyXMLFileName(aBOID));
                if (lLookUpListDs != null)
                {
                    lCache = new TCache();
                    lCache.LookUpListDs = lLookUpListDs;
                    lDtLookUpListInfo = GetLookUpListInfoFromCache(lCache, aBOID);
                    lCache.RowVersion = new TRowVersion();
                    lCache.RowVersion.Val = (ulong)lDtLookUpListInfo.Rows[0][cRowVersionFldNm];
                    lCache.Available = true;
                    mCacheList[aBOID] = lCache;
                }
            }
            catch
            {
            }
        }
        public void SaveCacheToSysData()
        {
            string lBOID = null;

            for (int i = 0; i < mBODv.Count; i++)
            {
                lBOID = mBODv[i]["BOT01ID"].ToString();
                SaveCacheToSysDataForOneBO(lBOID);
            }
        }
        public void SaveCacheToSysDataForOneBO(string aBOID)
        {
            TCache lCache = null;

            lCache = (TCache)mCacheList[aBOID];
            if (lCache != null)
            {
                mSysDataRdr.SetSysData(LookUpListProxyXMLFileName(aBOID), lCache.LookUpListDs);
            }
        }
        #endregion

        #region LookUpList Info
        private DataTable CreateLookUpListInfo(string aBOID, TRowVersion aRowVersion)
        {
            DataTable lReturnValue = null;
            // Create Info DataTable
            lReturnValue = new DataTable();
            lReturnValue.TableName = aBOID + "_Info";
            lReturnValue.Columns.Add(cRowVersionFldNm, typeof(ulong));
            //lReturnValue.Columns.Add(cAvailableFldNm, typeof(bool));
            //lReturnValue.Rows.Add(aRowVersion.Val, false);
            lReturnValue.Rows.Add(aRowVersion.Val);
            return lReturnValue;
        }
        private string GetLookUpListInfoTblNm(string aBOID)
        {
            return aBOID + "_Info";
        }
        private DataTable GetLookUpListInfoFromCache(TCache aCache, string aBOID)
        {
            if (aCache != null && aCache.LookUpListDs != null && aCache.LookUpListDs.Tables.Contains(GetLookUpListInfoTblNm(aBOID)))
            {
                return aCache.LookUpListDs.Tables[GetLookUpListInfoTblNm(aBOID)];
            }
            else
            {
                return null;
            }
        }
        public string LookUpListProxyXMLFileName(string aBOID)
        {
            return TCurrentUser.BOServerID.ToString() + "." + aBOID + "." + cLookUpListProxyXMLFileName;
        }
        #endregion

        #region Cache Update
        private void UpdateCache()
        {
            string lBOID = null;

            LoadCacheFromSysData();
            if (mCacheList == null)
            {
                mCacheList = new Hashtable();
            }
            for (int i = 0; i < mBODv.Count; i++)
            {
                lBOID = mBODv[i]["BOT01ID"].ToString();
                UpdateCacheForOneBO(lBOID);
            }
        }
        public void UpdateCacheForOneBO(string aBOID)
        {
            TCache lCache = null;
            DataSet lLookUpListDs = null;
            DataTable lDtLookUpList = null;
            DataTable lDtLookUpListInfo = null;
            DataTable lDtDeletedPKList = null;
            DataTable lDtDeltaLookUpList = null;
            TRowVersion lNewRowVersion = null;
            bool lReplaceWholeList = false;

            if ((mCacheList[aBOID] != null))
            {
                lCache = (TCache)mCacheList[aBOID];
                
                lock (lCache.Locker)
                {
                    lLookUpListDs = lCache.LookUpListDs;
                    lDtLookUpList = lLookUpListDs.Tables[aBOID];
                    lNewRowVersion = new TRowVersion();
                    lNewRowVersion.Val = lCache.RowVersion.Val;

                    lDtDeltaLookUpList = mLookUpList.GetList(aBOID, lNewRowVersion, ref lReplaceWholeList);
                    //if (lDtDeltaLookUpList != null && lDtDeltaLookUpList.Rows.Count != 0)
                    if (lReplaceWholeList)
                    {
                        lDtLookUpList = lDtDeltaLookUpList;
                    }
                    else
                    {
                        lDtLookUpList.Merge(lDtDeltaLookUpList, false, MissingSchemaAction.Add);
                        
                    }
                    lCache.RowVersion.Val = lNewRowVersion.Val;
                    lDtDeletedPKList = GetDeletedPKList(aBOID, lCache.RowVersion);
                    RemoveDeletedRows(lDtLookUpList, lDtDeletedPKList);
                }
            }
            else
            {
                // Create a new Cache
                lCache = new TCache();
                lLookUpListDs = new DataSet();
                lNewRowVersion = new TRowVersion();
                lDtLookUpList = mLookUpList.GetList(aBOID, lNewRowVersion, ref lReplaceWholeList);
                if (lDtLookUpList != null)
                {
                    lLookUpListDs.Tables.Add(lDtLookUpList);
                    // Create Info DataTable
                    lDtLookUpListInfo = CreateLookUpListInfo(aBOID, lNewRowVersion);
                    lLookUpListDs.Tables.Add(lDtLookUpListInfo);
                    lCache.LookUpListDs = lLookUpListDs;
                    lCache.RowVersion = lNewRowVersion;
                    lCache.Available = true;
                    mCacheList[aBOID] = lCache;
                }
            }
        }
        #endregion

        #region Deleted Rows Handling
        private DataTable GetDeletedPKList(string aBOID, TRowVersion aRowVersion)
        {
            DataTable lReturnValue = null;
            TDataObject lDao = new TDataObject();

            try
            {
                if (TAppSettings.ClientMode == ClientModes.ThickClient)
                {
                    lDao.SQL.Stmt = "SELECT * FROM DelRowLog WHERE TblNm = '" + Innotelli.BO.TSingletons.SPrpsBOT01s[aBOID].TblName + "' AND upsize_ts > " + aRowVersion.Val;
                    lDao.OpenTable();
                    lReturnValue = lDao.Dt.Copy();
                }
                else
                {
                    TReflectionParams lReflectionParams = new TReflectionParams();

                    DataSet lDs = new DataSet();

                    lReflectionParams["aBOID"] = aBOID;
                    lReflectionParams["aRowVersionVal"] = aRowVersion.Val;
                    lDs = (DataSet)TReflectionClient.ExecuteMethod(ClassFullName, "WSGetDeletedPKList", lReflectionParams);
                    if (lDs.Tables.Count > 0)
                    {
                        lReturnValue = lDs.Tables[0];
                    }
                }
            }
            catch
            {
                lReturnValue = null;
            }

            return lReturnValue;
        }
        public DataSet WSGetDeletedPKList(string aBOID, ulong aRowVersionVal)
        {
            DataSet lReturnValue = new DataSet();
            DataTable lDt = null;

            lDt = GetDeletedPKList(aBOID, new TRowVersion(aRowVersionVal));
            if (lDt != null)
            {
                lReturnValue.Tables.Add(lDt);
            }

            return lReturnValue;
        }
        private void RemoveDeletedRows(DataTable aLookUpList, DataTable aDeletedPKList)
        {
            DataRow lDr = null;

            if (aLookUpList != null && aDeletedPKList != null)
            {
                if (aDeletedPKList.Rows.Count != 0)
                {
                    for (int i = 0; i < aDeletedPKList.Rows.Count; i++)
                    {
                        lDr = aLookUpList.Rows.Find(int.Parse(aDeletedPKList.Rows[i]["RowPK"].ToString()));
                        if (lDr != null)
                        {
                            aLookUpList.Rows.Remove(lDr);
                        }

                    }
                }
            }
        }
        #endregion        

        #region Direct Push LookUpList Update
        public DataSet GetRowVersionDsFromCacheList()
        {
            DataSet lReturnValue = null;
            DataTable lDt = null;

            if (CacheList.Count > 0)
            {
                lReturnValue = new DataSet();
                lDt = new DataTable();
                lDt.TableName = ROW_VERSION_LIST_TABLENAME;
                lDt.Columns.Add("BOID", typeof(string));
                lDt.Columns.Add("RowVersion", typeof(ulong));
                foreach (var lKey in CacheList.Keys)
                {
                    lDt.Rows.Add((string)lKey, ((TCache)CacheList[lKey]).RowVersion.Val);
                }
                lReturnValue.Tables.Add(lDt);
            }

            return lReturnValue;
        }
        //Run on server side
        public Hashtable GetUpdatedLookUpListHT(Hashtable aOldRowVersionHT, string aCnnStr)
        {
            Hashtable lReturnValue = null;
            Hashtable lNewRowVersionHT = new Hashtable();
            string lBOID = string.Empty;
            TRowVersion lRowVersion = null;

            for (int i = 0; i < BODv.Count; i++)
            {
                lBOID = (string)BODv[i].Row["BOT01ID"];
                lRowVersion = TLookUpList.GetNewRowVersion(lBOID, aCnnStr);
                if (lRowVersion.Val > (ulong)aOldRowVersionHT[lBOID])
                {
                    lNewRowVersionHT[lBOID] = lRowVersion.Val;
                }
            }
            if (lNewRowVersionHT.Count > 0)
            {
                lReturnValue = lNewRowVersionHT;
            }

            return lReturnValue;
        }
        //Run on server side
        public void UpdateLookUpLists()
        {
            Hashtable lNewRowVersionHT = null;

            lNewRowVersionHT = PullUpdatedLookUpListHT();
            if (lNewRowVersionHT != null && lNewRowVersionHT.Count > 0)
            {
                foreach (var lKey in lNewRowVersionHT.Keys)
                {
                    UpdateCacheForOneBO((string)lKey);
                }
            }

        }
        public Hashtable PullUpdatedLookUpListHT()
        {
            Hashtable lReturnValue = null;
            DataSet lOldRowVersionDs = null;
            DataSet lNewRowVersionDs = null;

            lOldRowVersionDs = GetRowVersionDsFromCacheList();
            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();

                lReflectionParams["aOldRowVersionDs"] = lOldRowVersionDs;
                lNewRowVersionDs = (DataSet)TReflectionClient.ExecuteMethod(ClassFullName, "WSPullUpdatedLookUpLists", lReflectionParams, 15 * 60 * 1000);
                if (lNewRowVersionDs != null && lNewRowVersionDs.Tables.Count == 1 && lNewRowVersionDs.Tables[0].TableName == ROW_VERSION_LIST_TABLENAME)
                {
                    lReturnValue = new Hashtable();
                    foreach (DataRow lDr in lNewRowVersionDs.Tables[0].Rows)
                    {
                        lReturnValue[lDr["BOID"]] = (ulong)lDr["RowVersion"];
                    }                    
                }
            }

            return lReturnValue;
        }
        public DataSet WSPullUpdatedLookUpLists(DataSet aOldRowVersionDs)
        {
            DataSet lReturnValue = null;
            DataTable lDt = null;

            if (aOldRowVersionDs != null && aOldRowVersionDs.Tables.Count == 1 && aOldRowVersionDs.Tables[0].TableName == ROW_VERSION_LIST_TABLENAME)
            {
                mOldRowVersionHT = new Hashtable();
                foreach (DataRow lDr in aOldRowVersionDs.Tables[0].Rows)
                {
                    mOldRowVersionHT[lDr["BOID"]] = (ulong)lDr["RowVersion"];
                }
                mTimer = new System.Timers.Timer();
                mTimer.Interval = ROW_VERSION_CHECKING_INTERVAL;
                mTimer.AutoReset = false;
                mTimer.Elapsed += new ElapsedEventHandler(mTimer_Elapsed);
                mTimer.Enabled = true;
                //To determine how long this web method can be alive,
                //default 10 minutes
                mManaulResetEvent = new ManualResetEvent(false);
                mManaulResetEvent.WaitOne(TimeSpan.FromMilliseconds(ROW_VERSION_CHECKING_LIFE_CYCLE), false);
                mTimer.Stop();
                if (mNewRowVersionHT != null && mNewRowVersionHT.Count > 0)
                {
                    lDt = new DataTable();
                    lDt.TableName = ROW_VERSION_LIST_TABLENAME;
                    lDt.Columns.Add("BOID", typeof(string));
                    lDt.Columns.Add("RowVersion", typeof(ulong));
                    foreach (var lKey in mNewRowVersionHT.Keys)
                    {
                        lDt.Rows.Add((string)lKey, (ulong)mNewRowVersionHT[lKey]);
                    }
                    lReturnValue = new DataSet();
                    lReturnValue.Tables.Add(lDt);
                }
            }

            return lReturnValue;
        }
        private void mTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            //In order to avoid the race condition arised by timer component
            Int32 lOriginalVal = 0;
            const int lExchangedVar = 1;
            const int lComparedVar = 0;

            lOriginalVal = Interlocked.CompareExchange(ref mTmSynVar, lExchangedVar, lComparedVar);
            if (lOriginalVal == 0)
            {
                mTimer.Stop();
                mNewRowVersionHT = GetUpdatedLookUpListHT(mOldRowVersionHT, mCnnStr);
                if (mNewRowVersionHT != null && mNewRowVersionHT.Count > 0)
                {
                    mManaulResetEvent.Set();
                }
                else
                {
                    Interlocked.Exchange(ref mTmSynVar, lOriginalVal);
                    mTimer.Start();
                }
            }
        }
        #endregion

        #region Others
        public DataTable GetList(string aBOID)
        {         
            DataTable lReturnValue = null;
            TCache lCache = null;

            if (mCacheList[aBOID] != null)
            {                
                lCache = (TCache)mCacheList[aBOID];
                //lock (lCache.Locker)
                //{
                    lReturnValue = lCache.LookUpListDs.Tables[aBOID];
                    //if (lReturnValue.Columns.Contains(Innotelli.Utilities.TGC.TIMESTAMP_FIELD_NAME))
                    //{
                    //    lReturnValue.Columns.Remove(Innotelli.Utilities.TGC.TIMESTAMP_FIELD_NAME);
                    //}
                //}
            }
            else
            {
                lReturnValue = null;
            }

            return lReturnValue;
        }
        #endregion

        #endregion
    }
}
