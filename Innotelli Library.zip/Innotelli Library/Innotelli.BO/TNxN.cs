using System;
using System.Data;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using Innotelli.Utilities;
using Innotelli.Db;

namespace Innotelli.BO
{
    public class TNxN
    {
        #region Members
        private string mSvrObjNm = null;
        #endregion

        #region Constructors
        public TNxN()
        {

        }
        #endregion

        #region Enums

        #endregion

        #region Properties
        public string SvrObjNm
        {
            get { return mSvrObjNm = this.GetType().Namespace + "." + this.GetType().Name; }
        }
        #endregion

        #region Event Handlers

        #endregion

        #region Functions
        public string GetNxNT01(string aBOID, string aNxNBOID, string aNxNFldNm)
        {
            string lReturnValue = string.Empty;
            string lNxN = string.Empty;
            string lTbl = string.Empty;
            string lSKFldNm = string.Empty;
            string lNxNTbl = string.Empty;
            string lPK = null;
            TDataObject lDao = new TDataObject();

            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                lTbl = Innotelli.BO.TSingletons.SPrpsBOT01s[aBOID].TblName;
                lSKFldNm = Innotelli.BO.TSingletons.SPrpsBOT01s[aBOID].SPrpsBOT01Flds.SKeyFieldName;

                lNxNTbl = Innotelli.BO.TSingletons.SPrpsBOT01s[aNxNBOID].TblName;

                lDao.SQL.Stmt = "SELECT * FROM " + lNxNTbl;
                lDao.MainTable = lNxNTbl;
                lDao.OpenTable();
                lNxN = lDao.Dr[aNxNFldNm].ToString();

                while (TDomain.LookupPK(lTbl, lSKFldNm + "='" + lNxN + "'", out lPK))
                {
                    lNxN = Innotelli.Utilities.TMisc.IncrementNumber(lNxN);
                }
                lDao.Dr[aNxNFldNm] = Innotelli.Utilities.TMisc.IncrementNumber(lNxN);
                lDao.UpdateRows();
                lReturnValue = lNxN;
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();


                lReflectionParams["aBOID"] = aBOID;
                lReflectionParams["aNxNBOID"] = aNxNBOID;
                lReflectionParams["aNxNFldNm"] = aNxNFldNm;
                lReturnValue = (string)TReflectionClient.ExecuteMethod(SvrObjNm, "GetNxNT01", lReflectionParams);
            }
            return lReturnValue;
        }
        public string GetNxNT02(string aBOID, string aNxNBOID, string aNxNFldNm, string aLetter)
        {
            string lReturnValue = string.Empty;
            string lNxN = string.Empty;
            string lTbl = string.Empty;
            string lSKFldNm = string.Empty;
            string lNxNTbl = string.Empty;
            string lPK = null;
            TDataObject lDao = new TDataObject();

            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                lTbl = Innotelli.BO.TSingletons.SPrpsBOT01s[aBOID].TblName;
                lSKFldNm = Innotelli.BO.TSingletons.SPrpsBOT01s[aBOID].SPrpsBOT01Flds.SKeyFieldName;
                lNxNTbl = Innotelli.BO.TSingletons.SPrpsBOT01s[aNxNBOID].TblName;

                lDao.SQL.Stmt = "Select * From " + lNxNTbl + " Where Lttr = '" + aLetter + "'";
                lDao.MainTable = lNxNTbl;
                lDao.OpenTable();
                if (!lDao.IsNoRow())
                {
                    lNxN = lDao.Dr[aNxNFldNm].ToString();

                    while (TDomain.LookupPK(lTbl, lSKFldNm + "='" + lNxN + "'", out lPK))
                    {
                        lNxN = Innotelli.Utilities.TMisc.IncrementNumber(lNxN);
                    }
                    lDao.Dr[aNxNFldNm] = Innotelli.Utilities.TMisc.IncrementNumber(lNxN);
                    lDao.UpdateRows();
                }
                lReturnValue = lNxN;
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();


                lReflectionParams["aBOID"] = aBOID;
                lReflectionParams["aNxNBOID"] = aNxNBOID;
                lReflectionParams["aNxNFldNm"] = aNxNFldNm;
                lReflectionParams["aLetter"] = aLetter;
                lReturnValue = (string)TReflectionClient.ExecuteMethod(SvrObjNm, "GetNxNT02", lReflectionParams);
            }
            return lReturnValue;
        }
        public string GetNxNT03(string aBOID, string aNxNBOID, string aNxNFldNm, string aPK)
        {
            string lReturnValue = string.Empty;
            string lNxN = string.Empty;
            string lTbl = string.Empty;
            string lSKFldNm = string.Empty;
            string lNxNTbl = string.Empty;
            string lPK = null;
            TDataObject lDao = new TDataObject();

            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                lTbl = Innotelli.BO.TSingletons.SPrpsBOT01s[aBOID].TblName;
                lSKFldNm = Innotelli.BO.TSingletons.SPrpsBOT01s[aBOID].SPrpsBOT01Flds.SKeyFieldName;
                lNxNTbl = Innotelli.BO.TSingletons.SPrpsBOT01s[aNxNBOID].TblName;

                lDao.SQL.Stmt = "SELECT " + Innotelli.Utilities.TGC.PKeyName + "," + aNxNFldNm + " FROM " + lNxNTbl + " WHERE " + Innotelli.Utilities.TGC.PKeyName + " = " + aPK;
                lDao.MainTable = lNxNTbl;
                lDao.OpenTable();
                if (!lDao.IsNoRow())
                {
                    lNxN = lDao.Dr[aNxNFldNm].ToString();

                    while (TDomain.LookupPK(lTbl, lSKFldNm + "='" + lNxN + "'", out lPK))
                    {
                        lNxN = Innotelli.Utilities.TMisc.IncrementNumber(lNxN);
                    }
                    lDao.Dr[aNxNFldNm] = Innotelli.Utilities.TMisc.IncrementNumber(lNxN);
                    lDao.UpdateRows();
                }
                lReturnValue = lNxN;
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["aBOID"] = aBOID;
                lReflectionParams["aNxNBOID"] = aNxNBOID;
                lReflectionParams["aNxNFldNm"] = aNxNFldNm;
                lReflectionParams["aPK"] = aPK;

                lReturnValue = (string)TReflectionClient.ExecuteMethod(SvrObjNm, "GetNxNT03", lReflectionParams);
            }
            return lReturnValue;
        }
        public string GetNxNT04(string aBOID, string aPrfx)
        {
            string lReturnValue = string.Empty;
            string lNxN = string.Empty;
            long lCount = 1;
            string lTbl = string.Empty;
            string lSKFldNm = string.Empty;
            int str = -1;
            Random lRandom = new Random();

            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                lTbl = Innotelli.BO.TSingletons.SPrpsBOT01s[aBOID].TblName;
                lSKFldNm = Innotelli.BO.TSingletons.SPrpsBOT01s[aBOID].SPrpsBOT01Flds.SKeyFieldName;
                lNxN = aPrfx + lRandom.Next(99999);
                lNxN = String.Format(lNxN, "00000");

                while ((TDomain.Lookup(Utilities.TGC.PKeyName, lTbl, lSKFldNm + "='" + lNxN + "'", out str)) || (lCount > 1000))
                {
                    lNxN = aPrfx + lRandom.Next(99999);
                    lNxN = String.Format(lNxN, "00000");
                    lCount++;
                }
                lReturnValue = lNxN;
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["aBOID"] = aBOID;
                lReflectionParams["aPrfx"] = aPrfx;

                lReturnValue = (string)TReflectionClient.ExecuteMethod(SvrObjNm, "GetNxNT04", lReflectionParams);
            }        
            return lReturnValue;
        }

        #endregion
    }
}

