﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Innotelli.BO
{
    // TBOT01 Datatable Properties
    public class TBOT01DtPrps
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        #endregion

        #region Properties
        private DataRow mDr;
        public DataRow Dr
        {
            get
            {
                return mDr;
            }
            set
            {
                mDr = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}
