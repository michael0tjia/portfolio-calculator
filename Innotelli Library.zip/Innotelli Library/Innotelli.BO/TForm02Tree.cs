using System;
using System.Collections.Generic;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using System.Text;
using System.Data;
using System.Reflection;
using Innotelli.Db;
using Innotelli.Utilities;
using Innotelli.Utilities.ReflectionProxy;

namespace Innotelli.BO
{
    public class TForm02Tree
    {
        #region Members
        private DataSet mDs = null;
        private ITree mTree = null;
        private INode mRootNode = null;
        //private DataSet mDataBackup = null;
        #endregion

        #region Constructors
        public TForm02Tree()
        {

        }
        #endregion

        #region Enums

        #endregion

        #region Properties
        public string DLLFolder
        {
            get
            {
                return ConfigurationManager.AppSettings["ReflectionDLLFolder"];
            }
        }
        public string ProjectNamespace
        {
            get
            {
                return ConfigurationManager.AppSettings["BOProjectNamespace"];
            }
        }
        public ITree Tree
        {
            get
            {
                return mTree;
            }
            set
            {
                if (mTree == value)
                    return;
                mTree = value;
            }
        }
        public INode RootNode
        {
            get
            {
                return mRootNode;
            }
            set
            {
                if (mRootNode == value)
                    return;
                mRootNode = value;
            }
        }
        #endregion

        #region Events

        #endregion

        #region Functions
        private string GetDLLFileNameFromTypeName(string aTypeName)
        {
            //#assume! one dll file, one namespace
            string lRtrnVal = aTypeName.Substring(0, aTypeName.LastIndexOf(".")) + ".dll";
            return lRtrnVal;
        }
        private Assembly GetAssemblyByTypeName(string aTypeName)
        {
            Assembly lRtrnVal;
            string lLocation = "";

            lLocation = DLLFolder + "\\" + GetDLLFileNameFromTypeName(aTypeName);
            lRtrnVal = Assembly.LoadFrom(lLocation);
            if (lRtrnVal == null)
            {
                throw new Exception("Could not find assembly");
            }
            return lRtrnVal;
        }
        private Type GetType(Assembly aAssembly, string aTypeName)
        {
            Type lRtrnVal = null;
            lRtrnVal = aAssembly.GetType(aTypeName);
            if (lRtrnVal == null)
            {
                throw new Exception("Could not find type!");
            }
            return lRtrnVal;
        }
        public DataSet LoadByPK(DataSet aDs)
        {
            object[] args = new object[0];
            TBOT01 lObj;
            Assembly lAssembly = null;
            DataSet[] lDs = new DataSet[1];
            DataSet lRtrnVal = new DataSet();
            string lTypeName = "";

            try
            {
                if (TAppSettings.ClientMode == ClientModes.ThickClient)
                {
                    lTypeName = ProjectNamespace + "." + aDs.Tables[0].TableName;
                    lAssembly = GetAssemblyByTypeName(lTypeName);

                    mDs = new DataSet();
                    lObj = (TBOT01)lAssembly.CreateInstance(ProjectNamespace + "." + aDs.Tables[0].TableName, true, BindingFlags.Default | BindingFlags.InvokeMethod, null, args, null, null);
                    lObj.PK = aDs.Tables[0].Rows[0][Utilities.TGC.PKeyName].ToString();
                    lObj.LoadDataSet();
                    mDs.Tables.Add(lObj.Dt.Copy());
                    int objIndex = -1;

                    for (int i = 1; i < aDs.Tables.Count; i++)
                    {
                        lObj = (TBOT01)lAssembly.CreateInstance(ProjectNamespace + "." + aDs.Tables[i].TableName, true, BindingFlags.Default | BindingFlags.InvokeMethod, null, args, null, null);
                        for (int k = 0; k < aDs.Tables.Count; k++)
                        {
                            if (aDs.Relations[i - 1].ParentTable.TableName == aDs.Tables[k].TableName)
                            {
                                objIndex = k;
                                break;
                            }
                        }
                        int prntRowsCount = mDs.Tables[objIndex].Rows.Count;
                        for (int j = 0; j < prntRowsCount; j++)
                        {
                            lObj.FK = "";
                            lObj.OtherFilter = aDs.Relations[i - 1].ChildColumns[0].ColumnName + " = '" + mDs.Tables[objIndex].Rows[j][aDs.Relations[i - 1].ParentColumns[0].ColumnName].ToString() + "'";
                            lObj.LoadDataSet();
                        }
                        #region Masking
                        //lObj.Dt.Columns.Add("NewItemStatus", typeof(string));
                        //lObj.Dt.Columns["NewItemStatus"].DefaultValue = "New";
                        //int chldRowsCount = lObj.Dt.Rows.Count;
                        //for (int k = 0; k < chldRowsCount; k++)
                        //{
                        //    lObj.Dt.Rows[k]["NewItemStatus"] = "Original";
                        //}
                        //lObj.Dt.Rows.Add(); 
                        #endregion
                        mDs.Tables.Add(lObj.Dt.Copy());
                    }

                    lRtrnVal = mDs;
                }
                else
                {
                    lDs[0] = aDs;
                    TStrIdxArr lStrIdxArr = new TStrIdxArr();
                    
                    lStrIdxArr["aDs"] = aDs;
                    TReflectionClient.ExecuteMethod("Innotelli.BO.TForm02Tree", "LoadByPK", ref lStrIdxArr, ref lRtrnVal);
                }

                //if (lRtrnVal != null)
                //{
                //    mDataBackup = lRtrnVal.Copy();
                //}

            }
            catch (Exception)
            {                
                throw;
            }
            return lRtrnVal;
        }
        public DataSet AddNew(DataSet aDs, string aFK)
        {
            TBOT01 lObj;
            Assembly lAssembly = null;
            DataSet lRtrnVal = new DataSet();
            string lTypeName = "";


            try
            {
                if (TAppSettings.ClientMode == ClientModes.ThickClient)
                {
                    lTypeName = ProjectNamespace + "." + aDs.Tables[0].TableName;
                    lAssembly = GetAssemblyByTypeName(lTypeName);
                    
                    mDs = new DataSet();
                    lObj = (TBOT01)lAssembly.CreateInstance(ProjectNamespace + "." + aDs.Tables[0].TableName, true, BindingFlags.Default | BindingFlags.InvokeMethod, null, null, null, null);
                    if (aFK == "")
                    {
                        aFK = null;
                    }
                    lObj.FK = aFK;
                    lObj.AddNew();
                    mDs.Tables.Add(lObj.Dt.Copy());

                    for (int i = 1; i < aDs.Tables.Count; i++)
                    {
                        lObj = (TBOT01)lAssembly.CreateInstance(ProjectNamespace + "." + aDs.Tables[i].TableName, true, BindingFlags.Default | BindingFlags.InvokeMethod, null, null, null, null);
                        lObj.LoadBlank();
                        #region Masking
                        //lObj.Dt.Columns.Add("NewItemStatus", typeof(string));
                        //lObj.Dt.Columns["NewItemStatus"].DefaultValue = "New"; 
                        #endregion
                        mDs.Tables.Add(lObj.Dt.Copy());
                    }
                    lRtrnVal = mDs;
                }
                else
                {
                    TStrIdxArr lStrIdxArr = new TStrIdxArr();
                    
                    //#check!
                    lStrIdxArr["aDs"] = aDs;                    
                    lStrIdxArr["aFK"] = TNull.Nz(aFK, "");
                    TReflectionClient.ExecuteMethod("Innotelli.BO.TForm02Tree", "AddNew", ref lStrIdxArr, ref lRtrnVal);                    
                }
            }
            catch (Exception)
            {
                throw;
            }
            return lRtrnVal;
        }
        public bool Save()
        {
            bool lRtrnVal = false;
            DataSet lDs = new DataSet();
            string lPK = "";
            TBOT01 lBOT01 = null;

            try
            {
                if (TAppSettings.ClientMode == ClientModes.ThickClient)
                {
                    lBOT01 = (TBOT01)((Element)mRootNode.Data).BOT01;
                    lBOT01.Save();
                    if (lBOT01.Dt.Rows[0][Utilities.TGC.PKeyName] == null || lBOT01.Dt.Rows[0][Utilities.TGC.PKeyName] == DBNull.Value)
                    {
                        lBOT01.SetNewID();
                    }
                    lBOT01.PK = lBOT01.Dr[Utilities.TGC.PKeyName].ToString();

                    foreach (INode lChild in mRootNode.DirectChildren)
                    {
                        lBOT01 = (TBOT01)((Element)mRootNode.Data).BOT01;
                        for (int j = 0; j < lBOT01.Dt.Rows.Count; j++)
                        {
                            if (lBOT01.Dt.Rows[j].RowState == DataRowState.Added)
                            {
                                lBOT01.Dt.Rows[j][Utilities.TGC.FKeyName] = lBOT01.PK;
                            }
                        }
                        lBOT01.Save();
                    }
                }
                else
                {
                    foreach (INode lChild in mTree.AllChildren)
                    {
                        lDs.Tables.Add(((TBOT01)((Element)lChild.Data).BOT01).Dt.Copy());
                    }

                    TStrIdxArr lStrIdxArr = new TStrIdxArr();
                    
                    lStrIdxArr["aDsData"] = lDs;
                    lStrIdxArr["aPK"] = lPK;
                    TReflectionClient.ExecuteMethod("Innotelli.BO.TForm02Tree", "WSSave", ref lStrIdxArr, ref lRtrnVal);
                    lPK = (string)lStrIdxArr["aPK"];

                    if (lRtrnVal)
                    {
                        lBOT01 = (TBOT01)((Element)mRootNode.Data).BOT01;
                        lBOT01.PK = lPK;
                    }
                }
                lRtrnVal = true;
            }
            catch (Exception)
            {
                throw;
            }
            return lRtrnVal;
        }
        public bool WSSave(DataSet aDsData, ref string aPK)
        {
            bool lRtrnVal = false;

            TBOT01 lBOT01;
            Assembly lAssembly = null;
            object[] args = new object[0];
            string lPKey = null;
            DataTable lDtTmp = null;            
            string lTypeName = "";

            try
            {
                aPK = null;
                //#check!
                //Db.TSingletons.GetCrrntCnnObj().BeginTrans();

                lTypeName = ProjectNamespace + "." + aDsData.Tables[0].TableName;
                lAssembly = GetAssemblyByTypeName(lTypeName);

                lBOT01 = (TBOT01)lAssembly.CreateInstance(ProjectNamespace + "." + aDsData.Tables[0].TableName, true, BindingFlags.Default | BindingFlags.InvokeMethod, null, null, null, null);
                lDtTmp = aDsData.Tables[0].Copy();
                lBOT01.Dt = lDtTmp;
                if (lBOT01.Dt.Rows[0][Utilities.TGC.PKeyName] == null || lBOT01.Dt.Rows[0][Utilities.TGC.PKeyName] == DBNull.Value)
                {
                    lBOT01.SetNewID();
                }
                lBOT01.Save();
                lPKey = lBOT01.Dt.Rows[0][Utilities.TGC.PKeyName].ToString();
                lBOT01.PK = lPKey;
                aPK = lPKey;

                for (int i = 1; i < aDsData.Tables.Count; i++)
                {
                    for (int j = 0; j < aDsData.Tables[i].Rows.Count; j++)
                    {
                        if (aDsData.Tables[i].Rows[j].RowState == DataRowState.Added)
                        {
                            aDsData.Tables[i].Rows[j][Utilities.TGC.FKeyName] = lPKey;
                        }
                    }
                    lBOT01 = (TBOT01)lAssembly.CreateInstance(ProjectNamespace + "." + aDsData.Tables[i].TableName, true, BindingFlags.Default | BindingFlags.InvokeMethod, null, null, null, null);
                    lDtTmp = aDsData.Tables[i].Copy();
                    lBOT01.Dt = lDtTmp;
                    lBOT01.Save();
                }
                //#check!
                //Db.TSingletons.GetCrrntCnnObj().Commit();
                lRtrnVal = true;
            }
            catch
            {
                //#check!
                //Db.TSingletons.GetCrrntCnnObj().RollBack();
                return false;
            }
            return lRtrnVal;
        }
        public int Delete(DataSet aDs)
        {
            TBOT01 lObj;
            Assembly lAssembly = null;
            object[] args = new object[0];
            bool lRst = false;
            int lRtrnVal = -1;
            string lTypeName = "";

            try
            {
                if (TAppSettings.ClientMode == ClientModes.ThickClient)
                {
                    lTypeName = ProjectNamespace + "." + aDs.Tables[0].TableName;
                    lAssembly = GetAssemblyByTypeName(lTypeName);

                    lObj = (TBOT01)lAssembly.CreateInstance(ProjectNamespace + "." + aDs.Tables[0].TableName, true, BindingFlags.Default | BindingFlags.InvokeMethod, null, args, null, null);
                    lRst = lObj.DeleteByPK(aDs.Tables[0].Rows[0][Utilities.TGC.PKeyName].ToString());
                    if (lRst)
                    {
                        lRtrnVal = 0;
                    }
                }
                else
                {
                    TStrIdxArr lStrIdxArr = new TStrIdxArr();
                    
                    lStrIdxArr["aDs"] = aDs;
                    TReflectionClient.ExecuteMethod("Innotelli.BO.TForm02Tree", "Delete", ref lStrIdxArr, ref lRtrnVal);
                }
            }
            catch (SqlException ex)
            {
                lRtrnVal = ex.ErrorCode;
            }
            catch (Exception)
            {
                throw;
            }
            return lRtrnVal;
        }
        #endregion

        #region TREE
        public INode InitRoot(Element aRootElement)
        {
            INode lRtrnVal = null;

            //mTree = NodeTree.NewTree();
            mTree = NodeTree.NewTree(typeof(Element));
            mTree.Clear();
            mRootNode = mTree.Root.AddChild(aRootElement);
            lRtrnVal = mRootNode;
            
            return lRtrnVal;
        }
        public INode AddChild(INode aParentNode, Element aChildElement)
        {
            INode lRtrnVal = null;

            if (aParentNode != null)
            {
                aParentNode.AddChild(CreateChildTree(aChildElement, out lRtrnVal));
            }

            //#check! carol 2008/01/03
            ((TBOT01)aChildElement.BOT01).BOT01ParentChildRel.ParentBO = (TBOT01)((Element)aParentNode.Data).BOT01;

            return lRtrnVal;
        }
        public ITree CreateChildTree(Element aChildElement, out INode aNode)
        {
            //aNode = null;
            ITree lRtrnVal = NodeTree.NewTree();

            aNode = lRtrnVal.AddChild(aChildElement);

            return lRtrnVal;
        }
        //private void OnFileNew()
        //{
        //    mTree.Clear();

        //    while (mTree.Count < 10)
        //    {
        //        mTree.Clear();
        //        //WriteLog("TREE " + mTree.Count + "START: (" + System.DateTime.Now.ToString() + ") \r\n");
        //        AddNodes(mTree.Root, "", 0);
        //    }
        //}
        //protected virtual void AddNodes(INode parent, int iDepth)
        //{
        //    if (iDepth >= mTreeDepth) return;

        //    for (int i = iDepth; i < mBOArr.Length; i++)
        //    {
        //        if (mTreeLevel[i] == iDepth)
        //        {
        //            INode child = parent.AddChild(new Element(mBOArr[i], mTreeLevel[i], mLinkKey[i]));
        //            AddNodes(child, iDepth + 1);
        //        }
        //    }
        //}

        #endregion
    }
}
