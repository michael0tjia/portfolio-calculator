﻿using System;
using System.Data;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public class TSPrpsTbl
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TSPrpsTbl(DataRow aDr)
        {
            mDr = aDr;
        }
        #endregion

        #region Properties
        private DataRow mDr = null;
        public DataRow Dr
        {
            get
            {
                return mDr;
            }
        }

        #region System Generated Columns
        public string TblID
        {
            get
            {
                return (string)Dr["TblID"];
            }
            set
            {
                Dr["TblID"] = value;
            }
        }
        public string Cat1
        {
            get
            {
                return (string)Dr["Cat1"];
            }
            set
            {
                Dr["Cat1"] = value;
            }
        }
        public string Cat2
        {
            get
            {
                return (string)Dr["Cat2"];
            }
            set
            {
                Dr["Cat2"] = value;
            }
        }
        public string Cat3
        {
            get
            {
                return (string)Dr["Cat3"];
            }
            set
            {
                Dr["Cat3"] = value;
            }
        }
        public int? Sort1
        {
            get
            {
                return (int?)Dr["Sort1"];
            }
            set
            {
                Dr["Sort1"] = value;
            }
        }
        public int? Sort2
        {
            get
            {
                return (int?)Dr["Sort2"];
            }
            set
            {
                Dr["Sort2"] = value;
            }
        }
        public int? Sort3
        {
            get
            {
                return (int?)Dr["Sort3"];
            }
            set
            {
                Dr["Sort3"] = value;
            }
        }
        public string TblAls
        {
            get
            {
                return (string)Dr["TblAls"];
            }
            set
            {
                Dr["TblAls"] = value;
            }
        }
        public string SrcTblID
        {
            get
            {
                return (string)Dr["SrcTblID"];
            }
            set
            {
                Dr["SrcTblID"] = value;
            }
        }
        public bool Chk
        {
            get
            {
                return (bool)Dr["Chk"];
            }
            set
            {
                Dr["Chk"] = value;
            }
        }
        public DateTime? DChk
        {
            get
            {
                return (DateTime?)Dr["DChk"];
            }
            set
            {
                Dr["DChk"] = value;
            }
        }
        public string ChkBy
        {
            get
            {
                return (string)Dr["ChkBy"];
            }
            set
            {
                Dr["ChkBy"] = value;
            }
        }
        public bool IsInitialData
        {
            get
            {
                return (bool)Dr["IsInitialData"];
            }
            set
            {
                Dr["IsInitialData"] = value;
            }
        }
        public bool Active
        {
            get
            {
                return (bool)Dr["Active"];
            }
            set
            {
                Dr["Active"] = value;
            }
        }
        public string Comment
        {
            get
            {
                return (string)Dr["Comment"];
            }
            set
            {
                Dr["Comment"] = value;
            }
        }
        public TDbRowID slkTblCat1
        {
            get
            {
                return (int?)Dr["slkTblCat1"];
            }
            set
            {
                Dr["slkTblCat1"] = value;
            }
        }
        public TDbRowID slkSttFld0
        {
            get
            {
                return (int?)Dr["slkSttFld0"];
            }
            set
            {
                Dr["slkSttFld0"] = value;
            }
        }
        public TDbRowID slkSttFld1
        {
            get
            {
                return (int?)Dr["slkSttFld1"];
            }
            set
            {
                Dr["slkSttFld1"] = value;
            }
        }
        public TDbRowID slkSttFld2
        {
            get
            {
                return (int?)Dr["slkSttFld2"];
            }
            set
            {
                Dr["slkSttFld2"] = value;
            }
        }
        public TDbRowID slkSttFld3
        {
            get
            {
                return (int?)Dr["slkSttFld3"];
            }
            set
            {
                Dr["slkSttFld3"] = value;
            }
        }
        public TDbRowID slkSttFld4
        {
            get
            {
                return (int?)Dr["slkSttFld4"];
            }
            set
            {
                Dr["slkSttFld4"] = value;
            }
        }
        public bool DupCp
        {
            get
            {
                return (bool)Dr["DupCp"];
            }
            set
            {
                Dr["DupCp"] = value;
            }
        }
        public string Notes
        {
            get
            {
                return (string)Dr["Notes"];
            }
            set
            {
                Dr["Notes"] = value;
            }
        }
        public string FieldList01
        {
            get
            {
                return (string)Dr["FieldList01"];
            }
            set
            {
                Dr["FieldList01"] = value;
            }
        }
        #endregion

        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}

