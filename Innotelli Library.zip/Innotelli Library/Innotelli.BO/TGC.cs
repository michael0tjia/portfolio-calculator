using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.BO
{
    public sealed class TGC
    {
        public const string VIRTUAL_PRIMARY_KEY_FIELD_NAME = "VIRTUALPRIMARYKEY";
        public const string VIRTUAL_PARENT_KEY_FIELD_NAME = "VIRTUALPARENTKEY";        

        private static string mFncCrncyPK = null;
        public static string FncCrncyPK
        {
            get
            {
                string lFncCrncyPK = null;

                if (string.IsNullOrEmpty(mFncCrncyPK))
                {
                    if (TDomain.LookupPK("Cmpny", "", out lFncCrncyPK))
                    {
                        mFncCrncyPK = lFncCrncyPK;

                    }

                }
                return mFncCrncyPK;
            }
        }
        private static string mFncCrncyID = "";
        public static string FncCrncyID
        {
            get
            {
                string lFncCrncyID = "";

                if (string.IsNullOrEmpty(mFncCrncyID))
                {
                    if (!string.IsNullOrEmpty(FncCrncyPK))
                    {
                        if (TDomain.Lookup("CrncyID", "Crncy", Innotelli.Utilities.TGC.PKeyName + " = " + FncCrncyPK, out lFncCrncyID))
                        {
                            mFncCrncyID = lFncCrncyID;
                        }
                    }
                }
                return mFncCrncyID;
            }
        }

    }
}
