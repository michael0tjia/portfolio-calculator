﻿using System.Collections;
using System.Data;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public class TMetaSimpleDataTypes
    {
        #region Enums
        #endregion

        #region Members
        private DataTable mDt = null;
        private Hashtable[] mMetaSimpleDataTypeHTs = null;
        public object mLocker = new object();
        #endregion

        #region Constructors
        public TMetaSimpleDataTypes()
        {
            mMetaSimpleDataTypeHTs = new Hashtable[2];
            mMetaSimpleDataTypeHTs[0] = new Hashtable();
            mMetaSimpleDataTypeHTs[1] = new Hashtable();
            mDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("FldType").Tables[0];
        }
        #endregion

        #region Properties
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }
        public int Count
        {
            get
            {
                return mDt.Rows.Count;
            }
        }
        public TMetaSimpleDataType this[string aSimpleDataTypeID]
        {
            get
            {
                TMetaSimpleDataType lReturnValue = null;
                DataRow[] lDrs = null;

                lock (mLocker)
                {
                    lDrs = mDt.Select("FldTypeID = '" + aSimpleDataTypeID + "'");
                    if (lDrs.Length != 0)
                    {
                        if (mMetaSimpleDataTypeHTs[0][aSimpleDataTypeID] == null)
                        {
                            mMetaSimpleDataTypeHTs[0][aSimpleDataTypeID] = new TMetaSimpleDataType(lDrs[0]);
                            lReturnValue = (TMetaSimpleDataType)mMetaSimpleDataTypeHTs[0][aSimpleDataTypeID];
                        }
                        else
                        {
                            lReturnValue = (TMetaSimpleDataType)mMetaSimpleDataTypeHTs[0][aSimpleDataTypeID];
                            lReturnValue.Dr = lDrs[0];
                        }
                    }
                }

                return lReturnValue;
            }
        }
        public TMetaSimpleDataType this[SimpleDataType aSimpleDataType]
        {
            get
            {
                TMetaSimpleDataType lReturnValue = null;
                DataRow[] lDrs = null;

                lock (mLocker)
                {
                    lDrs = mDt.Select("prmykey = " + (int)aSimpleDataType + "");
                    if (lDrs.Length != 0)
                    {
                        if (mMetaSimpleDataTypeHTs[1][(int)aSimpleDataType] == null)
                        {
                            mMetaSimpleDataTypeHTs[1][(int)aSimpleDataType] = new TMetaSimpleDataType(lDrs[0]);
                            lReturnValue = (TMetaSimpleDataType)mMetaSimpleDataTypeHTs[1][(int)aSimpleDataType];
                        }
                        else
                        {
                            lReturnValue = (TMetaSimpleDataType)mMetaSimpleDataTypeHTs[1][(int)aSimpleDataType];
                            lReturnValue.Dr = lDrs[0];
                        }
                    }
                }

                return lReturnValue;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}