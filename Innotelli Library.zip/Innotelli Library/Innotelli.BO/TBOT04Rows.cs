﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Innotelli.Db;

namespace Innotelli.BO
{
    public class TBOT04Rows<T> where T : TBOT04Dr, new()
    {
        #region Members
        private Dictionary<int, T> mBOT04DrsDict = new Dictionary<int, T>();
        private TBOT04 mBOT04 = null;
        #endregion

        #region Constructors
        public TBOT04Rows(TBOT04 aBOT04)
        {
            mBOT04 = aBOT04;
        }
        #endregion

        #region Properties

        public int Count
        {
            get
            {
                return mBOT04.DefaultView.Count;
            }
        }
        #endregion

        #region Functions
        public T this[int aRowIndex]
        {
            get
            {
                T lReturnValue = default(T);

                if (!mBOT04DrsDict.TryGetValue(aRowIndex, out lReturnValue))
                {
                    mBOT04DrsDict.Add(aRowIndex, new T());
                    lReturnValue = (T)mBOT04DrsDict[aRowIndex];
                }
                lReturnValue.Dr = mBOT04.DefaultView[aRowIndex].Row;

                return lReturnValue;
            }
        }

        #endregion
    }
}
