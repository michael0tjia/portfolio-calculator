using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Runtime.InteropServices;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public static class TCurrentUser
    {
        /* initialization and shutdown calls */
        [DllImport("aceclnt.dll")]
        public static extern int AceInitialize();
        [DllImport("aceclnt.dll")]
        public static extern int SD_Init(out int SdiHandle);
        [DllImport("aceclnt.dll")]
        public static extern int SD_Lock(int SdiHandle, String userID);
        [DllImport("aceclnt.dll")]
        public static extern int SD_Check(int SdiHandle, String passcode, String userID);
        [DllImport("aceclnt.dll")]
        public static extern int SD_Next(int SdiHandle, String passcode);
        [DllImport("aceclnt.dll")]
        public static extern int SD_Close(int SdiHandle);

        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        #endregion

        #region Properties
        private static string mID = "Admin";
        public static string ID
        {
            get
            {
                return mID;
            }
            set
            {
                mID = value;
            }
        }
        private static string mPK = "1";
        public static string PK
        {
            get
            {
                return mPK;
            }
            set
            {
                mPK = value;
            }
        }
        private static string mUsrRgnPK = "1";
        public static string UsrRgnPK
        {
            get
            {
                return mUsrRgnPK;
            }
            set
            {
                mUsrRgnPK = value;
            }
        }

        private static string mName = "Admin";
        public static string Name
        {
            get
            {
                return mName;
            }
            set
            {
                mName = value;
            }
        }
        private static string mUserPrefix = "";
        public static string UserPrefix
        {
            get
            {
                return mUserPrefix;
            }
            set
            {
                mUserPrefix = value;
            }
        }
        public static Guid BOServerID
        {
            get
            {
                return TReflectionClient.BOServerID;
            }
            set
            {

                TReflectionClient.BOServerID = value; 
            }
        }
        private static string mBOServerURL = "";
        public static string BOServerURL
        {
            get
            {
                return mBOServerURL;
            }
            set
            {
                mBOServerURL = value;
            }
        }
        private static string mCompanyName = "";
        public static string CompanyName
        {
            get
            {
                return mCompanyName;
            }
            set
            {
                mCompanyName = value;
            }
        }
        static TB01UserMMenu mB01UserMMenu = null;
        public static TB01UserMMenu B01UserMMenu
        {
            get
            {
                return mB01UserMMenu;
            }
            set
            {
                mB01UserMMenu = value;
            }
        }
        static TB01UserRpt mB01UserRpt = null;
        public static TB01UserRpt B01UserRpt
        {
            get
            {
                return mB01UserRpt;
            }
            set
            {
                mB01UserRpt = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions

        public static bool IsSeniorUsers(string aUserNm)
        {
            aUserNm = aUserNm.ToUpper();
            // HK
            return ((aUserNm == "ANDY") || (aUserNm == "PAT") || (aUserNm == "YAN") || (aUserNm == "JAZZ") || (aUserNm == "ADMIN") || (aUserNm == "BILLY"));
            // SZ
            // return (aUserNm == "CHENJUANFEN") || (aUserNm == "LIJUN") || (aUserNm == "Amanda"));
            //SH
            //return true;
        }
        public static bool Authenticate(string aLogin, string aPw)
        {
            bool lRtrnVal = false;
            DataRow lDr = null;
            string lChkPW = "";

            //int lhandle;
            //int lres;

            //const string lusername = "testing@innotelli";

            TDomain.LookupDataRow("*", "User", "UserID = '" + aLogin + "'", out lDr);
            if (lDr != null)
            {
                lChkPW = lDr["Password"].ToString();
                if ((lChkPW != "") && (lChkPW == aPw))
                {
                    //AceInitialize();
                    //lres = SD_Init(out lhandle);
                    //lres = SD_Lock(lhandle, lusername);
                    //lres = SD_Check(lhandle, "1234", lusername);
                    //if (lres == 0)
                    //{
                    lRtrnVal = true;
                    mID = aLogin;
                    mPK = lDr[Innotelli.Utilities.TGC.PKeyName].ToString(); ;
                    mName = lDr["NameEng"].ToString();
                    mUserPrefix = lDr["Prfx"].ToString();
                    //TODO: Michael Check
                    try
                    {
                        TDomain.Lookup("Cmpny", "Cmpny", "", out mCompanyName);
                    }
                    catch
                    {
                    }
                    if (mCompanyName == string.Empty)
                    {
                        try
                        {
                            TDomain.Lookup("Company", "Company", "", out mCompanyName);
                        }
                        catch
                        {
                        }
                    }
                    mB01UserMMenu = new TB01UserMMenu();
                    mB01UserMMenu.ParentKeyFieldName = Innotelli.Utilities.TGC.FKeyName;
                    mB01UserMMenu.ParentKey = mPK;
                    mB01UserMMenu.LoadDataSet();
                    mB01UserRpt = new TB01UserRpt();
                    mB01UserRpt.ParentKeyFieldName = Innotelli.Utilities.TGC.FKeyName;
                    mB01UserRpt.ParentKey = mPK;
                    mB01UserRpt.LoadDataSet();
                    //}

                    //SD_Close(lhandle);
                }
            }

            return lRtrnVal;
        }
        #endregion
    }
}
