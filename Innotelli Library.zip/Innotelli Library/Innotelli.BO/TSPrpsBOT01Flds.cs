﻿using System.Collections;
using System.Data;
using Innotelli.Db;

namespace Innotelli.BO
{
    public class TSPrpsBOT01Flds
    {
        #region Enums
        #endregion

        #region Members
        private string mBOID = string.Empty;
        private DataTable mDt = null;
        private Hashtable[] mSPrpsBOT01FldHTs = null;
        public object mLocker = new object();
        #endregion

        #region Constructors
        public TSPrpsBOT01Flds(string aBOID)
        {
            DataView lDv = new DataView();

            mBOID = aBOID;
            mSPrpsBOT01FldHTs = new Hashtable[2];
            mSPrpsBOT01FldHTs[0] = new Hashtable();
            mSPrpsBOT01FldHTs[1] = new Hashtable();
            lDv.Table = BOT01FldDt;
            lDv.RowFilter = "BOT01ID =  '" + mBOID + "'";
            mDt = lDv.ToTable();
        }
        #endregion

        #region Properties
        private static DataTable mBOT01FldDt = null;
        public static DataTable BOT01FldDt
        {
            get
            {
                if (mBOT01FldDt == null)
                {
                    mBOT01FldDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("BOT01Fld").Tables[0];
                }
                return mBOT01FldDt;
            }
        }
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }
        public int Count
        {
            get
            {
                return mDt.Rows.Count;
            }
        }
        public TSPrpsBOT01Fld this[int aRowIndex]
        {
            get
            {
                TSPrpsBOT01Fld lReturnValue = null;
                TSPrpsBOT01Fld lSPrpsBOT01Fld = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT01FldHTs[0][aRowIndex] == null)
                    {
                        mSPrpsBOT01FldHTs[0][aRowIndex] = new TSPrpsBOT01Fld();
                    }
                }
                lSPrpsBOT01Fld = (TSPrpsBOT01Fld)mSPrpsBOT01FldHTs[0][aRowIndex];
                lSPrpsBOT01Fld.Dr = mDt.Rows[aRowIndex];
                lReturnValue = lSPrpsBOT01Fld;

                return lReturnValue;
            }
        }
        public TSPrpsBOT01Fld this[string aFldNm]
        {
            get
            {
                TSPrpsBOT01Fld lReturnValue = null;
                TSPrpsBOT01Fld lSPrpsBOT01Fld = null;
                DataRow[] lDrs = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT01FldHTs[1][aFldNm] == null)
                    {
                        mSPrpsBOT01FldHTs[1][aFldNm] = new TSPrpsBOT01Fld();
                    }
                }
                lSPrpsBOT01Fld = (TSPrpsBOT01Fld)mSPrpsBOT01FldHTs[1][aFldNm];
                lDrs = mDt.Select("FldNm = '" + aFldNm + "'");
                if (lDrs.Length != 0)
                {
                    lSPrpsBOT01Fld.Dr = lDrs[0];
                    lReturnValue = lSPrpsBOT01Fld;
                }

                return lReturnValue;
            }
        }
        public string ItemNumberFieldName
        {
            get
            {
                string lReturnValue = string.Empty;
                DataRow lDr = null;

                lDr = TDomain.DataTableGetDataRow(mDt, "slkFldType = 108");
                if (lDr != null)
                {
                    lReturnValue = lDr["FldNm"].ToString();
                }
                return lReturnValue;
            }
        }
        public string SKeyFieldName
        {
            get
            {
                string lReturnValue = string.Empty;
                DataRow lDr = null;

                lDr = TDomain.DataTableGetDataRow(mDt, "SKey = " + TSQL.SqlBool(true));
                if (lDr != null)
                {
                    lReturnValue = lDr["FldNm"].ToString();
                }
                return lReturnValue;
            }
        }
        public TSPrpsBOT01Fld SKeySPrps
        {
            get
            {
                TSPrpsBOT01Fld lReturnValue = null;

                lReturnValue = this[SKeyFieldName];
                return lReturnValue;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}
