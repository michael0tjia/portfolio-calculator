﻿using System;
using System.Data;

namespace Innotelli.BO
{
    public class TSPrpsValLst
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TSPrpsValLst(DataRow aDr)
        {
            mDr = aDr;
            mValLstPK = prmykey;
            mSPrpsValLstDtls = new TSPrpsValLstDtls(mValLstPK);
        }
        #endregion

        #region Properties
        private string mValLstPK = string.Empty;
        public string ValLstPK
        {
            get
            {
                return mValLstPK;
            }
        }
        public string prmykey
        {
            get
            {
                return Dr["prmykey"].ToString();
            }
            set
            {
                Dr["prmykey"] = value;
            }
        }
        private DataRow mDr = null;
        public DataRow Dr
        {
            get
            {
                return mDr;
            }
        }
        private TSPrpsValLstDtls mSPrpsValLstDtls = null;
        public TSPrpsValLstDtls SPrpsValLstDtls
        {
            get
            {
                return mSPrpsValLstDtls;
            }
        }

        #region System Generated Columns
        public string ValLstID
        {
            get
            {
                return (string)Dr["ValLstID"];
            }
            set
            {
                Dr["ValLstID"] = value;
            }
        }
        public string Dscp
        {
            get
            {
                return (string)Dr["Dscp"];
            }
            set
            {
                Dr["Dscp"] = value;
            }
        }
        public int? ColCnt
        {
            get
            {
                return (int?)Dr["ColCnt"];
            }
            set
            {
                Dr["ColCnt"] = value;
            }
        }
        public int Column01Width
        {
            get
            {
                return (int)Dr["Column01Width"];
            }
            set
            {
                Dr["Column01Width"] = value;
            }
        }
        public int Column02Width
        {
            get
            {
                return (int)Dr["Column02Width"];
            }
            set
            {
                Dr["Column02Width"] = value;
            }
        }
        #endregion

        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}

