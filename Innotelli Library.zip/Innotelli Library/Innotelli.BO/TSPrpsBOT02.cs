using System.Diagnostics;
using System;
using System.Collections;
using System.Data;
using Innotelli.Utilities;
using System.Configuration;

namespace Innotelli.BO
{
    public class TSPrpsBOT02
    {
        #region Enums

        #endregion

        #region Members
        private string mBOID;
        private const string mPgmBuObj = "BOT02";
        private TSysDataRdr mSysDataRdr = Innotelli.Utilities.TSingletons.SysData01Rdr;
        #endregion

        #region Constructors
        public TSPrpsBOT02()
        {
        }
        #endregion

        #region Properties
        public string BOID
        {
            get
            {
                return mBOID;
            }
            set
            {
                mBOID = value;
            }
        }

        public string SKFldNm
        {
            get
            {
                return GetSPrps("SKFldNm", this.BOID);
            }
        }

        public string Dmn
        {
            get
            {
                return GetSPrps("Dmn", this.BOID);
            }
        }
        public string Tbl
        {
            get
            {
                return GetSPrps("Dmn", this.BOID).Substring(6);
            }
        }
        public string DtlDmn
        {
            get
            {
                return GetSPrps("DtlDmn", this.BOID);
            }
        }
        public string DtlTbl
        {
            get
            {
                return GetSPrps("DtlDmn", this.BOID).Substring(6);
            }
        }
        public string DTransFldNm
        {
            get
            {
                return GetSPrps("DTransFldNm", this.BOID);
            }
        }

        public string CrFldNm
        {
            get
            {
                return GetSPrps("CrFldNm", this.BOID);
            }
        }

        public string ERFldNm
        {
            get
            {
                return GetSPrps("ERFldNm", this.BOID);
            }
        }

        public string DtlCrFldNm
        {
            get
            {
                return GetSPrps("DtlCrFldNm", this.BOID);
            }
        }

        public string DtlERFldNm
        {
            get
            {
                return GetSPrps("DtlERFldNm", this.BOID);
            }
        }

        public string DocType
        {
            get
            {
                return GetSPrps("DocType", this.BOID);
            }
        }
        public string BONameSpace
        {
            get
            {
                return (string)GetSPrps("BONameSpace", this.BOID);
            }
        }
        public string UINameSpace
        {
            get
            {
                return (string)GetSPrps("UINameSpace", this.BOID);
            }
        }
        public string FullBOClassName
        {
            get
            {
                return (string)GetSPrps("FullBOClassName", this.BOID);
            }
        }
        #endregion

        #region Event Handlers

        #endregion

        #region Functions
        public string GetSKFldNm(string aBOT02ID)
        {
            string lReturnValue = "";
            lReturnValue = GetSPrps("SKFldNm", aBOT02ID);
            return lReturnValue;
        }

        public string GetDmn(string aBOT02ID)
        {
            string lReturnValue = "";
            lReturnValue = GetSPrps("Dmn", aBOT02ID);
            return lReturnValue;
        }

        public string GetDtlDmn(string aBOT02ID)
        {
            string lReturnValue = "";
            lReturnValue = GetSPrps("DtlDmn", aBOT02ID);
            return lReturnValue;
        }

        public string GetDTransFldNm(string aBOT02ID)
        {
            string lReturnValue = "";
            lReturnValue = GetSPrps("DTransFldNm", aBOT02ID);
            return lReturnValue;
        }

        public string GetCrFldNm(string aBOT02ID)
        {
            string lReturnValue = "";
            lReturnValue = GetSPrps("CrFldNm", aBOT02ID);
            return lReturnValue;
        }

        public string GetERFldNm(string aBOT02ID)
        {
            string lReturnValue = "";
            lReturnValue = GetSPrps("ERFldNm", aBOT02ID);
            return lReturnValue;
        }

        public string GetDtlCrFldNm(string aBOT02ID)
        {
            string lReturnValue = "";
            lReturnValue = GetSPrps("DtlCrFldNm", aBOT02ID);
            return lReturnValue;
        }

        public string GetDtlERFldNm(string aBOT02ID)
        {
            string lReturnValue = "";
            lReturnValue = GetSPrps("DtlERFldNm", aBOT02ID);
            return lReturnValue;
        }

        public string GetDocType(string aBOT02ID)
        {
            string lReturnValue = "";
            lReturnValue = GetSPrps("DocType", aBOT02ID);
            return lReturnValue;
        }

        private string GetSPrps(string aPrpNm, string aBOT02ID)
        {
            DataSet dsBuObj = new DataSet();
            DataTable dtBuObj = new DataTable();
            DataRow[] foundRow;
            string lPrpVal = null;
            string lExp = "BOT02ID = '" + aBOT02ID + "'";

            dsBuObj = mSysDataRdr.GetSysData(mPgmBuObj);

            foundRow = dsBuObj.Tables[0].Select(lExp);
            lPrpVal = foundRow[0][aPrpNm].ToString();

            return lPrpVal;
        }
        #endregion

    }
}
