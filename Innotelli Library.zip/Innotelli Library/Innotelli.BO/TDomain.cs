using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Text;
using Innotelli.Utilities;
using Innotelli.Db;

namespace Innotelli.BO
{
    public static class TDomain
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        #endregion

        #region Properties
        public static string ClassFullName
        {
            get
            {
                return "Innotelli.BO.TDomain";
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        public static bool Lookup(string aExpr, string aTbl, string aCriteria, out object aResult)
        {
            bool lReturnValue = false;
            aResult = null;
            string lSQL;
            TDataObject lDataObject = null;

            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                lDataObject = new TDataObject();

                lSQL = "SELECT " + aExpr + " AS DataReturned FROM [" + aTbl + "] ";
                if (aCriteria != "")
                {
                    lSQL = lSQL + "WHERE " + aCriteria;
                }
                lSQL = lSQL + ";";
                lDataObject.MainTable = aTbl;
                lDataObject.OpenTable(lSQL);
                if (!lDataObject.IsNoRow())
                {
                    lDataObject.MoveFirst();
                    aResult = lDataObject.Dr["DataReturned"];
                    lReturnValue = true;
                }
                else
                {
                    lReturnValue = false;
                }
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["aResult"] = new object();
                lReflectionParams["aExpr"] = aExpr;
                lReflectionParams["aTbl"] = aTbl;
                lReflectionParams["aCriteria"] = aCriteria;
                //#check!
                //lReflectionParams["aResult"] = aResult;

                lReturnValue = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "Lookup", lReflectionParams);
                aResult = lReflectionParams["aResult"];
            }
            return lReturnValue;
        }
        public static bool Lookup(string aExpr, string aTable, string aCriteria, out int aResult)
        {
            bool lReturnValue = false;
            object lResult;
            aResult = 0;

            lReturnValue = Lookup(aExpr, aTable, aCriteria, out lResult);
            if (lReturnValue)
            {
                aResult = int.Parse(lResult.ToString());
            }

            return lReturnValue;
        }
        public static bool Lookup(string aExpr, string aTable, string aCriteria, out double aResult)
        {
            bool lReturnValue = false;
            object lResult;
            aResult = 0;

            lReturnValue = Lookup(aExpr, aTable, aCriteria, out lResult);
            if (lReturnValue)
            {
                aResult = double.Parse(lResult.ToString());
            }
            return lReturnValue;
        }
        public static bool Lookup(string aExpr, string aTable, string aCriteria, out decimal aResult)
        {
            bool lReturnValue = false;
            object lResult;
            aResult = 0;

            lReturnValue = Lookup(aExpr, aTable, aCriteria, out lResult);
            if (lReturnValue)
            {
                aResult = decimal.Parse(lResult.ToString());
            }
            return lReturnValue;
        }
        public static bool Lookup(string aExpr, string aTable, string aCriteria, out bool aResult)
        {
            bool lReturnValue = false;
            object lResult;
            aResult = false;

            lReturnValue = Lookup(aExpr, aTable, aCriteria, out lResult);
            if (lReturnValue)
            {
                aResult = bool.Parse(lResult.ToString());
            }
            return lReturnValue;
        }
        public static bool Lookup(string aExpr, string aTable, string aCriteria, out DateTime aResult)
        {
            bool lReturnValue = false;
            object lResult;
            aResult = DateTime.Now;

            lReturnValue = Lookup(aExpr, aTable, aCriteria, out lResult);
            if (lReturnValue)
            {
                aResult = DateTime.Parse(lResult.ToString());
            }
            return lReturnValue;
        }
        public static bool Lookup(string aExpr, string aTable, string aCriteria, out DateTime? aResult)
        {
            bool lReturnValue = false;
            object lResult;
            aResult = null;

            lReturnValue = Lookup(aExpr, aTable, aCriteria, out lResult);
            if (lReturnValue)
            {
                aResult = (DateTime?)lResult;
            }
            return lReturnValue;
        }
        public static bool Lookup(string aExpr, string aTable, string aCriteria, out string aResult)
        {
            bool lReturnValue = false;
            object lResult;
            aResult = "";

            lReturnValue = Lookup(aExpr, aTable, aCriteria, out lResult);
            if (lReturnValue)
            {
                aResult = lResult.ToString();
            }
            return lReturnValue;
        }
        public static bool LookupPK(string aTable, string aCriteria, out string aPK)
        {
            bool lReturnValue = false;
            string lPK = null;

            aPK = null;
            lReturnValue = Lookup(Utilities.TGC.PKeyName, aTable, aCriteria, out lPK);
            if (lReturnValue)
            {
                aPK = lPK;
            }
            return lReturnValue;
        }
        public static bool LookupPK(string aTable, string aCriteria, out TDbRowID aPK)
        {
            bool lReturnValue = false;
            int lPK = 0;

            lReturnValue = Lookup(Utilities.TGC.PKeyName, aTable, aCriteria, out lPK);
            if (lReturnValue)
            {
                aPK = lPK;
            }
            else
            {
                aPK = TDbRowID.Null;
            }
            return lReturnValue;
        }
        public static bool Average(string aField, string aTable, string aCriteria, out double aResult)
        {
            bool lReturnValue = false;
            object lResult;
            aResult = 0;

            string lExpr = "AVG([" + aField + "])";
            lReturnValue = Lookup(lExpr, aTable, aCriteria, out lResult);
            if (lReturnValue)
            {
                aResult = double.Parse(string.Format(lResult.ToString(), "0.00"));
            }
            return lReturnValue;
        }
        public static bool Count(string aField, string aTable, string aCriteria, out int aResult)
        {
            bool lReturnValue = false;
            object lResult;
            aResult = 0;

            string lExpr = "COUNT([" + aField + "])";
            lReturnValue = Lookup(lExpr, aTable, aCriteria, out lResult);
            if (lReturnValue)
            {
                aResult = int.Parse(lResult.ToString());
            }
            return lReturnValue;
        }
        public static bool Max(string aField, string aTable, string aCriteria, out double aResult)
        {
            bool lReturnValue = false;
            object lResult;
            aResult = 0;

            string lExpr = "MAX([" + aField + "])";
            lReturnValue = Lookup(lExpr, aTable, aCriteria, out lResult);
            if (lReturnValue)
            {
                aResult = double.Parse(string.Format(lResult.ToString(), "0.00"));
            }
            return lReturnValue;
        }
        public static bool Min(string aField, string aTable, string aCriteria, out double aResult)
        {
            bool lReturnValue = false;
            object lResult;
            aResult = 0;

            string lExpr = "MIN([" + aField + "])";
            lReturnValue = Lookup(lExpr, aTable, aCriteria, out lResult);
            if (lReturnValue)
            {
                aResult = double.Parse(string.Format(lResult.ToString(), "0.00"));
            }
            return lReturnValue;
        }
        public static bool Sum(string aField, string aTable, string aCriteria, out double aResult)
        {
            bool lReturnValue = false;
            object lResult;
            aResult = 0;

            string lExpr = "SUM([" + aField + "])";
            lReturnValue = Lookup(lExpr, aTable, aCriteria, out lResult);
            if (lReturnValue && lResult != null)
            {
                aResult = double.Parse(string.Format(lResult.ToString(), "0.00"));
            }
            else
            {
                aResult = 0;
            }
            return lReturnValue;
        }
        public static bool Sum(string aField, string aTable, string aCriteria, out decimal aResult)
        {
            bool lReturnValue = false;
            object lResult;
            aResult = 0;

            string lExpr = "SUM([" + aField + "])";
            lReturnValue = Lookup(lExpr, aTable, aCriteria, out lResult);
            if (lReturnValue && lResult != null)
            {
                aResult = decimal.Parse(string.Format(lResult.ToString(), "0.00"));
            }
            else
            {
                aResult = 0;
            }
            return lReturnValue;
        }
        public static bool StDev(string aField, string aTable, string aCriteria, out double aResult)
        {
            bool lReturnValue = false;
            object lResult;
            aResult = 0;

            string lExpr = "STDDEV([" + aField + "])";
            lReturnValue = Lookup(lExpr, aTable, aCriteria, out lResult);
            if (lReturnValue)
            {
                aResult = double.Parse(string.Format(lResult.ToString(), "0.00"));
            }
            return lReturnValue;
        }
        public static bool Var(string aField, string aTable, string aCriteria, out double aResult)
        {
            bool lReturnValue = false;
            object lResult;
            aResult = 0;

            string lExpr = "VAR([" + aField + "])";
            lReturnValue = Lookup(lExpr, aTable, aCriteria, out lResult);
            if (lReturnValue)
            {
                aResult = double.Parse(string.Format(lResult.ToString(), "0.00"));
            }
            return lReturnValue;
        }
        public static bool LookupDataRow(string aFldLst, string aTbl, string aCriteria, out DataRow aResult)
        {
            bool lReturnValue = false;
            string lSQL;
            TDataObject lDataObject = null;

            aResult = null;

            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                lDataObject = new TDataObject();
                lSQL = "SELECT " + AddBracket(aFldLst) + " FROM [" + aTbl + "] ";
                if (aCriteria != "")
                {
                    lSQL = lSQL + "WHERE " + aCriteria;
                }
                lSQL = lSQL + ";";
                lDataObject.MainTable = aTbl;
                lDataObject.OpenTable(lSQL);
                if (!lDataObject.IsNoRow())
                {
                    lDataObject.MoveFirst();
                    aResult = lDataObject.Dr;
                    lReturnValue = true;
                }
                else
                {
                    lReturnValue = false;
                }
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["aFldLst"] = aFldLst;
                lReflectionParams["aTbl"] = aTbl;
                lReflectionParams["aCriteria"] = aCriteria;
                lReflectionParams.Types["aResult"] = ReflectionParamTypes.DataSet;
                lReflectionParams["aResult"] = null;

                lReturnValue = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "WSLookupDataSet", lReflectionParams);
                if (lReturnValue)
                {
                    aResult = ((DataSet)lReflectionParams["aResult"]).Tables[0].Rows[0];
                }
            }
            return lReturnValue;
        }
        private static string AddBracket(string aFieldList)
        {
            string lReturnValue = "";
            string[] lFieldLists;

            if (aFieldList == "*")
            {
                lReturnValue = aFieldList;
            }
            else
            {
                lFieldLists = aFieldList.Split(',');
                for (int i = 0; i < lFieldLists.Length; i++)
                {
                    lReturnValue += "[" + lFieldLists[i].Trim() + "], ";
                }
                lReturnValue = TStr.Left(lReturnValue, lReturnValue.Length - 2);
            }

            return lReturnValue;
        }
        //#check!
        public static DataRow DataTableGetDataRow(DataTable aDt, string aCriteria)
        {
            DataRow lReturnValue = null;
            DataView lDv = new DataView();

            lDv.Table = aDt;
            lDv.RowFilter = aCriteria;
            if (lDv.Count != 0)
            {
                //#check!
                lReturnValue = lDv[0].Row;
            }
            return lReturnValue;
        }

        #region Web Service
        public static bool WSLookup(string aExpr, string aTbl, string aCriteria, ref object aResult)
        {
            bool lReturnValue = false;
            aResult = null;
            string lSQL;
            TDataObject lDataObject = null;

            lDataObject = new TDataObject();

            lSQL = "SELECT " + aExpr + " AS DataReturned FROM [" + aTbl + "] ";
            if (aCriteria != "")
            {
                lSQL = lSQL + "WHERE " + aCriteria;
            }
            lSQL = lSQL + ";";
            lDataObject.MainTable = aTbl;
            lDataObject.OpenTable(lSQL);
            if (!lDataObject.IsNoRow())
            {
                lDataObject.MoveFirst();
                aResult = lDataObject.Dr["DataReturned"];
                lReturnValue = true;
            }
            else
            {
                lReturnValue = false;
            }
            return lReturnValue;
        }
        public static bool WSLookupDataSet(string aFldLst, string aTbl, string aCriteria, ref DataSet aResult)
        {
            bool lReturnValue = false;
            aResult = new DataSet();
            string lSQL;
            TDataObject lDataObject = null;

            lDataObject = new TDataObject();

            lSQL = "SELECT " + AddBracket(aFldLst) + " FROM [" + aTbl + "] ";
            if (aCriteria != "")
            {
                lSQL = lSQL + "WHERE " + aCriteria;
            }
            lSQL = lSQL + ";";
            lDataObject.MainTable = aTbl;
            lDataObject.OpenTable(lSQL);
            if (!lDataObject.IsNoRow())
            {
                lDataObject.MoveFirst();

                aResult.Tables.Add(lDataObject.Dt.Copy());
                lReturnValue = true;
            }
            else
            {
                lReturnValue = false;
            }
            return lReturnValue;
        } 
        #endregion

        #endregion
    }
}