using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using System.Data;
using Innotelli.Db;
using Innotelli.Utilities;
using System.Windows.Forms;


namespace Innotelli.BO
{
    public class TSearchList
    {
        #region Constructors
        public TSearchList()
        {
            mCriteriaTable = CreateCriteriaTable();
        }
        #endregion

        #region Properties
        public string ClassFullName
        {
            get
            {
                return this.GetType().Namespace + "." + this.GetType().Name;
            }
        }
        private string mBOID = string.Empty;
        public string BOID
        {
            get
            {
                return mBOID;
            }
            set
            {
                mBOID = value;
            }
        }
        private string mCriteria = string.Empty;
        public string Criteria
        {
            get
            {
                return mCriteria;
            }
            set
            {
                mCriteria = value;
            }
        }
        private string mOtherFilter = string.Empty;
        public string OtherFilter
        {
            get
            {
                return mOtherFilter;
            }
            set
            {
                mOtherFilter = value;
            }
        }
        private string mOrderByFieldList = string.Empty;
        public string OrderByFieldList
        {
            get
            {
                return mOrderByFieldList;
            }
            set
            {
                mOrderByFieldList = value;
            }
        }
        private DataTable mCriteriaTable = null;
        public DataTable CriteriaTable
        {
            get
            {
                return mCriteriaTable;
            }
        }
        public DataRow CriteriaRow
        {
            get
            {
                return mCriteriaTable.Rows[0];
            }
        }
        private string mDefaultOrderByField;
        public string DefaultOrderByField
        {
            get
            {
                return mDefaultOrderByField;
            }
            set
            {
                mDefaultOrderByField = value;
            }
        }
        private string mCnnStr = string.Empty;
        public string CnnStr
        {
            get
            {
                return mCnnStr;
            }
            set
            {
                mCnnStr = value;
            }
        }
        #endregion

        #region Functions

        #region Criteria Table
        private DataTable CreateCriteriaTable()
        {
            DataTable lReturnValue = null;
            DataRow lDr = null;

            lReturnValue = new DataTable();
            lReturnValue.TableName = "Criteria";
            lReturnValue.Columns.Add("FieldName", typeof(string));
            lReturnValue.Columns.Add("FieldType", typeof(string));
            lReturnValue.Columns.Add("Operator", typeof(string));
            lReturnValue.Columns.Add("Value1", typeof(object));
            lReturnValue.Columns.Add("And", typeof(string));
            lReturnValue.Columns.Add("Value2", typeof(object));
            lDr = lReturnValue.NewRow();
            lDr["And"] = "AND";
            lReturnValue.Rows.Add(lDr);
            return lReturnValue;
        }
        public string GetCriteriaFromCriteriaRow()
        {
            string lReturnValue = string.Empty;

            object lValue1 = CriteriaRow["Value1"];
            object lValue2 = CriteriaRow["Value2"];
            TSQL lSQL = new TSQL();
            string lSQLVal1 = string.Empty;
            string lSQLVal2 = string.Empty;

            string lBgnStr = string.Empty;
            string lEndStr = string.Empty;
            string lOptr = string.Empty;
            DataRow lOperatorDr;
            string lFldNm = CriteriaRow["FieldName"].ToString();
            string lFldType = CriteriaRow["FieldType"].ToString();
            string lOperator = CriteriaRow["Operator"].ToString();

            lOperatorDr = Innotelli.Utilities.TSingletons.SrchCndtnDs.Tables[0].Select("Cndtn = " + TSQL.SqlText(lOperator))[0];
            lOptr = lOperatorDr["Optr"].ToString();
            lBgnStr = lOperatorDr["BgnStr"].ToString();
            lEndStr = lOperatorDr["EndStr"].ToString();

            if (lOperator == "Is between" && !TNull.IsValueNull(lValue1) && !string.IsNullOrEmpty(lValue1.ToString()) && !TNull.IsValueNull(lValue2) && !string.IsNullOrEmpty(lValue2.ToString()))
            {
                if (lFldType == "TEXT")
                {
                    lValue1 = lBgnStr + (string)lValue1 + lEndStr;
                    lValue2 = lBgnStr + (string)lValue2 + lEndStr;
                }
                lSQLVal1 = TSQL.SqlValStr(lValue1, lFldType);
                lSQLVal2 = TSQL.SqlValStr(lValue2, lFldType);
                lReturnValue = lFldNm + " " + lOptr + " " + lSQLVal1 + " AND " + lSQLVal2;
            }
            else if (lOperator != "Is between" && !TNull.IsValueNull(lValue1) && !string.IsNullOrEmpty(lValue1.ToString()))
            {
                if (lFldType == "TEXT")
                {
                    lValue1 = lBgnStr + (string)lValue1 + lEndStr;
                }
                lSQLVal1 = TSQL.SqlValStr(lValue1, lFldType);
                lReturnValue = lFldNm + " " + lOptr + " " + lSQLVal1;
            }

            return lReturnValue;
        }
        #endregion

        public DataSet WSGetList(string aBOID, string aCriteria, string aOtherFilter, string aOrderByFieldList)
        {

            DataSet lReturnValue = new DataSet();
            DataTable lDt = null;

            BOID = aBOID;
            Criteria = aCriteria;
            OtherFilter = aOtherFilter;
            OrderByFieldList = aOrderByFieldList;

            //lDt = GetList();
            if (lDt != null)
            {
                lReturnValue.Tables.Add(lDt);
            }
            return lReturnValue;
        }
        #endregion
    }
}