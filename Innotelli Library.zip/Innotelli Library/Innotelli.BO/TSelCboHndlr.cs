using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Text;
using System.IO;
using Innotelli.Db;
using Innotelli.Utilities;
using Innotelli.Utilities.ReflectionProxy;

namespace Innotelli.BO
{
    public class TSelCboHndlr
    {
        #region Members
        private ReflectionProxySvc mReflectionProxySvc;
        private string mSvrObjNm;
        #endregion

        #region Constructors
        public TSelCboHndlr()
        {
            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {

            }
            else
            {
                mReflectionProxySvc = TServiceFactory.GetService();
                mSvrObjNm = this.GetType().Namespace + "." + this.GetType().Name;
            }
        }
        #endregion

        #region Enums

        #endregion

        #region Properties

        #endregion

        #region Events

        #endregion

        #region Functions
        public DataSet GetDataSource(string aRowSource, string aWhereClause)
        {
            DataSet lRtrnVal = null;
            try
            {
                lRtrnVal = new DataSet();
                if (TAppSettings.ClientMode == ClientModes.ThickClient)
                {
                    TDataObject lDataObject = new TDataObject();
                    lDataObject.OpenTable("SELECT " + aRowSource + ".* FROM " + aRowSource + " " + aWhereClause);
                    lRtrnVal = new DataSet();
                    lRtrnVal.Tables.Add(lDataObject.Dt);
                }
                else
                {
                    TStrIdxArr lStrIdxArr = new TStrIdxArr();
                    
                    lStrIdxArr["aRowSource"] = aRowSource;
                    lStrIdxArr["aWhereClause"] = aWhereClause;
                    TReflectionClient.ExecuteMethod(mSvrObjNm, "GetDataSource", ref lStrIdxArr, ref lRtrnVal);
                }
            }
            catch(Exception)
            {
                throw;
            }
            return lRtrnVal;
        }
        public int GetDataSourceCount(string aRowSource, string aWhereClause)
        {
            int lRtrnVal = 0;
            try
            {
                if (TAppSettings.ClientMode == ClientModes.ThickClient)
                {
                    TDomain.Count(Utilities.TGC.PKeyName,aRowSource,aWhereClause,out lRtrnVal);
                    //TDataObject lDataObject = new TDataObject();
                    //lDataObject.OpenTable("SELECT COUNT("+Utilities.TGC.PKeyName+") " + aRowSource + ".* FROM " + aRowSource + " " + aWhereClause);
                    //lRtrnVal = lDataObject.Ds.Tables[0].;
                }
                else
                {
                    TStrIdxArr lStrIdxArr = new TStrIdxArr();
                    
                    lStrIdxArr["aRowSource"] = aRowSource;
                    lStrIdxArr["aWhereClause"] = aWhereClause;
                    TReflectionClient.ExecuteMethod(mSvrObjNm, "GetDataSourceCount", ref lStrIdxArr, ref lRtrnVal);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return lRtrnVal;
        }
        #endregion
    }
}
