using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace Innotelli.BO
{
    public class TDataRight
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        #endregion

        #region Properties
        private bool mAllowRead = true;
        public bool AllowRead
        {
            get
            {
                return mAllowRead;
            }
            set
            {
                mAllowRead = value;
            }
        }
        private bool mAllowEdit = true;
        public bool AllowEdit
        {
            get 
            { 
                return mAllowEdit; 
            }
            set 
            { 
                mAllowEdit = value;
            }
        }
        private bool mAllowAdd = true;
        public bool AllowAdd
        {
            get
            {
                return mAllowAdd;
            }
            set
            {
                mAllowAdd = value;
            }
        }
        private bool mAllowDelete = true;
        public bool AllowDelete
        {
            get
            {
                return mAllowDelete;
            }
            set
            {
                mAllowDelete = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}
