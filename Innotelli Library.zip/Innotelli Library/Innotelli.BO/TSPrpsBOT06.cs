﻿using System;
using System.Data;
using Innotelli.Db;

namespace Innotelli.BO
{
    public class TSPrpsBOT06
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TSPrpsBOT06(TDataRow aDr)
        {
            mDr = aDr;
            mBOID = BOT06ID;
            mSPrpsBOT06Flds = new TSPrpsBOT06Flds(mBOID);
        }
        #endregion

        #region Properties
        private string mBOID = string.Empty;
        public string BOID
        {
            get
            {
                return mBOID;
            }
        }
        private TDataRow mDr = null;
        public TDataRow Dr
        {
            get
            {
                return mDr;
            }
        }
        private TSPrpsBOT06Flds mSPrpsBOT06Flds = null;
        public TSPrpsBOT06Flds SPrpsBOT06Flds
        {
            get
            {
                return mSPrpsBOT06Flds;
            }
        }
        public string BOT06ID
        {
            get
            {
                return Dr["BOT06ID"].ToString();
            }
        }
        public string prmykey
        {
            get
            {
                return Dr["prmykey"].ToString();
            }
        }
        public string BONameSpace
        {
            get
            {
                return (string)mDr["BONameSpace"];
            }
        }
        public string UINameSpace
        {
            get
            {
                return (string)mDr["UINameSpace"];
            }
        }
        public string FullBOClassName
        {
            get
            {
                return (string)mDr["FullBOClassName"];
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}

