﻿using System.Collections;
using System.Data;

namespace Innotelli.BO
{
    public class TSPrpsBOT01LookUpColumns
    {
        #region Enums
        #endregion

        #region Members
        private string mBOID = string.Empty;
        private DataTable mDt = null;
        private Hashtable[] mSPrpsBOT01LookUpColumnHTs = null;
        public object mLocker = new object();
        #endregion

        #region Constructors
        public TSPrpsBOT01LookUpColumns(string aBOID)
        {
            DataView lDv = new DataView();

            mBOID = aBOID;
            mSPrpsBOT01LookUpColumnHTs = new Hashtable[2];
            mSPrpsBOT01LookUpColumnHTs[0] = new Hashtable();
            mSPrpsBOT01LookUpColumnHTs[1] = new Hashtable();
            lDv.Table = BOT01LookUpColumnDt;
            lDv.RowFilter = "BOT01ID =  '" + mBOID + "'";
            lDv.Sort = "ColumnIndex ASC";
            mDt = lDv.ToTable();
        }
        #endregion

        #region Properties
        private static DataTable mBOT01LookUpColumnDt = null;
        public static DataTable BOT01LookUpColumnDt
        {
            get
            {
                if (mBOT01LookUpColumnDt == null)
                {
                    mBOT01LookUpColumnDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("BOT01LookUpColumn").Tables[0];
                }
                return mBOT01LookUpColumnDt;
            }
        }
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }
        public int Count
        {
            get
            {
                return mDt.Rows.Count;
            }
        }
        public TSPrpsBOT01LookUpColumn this[int aRowIndex]
        {
            get
            {
                TSPrpsBOT01LookUpColumn lReturnValue = null;
                TSPrpsBOT01LookUpColumn lSPrpsBOT01LookUpColumn = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT01LookUpColumnHTs[0][aRowIndex] == null)
                    {
                        mSPrpsBOT01LookUpColumnHTs[0][aRowIndex] = new TSPrpsBOT01LookUpColumn();
                    }
                }
                lSPrpsBOT01LookUpColumn = (TSPrpsBOT01LookUpColumn)mSPrpsBOT01LookUpColumnHTs[0][aRowIndex];
                lSPrpsBOT01LookUpColumn.Dr = mDt.Rows[aRowIndex];
                lReturnValue = lSPrpsBOT01LookUpColumn;

                return lReturnValue;
            }
        }
        public TSPrpsBOT01LookUpColumn this[string aFldNm]
        {
            get
            {
                TSPrpsBOT01LookUpColumn lReturnValue = null;
                TSPrpsBOT01LookUpColumn lSPrpsBOT01LookUpColumn = null;
                DataRow[] lDrs = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT01LookUpColumnHTs[1][aFldNm] == null)
                    {
                        mSPrpsBOT01LookUpColumnHTs[1][aFldNm] = new TSPrpsBOT01LookUpColumn();
                    }
                }
                lSPrpsBOT01LookUpColumn = (TSPrpsBOT01LookUpColumn)mSPrpsBOT01LookUpColumnHTs[1][aFldNm];
                lDrs = mDt.Select("FldNm = '" + aFldNm + "'");
                if (lDrs.Length != 0)
                {
                    lSPrpsBOT01LookUpColumn.Dr = lDrs[0];
                    lReturnValue = lSPrpsBOT01LookUpColumn;
                }

                return lReturnValue;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}
