using System;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.BO
{
	partial class TB01SecurityPermissionAssignDr
	{
		public bool PermissionAllow
		{
			get
			{
				return (bool)Dr["PermissionAllow"];
			}
			set
			{
				Dr["PermissionAllow"] = value;
			}
		}
		public Guid? PermissionGUID
		{
			get
			{
				return (Guid?)Dr["PermissionGUID"];
			}
			set
			{
				Dr["PermissionGUID"] = value;
			}
		}
		public TDbRowID slkGroup
		{
			get
			{
				return (int?)Dr["slkGroup"];
			}
			set
			{
				Dr["slkGroup"] = value;
			}
		}
	}
}

