using System;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.BO
{
	partial class TB01SecurityGroupDr
	{
		public string Description
		{
			get
			{
				return (string)Dr["Description"];
			}
			set
			{
				Dr["Description"] = value;
			}
		}
		public Guid? GroupGUID
		{
			get
			{
				return (Guid?)Dr["GroupGUID"];
			}
			set
			{
				Dr["GroupGUID"] = value;
			}
		}
		public string GroupName
		{
			get
			{
				return (string)Dr["GroupName"];
			}
			set
			{
				Dr["GroupName"] = value;
			}
		}
	}
}

