using System;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.BO
{
	partial class TB01SecurityGroupAssignDr
	{
		public string UserName
		{
			get
			{
				return (string)Dr["UserName"];
			}
		}
		public TDbRowID slkGroup
		{
			get
			{
				return (int?)Dr["slkGroup"];
			}
			set
			{
				Dr["slkGroup"] = value;
			}
		}
		public TDbRowID slkUser
		{
			get
			{
				return (int?)Dr["slkUser"];
			}
			set
			{
				Dr["slkUser"] = value;
			}
		}
		public string GroupName
		{
			get
			{
				return (string)Dr["GroupName"];
			}
		}
		public string UserDescription
		{
			get
			{
				return (string)Dr["UserDescription"];
			}
		}
		public string GroupDescription
		{
			get
			{
				return (string)Dr["GroupDescription"];
			}
		}
	}
}

