using System;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.BO
{
	partial class TB01SecurityUserDr
	{
		public string Description
		{
			get
			{
				return (string)Dr["Description"];
			}
			set
			{
				Dr["Description"] = value;
			}
		}
		public string Initial
		{
			get
			{
				return (string)Dr["Initial"];
			}
			set
			{
				Dr["Initial"] = value;
			}
		}
		public string Password
		{
			get
			{
				return (string)Dr["Password"];
			}
			set
			{
				Dr["Password"] = value;
			}
		}
		public Guid? UserGUID
		{
			get
			{
				return (Guid?)Dr["UserGUID"];
			}
			set
			{
				Dr["UserGUID"] = value;
			}
		}
		public string UserName
		{
			get
			{
				return (string)Dr["UserName"];
			}
			set
			{
				Dr["UserName"] = value;
			}
		}
	}
}

