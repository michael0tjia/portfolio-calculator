using System;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.BO
{
	public partial class TB01SecurityUserDr : TBOT01Dr
	{
	}
}

