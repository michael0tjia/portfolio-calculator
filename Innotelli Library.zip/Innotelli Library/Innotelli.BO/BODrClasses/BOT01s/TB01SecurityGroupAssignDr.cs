using System;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.BO
{
	public partial class TB01SecurityGroupAssignDr : TBOT01Dr
	{
	}
}

