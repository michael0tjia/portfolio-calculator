﻿using System.Collections;
using System.Data;
using Innotelli.Db;

namespace Innotelli.BO
{
    public class TSPrpsBOT04ImprtFlds
    {
        #region Enums
        #endregion

        #region Members
        private string mBOID = string.Empty;
        private DataTable mDt = null;
        private Hashtable[] mSPrpsBOT04ImprtFldHTs = null;
        public object mLocker = new object();
        #endregion

        #region Constructors
        public TSPrpsBOT04ImprtFlds(string aBOID)
        {
            DataView lDv = new DataView();

            mBOID = aBOID;
            mSPrpsBOT04ImprtFldHTs = new Hashtable[2];
            mSPrpsBOT04ImprtFldHTs[0] = new Hashtable();
            mSPrpsBOT04ImprtFldHTs[1] = new Hashtable();
            lDv.Table = BOT04ImprtFldDt;
            lDv.RowFilter = "BOT04ID =  '" + mBOID + "'";
            mDt = lDv.ToTable();
        }
        #endregion

        #region Properties
        private static DataTable mBOT04ImprtFldDt = null;
        public static DataTable BOT04ImprtFldDt
        {
            get
            {
                if (mBOT04ImprtFldDt == null)
                {
                    mBOT04ImprtFldDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("BOT04ImprtFld").Tables[0];
                }
                return mBOT04ImprtFldDt;
            }
        }
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }
        public int Count
        {
            get
            {
                return mDt.Rows.Count;
            }
        }
        public TSPrpsBOT04ImprtFld this[int aRowIndex]
        {
            get
            {
                TSPrpsBOT04ImprtFld lReturnValue = null;
                TSPrpsBOT04ImprtFld lSPrpsBOT04ImprtFld = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT04ImprtFldHTs[0][aRowIndex] == null)
                    {
                        mSPrpsBOT04ImprtFldHTs[0][aRowIndex] = new TSPrpsBOT04ImprtFld();
                    }
                }
                lSPrpsBOT04ImprtFld = (TSPrpsBOT04ImprtFld)mSPrpsBOT04ImprtFldHTs[0][aRowIndex];
                lSPrpsBOT04ImprtFld.Dr = mDt.Rows[aRowIndex];
                lReturnValue = lSPrpsBOT04ImprtFld;

                return lReturnValue;
            }
        }
        public TSPrpsBOT04ImprtFld this[string aFldNm]
        {
            get
            {
                TSPrpsBOT04ImprtFld lReturnValue = null;
                TSPrpsBOT04ImprtFld lSPrpsBOT04ImprtFld = null;
                DataRow[] lDrs = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT04ImprtFldHTs[1][aFldNm] == null)
                    {
                        mSPrpsBOT04ImprtFldHTs[1][aFldNm] = new TSPrpsBOT04ImprtFld();
                    }
                }
                lSPrpsBOT04ImprtFld = (TSPrpsBOT04ImprtFld)mSPrpsBOT04ImprtFldHTs[1][aFldNm];
                lDrs = mDt.Select("FldNm = '" + aFldNm + "'");
                if (lDrs.Length != 0)
                {
                    lSPrpsBOT04ImprtFld.Dr = lDrs[0];
                    lReturnValue = lSPrpsBOT04ImprtFld;
                }

                return lReturnValue;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}
