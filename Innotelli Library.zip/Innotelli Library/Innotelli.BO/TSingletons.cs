using System.Data;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public static class TSingletons
    {
        #region Constructors
        static TSingletons()
        {
        }
        #endregion

        #region Properties
        private static bool mInitialized = false;
        public static bool Initialized
        {
            get
            {
                return mInitialized;
            }
            set
            {
                mInitialized = value;
            }
        }
        private static TLookUpListProxy mLookUpListProxy = null;
        public static TLookUpListProxy LookUpListProxy
        {
            get
            {
                return mLookUpListProxy;
            }
        }
        private static TSPrpsTbls mSPrpsTbls = null;
        public static TSPrpsTbls SPrpsTbls
        {
            get
            {
                return mSPrpsTbls;
            }
        }
        private static TSPrpsBOT01s mSPrpsBOT01s = null;
        public static TSPrpsBOT01s SPrpsBOT01s
        {
            get
            {
                return mSPrpsBOT01s;
            }
        }
        private static TSPrpsBOT03s mSPrpsBOT03s = null;
        public static TSPrpsBOT03s SPrpsBOT03s
        {
            get
            {
                return mSPrpsBOT03s;
            }
        }
        private static TSPrpsBOT04s mSPrpsBOT04s = null;
        public static TSPrpsBOT04s SPrpsBOT04s
        {
            get
            {
                return mSPrpsBOT04s;
            }
        }
        private static TSPrpsBOT06s mSPrpsBOT06s = null;
        public static TSPrpsBOT06s SPrpsBOT06s
        {
            get
            {
                return mSPrpsBOT06s;
            }
        }
        private static TSPrpsValLsts mSPrpsValLsts = null;
        public static TSPrpsValLsts SPrpsValLsts
        {
            get
            {
                return mSPrpsValLsts;
            }
        }
        private static DataSet mBOT01FldCpFldDs = null;
        public static DataSet BOT01FldCpFldDs
        {
            get
            {
                if (mBOT01FldCpFldDs == null)
                {
                    mBOT01FldCpFldDs = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("BOT01FldCpFld");
                }
                return mBOT01FldCpFldDs;
            }
        }
        private static DataSet mBOT01FldValLstDs = null;
        public static DataSet BOT01FldValLstDs
        {
            get
            {
                if (mBOT01FldValLstDs == null)
                {
                    mBOT01FldValLstDs = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("BOT01FldValLst");
                }
                return mBOT01FldValLstDs;
            }
        }
        private static TMetaSimpleDataTypes mMetaSimpleDataTypes = null;
        public static TMetaSimpleDataTypes MetaSimpleDataTypes
        {
            get
            {
                return mMetaSimpleDataTypes;
            }
        }
        private static TMetaSecurityPermissions mMetaSecurityPermissions = null;
        public static TMetaSecurityPermissions MetaSecurityPermissions
        {
            get
            {
                return mMetaSecurityPermissions;
            }
        }
        #endregion

        #region Functions
        public static void Init()
        {
            // META Data is preloaded. Prevent multi-thread locking issue.
            mSPrpsTbls = new TSPrpsTbls();
            mSPrpsBOT01s = new TSPrpsBOT01s();
            mSPrpsBOT03s = new TSPrpsBOT03s();
            mSPrpsBOT04s = new TSPrpsBOT04s();
            mSPrpsBOT06s = new TSPrpsBOT06s();
            mSPrpsValLsts = new TSPrpsValLsts();
            mMetaSimpleDataTypes = new TMetaSimpleDataTypes();
            mMetaSecurityPermissions = new TMetaSecurityPermissions();
            if (TAppSettings.ClientMode != ClientModes.ObjectServer)
            {
                mLookUpListProxy = new TLookUpListProxy();
            }            
            mInitialized = true;
        }
        #endregion
    }
}
