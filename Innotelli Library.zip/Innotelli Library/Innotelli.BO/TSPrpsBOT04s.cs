﻿using System.Collections;
using System.Data;

namespace Innotelli.BO
{
    public class TSPrpsBOT04s
    {
        #region Enums
        #endregion

        #region Members
        private DataTable mDt = null;
        private Hashtable[] mSPrpsBOT04HTs = null;
        public object mLocker = new object();
        #endregion

        #region Constructors
        public TSPrpsBOT04s()
        {
            mSPrpsBOT04HTs = new Hashtable[2];
            mSPrpsBOT04HTs[0] = new Hashtable();
            mSPrpsBOT04HTs[1] = new Hashtable();
            mDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("BOT04").Tables[0];
        }
        #endregion

        #region Properties
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }
        public int Count
        {
            get
            {
                return mDt.Rows.Count;
            }
        }
        public TSPrpsBOT04 this[int aRowIndex]
        {
            get
            {
                TSPrpsBOT04 lRtrnVal = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT04HTs[0][aRowIndex] == null)
                    {
                        mSPrpsBOT04HTs[0][aRowIndex] = new TSPrpsBOT04(mDt.Rows[aRowIndex]);
                        lRtrnVal = (TSPrpsBOT04)mSPrpsBOT04HTs[0][aRowIndex];
                    }
                    else
                    {
                        lRtrnVal = (TSPrpsBOT04)mSPrpsBOT04HTs[0][aRowIndex];
                        lRtrnVal.Dr = mDt.Rows[aRowIndex];
                    }
                }
                return lRtrnVal;
            }
        }
        public TSPrpsBOT04 this[string aBOID]
        {
            get
            {
                TSPrpsBOT04 lRtrnVal = null;
                DataRow[] lDrs = null;

                lock (mLocker)
                {
                    lDrs = mDt.Select("BOT04ID = '" + aBOID + "'");
                    if (lDrs.Length != 0)
                    {
                        if (mSPrpsBOT04HTs[1][aBOID] == null)
                        {
                            mSPrpsBOT04HTs[1][aBOID] = new TSPrpsBOT04(lDrs[0]);
                            lRtrnVal = (TSPrpsBOT04)mSPrpsBOT04HTs[1][aBOID];
                        }
                        else
                        {
                            lRtrnVal = (TSPrpsBOT04)mSPrpsBOT04HTs[1][aBOID];
                            lRtrnVal.Dr = lDrs[0];
                        }
                    }
                }

                return lRtrnVal;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}