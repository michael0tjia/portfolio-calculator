﻿using System.Collections;
using System.Data;

namespace Innotelli.BO
{
    public class TSPrpsBOT01FindCols
    {
        #region Enums
        #endregion

        #region Members
        private string mBOID = string.Empty;
        private DataTable mDt = null;
        private Hashtable[] mSPrpsBOT01FindColHTs = null;
        public object mLocker = new object();
        #endregion

        #region Constructors
        public TSPrpsBOT01FindCols(string aBOID)
        {
            DataView lDv = new DataView();

            mBOID = aBOID;
            mSPrpsBOT01FindColHTs = new Hashtable[2];
            mSPrpsBOT01FindColHTs[0] = new Hashtable();
            mSPrpsBOT01FindColHTs[1] = new Hashtable();
            lDv.Table = BOT01FindColDt;
            lDv.RowFilter = "BOT01ID =  '" + mBOID + "'";
            lDv.Sort = "ColNo ASC";
            mDt = lDv.ToTable();
        }
        #endregion

        #region Properties
        private static DataTable mBOT01FindColDt = null;
        public static DataTable BOT01FindColDt
        {
            get
            {
                if (mBOT01FindColDt == null)
                {
                    mBOT01FindColDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("BOT01FindCol").Tables[0];
                }
                return mBOT01FindColDt;
            }
        }
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }
        public int Count
        {
            get
            {
                return mDt.Rows.Count;
            }
        }
        public TSPrpsBOT01FindCol this[int aRowIndex]
        {
            get
            {
                TSPrpsBOT01FindCol lReturnValue = null;
                TSPrpsBOT01FindCol lSPrpsBOT01FindCol = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT01FindColHTs[0][aRowIndex] == null)
                    {
                        mSPrpsBOT01FindColHTs[0][aRowIndex] = new TSPrpsBOT01FindCol();
                    }
                }
                lSPrpsBOT01FindCol = (TSPrpsBOT01FindCol)mSPrpsBOT01FindColHTs[0][aRowIndex];
                lSPrpsBOT01FindCol.Dr = mDt.Rows[aRowIndex];
                lReturnValue = lSPrpsBOT01FindCol;

                return lReturnValue;
            }
        }
        public TSPrpsBOT01FindCol this[string aFldNm]
        {
            get
            {
                TSPrpsBOT01FindCol lReturnValue = null;
                TSPrpsBOT01FindCol lSPrpsBOT01FindCol = null;
                DataRow[] lDrs = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT01FindColHTs[1][aFldNm] == null)
                    {
                        mSPrpsBOT01FindColHTs[1][aFldNm] = new TSPrpsBOT01FindCol();
                    }
                }
                lSPrpsBOT01FindCol = (TSPrpsBOT01FindCol)mSPrpsBOT01FindColHTs[1][aFldNm];
                lDrs = mDt.Select("FldNm = '" + aFldNm + "'");
                if (lDrs.Length != 0)
                {
                    lSPrpsBOT01FindCol.Dr = lDrs[0];
                    lReturnValue = lSPrpsBOT01FindCol;
                }

                return lReturnValue;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}
