using System;
using System.Collections;
using System.Data;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public abstract class TBOT04 : TBOBaseT01
    {
        #region Members
        #region OldCode
        private bool mInDoFieldDependency = false;
        private ArrayList mCalColumnCollection = null;
        #endregion
        private TSysDataRdr mSysDataRdr = Innotelli.Utilities.TSingletons.SysData01Rdr;
        #endregion

        #region Constructors
        public TBOT04()
        {
        }
        #endregion

        #region Properties

        #region OldCode
        public bool InDoFieldDependency
        {
            get
            {
                return mInDoFieldDependency;
            }
            set
            {
                mInDoFieldDependency = value;
            }
        }
        public ArrayList CalColumnCollection
        {
            get
            {
                return mCalColumnCollection;
            }
            set
            {
                mCalColumnCollection = value;
            }
        }
        #endregion

        public TSPrpsBOT04 SPrps
        {
            get
            {
                return Innotelli.BO.TSingletons.SPrpsBOT04s[BOID];
            }
        }

        public string DefaultViewName
        {
            get
            {
                return "A_" + BOID + "_DefaultView";
            }
        }
        private string mLoadDataFilter = string.Empty;
        public string LoadDataFilter
        {
            get
            {
                return mLoadDataFilter;
            }
            set
            {
                mLoadDataFilter = value;
            }
        }
        private string mProcessRowFilter = string.Empty;
        public string ProcessRowFilter
        {
            get
            {
                return mProcessRowFilter;
            }
            set
            {
                mProcessRowFilter = value;
            }
        }
        #endregion

        #region Functions
        #region OldCode
        protected override void AssignDtEventHandlers()
        {
            base.AssignDtEventHandlers();
            Dt.ColumnChanged += new DataColumnChangeEventHandler(Dt_ColumnChanged);
        }
        public virtual void Dt_ColumnChanged(object sender, DataColumnChangeEventArgs e)
        {
            DataRow lDr = null;

            if (!InDoFieldDependency)
            {
                lDr = e.Row;
                if (lDr[e.Column.ColumnName, DataRowVersion.Current] != e.ProposedValue) //if (!((lDr[e.Column] == null) && (e.ProposedValue == null)))
                {
                    InDoFieldDependency = true;
                    DoFieldDependency(e);
                    CalAllColumnValues();
                    e.Row.EndEdit();
                    InDoFieldDependency = false;
                }
            }
        }
        public virtual void AddDataColumns()
        {
            mCalColumnCollection = new ArrayList();
        }
        public void AddDataColumn(string aColumnName, Type aType)
        {
            Dt.Columns.Add(aColumnName, aType);
            mCalColumnCollection.Add(aColumnName);
        }
        public void AddDataColumn(string aColumnName, Type aType, string aExpression)
        {
            Dt.Columns.Add(aColumnName, aType, aExpression);
            mCalColumnCollection.Add(aColumnName);
        }

        public virtual void CalAllColumnValues()
        {
        }
        public virtual void DoFieldDependency(DataColumnChangeEventArgs e)
        {
        }
        public bool IsTempCol(string aFldNm, string aBOT04ID)
        {
            bool lReturnValue = false;
            DataSet lDs = new DataSet();
            DataRow[] lDataRowsFound;
            string lExp = "";

            lExp = "BOT04ID = '" + aBOT04ID + "' and FldNm = '" + aFldNm + "'";

            lDs = mSysDataRdr.GetSysData("BOT04Fld");

            lDataRowsFound = lDs.Tables[0].Select(lExp);
            if (lDataRowsFound.Length != 0)
            {
                if (lDataRowsFound[0]["Cat4"].ToString() == "Temp")
                {
                    lReturnValue = true;
                }
            }

            return lReturnValue;
        }
        public void RemoveColumn(string aColumn)
        {
            //TODO: Michael Follow
            Dt.Columns.Remove(aColumn);
        }
        public bool RemoveCalColumns()
        {
            bool lReturnValue = false;

            lReturnValue = RemoveColumns(mCalColumnCollection);
            return lReturnValue;
        }
        public bool RemoveColumns(ArrayList aCalColumnCollection)
        {
            if (aCalColumnCollection != null)
            {
                for (int i = 0; i < aCalColumnCollection.Count; i++)
                {
                    //TODO: Michael
                    //Dt.Columns.Remove(aCalColumnCollection[i].ToString());
                }
            }

            return true;
        }
        #endregion

        public virtual void LoadDataSet()
        {
            DataTable lDt = mSysDataRdr.GetSysData("BOT04ImprtFld").Tables[0];
            DataColumn lDc;

            lDt.DefaultView.RowFilter = "BOT04ID = '" + BOID + "'";

            Dao.SQL.Stmt = "SELECT * FROM " + DefaultViewName;
            if (!string.IsNullOrEmpty(LoadDataFilter))
            {
                Dao.SQL.AddToWhereClause(LoadDataFilter);
            }
            Dao.OpenTable();
            Dao.Dt.TableName = BOID;
            foreach (DataRowView lDrv in lDt.DefaultView)
            {

                if (lDrv["DotNETFldType"] != DBNull.Value && lDrv["DftVal"] != DBNull.Value)
                {
                    switch (lDrv["DotNETFldType"].ToString())
                    {
                        case "bool":
                            lDc = Dao.Dt.Columns.Add(lDrv["FldNm"].ToString(), typeof(bool));
                            foreach (DataRow lDr in Dao.Dt.Rows)
                            {
                                lDr[lDrv["FldNm"].ToString()] = Convert.ToBoolean(lDrv["DftVal"]);
                            }
                            break;
                        case "double":
                            lDc = Dao.Dt.Columns.Add(lDrv["FldNm"].ToString(), typeof(double));
                            foreach (DataRow lDr in Dao.Dt.Rows)
                            {
                                lDr[lDrv["FldNm"].ToString()] = Convert.ToDouble(lDrv["DftVal"]);
                            }
                            break;
                        case "decimal":
                            lDc = Dao.Dt.Columns.Add(lDrv["FldNm"].ToString(), typeof(decimal));
                            foreach (DataRow lDr in Dao.Dt.Rows)
                            {
                                lDr[lDrv["FldNm"].ToString()] = Convert.ToDecimal(lDrv["DftVal"]);
                            }
                            break;
                        case "DateTime":
                            lDc = Dao.Dt.Columns.Add(lDrv["FldNm"].ToString(), typeof(DateTime));
                            foreach (DataRow lDr in Dao.Dt.Rows)
                            {
                                lDr[lDrv["FldNm"].ToString()] = Convert.ToDateTime(lDrv["DftVal"]);
                            }
                            break;
                        case "int":
                            lDc = Dao.Dt.Columns.Add(lDrv["FldNm"].ToString(), typeof(int));
                            foreach (DataRow lDr in Dao.Dt.Rows)
                            {
                                lDr[lDrv["FldNm"].ToString()] = Convert.ToInt32(lDrv["DftVal"]);
                            }
                            break;
                        case "string":
                            lDc = Dao.Dt.Columns.Add(lDrv["FldNm"].ToString(), typeof(string));
                            foreach (DataRow lDr in Dao.Dt.Rows)
                            {
                                lDr[lDrv["FldNm"].ToString()] = Convert.ToString(lDrv["DftVal"]);
                            }
                            break;
                    }
                }
            }
            AddDataColumns();
            AssignDtEventHandlers();
        }
        private string[] GetFilterColumnList()
        {
            DataTable lDt = mSysDataRdr.GetSysData("BOT04ImprtFld").Tables[0];
            string[] lReturnValue = null;
            int i = 1;

            lDt.DefaultView.RowFilter = "BOT04ID = '" + BOID + "'";

            lReturnValue = new string[lDt.DefaultView.Count + 1];
            lReturnValue[0] = "linkkey";


            foreach (DataRowView lDrv in lDt.DefaultView)
            {
                lReturnValue[i] = lDrv["FldNm"].ToString();
                i++;
            }
            return lReturnValue;
        }
        public DataSet GetToBeProcessedDataSet()
        {
            DataSet lReturnValue = new DataSet();
            string[] lColumnNames = null;

            DefaultView.RowFilter = mProcessRowFilter;
            lColumnNames = GetFilterColumnList();
            lReturnValue.Tables.Add(DefaultView.ToTable(BOID, false, lColumnNames));

            return lReturnValue;
        }
        public void SetAllIsSelVals(bool aVal)
        {
            int lCurrentRowIndex = 0;

            if (Dt != null)
            {
                if (!IsNoRow())
                {
                    lCurrentRowIndex = CurrentRowIndex;
                    MoveFirst();
                    while (!EOF())
                    {
                        Dr["IsSel"] = aVal;
                        MoveNext();
                    }
                    CurrentRowIndex = lCurrentRowIndex;
                }
            }
        }
        #endregion
    }
}