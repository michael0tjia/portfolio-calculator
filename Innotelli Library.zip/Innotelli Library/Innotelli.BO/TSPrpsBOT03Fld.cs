﻿using System;
using System.ComponentModel;
using System.Data;
using Innotelli.Utilities;
using Innotelli.Db;

namespace Innotelli.BO
{
    public class TSPrpsBOT03Fld
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        #endregion

        #region Properties
        private TDataRow mDr;
        public TDataRow Dr
        {
            get
            {
                return mDr;
            }
            set
            {
                mDr = value;
            }
        }

        #region Generated Properties
        public double? Sort
        {
            get
            {
                return (double?)Dr["Sort"];
            }
            set
            {
                Dr["Sort"] = value;
            }
        }
        public string FldNm
        {
            get
            {
                return (string)Dr["FldNm"];
            }
            set
            {
                Dr["FldNm"] = value;
            }
        }
        public string FldAls
        {
            get
            {
                return (string)Dr["FldAls"];
            }
            set
            {
                Dr["FldAls"] = value;
            }
        }
        public string SelObjID
        {
            get
            {
                return (string)Dr["SelObjID"];
            }
            set
            {
                Dr["SelObjID"] = value;
            }
        }
        public int? FldSize
        {
            get
            {
                return (int?)Dr["FldSize"];
            }
            set
            {
                Dr["FldSize"] = value;
            }
        }
        public bool Required
        {
            get
            {
                return (bool)Dr["Required"];
            }
            set
            {
                Dr["Required"] = value;
            }
        }
        #endregion

        public SimpleDataType SimpleDataType
        {
            get
            {
                return (SimpleDataType)(Dr["slkFldType"]);
            }
        }
        public SimpleDataTypeCat1s SimpleDataTypeCat1
        {
            get
            {
                return TSimpleDataType.GetCat1(SimpleDataType);
            }
        }

        public bool IsNumeric
        {
            get
            {
                bool lReturnValue = false;

                switch (SimpleDataTypeCat1)
                {
                    case SimpleDataTypeCat1s.Integer:
                    case SimpleDataTypeCat1s.PreciseReal:
                    case SimpleDataTypeCat1s.UnpreciseReal:
                        lReturnValue = true;
                        break;
                    default:
                        lReturnValue = false;
                        break;
                }

                return lReturnValue;
            }
        }
        public bool IsDateTime
        {
            get
            {
                return (SimpleDataTypeCat1 == SimpleDataTypeCat1s.DateTime);
            }
        }

        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion

    }
}

