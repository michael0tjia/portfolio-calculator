﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Innotelli.Db;

namespace Innotelli.BO
{
    public class TBOT01Rows<T> where T : TBOT01Dr, new()
    {       
        #region Members
        private Dictionary<int, T> mBOT01DrsDict = new Dictionary<int, T>();
        private TBOT01 mBOT01 = null;
        #endregion

        #region Constructors
        public TBOT01Rows(TBOT01 aBOT01)
        {
            mBOT01 = aBOT01;
        }
        #endregion

        #region Properties
        
        public int Count
        {
            get 
            {
                return mBOT01.DefaultView.Count; 
            }
        }
        #endregion

        #region Functions
        public T this[int aRowIndex]
        {
            get
            {
                T lReturnValue = default(T);

                if (!mBOT01DrsDict.TryGetValue(aRowIndex, out lReturnValue))
                {
                    mBOT01DrsDict.Add(aRowIndex, new T());
                    lReturnValue = (T)mBOT01DrsDict[aRowIndex];
                }
                if (aRowIndex == TDataObject.DetachedRowIndex)
                {
                    lReturnValue.Dr = mBOT01.DetachedDataRow;
                }
                else
                {
                    lReturnValue.Dr = mBOT01.DefaultView[aRowIndex].Row;
                }

                return lReturnValue;
            }
        } 

        #endregion
    }
}
