﻿using System;
using System.Data;
using Innotelli.Utilities;
using Innotelli.Db;

namespace Innotelli.BO
{
    public class TMetaSimpleDataType
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TMetaSimpleDataType(TDataRow aDr)
        {
            mDr = aDr;
        }
        #endregion

        #region Properties
        public string SimpleDataTypeID
        {
            get
            {
                return FldTypeID;
            }
        }
        private TDataRow mDr = null;
        public TDataRow Dr
        {
            set
            {
                mDr = value;
            }
        }

        #region System Generated
        public string FldTypeID
        {
            get
            {
                return (string)mDr["FldTypeID"];
            }
        }
        public bool Complex
        {
            get
            {
                return (bool)mDr["Complex"];
            }
            set
            {
                mDr["Complex"] = value;
            }
        }
        public string Dscp
        {
            get
            {
                return (string)mDr["Dscp"];
            }
            set
            {
                mDr["Dscp"] = value;
            }
        }
        public TDbRowID slkCat1
        {
            get
            {
                return (int?)mDr["slkCat1"];
            }
            set
            {
                mDr["slkCat1"] = value;
            }
        }
        public string SQLFldType
        {
            get
            {
                return (string)mDr["SQLFldType"];
            }
            set
            {
                mDr["SQLFldType"] = value;
            }
        }
        public string AccFldType
        {
            get
            {
                return (string)mDr["AccFldType"];
            }
            set
            {
                mDr["AccFldType"] = value;
            }
        }
        public string DotNETFldType
        {
            get
            {
                return (string)mDr["DotNETFldType"];
            }
            set
            {
                mDr["DotNETFldType"] = value;
            }
        }
        public string DotNETNullableType
        {
            get
            {
                return (string)mDr["DotNETNullableType"];
            }
            set
            {
                mDr["DotNETNullableType"] = value;
            }
        }
        public byte? Precision
        {
            get
            {
                return (byte?)mDr["Precision"];
            }
            set
            {
                mDr["Precision"] = value;
            }
        }
        public byte? Scale
        {
            get
            {
                return (byte?)mDr["Scale"];
            }
            set
            {
                mDr["Scale"] = value;
            }
        }
        public string Comment
        {
            get
            {
                return (string)mDr["Comment"];
            }
            set
            {
                mDr["Comment"] = value;
            }
        }
        public string Notes
        {
            get
            {
                return (string)mDr["Notes"];
            }
            set
            {
                mDr["Notes"] = value;
            }
        }
        public string DisplayFormat
        {
            get
            {
                return (string)mDr["DisplayFormat"];
            }
            set
            {
                mDr["DisplayFormat"] = value;
            }
        }
        public string EditFormat
        {
            get
            {
                return (string)mDr["EditFormat"];
            }
            set
            {
                mDr["EditFormat"] = value;
            }
        }
        #endregion

        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}

