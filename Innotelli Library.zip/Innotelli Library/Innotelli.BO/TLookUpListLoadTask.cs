using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public class TLookUpListLoadTask : TThreadWrapperBase
    {
        #region Enums
        #endregion

        #region Members
        TLookUpListProxy mLookUpListProxy = Innotelli.BO.TSingletons.LookUpListProxy;
        #endregion

        #region Constructors
        public TLookUpListLoadTask()
        {
            SupportsProgress = true;
            CancelWaitTime = TimeSpan.FromSeconds(5);
        }
        #endregion

        #region Properties
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        protected override void DoTask()
        {
            string lBOID = string.Empty;
            DataView lBODv = null;
            int lLoadCacheOffset = 0;

            lBODv = mLookUpListProxy.BODv;

            lLoadCacheOffset = 50;
            for (int i = 0; i < mLookUpListProxy.BODv.Count; i++)
            {
                lBOID = lBODv[i]["BOT01ID"].ToString();
                mLookUpListProxy.LoadCacheFromSysDataForOneBO(lBOID);
                Progress = (int)Math.Round((decimal)i / lBODv.Count * (lLoadCacheOffset), 0, MidpointRounding.AwayFromZero);
            }
            for (int i = 0; i < mLookUpListProxy.BODv.Count; i++)
            {
                lBOID = lBODv[i]["BOT01ID"].ToString();
                mLookUpListProxy.UpdateCacheForOneBO(lBOID);
                Progress = lLoadCacheOffset + (int)Math.Round((decimal)i / lBODv.Count * (100 - lLoadCacheOffset), 0, MidpointRounding.AwayFromZero);
            }
        }
        #endregion
    }
}
