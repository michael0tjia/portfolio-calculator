using System;
using System.Data;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public abstract class TBOT06 : TBOBaseT01
    {
        #region Members
        private bool mInDoFieldDependency = false;
        private TSysDataRdr mSysDataRdr = Innotelli.Utilities.TSingletons.SysData01Rdr;

        private string[] mCalColumnCollection = null;
        private bool mIsValueChanged = false;
        #endregion

        #region Constructors
        public TBOT06()
        {
        }
        #endregion

        #region Properties
        public TSPrpsBOT06 SPrps
        {
            get
            {
                return Innotelli.BO.TSingletons.SPrpsBOT06s[BOID];
            }
        }
        public bool InDoFieldDependency
        {
            get
            {
                return mInDoFieldDependency;
            }
            set
            {
                mInDoFieldDependency = value;
            }
        }
        public string[] CalColumnCollection
        {
            get
            {
                return mCalColumnCollection;
            }
            set
            {
                mCalColumnCollection = value;
            }
        }
        public bool IsValueChanged
        {
            get
            {
                return mIsValueChanged;
            }
            set
            {
                mIsValueChanged = value;
            }
        }
        #endregion

        #region Functions
        protected override void AssignDtEventHandlers()
        {
            Dt.ColumnChanged += new DataColumnChangeEventHandler(Dt_ColumnChanged);
            Dt.TableNewRow += new DataTableNewRowEventHandler(Dt_TableNewRow);
            Dt.RowDeleted += new DataRowChangeEventHandler(Dt_RowDeleted);
        }
        public void RemoveColumn(string aColumn)
        {
            Dt.Columns.Remove(aColumn);

        }
        public void RemoveColumns(string[] aColumns)
        {
            if (aColumns != null)
            {
                for (int i = 0; i < aColumns.Length; i++)
                {
                    Dt.Columns.Remove(aColumns[i]);
                }
            }
        }
        public void RemoveCalColumns()
        {
            RemoveColumns(mCalColumnCollection);
        }
        public virtual void Dt_TableNewRow(object sender, DataTableNewRowEventArgs e)
        {
            Dt.ColumnChanged -= Dt_ColumnChanged;
            SetCurrentRow(e.Row);
            SetDefaults();
            Dt.ColumnChanged += Dt_ColumnChanged;
        }
        public virtual void Dt_ColumnChanged(object sender, DataColumnChangeEventArgs e)
        {
            bool lDoColDependencyTrigger = false;
            object lNewVal;
            object lOldVal;

            mIsValueChanged = false;
            if (e.Row.RowState == DataRowState.Detached)
            {
                lOldVal = null;
            }
            else
            {
                lOldVal = e.Row[e.Column, DataRowVersion.Current];
            }
            lNewVal = e.ProposedValue;
            lDoColDependencyTrigger = (e.Column.ColumnName != Utilities.TGC.PKeyName) && (e.Column.ColumnName != Utilities.TGC.FKeyName) && !(TNull.IsValueNull(lOldVal) && TNull.IsValueNull(lNewVal));
            if (lDoColDependencyTrigger)
            {
                Dt.ColumnChanged -= Dt_ColumnChanged;
                try
                {
                    DoFieldDependency(e);
                    e.Row.EndEdit();
                }
                catch
                {
                }
                Dt.ColumnChanged += Dt_ColumnChanged;
                mIsValueChanged = true;
            }
        }
        public virtual void Dt_RowDeleted(object sender, DataRowChangeEventArgs e)
        {
        }
        public virtual void SetDefaults()
        {
            TSPrpsBOT06Fld lSPrpsBOT06Fld = null;

            for (int i = 0; i < SPrps.SPrpsBOT06Flds.Count; i++)
            {
                lSPrpsBOT06Fld = SPrps.SPrpsBOT06Flds[i];

                if (lSPrpsBOT06Fld.slkDftValType.HasValue)
                {
                    switch (lSPrpsBOT06Fld.slkDftValType.Value)
                    {
                        case 2: // "Const":
                            if (TStr.Left(lSPrpsBOT06Fld.DftVal, 1) == "\"" && TStr.Right(lSPrpsBOT06Fld.DftVal, 1) == "\"")
                            {
                                Dr[lSPrpsBOT06Fld.FldNm] = TStr.Mid(lSPrpsBOT06Fld.DftVal, 1, lSPrpsBOT06Fld.DftVal.Length - 2);
                            }
                            else
                            {
                                Dr[lSPrpsBOT06Fld.FldNm] = lSPrpsBOT06Fld.DftVal;
                            }
                            break;
                        case 7: //"SysDate":
                            Dr[lSPrpsBOT06Fld.FldNm] = TDtTm.Date(DateTime.Now.Date);
                            break;
                        case 9: //"SysTime":
                            Dr[lSPrpsBOT06Fld.FldNm] = TDtTm.Time(DateTime.Now);
                            break;
                        case 8: //"SysDT":
                            Dr[lSPrpsBOT06Fld.FldNm] = TDtTm.DateTime(DateTime.Now);
                            break;
                        case 12: //"CurUserPK":
                            #region CurUserPK
                            Dr[lSPrpsBOT06Fld.FldNm] = 1;
                            #endregion
                            break;
                        case 3: //"DftTbl":
                            #region Incomplete Later
                            //if ((lDt.Rows[i]["DftTblNm"] != null) && (lDt.Rows[i]["DftFldNm"] != null))
                            //{
                            //    Dr[lDt.Rows[i]["FldNm"].ToString()] = DLookup(lDt.Rows[i]["DftFldNm"],lDt.Rows[i]["DftTblNm"]);
                            //}
                            #endregion
                            break;
                        case 11: //"FncCrncy":
                            #region Incomplete Later
                            //Dr[lDt.Rows[i]["FldNm"].ToString()] = DLookup("slkCrncy", "Optn");
                            #endregion
                            break;
                    }
                }
            }

        }


        public virtual void AddDataColumns()
        {
        }
        public virtual void CalAllColumnValues()
        {
        }
        public virtual void DoFieldDependency(DataColumnChangeEventArgs e)
        {
        }
        #endregion
    }
}