﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public class TSPrpsBOT01FindCol
    {
        private TDataRow mDr;
        public TDataRow Dr
        {
            get
            {
                return mDr;
            }
            set
            {
                mDr = value;
            }
        }

        public short Align
		{
			get
			{
				return short.Parse(Dr["Align"].ToString());
			}
		}
		public bool CanSrch
		{
			get
			{
				return bool.Parse(Dr["CanSrch"].ToString());
			}
		}
        public string Caption
        {
            get
            {
                string lReturnValue = string.Empty;

                switch (Innotelli.Utilities.TAppSettings.SystemLanguage)
                {
                    case SystemLanguages.English:
                        lReturnValue = (string)Dr["Caption"];
                        break;
                    case SystemLanguages.SimplifiedChinese:
                        lReturnValue = (string)Dr["CaptionSCh"];
                        break;
                    case SystemLanguages.TraditionalChinese:
                        lReturnValue = (string)Dr["CaptionTCh"];
                        break;
                }

                return lReturnValue;
            }
        }
        public int ColNo
		{
			get
			{
				return int.Parse(Dr["ColNo"].ToString());
			}
		}
		public DateTime? DCreated
		{
			get
			{
				if (Dr["DCreated"] == null)
				{
					return null;
				}
				return DateTime.Parse(Dr["DCreated"].ToString());
			}
		}
		public DateTime? DModified
		{
			get
			{
				if (Dr["DModified"] == null)
				{
					return null;
				}
				return DateTime.Parse(Dr["DModified"].ToString());
			}
		}
		public string EditUser
		{
			get
			{
				if (Dr["EditUser"] == null)
				{
					return null;
				}
				return Dr["EditUser"].ToString();
			}
		}
		public string FldNm
		{
			get
			{
				if (Dr["FldNm"] == null)
				{
					return null;
				}
				return Dr["FldNm"].ToString();
			}
		}
		public string FldType
		{
			get
			{
				if (Dr["FldType"] == null)
				{
					return null;
				}
				return Dr["FldType"].ToString();
			}
		}
		public string Format
		{
			get
			{
				if (Dr["Format"] == null)
				{
					return null;
				}
				return Dr["Format"].ToString();
			}
		}
		public bool? InEdit
		{
			get
			{
				if (Dr["InEdit"] == null)
				{
					return null;
				}
				return bool.Parse(Dr["InEdit"].ToString());
			}
		}
		public int? Order
		{
			get
			{
				if (Dr["Order"] == null)
				{
					return null;
				}
				return int.Parse(Dr["Order"].ToString());
			}
		}
		public string prmykey
		{
			get
			{
				return Dr["prmykey"].ToString();
			}
		}
		public string prntkey
		{
			get
			{
				return Dr["prntkey"].ToString();
			}
		}
		public string Tag
		{
			get
			{
				if (Dr["Tag"] == null)
				{
					return null;
				}
				return Dr["Tag"].ToString();
			}
		}
		public DateTime? TCreated
		{
			get
			{
				if (Dr["TCreated"] == null)
				{
					return null;
				}
				return DateTime.Parse(Dr["TCreated"].ToString());
			}
		}
		public DateTime? TModified
		{
			get
			{
				if (Dr["TModified"] == null)
				{
					return null;
				}
				return DateTime.Parse(Dr["TModified"].ToString());
			}
		}
		public string UCreated
		{
			get
			{
				if (Dr["UCreated"] == null)
				{
					return null;
				}
				return Dr["UCreated"].ToString();
			}
		}
		public string UModified
		{
			get
			{
				if (Dr["UModified"] == null)
				{
					return null;
				}
				return Dr["UModified"].ToString();
			}
		}
		public bool Visible
		{
			get
			{
				return bool.Parse(Dr["Visible"].ToString());
			}
		}
		public string Width
		{
			get
			{
				return Dr["Width"].ToString();
			}
		}
	}
}
