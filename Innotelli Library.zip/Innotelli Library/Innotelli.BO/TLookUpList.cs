using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public class TLookUpList
    {
        #region Members
        private const string cTimeStampParamName = "@TimeStamp";
        private const string cNewTimeStamp = "NewTimeStamp";
        #endregion

        #region Constructors
        #endregion

        #region Properties
        public string ClassFullName
        {
            get
            {
                return this.GetType().Namespace + "." + this.GetType().Name;
            }
        }
        private string mCnnStr = string.Empty;
        public string CnnStr
        {
            get
            {
                return mCnnStr;
            }
            set
            {
                mCnnStr = value;
            }
        }
        #endregion

        #region Functions
        public DataTable GetList(string aBOID, TRowVersion aRowVersion, ref bool aReplaceWholeList)
        {
            DataTable lReturnValue = null;
            TDbObj lDbObj = null;
            TDataObject lDao = null;
            TSPrc lSPrc = null;

            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                if (string.IsNullOrEmpty(mCnnStr))
                {
                    lDao = new TDataObject();
                    lSPrc = new TSPrc();
                }
                else
                {
                    lDbObj = new TDbObj(mCnnStr);
                    lDao = new TDataObject(lDbObj);
                    lSPrc = new TSPrc(lDbObj);
                }

                lDao.CmdType = CommandType.Text;
                lDao.SQL.Stmt = "SELECT * FROM A_" + aBOID + "_LookUpList WHERE " + Innotelli.Utilities.TGC.TIMESTAMP_FIELD_NAME + " > CAST(" + aRowVersion.Val + " AS TIMESTAMP)";
                lDao.OpenTable();
                if (lDao.Dt.Rows.Count > 100)
                {
                    lDao.CmdType = CommandType.Text;
                    lDao.SQL.Stmt = "SELECT * FROM A_" + aBOID + "_LookUpList";
                    lDao.OpenTable();
                    aReplaceWholeList = true;
                }
                else
                {
                    aReplaceWholeList = false;
                }
                lDao.Dt.TableName = aBOID;
                lDao.Dt.PrimaryKey = new DataColumn[] { lDao.Dt.Columns[Utilities.TGC.PKeyName] };
                if (!lDao.IsNoRow())
                {
                    lSPrc.CmdType = CommandType.Text;
                    lSPrc.CmdText = "SELECT MAX(" + Innotelli.Utilities.TGC.TIMESTAMP_FIELD_NAME  + ") AS NewTimeStamp FROM A_" + aBOID + "_LookUpList";
                    object lObject = lSPrc.ExecuteScalar();
                    aRowVersion.SetValByObj(lObject);
                }
                lReturnValue = lDao.Dt;
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();
                DataSet lDs = new DataSet();

                lReflectionParams["aCnnStr"] = CnnStr;
                lReflectionParams["aBOID"] = aBOID;
                lReflectionParams["aRowVersionVal"] = aRowVersion.Val;
                lReflectionParams["aReplaceWholeList"] = aReplaceWholeList;
                lDs = (DataSet)TReflectionClient.ExecuteMethod(ClassFullName, "WSGetList", lReflectionParams);
                if (lDs.Tables.Count > 0)
                {
                    aRowVersion.Val = (ulong)lReflectionParams["aRowVersionVal"];
                    lReturnValue = lDs.Tables[0];
                    lDs.Tables.Remove(lReturnValue);
                    aReplaceWholeList = (bool)lReflectionParams["aReplaceWholeList"];
                }
            }

            return lReturnValue;
        }
        public DataSet WSGetList(string aCnnStr, string aBOID, ref ulong aRowVersionVal, ref bool aReplaceWholeList)
        {
            DataSet lReturnValue = new DataSet();
            DataTable lDt = null;
            TRowVersion lRowVersion = new TRowVersion(aRowVersionVal);
            
            CnnStr = aCnnStr;
            lDt = GetList(aBOID, lRowVersion, ref aReplaceWholeList);
            if (lDt != null)
            {
                lReturnValue.Tables.Add(lDt);
                aRowVersionVal = lRowVersion.Val;
            }
            return lReturnValue;
        }
        public static TRowVersion GetNewRowVersion(string aBOID, string aCnnStr)
        {
            TRowVersion lReturnValue = new TRowVersion();
            TSPrc lSPrc = new TSPrc(new TDbObj(aCnnStr));

            lSPrc.CmdType = CommandType.Text;
            lSPrc.CmdText = "SELECT MAX(" + Innotelli.Utilities.TGC.TIMESTAMP_FIELD_NAME + ") AS NewTimeStamp FROM A_" + aBOID + "_LookUpList";
            object lObject = lSPrc.ExecuteScalar();
            lReturnValue.SetValByObj(lObject);

            return lReturnValue;
        }
        #endregion
    }    
}