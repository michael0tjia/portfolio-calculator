using System;
using System.Data;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public class TSPrpsBOT01
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TSPrpsBOT01(TDataRow aDr)
        {
            mDr = aDr;
            mBOID = BOT01ID;
            mSPrpsBOT01Flds = new TSPrpsBOT01Flds(mBOID);
            mSPrpsBOT01FindCols = new TSPrpsBOT01FindCols(mBOID);
            mSPrpsBOT01LookUpColumns = new TSPrpsBOT01LookUpColumns(mBOID);
        }
        #endregion

        #region Properties
        private string mBOID = string.Empty;
        public string BOID
        {
            get
            {
                return mBOID;
            }
        }
        private TDataRow mDr = null;
        public TDataRow Dr
        {
            set
            {
                mDr = value;
            }
        }
        private TSPrpsBOT01Flds mSPrpsBOT01Flds = null;
        public TSPrpsBOT01Flds SPrpsBOT01Flds
        {
            get
            {
                return mSPrpsBOT01Flds;
            }
        }
        private TSPrpsBOT01FindCols mSPrpsBOT01FindCols = null;
        public TSPrpsBOT01FindCols SPrpsBOT01FindCols
        {
            get
            {
                return mSPrpsBOT01FindCols;
            }
        }
        private TSPrpsBOT01LookUpColumns mSPrpsBOT01LookUpColumns = null;
        public TSPrpsBOT01LookUpColumns SPrpsBOT01LookUpColumns
        {
            get
            {
                return mSPrpsBOT01LookUpColumns;
            }
        }

        #region UI
        public string DefaultForm01Name
        {
            get
            {
                return UINameSpace + ".TF01" + BOID.Substring(4);
            }
        }
        public string DefaultForm02Name
        {
            get
            {
                return UINameSpace + ".TF02" + BOID.Substring(4);
            }
        }
        public string DefaultForm06Name
        {
            get
            {
                return UINameSpace + ".TF06" + BOID.Substring(4);
            }
        }
        public string DefaultForm08Name
        {
            get
            {
                return UINameSpace + ".TF08" + BOID.Substring(4);
            }
        }
        public string FullBOClassName
        {
            get
            {
                return BONameSpace + "." + BOT01ID;
            }
        }
        #endregion

        public string FindFormCaption
        {
            get
            {
                string lReturnValue = string.Empty;

                switch (Innotelli.Utilities.TAppSettings.SystemLanguage)
                {
                    case SystemLanguages.English:
                        lReturnValue = (string)mDr["FindFormCaption"];
                        break;
                    case SystemLanguages.SimplifiedChinese:
                        lReturnValue = (string)mDr["FindFormCaptionSCh"];
                        break;
                    case SystemLanguages.TraditionalChinese:
                        lReturnValue = (string)mDr["FindFormCaptionTCh"];
                        break;
                }

                return lReturnValue;
            }
        }

        #region System Generated
        public string BOT01ID
        {
            get
            {
                return (string)mDr["BOT01ID"];
            }
        }
        public string BuObjAls
        {
            get
            {
                return (string)mDr["BuObjAls"];
            }
        }
        public TDbRowID slkTbl
        {
            get
            {
                return (int?)mDr["slkTbl"];
            }
            set
            {
                mDr["slkTbl"] = value;
            }
        }
        public string Table
        {
            get
            {
                return (string)mDr["Table"];
            }
            set
            {
                mDr["Table"] = value;
            }
        }
        public bool Actv
        {
            get
            {
                return (bool)mDr["Actv"];
            }
            set
            {
                mDr["Actv"] = value;
            }
        }
        public string Comment
        {
            get
            {
                return (string)mDr["Comment"];
            }
            set
            {
                mDr["Comment"] = value;
            }
        }
        public bool CanLookUp
        {
            get
            {
                return (bool)mDr["CanLookUp"];
            }
            set
            {
                mDr["CanLookUp"] = value;
            }
        }
        public bool ColumnHeads
        {
            get
            {
                return (bool)mDr["ColumnHeads"];
            }
            set
            {
                mDr["ColumnHeads"] = value;
            }
        }
        public bool CanSearch
        {
            get
            {
                return (bool)mDr["CanSearch"];
            }
            set
            {
                mDr["CanSearch"] = value;
            }
        }
        public string SchFldNm
        {
            get
            {
                return (string)mDr["SchFldNm"];
            }
            set
            {
                mDr["SchFldNm"] = value;
            }
        }
        public string DftCndtn
        {
            get
            {
                return (string)mDr["DftCndtn"];
            }
            set
            {
                mDr["DftCndtn"] = value;
            }
        }
        public byte? BuObjLvl
        {
            get
            {
                return (byte?)mDr["BuObjLvl"];
            }
            set
            {
                mDr["BuObjLvl"] = value;
            }
        }
        public bool AccssCtl
        {
            get
            {
                return (bool)mDr["AccssCtl"];
            }
            set
            {
                mDr["AccssCtl"] = value;
            }
        }
        public string AccssCtlNm
        {
            get
            {
                return (string)mDr["AccssCtlNm"];
            }
            set
            {
                mDr["AccssCtlNm"] = value;
            }
        }
        public int? PreLoadFrm02Tp
        {
            get
            {
                return (int?)mDr["PreLoadFrm02Tp"];
            }
            set
            {
                mDr["PreLoadFrm02Tp"] = value;
            }
        }
        public string MainViewSQLStmt
        {
            get
            {
                return (string)mDr["MainViewSQLStmt"];
            }
            set
            {
                mDr["MainViewSQLStmt"] = value;
            }
        }
        public string MainViewSQLLayout
        {
            get
            {
                return (string)mDr["MainViewSQLLayout"];
            }
            set
            {
                mDr["MainViewSQLLayout"] = value;
            }
        }
        public string SearchViewSQLStmt
        {
            get
            {
                return (string)mDr["SearchViewSQLStmt"];
            }
            set
            {
                mDr["SearchViewSQLStmt"] = value;
            }
        }
        public string SearchViewSQLLayout
        {
            get
            {
                return (string)mDr["SearchViewSQLLayout"];
            }
            set
            {
                mDr["SearchViewSQLLayout"] = value;
            }
        }
        public string LookUpViewSQLStmt
        {
            get
            {
                return (string)mDr["LookUpViewSQLStmt"];
            }
            set
            {
                mDr["LookUpViewSQLStmt"] = value;
            }
        }
        public string LookUpViewSQLLayout
        {
            get
            {
                return (string)mDr["LookUpViewSQLLayout"];
            }
            set
            {
                mDr["LookUpViewSQLLayout"] = value;
            }
        }
        public string TblName
        {
            get
            {
                return (string)mDr["TblName"];
            }
        }


        public int ColumnCount
        {
            get
            {
                return (int)mDr["ColumnCount"];
            }
        }
        public string ColumnWidth01
        {
            get
            {
                if (mDr["ColumnWidth01"] == null)
                {
                    return null;
                }
                return mDr["ColumnWidth01"].ToString();
            }
        }
        public string ColumnWidth02
        {
            get
            {
                if (mDr["ColumnWidth02"] == null)
                {
                    return null;
                }
                return mDr["ColumnWidth02"].ToString();
            }
        }
        public string ColumnWidth03
        {
            get
            {
                if (mDr["ColumnWidth03"] == null)
                {
                    return null;
                }
                return mDr["ColumnWidth03"].ToString();
            }
        }
        public string ColumnWidth04
        {
            get
            {
                if (mDr["ColumnWidth04"] == null)
                {
                    return null;
                }
                return mDr["ColumnWidth04"].ToString();
            }
        }
        public string ColumnWidth05
        {
            get
            {
                if (mDr["ColumnWidth05"] == null)
                {
                    return null;
                }
                return mDr["ColumnWidth05"].ToString();
            }
        }
        public string ColumnWidth06
        {
            get
            {
                if (mDr["ColumnWidth06"] == null)
                {
                    return null;
                }
                return mDr["ColumnWidth06"].ToString();
            }
        }
        public string ColumnWidth07
        {
            get
            {
                if (mDr["ColumnWidth07"] == null)
                {
                    return null;
                }
                return mDr["ColumnWidth07"].ToString();
            }
        }
        public string ColumnWidth08
        {
            get
            {
                if (mDr["ColumnWidth08"] == null)
                {
                    return null;
                }
                return mDr["ColumnWidth08"].ToString();
            }
        }
        public string ColumnWidth09
        {
            get
            {
                if (mDr["ColumnWidth09"] == null)
                {
                    return null;
                }
                return mDr["ColumnWidth09"].ToString();
            }
        }
        public string ColumnWidth10
        {
            get
            {
                if (mDr["ColumnWidth10"] == null)
                {
                    return null;
                }
                return mDr["ColumnWidth10"].ToString();
            }
        }
        public double? ListWidth
        {
            get
            {
                if (mDr["ListWidth"] == null)
                {
                    return null;
                }
                return double.Parse(mDr["ListWidth"].ToString());
            }
        }
        public Guid ObjectGUID
        {
            get
            {
                return (Guid)mDr["ObjectGUID"];
            }
        }
        public string BONameSpace
        {
            get
            {
                return (string)mDr["BONameSpace"];
            }
        }
        public string UINameSpace
        {
            get
            {
                return (string)mDr["UINameSpace"];
            }
        }
        #endregion

        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}

