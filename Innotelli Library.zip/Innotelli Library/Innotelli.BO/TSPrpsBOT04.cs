using System;
using System.Data;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public class TSPrpsBOT04
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TSPrpsBOT04(TDataRow aDr)
        {
            mDr = aDr;
            mBOID = BOT04ID;
            mSPrpsBOT04Flds = new TSPrpsBOT04Flds(mBOID);
            mSPrpsBOT04ImprtFlds = new TSPrpsBOT04ImprtFlds(mBOID);
        }
        #endregion

        #region Properties
        private string mBOID = string.Empty;
        public string BOID
        {
            get
            {
                return mBOID;
            }
        }
        private TDataRow mDr = null;
        public TDataRow Dr
        {
            set
            {
                mDr = value;
            }
        }
        private TSPrpsBOT04Flds mSPrpsBOT04Flds = null;
        public TSPrpsBOT04Flds SPrpsBOT04Flds
        {
            get
            {
                return mSPrpsBOT04Flds;
            }
        }
        private TSPrpsBOT04ImprtFlds mSPrpsBOT04ImprtFlds = null;
        public TSPrpsBOT04ImprtFlds SPrpsBOT04ImprtFlds
        {
            get
            {
                return mSPrpsBOT04ImprtFlds;
            }
        }

        #region UI
        public string BOT04ID
        {
            get
            {
                return (string)mDr["BOT04ID"];
            }
        }
        #endregion

        #region System Generated
        public string BONameSpace
        {
            get
            {
                return (string)mDr["BONameSpace"];
            }
        }
        public string UINameSpace
        {
            get
            {
                return (string)mDr["UINameSpace"];
            }
        }
        public string FullBOClassName
        {
            get
            {
                return (string)mDr["FullBOClassName"];
            }
        }
        #endregion

        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}