using System;
using System.ComponentModel;
using Innotelli.BO;

namespace Innotelli.BO
{
	public class TB01UserMMenuDR : TBOT01
	{
		public event PropertyChangedEventHandler PropertyChanged;
		private void NotifyPropertyChanged(String info)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(info));
			}
		}
		public bool AllwAdd
		{
			get
			{
				return bool.Parse(Dr["AllwAdd"].ToString());
			}
			set
			{
				Dr["AllwAdd"] = value;
				NotifyPropertyChanged("AllwAdd");
			}
		}
		public bool AllwDelete
		{
			get
			{
				return bool.Parse(Dr["AllwDelete"].ToString());
			}
			set
			{
				Dr["AllwDelete"] = value;
				NotifyPropertyChanged("AllwDelete");
			}
		}
		public bool AllwEdit
		{
			get
			{
				return bool.Parse(Dr["AllwEdit"].ToString());
			}
			set
			{
				Dr["AllwEdit"] = value;
				NotifyPropertyChanged("AllwEdit");
			}
		}
		public bool AllwRead
		{
			get
			{
				return bool.Parse(Dr["AllwRead"].ToString());
			}
			set
			{
				Dr["AllwRead"] = value;
				NotifyPropertyChanged("AllwRead");
			}
		}
		public string BOT01ID
		{
			get
			{
				if (Dr["BOT001ID"] == null)
				{
					return null;
				}
				return Dr["BOT001ID"].ToString();
			}
			set
			{
				if (value == null)
				{
					Dr["BOT001ID"] = null;
				}
				else
				{
					Dr["BOT001ID"] = value;
					NotifyPropertyChanged("BOT001ID");
				}
			}
		}
		public DateTime? DCreated
		{
			get
			{
				if (Dr["DCreated"] == null)
				{
					return null;
				}
				return DateTime.Parse(Dr["DCreated"].ToString());
			}
			set
			{
				if (value == null)
				{
					Dr["DCreated"] = null;
				}
				else
				{
					Dr["DCreated"] = value;
					NotifyPropertyChanged("DCreated");
				}
			}
		}
		public DateTime? DModified
		{
			get
			{
				if (Dr["DModified"] == null)
				{
					return null;
				}
				return DateTime.Parse(Dr["DModified"].ToString());
			}
			set
			{
				if (value == null)
				{
					Dr["DModified"] = null;
				}
				else
				{
					Dr["DModified"] = value;
					NotifyPropertyChanged("DModified");
				}
			}
		}
		public string EditUser
		{
			get
			{
				if (Dr["EditUser"] == null)
				{
					return null;
				}
				return Dr["EditUser"].ToString();
			}
			set
			{
				if (value == null)
				{
					Dr["EditUser"] = null;
				}
				else
				{
					Dr["EditUser"] = value;
					NotifyPropertyChanged("EditUser");
				}
			}
		}
		public bool InEdit
		{
			get
			{
				return bool.Parse(Dr["InEdit"].ToString());
			}
			set
			{
				Dr["InEdit"] = value;
				NotifyPropertyChanged("InEdit");
			}
		}
		public string MMenu
		{
			get
			{
				return Dr["MMenu"].ToString();
			}
			set
			{
				Dr["MMenu"] = value;
				NotifyPropertyChanged("MMenu");
			}
		}
		public string prmykey
		{
			get
			{
				return Dr["prmykey"].ToString();
			}
			set
			{
				Dr["prmykey"] = value;
				NotifyPropertyChanged("prmykey");
			}
		}
		public string prntkey
		{
			get
			{
				return Dr["prntkey"].ToString();
			}
			set
			{
				Dr["prntkey"] = value;
				NotifyPropertyChanged("prntkey");
			}
		}
		public DateTime? TCreated
		{
			get
			{
				if (Dr["TCreated"] == null)
				{
					return null;
				}
				return DateTime.Parse(Dr["TCreated"].ToString());
			}
			set
			{
				if (value == null)
				{
					Dr["TCreated"] = null;
				}
				else
				{
					Dr["TCreated"] = value;
					NotifyPropertyChanged("TCreated");
				}
			}
		}
		public DateTime? TModified
		{
			get
			{
				if (Dr["TModified"] == null)
				{
					return null;
				}
				return DateTime.Parse(Dr["TModified"].ToString());
			}
			set
			{
				if (value == null)
				{
					Dr["TModified"] = null;
				}
				else
				{
					Dr["TModified"] = value;
					NotifyPropertyChanged("TModified");
				}
			}
		}
		public string UCreated
		{
			get
			{
				if (Dr["UCreated"] == null)
				{
					return null;
				}
				return Dr["UCreated"].ToString();
			}
			set
			{
				if (value == null)
				{
					Dr["UCreated"] = null;
				}
				else
				{
					Dr["UCreated"] = value;
					NotifyPropertyChanged("UCreated");
				}
			}
		}
		public string UModified
		{
			get
			{
				if (Dr["UModified"] == null)
				{
					return null;
				}
				return Dr["UModified"].ToString();
			}
			set
			{
				if (value == null)
				{
					Dr["UModified"] = null;
				}
				else
				{
					Dr["UModified"] = value;
					NotifyPropertyChanged("UModified");
				}
			}
		}
		public string UserID
		{
			get
			{
				return Dr["UserID"].ToString();
			}
			set
			{
				Dr["UserID"] = value;
				NotifyPropertyChanged("UserID");
			}
		}
	}
}

