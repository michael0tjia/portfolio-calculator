using System;
using System.ComponentModel;
using Innotelli.BO;

namespace Innotelli.BO
{
    public class B01UsrLytDR : TBOT01
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private void NotifyPropertyChanged(String info)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(info));
            }
        }
        public string prmykey
        {
            get
            {
                return Dr["prmykey"].ToString();
            }
            set
            {
                Dr["prmykey"] = value;
                NotifyPropertyChanged("prmykey");
            }
        }
        public int prntkey
        {
            get
            {
                return int.Parse(Dr["prntkey"].ToString());
            }
            set
            {
                Dr["prntkey"] = value;
                NotifyPropertyChanged("prntkey");
            }
        }
        public string NmSpc
        {
            get
            {
                if (Dr["NmSpc"] == null)
                {
                    return null;
                }
                return Dr["NmSpc"].ToString();
            }
            set
            {
                if (value == null)
                {
                    Dr["NmSpc"] = null;
                }
                else
                {
                    Dr["NmSpc"] = value;
                    NotifyPropertyChanged("NmSpc");
                }
            }
        }
        public string LytXML
        {
            get
            {
                if (Dr["LytXML"] == null)
                {
                    return null;
                }
                return Dr["LytXML"].ToString();
            }
            set
            {
                if (value == null)
                {
                    Dr["LytXML"] = null;
                }
                else
                {
                    Dr["LytXML"] = value;
                    NotifyPropertyChanged("LytXML");
                }
            }
        }
        public string UCreated
        {
            get
            {
                if (Dr["UCreated"] == null)
                {
                    return null;
                }
                return Dr["UCreated"].ToString();
            }
            set
            {
                if (value == null)
                {
                    Dr["UCreated"] = null;
                }
                else
                {
                    Dr["UCreated"] = value;
                    NotifyPropertyChanged("UCreated");
                }
            }
        }
        public DateTime? DCreated
        {
            get
            {
                if (Dr["DCreated"] == null)
                {
                    return null;
                }
                return DateTime.Parse(Dr["DCreated"].ToString());
            }
            set
            {
                if (value == null)
                {
                    Dr["DCreated"] = null;
                }
                else
                {
                    Dr["DCreated"] = value;
                    NotifyPropertyChanged("DCreated");
                }
            }
        }
        public DateTime? TCreated
        {
            get
            {
                if (Dr["TCreated"] == null)
                {
                    return null;
                }
                return DateTime.Parse(Dr["TCreated"].ToString());
            }
            set
            {
                if (value == null)
                {
                    Dr["TCreated"] = null;
                }
                else
                {
                    Dr["TCreated"] = value;
                    NotifyPropertyChanged("TCreated");
                }
            }
        }
        public string UModified
        {
            get
            {
                if (Dr["UModified"] == null)
                {
                    return null;
                }
                return Dr["UModified"].ToString();
            }
            set
            {
                if (value == null)
                {
                    Dr["UModified"] = null;
                }
                else
                {
                    Dr["UModified"] = value;
                    NotifyPropertyChanged("UModified");
                }
            }
        }
        public DateTime? DModified
        {
            get
            {
                if (Dr["DModified"] == null)
                {
                    return null;
                }
                return DateTime.Parse(Dr["DModified"].ToString());
            }
            set
            {
                if (value == null)
                {
                    Dr["DModified"] = null;
                }
                else
                {
                    Dr["DModified"] = value;
                    NotifyPropertyChanged("DModified");
                }
            }
        }
        public DateTime? TModified
        {
            get
            {
                if (Dr["TModified"] == null)
                {
                    return null;
                }
                return DateTime.Parse(Dr["TModified"].ToString());
            }
            set
            {
                if (value == null)
                {
                    Dr["TModified"] = null;
                }
                else
                {
                    Dr["TModified"] = value;
                    NotifyPropertyChanged("TModified");
                }
            }
        }
        public string EditUser
        {
            get
            {
                if (Dr["EditUser"] == null)
                {
                    return null;
                }
                return Dr["EditUser"].ToString();
            }
            set
            {
                if (value == null)
                {
                    Dr["EditUser"] = null;
                }
                else
                {
                    Dr["EditUser"] = value;
                    NotifyPropertyChanged("EditUser");
                }
            }
        }
        public bool InEdit
        {
            get
            {
                return bool.Parse(Dr["InEdit"].ToString());
            }
            set
            {
                Dr["InEdit"] = value;
                NotifyPropertyChanged("InEdit");
            }
        }
    }
}

