using System;
using System.ComponentModel;
using Innotelli.BO;

namespace Innotelli.BO
{
	public class TB01UserDR : TBOT01
	{
		public event PropertyChangedEventHandler PropertyChanged;
		private void NotifyPropertyChanged(String info)
		{
			if (PropertyChanged != null)
			{
				PropertyChanged(this, new PropertyChangedEventArgs(info));
			}
		}
		public bool Account
		{
			get
			{
				return bool.Parse(Dr["Account"].ToString());
			}
			set
			{
				Dr["Account"] = value;
				NotifyPropertyChanged("Account");
			}
		}
		public bool AutoSclFrm
		{
			get
			{
				return bool.Parse(Dr["AutoSclFrm"].ToString());
			}
			set
			{
				Dr["AutoSclFrm"] = value;
				NotifyPropertyChanged("AutoSclFrm");
			}
		}
		public DateTime? DCreated
		{
			get
			{
				if (Dr["DCreated"] == null)
				{
					return null;
				}
				return DateTime.Parse(Dr["DCreated"].ToString());
			}
			set
			{
				if (value == null)
				{
					Dr["DCreated"] = null;
				}
				else
				{
					Dr["DCreated"] = value;
					NotifyPropertyChanged("DCreated");
				}
			}
		}
		public DateTime? DModified
		{
			get
			{
				if (Dr["DModified"] == null)
				{
					return null;
				}
				return DateTime.Parse(Dr["DModified"].ToString());
			}
			set
			{
				if (value == null)
				{
					Dr["DModified"] = null;
				}
				else
				{
					Dr["DModified"] = value;
					NotifyPropertyChanged("DModified");
				}
			}
		}
		public string EditUser
		{
			get
			{
				if (Dr["EditUser"] == null)
				{
					return null;
				}
				return Dr["EditUser"].ToString();
			}
			set
			{
				if (value == null)
				{
					Dr["EditUser"] = null;
				}
				else
				{
					Dr["EditUser"] = value;
					NotifyPropertyChanged("EditUser");
				}
			}
		}
		public bool InEdit
		{
			get
			{
				return bool.Parse(Dr["InEdit"].ToString());
			}
			set
			{
				Dr["InEdit"] = value;
				NotifyPropertyChanged("InEdit");
			}
		}
		public bool Mgr
		{
			get
			{
				return bool.Parse(Dr["Mgr"].ToString());
			}
			set
			{
				Dr["Mgr"] = value;
				NotifyPropertyChanged("Mgr");
			}
		}
		public string NameChin
		{
			get
			{
				if (Dr["NameChin"] == null)
				{
					return null;
				}
				return Dr["NameChin"].ToString();
			}
			set
			{
				if (value == null)
				{
					Dr["NameChin"] = null;
				}
				else
				{
					Dr["NameChin"] = value;
					NotifyPropertyChanged("NameChin");
				}
			}
		}
		public string NameEng
		{
			get
			{
				if (Dr["NameEng"] == null)
				{
					return null;
				}
				return Dr["NameEng"].ToString();
			}
			set
			{
				if (value == null)
				{
					Dr["NameEng"] = null;
				}
				else
				{
					Dr["NameEng"] = value;
					NotifyPropertyChanged("NameEng");
				}
			}
		}
		public string Password
		{
			get
			{
				if (Dr["Password"] == null)
				{
					return null;
				}
				return Dr["Password"].ToString();
			}
			set
			{
				if (value == null)
				{
					Dr["Password"] = null;
				}
				else
				{
					Dr["Password"] = value;
					NotifyPropertyChanged("Password");
				}
			}
		}
		public string Prfx
		{
			get
			{
				if (Dr["Prfx"] == null)
				{
					return null;
				}
				return Dr["Prfx"].ToString();
			}
			set
			{
				if (value == null)
				{
					Dr["Prfx"] = null;
				}
				else
				{
					Dr["Prfx"] = value;
					NotifyPropertyChanged("Prfx");
				}
			}
		}
		public string prmykey
		{
			get
			{
				return Dr["prmykey"].ToString();
			}
			set
			{
				Dr["prmykey"] = value;
				NotifyPropertyChanged("prmykey");
			}
		}
		public bool Sales
		{
			get
			{
				return bool.Parse(Dr["Sales"].ToString());
			}
			set
			{
				Dr["Sales"] = value;
				NotifyPropertyChanged("Sales");
			}
		}
		public bool Shipping
		{
			get
			{
				return bool.Parse(Dr["Shipping"].ToString());
			}
			set
			{
				Dr["Shipping"] = value;
				NotifyPropertyChanged("Shipping");
			}
		}
		public string slkActvFsclYr
		{
			get
			{
				if (Dr["slkActvFsclYr"] == null)
				{
					return null;
				}
				return Dr["slkActvFsclYr"].ToString();
			}
			set
			{
				if (value == null)
				{
					Dr["slkActvFsclYr"] = null;
				}
				else
				{
					Dr["slkActvFsclYr"] = value;
					NotifyPropertyChanged("slkActvFsclYr");
				}
			}
		}
		public DateTime? TCreated
		{
			get
			{
				if (Dr["TCreated"] == null)
				{
					return null;
				}
				return DateTime.Parse(Dr["TCreated"].ToString());
			}
			set
			{
				if (value == null)
				{
					Dr["TCreated"] = null;
				}
				else
				{
					Dr["TCreated"] = value;
					NotifyPropertyChanged("TCreated");
				}
			}
		}
		public DateTime? TModified
		{
			get
			{
				if (Dr["TModified"] == null)
				{
					return null;
				}
				return DateTime.Parse(Dr["TModified"].ToString());
			}
			set
			{
				if (value == null)
				{
					Dr["TModified"] = null;
				}
				else
				{
					Dr["TModified"] = value;
					NotifyPropertyChanged("TModified");
				}
			}
		}
		public string UCreated
		{
			get
			{
				if (Dr["UCreated"] == null)
				{
					return null;
				}
				return Dr["UCreated"].ToString();
			}
			set
			{
				if (value == null)
				{
					Dr["UCreated"] = null;
				}
				else
				{
					Dr["UCreated"] = value;
					NotifyPropertyChanged("UCreated");
				}
			}
		}
		public string UModified
		{
			get
			{
				if (Dr["UModified"] == null)
				{
					return null;
				}
				return Dr["UModified"].ToString();
			}
			set
			{
				if (value == null)
				{
					Dr["UModified"] = null;
				}
				else
				{
					Dr["UModified"] = value;
					NotifyPropertyChanged("UModified");
				}
			}
		}
		public bool UsePreBuObjNN
		{
			get
			{
				return bool.Parse(Dr["UsePreBuObjNN"].ToString());
			}
			set
			{
				Dr["UsePreBuObjNN"] = value;
				NotifyPropertyChanged("UsePreBuObjNN");
			}
		}
		public string UserID
		{
			get
			{
				return Dr["UserID"].ToString();
			}
			set
			{
				Dr["UserID"] = value;
				NotifyPropertyChanged("UserID");
			}
		}
	}
}

