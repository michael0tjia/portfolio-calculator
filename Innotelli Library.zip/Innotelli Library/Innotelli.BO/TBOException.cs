﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Innotelli.BO
{
    public class TBOException : Exception
    {
        public TBOException(string message)
            : base(message)
        {
        }
    }
}
