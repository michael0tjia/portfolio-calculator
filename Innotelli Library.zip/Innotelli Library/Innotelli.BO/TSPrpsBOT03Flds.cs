﻿using System.Collections;
using System.Data;
using Innotelli.Db;

namespace Innotelli.BO
{
    public class TSPrpsBOT03Flds
    {
        #region Enums
        #endregion

        #region Members
        private string mBOID = string.Empty;
        private DataTable mDt = null;
        private Hashtable[] mSPrpsBOT03FldHTs = null;
        public object mLocker = new object();
        #endregion

        #region Constructors
        public TSPrpsBOT03Flds(string aBOID)
        {
            DataView lDv = new DataView();

            mBOID = aBOID;
            mSPrpsBOT03FldHTs = new Hashtable[2];
            mSPrpsBOT03FldHTs[0] = new Hashtable();
            mSPrpsBOT03FldHTs[1] = new Hashtable();
            lDv.Table = BOT03FldDt;
            lDv.RowFilter = "BOT03ID =  '" + mBOID + "'";
            mDt = lDv.ToTable();
        }
        #endregion

        #region Properties
        private static DataTable mBOT03FldDt = null;
        public static DataTable BOT03FldDt
        {
            get
            {
                if (mBOT03FldDt == null)
                {
                    mBOT03FldDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("BOT03Fld").Tables[0];
                }
                return mBOT03FldDt;
            }
        }
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }
        public int Count
        {
            get
            {
                return mDt.Rows.Count;
            }
        }
        public TSPrpsBOT03Fld this[int aRowIndex]
        {
            get
            {
                TSPrpsBOT03Fld lReturnValue = null;
                TSPrpsBOT03Fld lSPrpsBOT03Fld = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT03FldHTs[0][aRowIndex] == null)
                    {
                        mSPrpsBOT03FldHTs[0][aRowIndex] = new TSPrpsBOT03Fld();
                    }
                }
                lSPrpsBOT03Fld = (TSPrpsBOT03Fld)mSPrpsBOT03FldHTs[0][aRowIndex];
                lSPrpsBOT03Fld.Dr = mDt.Rows[aRowIndex];
                lReturnValue = lSPrpsBOT03Fld;

                return lReturnValue;
            }
        }
        public TSPrpsBOT03Fld this[string aFldNm]
        {
            get
            {
                TSPrpsBOT03Fld lReturnValue = null;
                TSPrpsBOT03Fld lSPrpsBOT03Fld = null;
                DataRow[] lDrs = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT03FldHTs[1][aFldNm] == null)
                    {
                        mSPrpsBOT03FldHTs[1][aFldNm] = new TSPrpsBOT03Fld();
                    }
                }
                lSPrpsBOT03Fld = (TSPrpsBOT03Fld)mSPrpsBOT03FldHTs[1][aFldNm];
                lDrs = mDt.Select("FldNm = '" + aFldNm + "'");
                if (lDrs.Length != 0)
                {
                    lSPrpsBOT03Fld.Dr = lDrs[0];
                    lReturnValue = lSPrpsBOT03Fld;
                }

                return lReturnValue;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}
