using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using Innotelli.BO;

namespace Innotelli.BO
{
    public class B01UsrLyt : B01UsrLytDR
    {
        #region Members
		#endregion
		
		#region Constructors
        public B01UsrLyt()
		{
		}
		#endregion
		
		#region Enums
		
		#endregion
		
		#region Properties
		
		#endregion
		
		#region Event Handlers
		
		#endregion
		
		#region Functions
		
		#endregion
    }
}

