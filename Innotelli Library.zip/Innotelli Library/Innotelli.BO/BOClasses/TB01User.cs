using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using Innotelli.BO;
using Innotelli.Utilities;

namespace Innotelli.BO
{
	public class TB01User : TB01UserDR
	{
		#region Members
		#endregion
		
		#region Constructors
		public TB01User()
		{
            NavOrderByFieldList = "UserID ASC";
		}
		#endregion
		
		#region Enums
		
		#endregion
		
		#region Properties
		
		#endregion
		
		#region Event Handlers
		
		#endregion
		
		#region Functions

        #region Data Validation
        public override bool DataValid(ref string aErrorMessage)
        {
            bool lReturnValue = true;

            if (string.IsNullOrEmpty(UserID))
            {
                aErrorMessage = aErrorMessage + "User ID must be entered!" + "\r\n";
                lReturnValue = false;
            }
            if (string.IsNullOrEmpty(NameEng))
            {
                aErrorMessage = aErrorMessage + "Name must be entered!" + "\r\n";
                lReturnValue = false;
            }

            return lReturnValue;
        }
        #endregion

       
        public bool CanLogin(string UserID, string Password)
        {
            bool lReturnValue = false;
            string lUsrPK = "";
            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                lReturnValue = TDomain.LookupPK("User", "UserID = '" + UserID + "' AND Password = '" + Password + "'", out lUsrPK);
                if (lReturnValue)
                {
                    TCurrentUser.PK = prmykey;
                    //gmUsrRgnPK = slkUsrRgn;
                }
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["UserID"] = UserID;
                lReflectionParams["Password"] = Password;
                lReturnValue = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "WSCanLogin", lReflectionParams);
            }
            return lReturnValue;
        }

        public bool CanLogin2(string UserID, string Password)
        {
            bool lReturnValue = false;
            string lUsrPK = "";
            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                lReturnValue = TDomain.LookupPK("User", "UserID = '" + UserID + "' AND Password = '" + Password + "'", out lUsrPK);
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["UserID"] = UserID;
                lReflectionParams["Password"] = Password;
                lReturnValue = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "WSCanLogin2", lReflectionParams);
            }
            return lReturnValue;
        }

        public bool WSCanLogin(string UserID, string Password)
        {
            return CanLogin(UserID, Password);
        }

        public bool WSCanLogin2(string UserID, string Password)
        {
            return CanLogin2(UserID, Password);
        }

		#endregion
	}
}

