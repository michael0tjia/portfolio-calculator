using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using Innotelli.BO;
using System.Data;
using Innotelli.Utilities;
using Innotelli.Db;
using System.Configuration;

namespace Innotelli.BO
{
	public class TB01UserRpt : TB01UserRptDR
	{
		#region Members
		#endregion
		
		#region Constructors
		public TB01UserRpt()
		{
		}
		#endregion
		
		#region Enums
		
		#endregion
		
		#region Properties
		
		#endregion
		
		#region Event Handlers
		
		#endregion
		
		#region Functions
        public bool RptAuthorized(string aRptNm)
        {
            bool lReturnValue = false;
            DataRow[] lDrs = null;

            lDrs = Dt.Select("RptNm = '" + aRptNm + "'");
            if (lDrs != null && lDrs.Length != 0)
            {
                lReturnValue = (bool)lDrs[0]["Authorized"];
            }
            else
            {
                lReturnValue = true;
            }

            return lReturnValue;
        }
        // Please help 04/02/2008
        public bool Reset(string aUserPK)
        {
            DataSet lDs = new DataSet();
            DataTable lDt = null;
            DataColumn lDc = null;
            DataView lDv = new DataView();

            bool lReturnValue = false;
            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                TSPrc lSPrc = new TSPrc();
                lSPrc.CmdType = CommandType.StoredProcedure;
                lSPrc.CmdText = "A_TB01UserRpt_Reset";

                lDt = Innotelli.Utilities.TSingletons.RptT01Ds.Tables[0];
                lDv.Table = lDt;
                lDv.RowFilter = "AccssCtl = True";
                lDt = lDv.ToTable();
                for (int i = lDt.Columns.Count - 1; i >= 0; i--)
                {
                    lDc = lDt.Columns[i];
                    if (lDc.ColumnName != "RptNm" && lDc.ColumnName != "AccssCtlNm")
                    {
                        lDt.Columns.Remove(lDc);
                    }
                }
                lDs.Tables.Add(lDt);
                lDs.DataSetName = "DataSet";
                lDt.TableName = BOID + "_Reset"; 

                lSPrc.Params.AddWithValue("@TMP01XML", TXML.Reformat(lDs.GetXml()));
                lSPrc.Params.AddWithValue("@UserPK", int.Parse(aUserPK));
                lSPrc.ExecuteNonQuery();
                lReturnValue = true;
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["aUserPK"] = aUserPK;
                lReturnValue = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "WSReset", lReflectionParams);
            }
            return lReturnValue;
        }

        public bool WSReset(string aUserPK)
        {
            return Reset(aUserPK);
        }

        public bool AuthAll(string aUserPK)
        {
            bool lReturnValue = false;
            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                TSPrc lSPrc = new TSPrc();
                lSPrc.CmdType = CommandType.StoredProcedure;
                lSPrc.CmdText = "A_TB01UserRpt_AuthAll";
                lSPrc.Params.AddWithValue("@UserPK", int.Parse(aUserPK));
                lSPrc.ExecuteNonQuery();
                lReturnValue = true;
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["aUserPK"] = aUserPK;
                lReturnValue = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "WSAuthAll", lReflectionParams);
            }
            return lReturnValue;
        }

        public bool WSAuthAll(string aUserPK)
        {
            return AuthAll(aUserPK);
        }

        public bool UnauthAll(string aUserPK)
        {
            bool lReturnValue = false;
            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                TSPrc lSPrc = new TSPrc();
                lSPrc.CmdType = CommandType.StoredProcedure;
                lSPrc.CmdText = "A_TB01UserRpt_UnauthAll";
                lSPrc.Params.AddWithValue("@UserPK", int.Parse(aUserPK));
                lSPrc.ExecuteNonQuery();
                lReturnValue = true;
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["aUserPK"] = aUserPK;
                lReturnValue = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "WSUnauthAll", lReflectionParams);
            }
            return lReturnValue;
        }

        public bool WSUnauthAll(string aUserPK)
        {
            return UnauthAll(aUserPK);
        }

		#endregion
	}
}

