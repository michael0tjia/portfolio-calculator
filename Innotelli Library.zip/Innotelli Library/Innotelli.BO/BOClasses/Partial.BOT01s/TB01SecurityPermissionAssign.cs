using System;
using Innotelli.BO;

namespace Innotelli.BO
{
	partial class TB01SecurityPermissionAssign
	{
		#region Classes
		public static class Cols
		{
			public const string PermissionAllow = "PermissionAllow";
			public const string PermissionGUID = "PermissionGUID";
			public const string slkGroup = "slkGroup";
		}
		#endregion

		#region Properties
		TBOT01Rows<TB01SecurityPermissionAssignDr> mRows = null;
		public TBOT01Rows<TB01SecurityPermissionAssignDr> Rows
		{
			get
			{
				return mRows;
			}
		}
		public TB01SecurityPermissionAssignDr Cr
		{
			get
			{
				return mRows[CurrentRowIndex];
			}
		}
		#endregion

		#region Functions
		public void InitPartial()
		{
			mRows = new TBOT01Rows<TB01SecurityPermissionAssignDr>(this);
		}
		#endregion
	}
}

