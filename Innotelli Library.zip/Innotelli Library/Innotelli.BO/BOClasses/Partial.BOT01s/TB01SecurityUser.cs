using System;
using Innotelli.BO;

namespace Innotelli.BO
{
	partial class TB01SecurityUser
	{
		#region Classes
		public static class Cols
		{
			public const string Description = "Description";
			public const string Initial = "Initial";
			public const string Password = "Password";
			public const string UserGUID = "UserGUID";
			public const string UserName = "UserName";
		}
		#endregion

		#region Properties
		TBOT01Rows<TB01SecurityUserDr> mRows = null;
		public TBOT01Rows<TB01SecurityUserDr> Rows
		{
			get
			{
				return mRows;
			}
		}
		public TB01SecurityUserDr Cr
		{
			get
			{
				return mRows[CurrentRowIndex];
			}
		}
		#endregion

		#region Functions
		public void InitPartial()
		{
			mRows = new TBOT01Rows<TB01SecurityUserDr>(this);
		}
		#endregion
	}
}

