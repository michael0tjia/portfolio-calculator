using System;
using Innotelli.BO;

namespace Innotelli.BO
{
	partial class TB01SecurityGroup
	{
		#region Classes
		public static class Cols
		{
			public const string Description = "Description";
			public const string GroupGUID = "GroupGUID";
			public const string GroupName = "GroupName";
		}
		#endregion

		#region Properties
		TBOT01Rows<TB01SecurityGroupDr> mRows = null;
		public TBOT01Rows<TB01SecurityGroupDr> Rows
		{
			get
			{
				return mRows;
			}
		}
		public TB01SecurityGroupDr Cr
		{
			get
			{
				return mRows[CurrentRowIndex];
			}
		}
		#endregion

		#region Functions
		public void InitPartial()
		{
			mRows = new TBOT01Rows<TB01SecurityGroupDr>(this);
		}
		#endregion
	}
}

