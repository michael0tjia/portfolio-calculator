using System;
using Innotelli.BO;

namespace Innotelli.BO
{
	partial class TB01SecurityGroupAssign
	{
		#region Classes
		public static class Cols
		{
			public const string UserName = "UserName";
			public const string slkGroup = "slkGroup";
			public const string slkUser = "slkUser";
			public const string GroupName = "GroupName";
			public const string UserDescription = "UserDescription";
			public const string GroupDescription = "GroupDescription";
		}
		#endregion

		#region Properties
		TBOT01Rows<TB01SecurityGroupAssignDr> mRows = null;
		public TBOT01Rows<TB01SecurityGroupAssignDr> Rows
		{
			get
			{
				return mRows;
			}
		}
		public TB01SecurityGroupAssignDr Cr
		{
			get
			{
				return mRows[CurrentRowIndex];
			}
		}
		#endregion

		#region Functions
		public void InitPartial()
		{
			mRows = new TBOT01Rows<TB01SecurityGroupAssignDr>(this);
		}
		#endregion
	}
}

