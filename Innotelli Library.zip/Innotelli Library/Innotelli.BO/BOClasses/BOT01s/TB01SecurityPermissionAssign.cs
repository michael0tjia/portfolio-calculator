using System;
using System.Data;

namespace Innotelli.BO
{
    public partial class TB01SecurityPermissionAssign : TBOT01
    {
        #region Enums

        #endregion

        #region Members

        #endregion

        #region Constructors
        public TB01SecurityPermissionAssign()
        {
            InitPartial();
        }
        #endregion

        #region Properties

        #endregion

        #region Event Handlers

        #endregion

        #region Functions
        public override void AddDataColumns()
        {
            base.AddDataColumns();
            AddDataColumn("Description", typeof(string));
        }
        public override void InitAllColumnValues()
        {
            DataTable lDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("SecurityPermission").Tables[0];
            DataRow lDr = null;

            lDt.PrimaryKey = new DataColumn[] { lDt.Columns["SecurityRightGUID"] };
            while (!EOF())
            {
                lDr = lDt.Rows.Find(Cr.PermissionGUID);
                Dr["Description"] = lDr["Description"];
                MoveNext();
            }
            MoveFirst();
        }
        #endregion
    }
}

