using System;
using System.Collections.Generic;

namespace Innotelli.BO
{
	public partial class TB01SecurityUser : TBOT01
	{
		#region Enums
		
		#endregion
		
		#region Members
		
		#endregion
		
		#region Constructors
		public TB01SecurityUser()
		{
			InitPartial();
		}
		#endregion
		
		#region Properties
		
		#endregion
		
		#region Event Handlers
		
		#endregion
		
		#region Functions
        public override bool DeleteByPK(string aPK)
        {
            TB01SecurityGroupAssign lB01SecurityGroupAssign = new TB01SecurityGroupAssign();
            List<string> lList = new List<string>();

            lB01SecurityGroupAssign.OtherFilter = "slkUser = " + aPK;
            lB01SecurityGroupAssign.LoadDataSet();
            if (!lB01SecurityGroupAssign.IsNoRow())
            {
                lB01SecurityGroupAssign.MoveFirst();
                while (!lB01SecurityGroupAssign.EOF())
                {
                    lList.Add(lB01SecurityGroupAssign.Cr.prmykey);
                    lB01SecurityGroupAssign.MoveNext();
                }
            }
            foreach (string lPK in lList)
            {
                lB01SecurityGroupAssign.DeleteByPK(lPK);
            }
            return base.DeleteByPK(aPK);
        }
		#endregion
	}
}

