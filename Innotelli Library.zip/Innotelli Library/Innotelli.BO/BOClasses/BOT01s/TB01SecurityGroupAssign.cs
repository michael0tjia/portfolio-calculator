using System;
using System.Data;

namespace Innotelli.BO
{
    public partial class TB01SecurityGroupAssign : TBOT01
    {
        #region Enums

        #endregion

        #region Members

        #endregion

        #region Constructors
        public TB01SecurityGroupAssign()
        {
            InitPartial();
            RefreshedRowFieldList = "GroupName, UserDescription, GroupDescription, UserName";
            RefreshedRowTriggerFieldList = "slkGroup";

        }
        #endregion

        #region Properties

        #endregion

        #region Event Handlers

        #endregion

        #region Functions
        #endregion
    }
}

