using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using Innotelli.BO;
using Innotelli.Db;
using System.Data;
using Innotelli.Utilities;
using System.Configuration;

namespace Innotelli.BO
{
	public class TB01UserMMenu : TB01UserMMenuDR
	{
		#region Members
		#endregion
		
		#region Constructors
		public TB01UserMMenu()
		{
		}
		#endregion
		
		#region Enums
		
		#endregion
		
		#region Properties
		
		#endregion
		
		#region Event Handlers
		
		#endregion
		
		#region Functions
        public bool AllwReadBO(string aBOID)
        {
            bool lRtrnVal = true;
            DataRow[] lDrs = null;

            if (!string.IsNullOrEmpty(aBOID))
            {
                //#check!
                aBOID = "dt" +  TStr.Mid(aBOID, 4, 20);
                lDrs = Dt.Select("BOT001ID = '" + aBOID + "'");
                if (lDrs != null && lDrs.Length != 0)
                {
                    lRtrnVal = (bool)lDrs[0]["AllwRead"];
                }
                else
                {
                    lRtrnVal = true;
                }
            }

            return lRtrnVal;
        }
        public bool AllwEditBO(string aBOID)
        {
            bool lRtrnVal = true;
            DataRow[] lDrs = null;

            if (!string.IsNullOrEmpty(aBOID))
            {
                //#check!
                aBOID = "dt" +  TStr.Mid(aBOID, 4, 20);
                lDrs = Dt.Select("BOT001ID = '" + aBOID + "'");
                if (lDrs != null && lDrs.Length != 0)
                {
                    lRtrnVal = (bool)lDrs[0]["AllwEdit"];
                }
                else
                {
                    lRtrnVal = true;
                }
            }

            return lRtrnVal;
        }
        public bool AllwAddBO(string aBOID)
        {
            bool lRtrnVal = true;
            DataRow[] lDrs = null;

            if (!string.IsNullOrEmpty(aBOID))
            {
                //#check!
                aBOID = "dt" +  TStr.Mid(aBOID, 4, 20);
                lDrs = Dt.Select("BOT001ID = '" + aBOID + "'");
                if (lDrs != null && lDrs.Length != 0)
                {
                    lRtrnVal = (bool)lDrs[0]["AllwAdd"];
                }
                else
                {
                    lRtrnVal = true;
                }
            }

            return lRtrnVal;
        }
        public bool AllwDeleteBO(string aBOID)
        {
            bool lRtrnVal = true;
            DataRow[] lDrs = null;

            if (!string.IsNullOrEmpty(aBOID))
            {
                //#check!
                aBOID = "dt" +  TStr.Mid(aBOID, 4, 20);
                lDrs = Dt.Select("BOT001ID = '" + aBOID + "'");
                if (lDrs != null && lDrs.Length != 0)
                {
                    lRtrnVal = (bool)lDrs[0]["AllwDelete"];
                }
                else
                {
                    lRtrnVal = true;
                }
            }

            return lRtrnVal;
        }
        public bool Reset(string aUserPK)
        {
            DataSet lDs = new DataSet();
            DataTable lDt = null;
            DataColumn lDc = null;
            DataView lDv = new DataView();

            bool lRtrnVal = false;
            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                TSPrc lSPrc = new TSPrc();
                lSPrc.CmdType = CommandType.StoredProcedure;
                lSPrc.CmdText = "A_TB01UserMMenu_Reset";

                lDt = Innotelli.BO.TSingletons.SPrpsBOT01s.Dt;
                lDv.Table = lDt;
                lDv.RowFilter = "AccssCtlNm IS NOT NULL AND AccssCtl = True";
                lDt = lDv.ToTable();
                for (int i = lDt.Columns.Count - 1; i >=0; i--)
                {
                    lDc = lDt.Columns[i];
                    if (lDc.ColumnName != "BOT01ID" && lDc.ColumnName != "AccssCtlNm")
                    {
                        lDt.Columns.Remove(lDc); 
                    }
                }
                //#check!
                for (int i = 0; i < lDt.Rows.Count; i++)
                {
                    lDt.Rows[i]["BOT01ID"] = "dt" + lDt.Rows[i]["BOT01ID"].ToString().Substring(4);
                }                
                lDs.Tables.Add(lDt);
                lDs.DataSetName = "DataSet";
                lDt.TableName = BOID + "_Reset";
                lSPrc.Params.AddWithValue("@TMP01XML", TXML.Reformat(lDs.GetXml()));
                lSPrc.Params.AddWithValue("@UserPK", int.Parse(aUserPK));
                lSPrc.ExecuteNonQuery();
                lRtrnVal = true;
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["aUserPK"] = aUserPK;
                lRtrnVal = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "WSReset", lReflectionParams);
            }
            return lRtrnVal; 
        }
        public bool WSReset(string aUserPK)
        {
            return Reset(aUserPK);
        }
        public bool AuthAll(string aUserPK)
        {
            bool lRtrnVal = false;
            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                TSPrc lSPrc = new TSPrc();
                lSPrc.CmdType = CommandType.StoredProcedure;
                lSPrc.CmdText = "A_TB01UserMMenu_AuthAll";
                lSPrc.Params.AddWithValue("@UserPK", int.Parse(aUserPK));
                lSPrc.ExecuteNonQuery();
                lRtrnVal = true;
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["aUserPK"] = aUserPK;
                lRtrnVal = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "WSAuthAll", lReflectionParams);
            }
            return lRtrnVal; 
        }
        public bool WSAuthAll(string aUserPK)
        {
            return AuthAll(aUserPK);
        }
        public bool UnauthAll(string aUserPK)
        {
            bool lRtrnVal = false;
            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                TSPrc lSPrc = new TSPrc();
                lSPrc.CmdType = CommandType.StoredProcedure;
                lSPrc.CmdText = "A_TB01UserMMenu_UnauthAll";
                lSPrc.Params.AddWithValue("@UserPK", int.Parse(aUserPK));
                lSPrc.ExecuteNonQuery();
                lRtrnVal = true;
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["aUserPK"] = aUserPK;
                lRtrnVal = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "WSUnauthAll", lReflectionParams);
            }
            return lRtrnVal; 
        }
        public bool WSUnauthAll(string aUserPK)
        {
            return UnauthAll(aUserPK);
        }
		#endregion
	}
}

