using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Innotelli.Db;

namespace Innotelli.BO
{
    public class TLogin
    {
        public TLogin()
        {
        }
        public bool Authenticate(string aLogin, string aPw, ref string aUserPK, ref string aUserName)
        {
            bool lReturnValue = false;
            DataRow lDr = null;
            string lChkPW = "";

            TDomain.LookupDataRow("*", "User", "UserID = '" + aLogin + "'", out lDr);
            if (lDr != null)
            {
                lChkPW = lDr["Password"].ToString();
                if ((lChkPW != "") && (lChkPW == aPw))
                {
                    lReturnValue = true;
                    aUserPK = lDr[Innotelli.Utilities.TGC.PKeyName].ToString();
                    aUserName = lDr["NameEng"].ToString();
                }
            }
            return lReturnValue;
        }
    }
}
