using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.BO
{     
    public abstract class TBOT01 : TBOBaseT01
    {
        #region Members
        public event BOIsDirtyEventHandler OnBOIsDirty;
        #endregion

        #region Constructors
        public TBOT01()
        {
            if (!string.IsNullOrEmpty(SPrps.TblName))
            {
                Dao.MainTable = SPrps.TblName;
            }            
        }
        #endregion

        #region Properties

        #region View Names
        public string DefaultViewName
        {
        get
        {
        return "A_" + BOID;
        }
        }
        public string SearchViewName
        {
            get
            {
                return "A_" + BOID + "_Search";
            }
        }
        public string LookUpListViewName
        {
            get
            {
                return "A_" + BOID + "_LookUpList";
            }
        }		
	    #endregion        

        public TSPrpsBOT01 SPrps
        {
            get
            {
                return Innotelli.BO.TSingletons.SPrpsBOT01s[BOID];
            }
        }

        private bool mIsDirty = false;
        public bool IsDirty
        {
            get
            {
                return mIsDirty;
            }
            set
            {
                if (mIsDirty == value)
                {
                    return;
                }
                else
                {
                    // If AllowEidt == false, IsDirty is always false. Cannot set to true;
                    if (!mIsDirty && DataRight.AllowEdit)
                    {
                        mIsDirty = true;

                        //if root BO
                        if (BOT01ParentChildRel.ParentBO == null)
                        {
                            System.EventArgs lEventArgs = new System.EventArgs();
                            if (OnBOIsDirty != null)
                            {
                                OnBOIsDirty(this, lEventArgs);
                            }
                        }
                        else
                        {
                            BOT01ParentChildRel.ParentBO.IsDirty = true;
                        }
                    }
                    else
                    {
                        mIsDirty = false;
                    }
                }
            }
        }

        private string mRowLockPK = null;
        public string RowLockPK
        {
            get
            {
                return mRowLockPK;
            }
            set
            {
                mRowLockPK = value;
            }
        }
        private string mLockedByUserID = "";
        public string LockedByUserID
        {
            get
            {
                return mLockedByUserID;
            }
            set
            {
                mLockedByUserID = value;
            }
        }

        #region Db Filters
        private string mPK = null;
        public string PK
        {
            //get
            //{
            //    return mPK;
            //}
            set
            {
                mPK = value;
                mOtherFilter = "";
            }
        }
        private string mFK = null;
        public string FK
        {
            get
            {
                return mFK;
            }
            set
            {
                mFK = value;
                mParentKeyFieldName = Innotelli.Utilities.TGC.FKeyName;
                mParentKey = mFK;
            }
        }
        private string mParentKeyFieldName = "";
        public string ParentKeyFieldName
        {
            get
            {
                return mParentKeyFieldName;
            }
            set
            {
                mParentKeyFieldName = value;
            }
        }
        private string mParentKey = null;
        public string ParentKey
        {
            get
            {
                return mParentKey;
            }
            set
            {
                mParentKey = value;
            }
        }
        private string mOtherFilter = "";
        public string OtherFilter
        {
            get
            {
                return mOtherFilter;
            }
            set
            {
                mOtherFilter = value;
            }
        }
        public string DbFilter
        {
            get
            {
                return GetResultantDbFilter();
            }
        }
        #endregion

        #region Parent Child Relationship
        private TBOT01ParentChildRel mBOT01ParentChildRel = new TBOT01ParentChildRel();
        public TBOT01ParentChildRel BOT01ParentChildRel
        {
            get
            {
                return mBOT01ParentChildRel;
            }
            set
            {
                mBOT01ParentChildRel = value;
            }
        }
        List<TBOT01> mChildern = new List<TBOT01>();
        public List<TBOT01> Childern
        {
            get
            {
                return mChildern;
            }
            set
            {
                mChildern = value;
            }
        }
        #endregion

        #region Row Filters
        #endregion

        #region Order By Field List
        private string mOrderByFieldList = "";
        public string OrderByFieldList
        {
            get { return mOrderByFieldList; }
            set { mOrderByFieldList = value; }
        }
        #endregion

        #region Navigation
        private bool mNavEnable = true;
        public bool NavEnable
        {
            get
            {
                return mNavEnable;
            }
            set
            {
                mNavEnable = value;
            }
        }
        private string mNavCriteria = "";
        virtual public string NavCriteria
        {
            get
            {
                return mNavCriteria;
            }
            set
            {
                mNavCriteria = value;
            }
        }
        private string mNavOrderByFieldList = "";
        public string NavOrderByFieldList
        {
            get
            {
                return mNavOrderByFieldList;
            }
            set
            {
                mNavOrderByFieldList = value;
            }
        }
        private long mNavCurPos = 0;
        public long NavCurPos
        {
            get
            {
                return mNavCurPos;
            }
            set
            {
                mNavCurPos = value;
            }
        }
        private long mNavRecCount = 0;
        public long NavRecCount
        {
            get
            {
                return mNavRecCount;
            }
            set
            {
                mNavRecCount = value;
            }
        }
        #endregion

        private ArrayList mCalColumnCollection = null;
        public ArrayList CalColumnCollection
        {
            get
            {
                return mCalColumnCollection;
            }
            set
            {
                mCalColumnCollection = value;
            }
        }

        #region Refreshed Rows
        private string mRefreshedRowFieldList = "";
        public string RefreshedRowFieldList
        {
            get
            {
                return mRefreshedRowFieldList;
            }
            set
            {
                mRefreshedRowFieldList = value;
            }
        }
        private string mRefreshedRowTriggerFieldList = "";
        public string RefreshedRowTriggerFieldList
        {
            get
            {
                return mRefreshedRowTriggerFieldList;
            }
            set
            {
                mRefreshedRowTriggerFieldList = value;
            }
        }
        #endregion

        private string mDataInvalidErrorMessage = "";
        public string DataInvalidErrorMessage
        {
            get
            {
                return mDataInvalidErrorMessage;
            }
            set
            {
                mDataInvalidErrorMessage = value;
            }
        }

        private bool mDetectColumnChanged = true;
        public bool DetectColumnChanged
        {
            get
            {
                return mDetectColumnChanged;
            }
            set
            {
                if (value)
                {
                    Dt.ColumnChanged += Dt_ColumnChanged;
                }
                else
                {
                    Dt.ColumnChanged -= Dt_ColumnChanged;
                }
                mDetectColumnChanged = value;
            }
        }
        private string mPreviousPKBeforeAddNew = null;
        public string PreviousPKBeforeAddNew
        {
            get
            {
                return mPreviousPKBeforeAddNew;
            }
            set
            {
                mPreviousPKBeforeAddNew = value;
            }
        }

        #region CRUD Rights
        // BO CRUD Right, example TB01SalesInvcPmts
        TDataRight mBODataRight = new TDataRight();
        public virtual TDataRight BODataRight
        {
            get
            {
                return mBODataRight;
            }
        }
        // Status CRUD Right depends on the content of the BOs (Posted or not) 
        public virtual bool Locked
        {
            get
            {
                return false;
            }
        }
        TDataRight mStatusDataRight = new TDataRight();
        public virtual TDataRight StatusDataRight
        {
            get
            {
                mStatusDataRight.AllowEdit = !Locked;
                mStatusDataRight.AllowDelete = !Locked;
                return mStatusDataRight;
            }
        }
        // User CRUD Right depends on the user's CRUD right specified in the user/group permission
        TDataRight mUserDataRight = new TDataRight();
        public virtual TDataRight UserDataRight
        {
            get
            {
                if (TCurrentUser.B01UserMMenu != null)
                {
                    mUserDataRight.AllowAdd = TCurrentUser.B01UserMMenu.AllwAddBO(BOID);
                    mUserDataRight.AllowDelete = TCurrentUser.B01UserMMenu.AllwDeleteBO(BOID);
                    mUserDataRight.AllowEdit = TCurrentUser.B01UserMMenu.AllwEditBO(BOID);
                    mUserDataRight.AllowRead = TCurrentUser.B01UserMMenu.AllwReadBO(BOID);
                }
                else
                {
                    mUserDataRight.AllowAdd = true;
                    mUserDataRight.AllowDelete = true;
                    mUserDataRight.AllowEdit = true;
                    mUserDataRight.AllowRead = true;
                }
                return mUserDataRight;
            }
        }
        TDataRight mConsistencyDataRight = new TDataRight();
        // Consistency CRUD Right depend on if the BO instance have the edit right after loading from the database
        public virtual TDataRight ConsistencyDataRight
        {
            get
            {
                return mConsistencyDataRight;
            }
        }
        // This is the overall right
        TDataRight mDataRight = new TDataRight();
        public TDataRight DataRight
        {
            get
            {
                mDataRight.AllowAdd = StatusDataRight.AllowAdd && BODataRight.AllowAdd && UserDataRight.AllowAdd;
                mDataRight.AllowDelete = StatusDataRight.AllowDelete && BODataRight.AllowDelete && UserDataRight.AllowDelete;
                mDataRight.AllowEdit = StatusDataRight.AllowEdit && BODataRight.AllowEdit && UserDataRight.AllowEdit && ConsistencyDataRight.AllowEdit;
                mDataRight.AllowRead = StatusDataRight.AllowRead && BODataRight.AllowRead && UserDataRight.AllowRead;
                return mDataRight;
            }
        }

        #endregion

        public TDbRowID PrmyKey
        {
            get
            {
                return (int?)Dr["prmykey"];
            }
            set
            {
                Dr["prmykey"] = value;
            }
        }
        public int VirtualPrmyKey
        {
            get
            {
                return (int)Dr[Innotelli.BO.TGC.VIRTUAL_PRIMARY_KEY_FIELD_NAME];
            }
        }

        #region UI
        public string DefaultForm01Name
        {
            get
            {
                return "TF01" + BOID.Substring(4);
            }
        }
        public string DefaultForm02Name
        {
            get
            {
                return "TF02" + BOID.Substring(4) ; 
            }
        }
        public string DefaultForm06Name
        {
            get
            {
                return "TF06" + BOID.Substring(4);
            }
        }
        public string DefaultForm08Name
        {
            get
            {
                return "TF08" + BOID.Substring(4);
            }
        }
        #endregion

        #endregion

        #region Event Handlers
        public virtual void Dt_ColumnChanged(object sender, DataColumnChangeEventArgs e)
        {
            bool lDoColDependencyTrigger = false;
            object lNewVal;
            object lOldVal;

            if (mDetectColumnChanged && Dt != null)
            {                
                if (e.Row.RowState == DataRowState.Detached)
                {
                    lOldVal = null;
                }
                else
                {
                    lOldVal = e.Row[e.Column, DataRowVersion.Current];
                }
                lNewVal = e.ProposedValue;
                lDoColDependencyTrigger = (e.Column.ColumnName != Utilities.TGC.PKeyName) && !(TNull.IsValueNull(lOldVal) && TNull.IsValueNull(lNewVal));
                if (lDoColDependencyTrigger) // NOT BOTH lOldVal and lNewVal is NULL
                {

                    if (!TNull.IsValueNull(lOldVal)) // lOldVal is NOT NULL
                    {
                        lDoColDependencyTrigger = !lOldVal.Equals(lNewVal);
                    }
                    else // lNewVal is NOT NULL
                    {
                        lDoColDependencyTrigger = !lNewVal.Equals(lOldVal);
                    }
                }
                if (lDoColDependencyTrigger)
                {
                    SetCurrentRow(e.Row);
                    Dt.ColumnChanged -= Dt_ColumnChanged;
                    IsDirty = true;
                    try
                    {
                        SelLnkFldCopyInfo(e.Column.ColumnName, e.ProposedValue);
                        DoFieldDependency(e);
                    }
                    finally
                    {
                        e.Row.EndEdit();
                        try
                        {
                            ReCalcAllColumnValues();
                            if (InRefreshedRowTriggerFieldList(e.Column.ColumnName))
                            {
                                UpdateRefreshedRow();
                            }
                        }
                        finally
                        {
                            Dt.ColumnChanged += Dt_ColumnChanged;
                        }
                    }
                    
                }
            }
        }
        public virtual void Dt_RowDeleted(object sender, DataRowChangeEventArgs e)
        {
            if (e.Action == DataRowAction.Delete)
            {
                if (BOT01ParentChildRel.ParentBO != null)
                {
                    BOT01ParentChildRel.ParentBO.IsDirty = true;
                }

                Dt.ColumnChanged -= Dt_ColumnChanged;
                if (CurrentRowIndex == 0 && DefaultView.Count > 0)
                {
                    MoveNext();
                }                
                else
                {
                    MovePrevious();
                }
                ReCalcAllColumnValues();
                RefreshItemNo();
                Dt.ColumnChanged += Dt_ColumnChanged;
            }

        }
        private void RefreshItemNo()
        {
            string lItemNoFldNm = SPrps.SPrpsBOT01Flds.ItemNumberFieldName;
            DataView lDv = new DataView();

            if (Dt != null && lItemNoFldNm != string.Empty)
            {
                lDv.Table = Dt;
                lDv.Sort = lItemNoFldNm;
                for (int i = 0; i < lDv.Count; i++)
                {
                    lDv[i].Row[lItemNoFldNm] = i + 1;
                }


            }
        }
        public virtual void Dt_RowChanged(object sender, DataRowChangeEventArgs e)
        {
            if (e.Action == DataRowAction.Add)
            {
                if (BOT01ParentChildRel.ParentBO != null)
                {
                    BOT01ParentChildRel.ParentBO.IsDirty = true;
                }
                Dt.ColumnChanged -= Dt_ColumnChanged;
                ReCalcAllColumnValues();
                Dt.ColumnChanged += Dt_ColumnChanged;
                CurrentRowIndex = DefaultView.Count - 1;
                OnAfterAddNewRow();
            }
        }
        public virtual void Dt_TableNewRow(object sender, DataTableNewRowEventArgs e)
        {
            Dt.ColumnChanged -= Dt_ColumnChanged;
            SetCurrentRow(e.Row);
            BaseSetDefaults();
            SetDefaults();
            Dt.ColumnChanged += Dt_ColumnChanged;
        }

        private void ParentBO_OnBOActiveRowChanged(object sender, TBOActiveRowChangedEventArgs e)
        {
            if (BOT01ParentChildRel.ParentBO != null)
            {
                if (e.ActiveRowIndex == TDataObject.BOFRowIndex || e.ActiveRowIndex == TDataObject.EOFRowIndex || e.ActiveRowIndex == TDataObject.DetachedRowIndex)
                {
                    DefaultView.RowFilter = "false";
                }
                else
                {
                    if (TNull.IsValueNull(BOT01ParentChildRel.ParentBO.Dr[BOT01ParentChildRel.ParentLinkFieldName]))
                    {
                        DefaultView.RowFilter = Innotelli.BO.TGC.VIRTUAL_PARENT_KEY_FIELD_NAME + " = " + BOT01ParentChildRel.ParentBO.Dr[Innotelli.BO.TGC.VIRTUAL_PRIMARY_KEY_FIELD_NAME].ToString();
                    }
                    else
                    {
                        DefaultView.RowFilter = BOT01ParentChildRel.ChildLinkFieldName + " = " + BOT01ParentChildRel.ParentBO.Dr[BOT01ParentChildRel.ParentLinkFieldName].ToString();
                    }
                }
            }
        }
        #endregion

        #region Functions

        #region Load

        #region Db Filters
        public void ClearFilters()
        {
            mOtherFilter = "";
        }
        private string GetResultantDbFilter()
        {
            string lRtrnVal = string.Empty;
            string lParentBOSubSQL = string.Empty;
            TSQL lSubSQL = new TSQL();

            #region Exclusive cases
            if (!string.IsNullOrEmpty(mPK))
            {
                lRtrnVal += "(" + Utilities.TGC.PKeyName + " = " + mPK + ") AND ";
            }
            else if (!string.IsNullOrEmpty(mFK))
            {
                lRtrnVal += "(" + Utilities.TGC.FKeyName + " = " + mFK + ") AND ";
            }
            else if (!string.IsNullOrEmpty(mParentKeyFieldName) && !string.IsNullOrEmpty(mParentKey))
            {
                lRtrnVal += "(" + mParentKeyFieldName + " = " + mParentKey + ") AND ";
            }
            else if (BOT01ParentChildRel.ParentBO != null)
            {
                lSubSQL.Stmt = "SELECT " + BOT01ParentChildRel.ParentLinkFieldName + " FROM " + BOT01ParentChildRel.ParentBO.DefaultViewName;
                lSubSQL.AddToWhereClause(BOT01ParentChildRel.ParentBO.DbFilter);
                lRtrnVal += "(" + BOT01ParentChildRel.ChildLinkFieldName + " IN (" + lSubSQL.Stmt + ")) AND ";
            }
            #endregion

            if (!string.IsNullOrEmpty(mOtherFilter))
            {
                lRtrnVal += "(" + mOtherFilter + ") AND ";
            }
            if (!string.IsNullOrEmpty(lRtrnVal))
            {
                lRtrnVal = TStr.Left(lRtrnVal, lRtrnVal.Length - 4);
            }
            return lRtrnVal;
        }
        #endregion

        public void LoadBlank()
        {
            Dao.SQL.SetEmptyStmtByTable(DefaultViewName);
            Dao.OpenTable();
            Dao.Dt.TableName = BOID;
            CreateVirtualPrimaryKeyColumn();
            CreateVirtualParentKeyColumn();
            AddDataColumns();
            AssignDtEventHandlers();
        }
        public void LoadDataSet()
        {
            TBOT01 lChild = null;
            string lDbFilter = string.Empty;

            Dao.SQL.Stmt = "SELECT * FROM " + DefaultViewName;
            lDbFilter = DbFilter;
            if (!string.IsNullOrEmpty(lDbFilter))
            {
                Dao.SQL.AddToWhereClause(lDbFilter);
            }
            if (!string.IsNullOrEmpty(mOrderByFieldList))
            {
                Dao.SQL.AddToOrderByClause(mOrderByFieldList);
            }
            Dao.OpenTable();
            Dao.Dt.TableName = BOID;
            CreateVirtualPrimaryKeyColumn();
            CreateVirtualParentKeyColumn();

            for (int i = 0; i < mChildern.Count; i++)
            {
                lChild = mChildern[i];
                lChild.ParentKey = mPK;
                lChild.LoadDataSet();
            }

            AddDataColumns();
            //#check!
            // why "if (!IsNoRow())" is commented before 
            if (!IsNoRow())
            {
                MoveFirst();
                InitAllColumnValues();
            }

            AssignDtEventHandlers();

            mIsDirty = false;
        }
        protected override void AssignDtEventHandlers()
        {
            base.AssignDtEventHandlers();
            Dt.ColumnChanged += new DataColumnChangeEventHandler(Dt_ColumnChanged);
            Dt.TableNewRow += new DataTableNewRowEventHandler(Dt_TableNewRow);
            Dt.RowChanged += new DataRowChangeEventHandler(Dt_RowChanged);
            Dt.RowDeleted += new DataRowChangeEventHandler(Dt_RowDeleted);
        }
        public void SetDataTableWithEvents(DataTable aDt)
        {
            Dt = aDt;
            AssignDtEventHandlers();
        }
        #endregion

        #region AddNew
        public void AddNew()
        {
            TBOT01 lChild = null;
            TBOT01 lGrandChild = null;
            mPreviousPKBeforeAddNew = mPK;
            mPK = null;
            LoadBlank();
            for (int i = 0; i < mChildern.Count; i++)
            {
                lChild = mChildern[i];
                lChild.ParentKey = null;
                lChild.LoadBlank();
                for (int j = 0; j < lChild.Childern.Count; j++)
                {
                    lGrandChild = lChild.mChildern[j];
                    lGrandChild.ParentKey = null;
                    lGrandChild.LoadBlank();
                }
            }
            AddNewRow();
            mIsDirty = true;
        }
        public void AddNewRow()
        {
            DetachedDataRow = Dt.NewRow();
            Dt.Rows.Add(DetachedDataRow);            
        }
        public virtual void OnAfterAddNewRow()
        {

        }
        public virtual void SetNewID()
        {
            string lNextID = string.Empty;
            TNxN lNxN = new TNxN();
            TSPrpsBOT01Fld lSPrpsBOT01Fld = null;

            lSPrpsBOT01Fld = Innotelli.BO.TSingletons.SPrpsBOT01s[BOID].SPrpsBOT01Flds.SKeySPrps;                
            if (lSPrpsBOT01Fld.slkDftValType.HasValue)
            {
                switch (lSPrpsBOT01Fld.slkDftValType.Value.ToString())
                {
                    case "4": //"DocNxNoT01":
                        if ((lSPrpsBOT01Fld.DftTblNm != string.Empty) && (lSPrpsBOT01Fld.DftFldNm != string.Empty))
                        {
                            lNextID = lNxN.GetNxNT01(BOID, "TB01" + lSPrpsBOT01Fld.DftTblNm, lSPrpsBOT01Fld.DftFldNm);
                        }
                        break;
                    case "14": //"DocNxNoT03":
                        if ((lSPrpsBOT01Fld.DftTblNm != string.Empty) && (lSPrpsBOT01Fld.DftFldNm != string.Empty) && (lSPrpsBOT01Fld.DftFldNm02 != string.Empty))
                        {
                            lNextID = lNxN.GetNxNT03(BOID, "TB01" + lSPrpsBOT01Fld.DftTblNm, lSPrpsBOT01Fld.DftFldNm, Dr[lSPrpsBOT01Fld.DftFldNm02].ToString());
                        }
                        break;
                    case "15": //DocNxNoT04
                        lNextID = lNxN.GetNxNT04(BOID, TCurrentUser.UserPrefix);
                        break;
                    case "DocNxNoT05":
                        #region Incomplete Later
                        //string lTempDftTblNm = "";
                        //if ((lDt.Rows[i]["DftTblNm"] == null) || (lDt.Rows[i]["DftTblNm"].ToString() == "0"))
                        //{
                        //    lTempDftTblNm = "";
                        //}
                        //else
                        //{
                        //    lTempDftTblNm = lDt.Rows[i]["DftTblNm"].ToString();
                        //}
                        //if ((lTempDftTblNm == "FsclYr") && (lDt.Rows[i]["DftFldNm"] != null))
                        //{
                        //    lNextID = lNxN.GetNxNT05(BOT01ID, lDt.Rows[i]["DftFldNm"]);
                        //    if (lNextID != null)
                        //    {
                        //        //RecSet(lRstFld("FldNm")) = lNextID;
                        //    }
                        //}
                        #endregion
                        break;
                }
                if (lNextID != string.Empty)
                {
                    Dr[lSPrpsBOT01Fld.FldNm] = lNextID;
                }
            }
        }
        public bool IsNewIDDuplicate(string aNewID)
        {
            bool lRtrnVal = false;
            string lPK = null;

            if (TDomain.LookupPK(SPrps.TblName, SPrps.SPrpsBOT01Flds.SKeyFieldName + " = '" + aNewID.Replace("'", "''") + "'", out lPK))
            {
                lRtrnVal = true;
            }

            return lRtrnVal;
        }
        #endregion

        #region Save
        public string GetPrimaryKeyFromVirtualPrimaryKey(string aVirtualPrimaryKey)
        {
            string lRtrnVal = string.Empty;
            int lRowIndex = -1;
            string lSort = string.Empty;
            DataRowView lDrv = null;

            lSort = DefaultView.Sort;
            DefaultView.Sort = Innotelli.BO.TGC.VIRTUAL_PRIMARY_KEY_FIELD_NAME;
            lRowIndex = DefaultView.Find(aVirtualPrimaryKey);
            
            if (lRowIndex >= 0 && lRowIndex <= DefaultView.Count - 1)
            {
                lDrv = DefaultView[lRowIndex];
                DefaultView.Sort = lSort;
                lRtrnVal = lDrv[Innotelli.Utilities.TGC.PKeyName].ToString();
            }
            else
            {
                DefaultView.Sort = lSort;
                throw new TDbException("Cannot locate the desired DataRowView by DataRow.");
            }

            return lRtrnVal;
        }
        public virtual bool Save()
        {
            bool lRtrnVal = false;
            TBOT01 lBOT01Child = null;
            string lParentKey = string.Empty;
            string lVirtualParentKey = string.Empty;

            if (!string.IsNullOrEmpty(SPrps.TblName))
            {
                //RemoveCalColumns();

                // If it is root BO
                if (BOT01ParentChildRel.ParentBO == null && Dt.Rows.Count == 1)
                {
                    //TODO: Michael Check. difficult
                    if (Innotelli.BO.TSingletons.SPrpsBOT01s[BOID].SPrpsBOT01Flds.SKeyFieldName != "prmykey")
                    {
                        if (Innotelli.BO.TSingletons.SPrpsBOT01s[BOID].SPrpsBOT01Flds.SKeyFieldName != string.Empty && Dr[Innotelli.BO.TSingletons.SPrpsBOT01s[BOID].SPrpsBOT01Flds.SKeyFieldName].ToString() == string.Empty)
                        {
                            SetNewID();
                        }
                    }
                }

                if (BOT01ParentChildRel.ParentBO != null)
                {
                    for (int i = 0; i < Dt.Rows.Count; i++)
                    {
                        if (Dt.Rows[i].RowState == DataRowState.Added && TNull.IsValueNull(Dt.Rows[i][BOT01ParentChildRel.ChildLinkFieldName]))
                        {
                            lVirtualParentKey = Dt.Rows[i][Innotelli.BO.TGC.VIRTUAL_PARENT_KEY_FIELD_NAME].ToString();
                            lParentKey = BOT01ParentChildRel.ParentBO.GetPrimaryKeyFromVirtualPrimaryKey(lVirtualParentKey);
                            Dt.Rows[i][BOT01ParentChildRel.ChildLinkFieldName] = lParentKey;
                        }
                    }
                }

                Dao.UpdateRows();

                for (int i = 0; i < mChildern.Count; i++)
                {
                    lBOT01Child = mChildern[i];
                    if (lBOT01Child.Dt.Rows.Count != 0)
                    {
                        lBOT01Child.Save();
                    }
                }

                mDataInvalidErrorMessage = "";

                if (SPrps.CanLookUp)
                {
                    Innotelli.BO.TSingletons.LookUpListProxy.UpdateCacheForOneBO(BOID);
                }

                lRtrnVal = true;
            }
            else
            {
                lRtrnVal = true;
            }

            return lRtrnVal;
        }
        #endregion

        #region Data Validation
        public virtual bool DataValid(ref string aErrorMessage)
        {
            aErrorMessage = "";
            return true;
        }
        #endregion

        #region Delete
        public virtual bool DeleteByPK(string aPK)
        {
            bool lRtrnVal = false;
            TSPrc lSPrc = new TSPrc();

            if (!string.IsNullOrEmpty(SPrps.TblName))
            {
                if (TAppSettings.ClientMode == ClientModes.ThickClient)
                {
                    lRtrnVal = lSPrc.DeleteRowByPK(SPrps.TblName, aPK);
                }
                else
                {
                    TReflectionParams lReflectionParams = new TReflectionParams();

                    lReflectionParams["aPK"] = aPK;
                    lRtrnVal = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "DeleteByPK", lReflectionParams);
                }
            }
            return lRtrnVal;
        }
        public bool DeleteByPKList(string aPKLst)
        {
            bool lRtrnVal = false;
            TSPrc lSPrc = null;

            if (!string.IsNullOrEmpty(SPrps.TblName))
            {
                if (TAppSettings.ClientMode == ClientModes.ThickClient)
                {
                    lSPrc = new TSPrc();
                    lRtrnVal = lSPrc.DeleteRowsByPKList(SPrps.TblName, aPKLst);
                }
                else
                {
                    TReflectionParams lReflectionParams = new TReflectionParams();
                    lReflectionParams["aPKLst"] = aPKLst;

                    lRtrnVal = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "DeleteByPKList", lReflectionParams);
                }
            }
            return lRtrnVal;
        }
        #endregion

        #region Field Default Value
        public virtual void SetDefaults()
        {
        }
        public virtual void BaseSetDefaults()
        {
            TSPrpsBOT01Fld lSPrpsBOT01Fld = null;
            string lItemNoFldNm = string.Empty;

            #region Parent Child Relationship
            if (!string.IsNullOrEmpty(FK) && Dt.Columns.Contains(Utilities.TGC.FKeyName))
            {
                Dr[Utilities.TGC.FKeyName] = FK;
            }
            else if (!string.IsNullOrEmpty(ParentKeyFieldName) && !string.IsNullOrEmpty(ParentKey) && Dt.Columns.Contains(ParentKeyFieldName))
            {
                Dr[ParentKeyFieldName] = ParentKey;
            }
            else if (BOT01ParentChildRel.ParentBO != null)
            {
                if (TNull.IsValueNull(BOT01ParentChildRel.ParentBO.Dr[BOT01ParentChildRel.ParentLinkFieldName]))
                {
                    Dr[Innotelli.BO.TGC.VIRTUAL_PARENT_KEY_FIELD_NAME] = BOT01ParentChildRel.ParentBO.Dr[Innotelli.BO.TGC.VIRTUAL_PRIMARY_KEY_FIELD_NAME];
                }
                else
                {
                    Dr[BOT01ParentChildRel.ChildLinkFieldName] = BOT01ParentChildRel.ParentBO.Dr[BOT01ParentChildRel.ParentLinkFieldName];
                }
            }
            #endregion

            for (int i = 0; i < SPrps.SPrpsBOT01Flds.Count; i++)
            {
                lSPrpsBOT01Fld = SPrps.SPrpsBOT01Flds[i];

                if (lSPrpsBOT01Fld.slkDftValType.HasValue)
                {
                    //TODO: Remove Try Catch
                    try
                    {
                        switch (lSPrpsBOT01Fld.slkDftValType.Value)
                        {
                            case 2: // "Const":
                                if (TStr.Left(lSPrpsBOT01Fld.DftVal, 1) == "\"" && TStr.Right(lSPrpsBOT01Fld.DftVal, 1) == "\"")
                                {
                                    Dr[lSPrpsBOT01Fld.FldNm] = TStr.Mid(lSPrpsBOT01Fld.DftVal, 1, lSPrpsBOT01Fld.DftVal.Length - 2);
                                }
                                else
                                {
                                    Dr[lSPrpsBOT01Fld.FldNm] = lSPrpsBOT01Fld.DftVal;
                                }
                                break;
                            case 7: //"SysDate":
                                Dr[lSPrpsBOT01Fld.FldNm] = TDtTm.Date(DateTime.Now.Date);
                                break;
                            case 9: //"SysTime":
                                Dr[lSPrpsBOT01Fld.FldNm] = TDtTm.Time(DateTime.Now);
                                break;
                            case 8: //"SysDT":
                                Dr[lSPrpsBOT01Fld.FldNm] = TDtTm.DateTime(DateTime.Now);
                                break;
                            case 12: //"CurUserPK":
                                #region CurUserPK
                                Dr[lSPrpsBOT01Fld.FldNm] = 1;
                                #endregion
                                break;
                            case 3: //"DftTbl":
                                #region Incomplete Later
                                //if ((lDt.Rows[i]["DftTblNm"] != null) && (lDt.Rows[i]["DftFldNm"] != null))
                                //{
                                //    Dr[lDt.Rows[i]["FldNm"].ToString()] = DLookup(lDt.Rows[i]["DftFldNm"],lDt.Rows[i]["DftTblNm"]);
                                //}
                                #endregion
                                break;
                            case 11: //"FncCrncy":
                                #region Incomplete Later
                                //Dr[lDt.Rows[i]["FldNm"].ToString()] = DLookup("slkCrncy", "Optn");
                                #endregion
                                break;
                        }
                    }
                    catch
                    {
                    }
                }
            }

            #region Init Item No
            lItemNoFldNm = SPrps.SPrpsBOT01Flds.ItemNumberFieldName;
            if (!string.IsNullOrEmpty(lItemNoFldNm))
            {
                Dr[lItemNoFldNm] = DefaultView.Count + 1;
            }
            #endregion
        }
        #endregion

        #region Calcuated Field Functions
        public virtual void AddDataColumns()
        {
            mCalColumnCollection = new ArrayList();
        }
        public void AddDataColumn(string aColumnName, Type aType)
        {
            Dt.Columns.Add(aColumnName, aType);
            mCalColumnCollection.Add(aColumnName);
        }
        public void AddDataColumn(string aColumnName, Type aType, string aExpression)
        {
            Dt.Columns.Add(aColumnName, aType, aExpression);
            mCalColumnCollection.Add(aColumnName);
        }
        public virtual void InitAllColumnValues()
        {
        }
        public virtual void ReCalcAllColumnValues()
        {
        }
        public virtual void CalcCommonValues()
        {
        }

        public void RemoveColumns(ArrayList aCalColumnCollection)
        {
            if (aCalColumnCollection != null)
            {
                for (int i = 0; i < aCalColumnCollection.Count; i++)
                {
                    Dt.Columns.Remove(aCalColumnCollection[i].ToString());
                }
            }
        }
        private void RemoveCalColumns()
        {
            RemoveColumns(mCalColumnCollection);
        }
        //public virtual void RecalAffectedColumnValues(DataColumnChangeEventArgs e)
        //{
        //}
        #endregion

        #region Field Dependency Trigger
        public virtual void DoFieldDependency(DataColumnChangeEventArgs e){}
        public virtual void SelLnkFldCopyInfo(string aLnkFldNm, object aValue)
        {
            string lCopiedTblID = string.Empty;
            string lSelObjID = string.Empty;
            TSQL lSQL = new TSQL();
            DataRow[] lDrs = null;
            DataRow lCopiedDr = null;

            if (!TNull.IsValueNull(aValue))
            {
                //TODO: Michael remove later
                if (SPrps.SPrpsBOT01Flds[aLnkFldNm] != null)
                {
                    lSelObjID = SPrps.SPrpsBOT01Flds[aLnkFldNm].SelObjID;
                    if (!string.IsNullOrEmpty(lSelObjID))
                    {
                        lCopiedTblID = Innotelli.BO.TSingletons.SPrpsBOT01s[lSelObjID].TblName;
                    }
                    if (!string.IsNullOrEmpty(lSelObjID) && !string.IsNullOrEmpty(lCopiedTblID))
                    {
                        if (Innotelli.BO.TSingletons.BOT01FldCpFldDs.Tables.Count != 0)
                        {
                            lDrs = Innotelli.BO.TSingletons.BOT01FldCpFldDs.Tables[0].Select("BOT01ID = '" + BOID + "' and LnkFldNm = '" + aLnkFldNm + "'");
                        }
                        if (lDrs != null && lDrs.Length != 0)
                        {
                            lSQL.SetStmtByTableAndPK(lCopiedTblID, aValue.ToString());
                            TDomain.LookupDataRow("*", lCopiedTblID, Innotelli.Utilities.TGC.PKeyName + " = " + aValue.ToString(), out lCopiedDr);
                            if (lCopiedDr != null)
                            {
                                for (int i = 0; i < lDrs.Length; i++)
                                {
                                    if ((lDrs[i]["CopiedFldNm"] != null) && (lDrs[i]["FldNm"] != null))
                                    {
                                        Dr[lDrs[i]["FldNm"].ToString()] = lCopiedDr[lDrs[i]["CopiedFldNm"].ToString()]; ;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        #endregion

        #region Others

        public int Sum(string aFldNm)
        {
            int lRtrnVal = 0;

            if (!IsNoRow() && Dt.Columns[aFldNm] != null)
            {
                //#check! Is Integer/Long??
                for (int i = 0; i < Dt.Rows.Count; i++)
                {
                    if (Dt.Rows[i].RowState != DataRowState.Deleted)
                    {
                        lRtrnVal += Convert.ToInt32(Dt.Rows[i][aFldNm]);
                    }
                }
            }

            return lRtrnVal;
        }
        public decimal Sum(string aFldNm, int aNoOfDecimalPlaces)
        {
            decimal lRtrnVal = 0;

            if (!IsNoRow() && Dt.Columns[aFldNm] != null)
            {
                //#check! Is Decimal/Currency??
                for (int i = 0; i < Dt.Rows.Count; i++)
                {
                    if (Dt.Rows[i].RowState != DataRowState.Deleted)
                    {
                        lRtrnVal += Convert.ToDecimal(Math.Round(Convert.ToDecimal(Dt.Rows[i][aFldNm]), aNoOfDecimalPlaces, MidpointRounding.AwayFromZero));
                    }
                }
            }

            return lRtrnVal;
        }
        //public decimal Sum(string aExp, int aNoOfDecimalPlaces)
        //{
        //    decimal lRtrnVal = 0;
        //    string lFldNm = aExp;

        //    bool lIsExp = System.Text.RegularExpressions.Regex.IsMatch(aExp, @"(\+|\-\*|\\)");

        //    if (!IsNoRow() && Dt.Columns[lFldNm] != null)
        //    {
        //        //#check! Is Decimal/Currency??
        //        for (int i = 0; i < Dt.Rows.Count; i++)
        //        {
        //            if (Dt.Rows[i].RowState != DataRowState.Deleted)
        //            {
        //                lRtrnVal += Convert.ToDecimal(TMath.Round(Convert.ToDecimal(Dt.Rows[i][lFldNm]), aNoOfDecimalPlaces));
        //            }
        //        }
        //    }

        //    return lRtrnVal;
        //}
        public int Sum(System.Data.DataColumnChangeEventArgs e)
        {
            int lRtrnVal = 0;

            if (!IsNoRow() && Dt.Columns[e.Column.ColumnName] != null)
            {
                //#check! Is Integer/Long??
                for (int i = 0; i < Dt.Rows.Count; i++)
                {
                    if (Dt.Rows[i].RowState != DataRowState.Deleted)
                    {
                        lRtrnVal += Convert.ToInt32(Dt.Rows[i][e.Column.ColumnName]);
                    }
                }
            }

            return lRtrnVal;
        }
        public decimal Sum(System.Data.DataColumnChangeEventArgs e, int aNoOfDecimalPlaces)
        {
            decimal lRtrnVal = 0;

            if (!IsNoRow() && Dt.Columns[e.Column.ColumnName] != null)
            {
                //#check! Is Decimal/Currency??
                for (int i = 0; i < Dt.Rows.Count; i++)
                {
                    if (Dt.Rows[i].RowState != DataRowState.Deleted)
                    {
                        lRtrnVal += Convert.ToDecimal(Math.Round(Convert.ToDecimal(Dt.Rows[i][e.Column.ColumnName]), aNoOfDecimalPlaces, MidpointRounding.AwayFromZero));
                    }
                }
            }

            return lRtrnVal;
        }
        #endregion

        #region Navigation
        // Not used in TForm02
        public virtual string Nav(string aOrgPK, string aDirection)
        {
            string lRtrnVal = string.Empty;
            long lNavCurPos = 0;
            long lNavRecCount = 0;

            lRtrnVal = GetNavNewPK(aOrgPK, aDirection, ref lNavCurPos, ref lNavRecCount);
            // if success
            if (!string.IsNullOrEmpty(lRtrnVal))
            {
                NavCurPos = lNavCurPos;
                NavRecCount = lNavRecCount;
                if (lRtrnVal != aOrgPK)
                {
                    PK = lRtrnVal;
                    LoadDataSet();
                }
            }
            return lRtrnVal;
        }
        // if fail, return ""
        public string GetNavNewPK(string aOrgPK, string aDirection, ref long aNavCurPos, ref long aNavRecCount)
        {
            string lRtrnVal = "";
            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                TDataObject lDao = new TDataObject();
                lDao.CmdType = CommandType.StoredProcedure;
                lDao.SQL.Stmt = "A_TB01ALL_GetNav";
                lDao.Params.AddWithValue("@TblNm", SPrps.TblName);
                if (NavCriteria != "")
                {
                    lDao.Params.AddWithValue("@Where", "WHERE " + NavCriteria);
                }
                else
                {
                    lDao.Params.AddWithValue("@Where", "");
                }
                if (NavOrderByFieldList != "")
                {
                    lDao.Params.AddWithValue("@OrderBy", "ORDER BY " + NavOrderByFieldList);
                }
                else
                {
                    lDao.Params.AddWithValue("@OrderBy", "");
                }
                lDao.Params.AddWithValue("@CurPK", aOrgPK);
                lDao.Params.AddWithValue("@Move", aDirection);
                lDao.OpenTable();
                aNavCurPos = long.Parse(lDao.Dr["CurRecNo"].ToString());
                aNavRecCount = long.Parse(lDao.Dr["TotRecNo"].ToString());
                lRtrnVal = lDao.Dr["CurPK"].ToString();
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();


                lReflectionParams["aOrgPK"] = aOrgPK;
                lReflectionParams["aDirection"] = aDirection;
                lReflectionParams["aNavCriteria"] = NavCriteria;
                lReflectionParams["aNavOrderByFieldList"] = NavOrderByFieldList;
                lReflectionParams["aNavCurPos"] = aNavCurPos;
                lReflectionParams["aNavRecCount"] = aNavRecCount;

                lRtrnVal = (string)TReflectionClient.ExecuteMethod(ClassFullName, "WSGetNavNewPK", lReflectionParams);
                aNavCurPos = int.Parse(lReflectionParams["aNavCurPos"].ToString());
                aNavRecCount = int.Parse(lReflectionParams["aNavRecCount"].ToString());
            }
            return lRtrnVal;
        }
        public string WSGetNavNewPK(string aOrgPK, string aDirection, string aNavCriteria, string aNavOrderByFieldList, ref long aNavCurPos, ref long aNavRecCount)
        {
            string lRtrnVal = "";
            TDataObject lDao = new TDataObject();
            lDao.CmdType = CommandType.StoredProcedure;
            lDao.SQL.Stmt = "A_TB01ALL_GetNav";
            lDao.Params.AddWithValue("@TblNm", SPrps.TblName);
            if (aNavCriteria != "")
            {
                lDao.Params.AddWithValue("@Where", "WHERE " + aNavCriteria);
            }
            else
            {
                lDao.Params.AddWithValue("@Where", "");
            }
            if (aNavOrderByFieldList != "")
            {
                lDao.Params.AddWithValue("@OrderBy", "ORDER BY " + aNavOrderByFieldList);
            }
            else
            {
                lDao.Params.AddWithValue("@OrderBy", "");
            }
            lDao.Params.AddWithValue("@CurPK", aOrgPK);
            lDao.Params.AddWithValue("@Move", aDirection);
            lDao.OpenTable();
            aNavCurPos = long.Parse(lDao.Dr["CurRecNo"].ToString());
            aNavRecCount = long.Parse(lDao.Dr["TotRecNo"].ToString());
            lRtrnVal = lDao.Dr["CurPK"].ToString();
            return lRtrnVal;
        }
        public void SetCurNavInfo(string aOrgPK)
        {
            long lNavCurPos = 0;
            long lNavRecCount = 0;

            GetNavNewPK(aOrgPK, "C", ref lNavCurPos, ref lNavRecCount);
            NavCurPos = lNavCurPos;
            NavRecCount = lNavRecCount;
        }
        public virtual string GetQuickFindNewPK(string aID)
        {
            string lRtrnVal = null;

            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                TDataObject lDao = new TDataObject();
                lDao.SQL.Stmt = "SELECT " + Utilities.TGC.PKeyName + " FROM " + SPrps.TblName + " WHERE " + SPrps.SPrpsBOT01Flds.SKeyFieldName + " = '" + aID + "'";
                lDao.OpenTable();
                if (!lDao.IsNoRow())
                {
                    lRtrnVal = lDao.Dr[Utilities.TGC.PKeyName].ToString();
                }
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["aID"] = aID;
                lRtrnVal = (string)TReflectionClient.ExecuteMethod(ClassFullName, "WSGetQuickFindNewPK", lReflectionParams);
            }
            return lRtrnVal;
        }
        public virtual string WSGetQuickFindNewPK(string aID)
        {
            string lRtrnVal = null;
            TDataObject lDao = new TDataObject();
            lDao.SQL.Stmt = "SELECT " + Utilities.TGC.PKeyName + " FROM " + SPrps.TblName + " WHERE " + SPrps.SPrpsBOT01Flds.SKeyFieldName + " = '" + aID + "'";
            lDao.OpenTable();
            if (!lDao.IsNoRow())
            {
                lRtrnVal = lDao.Dr[Utilities.TGC.PKeyName].ToString();
            }
            return lRtrnVal;
        }
        #endregion

        #region Refreshed Row
        public DataTable GetRefreshedTable()
        {
            DataTable lRtrnVal = null;
            TDataObject lDao = null;
            DataSet lRowDs = new DataSet();
            DataTable lDt = null;
            DataRow lDr = null;
            StringBuilder lSb = new StringBuilder();
            string lMainViewSQLStmt = string.Empty;

            lRowDs.DataSetName = "DataSet";
            if (RefreshedRowFieldList != "")
            {
                lDt = Dt.Clone();
                lDr = lDt.NewRow();
                lDr.ItemArray = Dr.Row.ItemArray;
                lDt.Rows.Add(lDr);
                lRowDs.Tables.Add(lDt);

                if (TAppSettings.ClientMode == ClientModes.ThickClient)
                {
                    lDao = new TDataObject();
                    lDao.CmdType = CommandType.Text;
                    lSb.AppendLine("DECLARE @DocHandle int;");
                    lSb.AppendLine("EXEC sp_xml_preparedocument @DocHandle OUTPUT, '" + TXML.Reformat(lRowDs.GetXml()) + "';");
                    lSb.AppendLine("SELECT * INTO #TMP01");
                    lSb.AppendLine("FROM");
                    lSb.AppendLine("OPENXML(@DocHandle,'" + "/DataSet/" + BOID + @"',2) ");
                    lSb.AppendLine("WITH");
                    lSb.AppendLine("(" + Innotelli.BO.TSingletons.SPrpsTbls[SPrps.TblName].FieldList01 + ")");
                    lSb.AppendLine("EXEC sp_xml_removedocument @DocHandle;");
                    lMainViewSQLStmt = SPrps.MainViewSQLStmt + ";";
                    lMainViewSQLStmt = TStr.ReplaceWithWordBoundary(lMainViewSQLStmt, SPrps.TblName, "#TMP01");
                    lSb.AppendLine(lMainViewSQLStmt);
                    lDao.SQL.Stmt = lSb.ToString();
                    lDao.OpenTable();
                    if (!lDao.IsNoRow())
                    {
                        lRtrnVal = lDao.Dt;
                    }
                }
                else
                {
                    TReflectionParams lReflectionParams = new TReflectionParams();
                    DataSet lDs = null;
                    lReflectionParams["aRowDs"] = lRowDs;
                    lDs = (DataSet)TReflectionClient.ExecuteMethod(ClassFullName, "WSGetRefreshedDataSet", lReflectionParams);
                    if (lDs != null && lDs.Tables.Count == 1)
                    {
                        lRtrnVal = lDs.Tables[0];
                        lDs.Tables.Remove(lRtrnVal);
                    }
                }
            }
            return lRtrnVal;
        }
        private void UpdateRefreshedRow()
        {
            DataTable lRefreshedDt = null;
            DataColumn lDc = null;

            lRefreshedDt = GetRefreshedTable();
            if (lRefreshedDt != null && lRefreshedDt.Rows.Count == 1)
            {
                for (int i = 0; i < lRefreshedDt.Columns.Count; i++)
                {
                    lDc = lRefreshedDt.Columns[i];
                    Dr[lDc.ColumnName] = lRefreshedDt.Rows[0][lDc.ColumnName];
                }
            }
        }
        private bool InRefreshedRowTriggerFieldList(string aFieldName)
        {
            bool lRtrnVal = false;
            string[] lFieldNames = RefreshedRowTriggerFieldList.Split(',');

            for (int i = 0; i < lFieldNames.Length; i++)
            {
                if (aFieldName == lFieldNames[i].Trim())
                {
                    lRtrnVal = true;
                    break;
                }
            }
            return lRtrnVal;
        }
        public DataSet WSGetRefreshedDataSet(DataSet aRowDs)
        {
            DataSet lRtrnVal = new DataSet();
            StringBuilder lSb = new StringBuilder();
            TDataObject lDao = new TDataObject();
            string lMainViewSQLStmt = string.Empty;

            lDao = new TDataObject();
            lDao.CmdType = CommandType.Text;
            lSb.AppendLine("DECLARE @DocHandle int;");
            lSb.AppendLine("EXEC sp_xml_preparedocument @DocHandle OUTPUT, N'<?xml version=\"1.0\" encoding=\"utf-16\"?>" + TXML.Reformat(aRowDs.GetXml()).Replace("\'", "\'\'") + "';");
            lSb.AppendLine("SELECT * INTO #TMP01");
            lSb.AppendLine("FROM");
            lSb.AppendLine("OPENXML(@DocHandle,'" + "/DataSet/" + BOID + @"',2) ");
            lSb.AppendLine("WITH");
            lSb.AppendLine("(" + Innotelli.BO.TSingletons.SPrpsTbls[SPrps.TblName].FieldList01 + ")");
            lSb.AppendLine("EXEC sp_xml_removedocument @DocHandle;");
            lMainViewSQLStmt = SPrps.MainViewSQLStmt + ";";
            lMainViewSQLStmt = TStr.ReplaceWithWordBoundary(lMainViewSQLStmt, SPrps.TblName, "#TMP01");
            lSb.AppendLine(lMainViewSQLStmt);
            lDao.SQL.Stmt = lSb.ToString();
            lDao.OpenTable();
            if (!lDao.IsNoRow())
            {
                lRtrnVal.Tables.Add(lDao.Dt);
            }

            return lRtrnVal;
        }
        #endregion

        #region Parent Child Relationship
        public void AddChild(TBOT01 aBOT01, string aParentKeyFieldName)
        {
            aBOT01.BOT01ParentChildRel.ParentBO = this;
            aBOT01.BOT01ParentChildRel.ParentLinkFieldName = Innotelli.Utilities.TGC.PKeyName;
            aBOT01.BOT01ParentChildRel.ChildLinkFieldName = aParentKeyFieldName;            
            Childern.Add(aBOT01);
            OnBOActiveRowChanged += new BOActiveRowChangedEventHandler(aBOT01.ParentBO_OnBOActiveRowChanged);
        }
        #endregion

        #region LookUpList
        public virtual string GetLookUpListRowFilter(string aColumnName)
        {
            return string.Empty;
        }
        #endregion

        public virtual void InitForReuse()
        {
            mPK = null;
            BOT01ParentChildRel.ParentBO = null;
            mParentKey = null;
            mParentKeyFieldName = "";
            mFK = null;
            //#check!
            // may need to add child code
        }
        #endregion

        #region Backup
        private void LoadByXML(string aXML)
        {
            DataSet lDs = new DataSet();
            TextReader lTr = new StringReader(aXML);
            lDs.ReadXml(lTr);
            lTr.Close();
            Dt = lDs.Tables[0].Copy();
        }
        #endregion
    }
}
