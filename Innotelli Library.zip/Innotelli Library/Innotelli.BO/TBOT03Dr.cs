﻿using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public class TBOT03Dr
    {
        #region Properties
        private TDataRow mDr;
        public TDataRow Dr
        {
            get
            {
                return mDr;
            }
            set
            {
                mDr = value;
            }
        }
        public TDbRowID prmykey
        {
            get
            {
                return (int?)Dr["prmykey"];
            }
        }
        public TDbRowID prntkey
        {
            get
            {
                return (int?)Dr["prntkey"];
            }
            set
            {
                Dr["prntkey"] = value;
            }
        }
        public object this[string aColumnName]
        {
            get
            {
                return Dr[aColumnName];
            }
        }
        #endregion
    }
}
