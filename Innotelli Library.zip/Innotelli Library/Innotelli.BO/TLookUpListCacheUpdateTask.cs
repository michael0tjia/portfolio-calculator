using System;
using System.Data;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public class TLookUpListCacheUpdateTask : TThreadWrapperBase
    {
        #region Members
        TLookUpListProxy mLookUpListProxy = Innotelli.BO.TSingletons.LookUpListProxy;
        #endregion

        #region Constructors
        public TLookUpListCacheUpdateTask()
        {
            CancelWaitTime = TimeSpan.FromSeconds(5);
        }
        #endregion

        #region Functions
        protected override void DoTask()
        {
            //Do not remove try catch       
            try
            {
                mLookUpListProxy.UpdateLookUpLists();
            }
            catch(Exception ex)
            {
                TAppLog.LogException(ex);
            }
        }
        #endregion
    }
}
