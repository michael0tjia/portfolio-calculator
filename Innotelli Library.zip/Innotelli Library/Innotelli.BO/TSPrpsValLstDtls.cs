﻿using System.Collections;
using System.Data;

namespace Innotelli.BO
{
    public class TSPrpsValLstDtls
    {
        #region Enums
        #endregion

        #region Members
        private string mValLstPK = string.Empty;
        private DataTable mDt = null;
        private Hashtable[] mSPrpsValLstDtlHTs = null;
        public object mLocker = new object();
        #endregion

        #region Constructors
        public TSPrpsValLstDtls(string aValLstPK)
        {
            DataView lDv = new DataView();

            mValLstPK = aValLstPK;
            mSPrpsValLstDtlHTs = new Hashtable[2];
            mSPrpsValLstDtlHTs[0] = new Hashtable();
            mSPrpsValLstDtlHTs[1] = new Hashtable();
            lDv.Table = ValLstDtlDt;
            lDv.RowFilter = Innotelli.Utilities.TGC.FKeyName +  " = " + mValLstPK;
            mDt = lDv.ToTable();
        }
        #endregion

        #region Properties
        private static DataTable mValLstDtlDt = null;
        public static DataTable ValLstDtlDt
        {
            get
            {
                if (mValLstDtlDt == null)
                {
                    mValLstDtlDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("ValLstDtl").Tables[0];
                }
                return mValLstDtlDt;
            }
        }
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }
        public int Count
        {
            get
            {
                return mDt.Rows.Count;
            }
        }
        public TSPrpsValLstDtl this[int aRowIndex]
        {
            get
            {
                TSPrpsValLstDtl lReturnValue = null;
                TSPrpsValLstDtl lSPrpsValLstDtl = null;

                lock (mLocker)
                {
                    if (mSPrpsValLstDtlHTs[0][aRowIndex] == null)
                    {
                        mSPrpsValLstDtlHTs[0][aRowIndex] = new TSPrpsValLstDtl();
                    }
                }
                lSPrpsValLstDtl = (TSPrpsValLstDtl)mSPrpsValLstDtlHTs[0][aRowIndex];
                lSPrpsValLstDtl.Dr = mDt.Rows[aRowIndex];
                lReturnValue = lSPrpsValLstDtl;

                return lReturnValue;
            }
        }
        public TSPrpsValLstDtl this[string aVal]
        {
            get
            {
                TSPrpsValLstDtl lReturnValue = null;
                TSPrpsValLstDtl lSPrpsValLstDtl = null;
                DataRow[] lDrs = null;

                lock (mLocker)
                {
                    if (mSPrpsValLstDtlHTs[1][aVal] == null)
                    {
                        mSPrpsValLstDtlHTs[1][aVal] = new TSPrpsValLstDtl();
                    }
                }
                lSPrpsValLstDtl = (TSPrpsValLstDtl)mSPrpsValLstDtlHTs[1][aVal];
                lDrs = mDt.Select("Val = " + aVal);
                if (lDrs.Length != 0)
                {
                    lSPrpsValLstDtl.Dr = lDrs[0];
                    lReturnValue = lSPrpsValLstDtl;
                }

                return lReturnValue;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}
