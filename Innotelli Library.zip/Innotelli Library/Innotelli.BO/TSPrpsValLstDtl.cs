﻿using System;
using System.ComponentModel;
using System.Data;

namespace Innotelli.BO
{
    public class TSPrpsValLstDtl
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        #endregion

        #region Properties
        private DataRow mDr;
        public DataRow Dr
        {
            get
            {
                return mDr;
            }
            set
            {
                mDr = value;
            }
        }
        public DateTime? DCreated
        {
            get
            {
                if (Dr["DCreated"] == null)
                {
                    return null;
                }
                return DateTime.Parse(Dr["DCreated"].ToString());
            }
            set
            {
                if (value == null)
                {
                    Dr["DCreated"] = null;
                }
                else
                {
                    Dr["DCreated"] = value;
                }
            }
        }
        public DateTime? DModified
        {
            get
            {
                if (Dr["DModified"] == null)
                {
                    return null;
                }
                return DateTime.Parse(Dr["DModified"].ToString());
            }
            set
            {
                if (value == null)
                {
                    Dr["DModified"] = null;
                }
                else
                {
                    Dr["DModified"] = value;
                }
            }
        }
        public string DsplyVal01
        {
            get
            {
                if (Dr["DsplyVal01"] == null)
                {
                    return null;
                }
                return Dr["DsplyVal01"].ToString();
            }
            set
            {
                if (value == null)
                {
                    Dr["DsplyVal01"] = null;
                }
                else
                {
                    Dr["DsplyVal01"] = value;
                }
            }
        }
        public string DsplyVal02
        {
            get
            {
                if (Dr["DsplyVal02"] == null)
                {
                    return null;
                }
                return Dr["DsplyVal02"].ToString();
            }
            set
            {
                if (value == null)
                {
                    Dr["DsplyVal02"] = null;
                }
                else
                {
                    Dr["DsplyVal02"] = value;
                }
            }
        }
        public string EditUser
        {
            get
            {
                if (Dr["EditUser"] == null)
                {
                    return null;
                }
                return Dr["EditUser"].ToString();
            }
            set
            {
                if (value == null)
                {
                    Dr["EditUser"] = null;
                }
                else
                {
                    Dr["EditUser"] = value;
                }
            }
        }
        public bool? InEdit
        {
            get
            {
                if (Dr["InEdit"] == null)
                {
                    return null;
                }
                return bool.Parse(Dr["InEdit"].ToString());
            }
            set
            {
                if (value == null)
                {
                    Dr["InEdit"] = null;
                }
                else
                {
                    Dr["InEdit"] = value;
                }
            }
        }
        public string prmykey
        {
            get
            {
                return Dr["prmykey"].ToString();
            }
            set
            {
                Dr["prmykey"] = value;
            }
        }
        public string prntkey
        {
            get
            {
                return Dr["prntkey"].ToString();
            }
            set
            {
                Dr["prntkey"] = value;
            }
        }
        public DateTime? TCreated
        {
            get
            {
                if (Dr["TCreated"] == null)
                {
                    return null;
                }
                return DateTime.Parse(Dr["TCreated"].ToString());
            }
            set
            {
                if (value == null)
                {
                    Dr["TCreated"] = null;
                }
                else
                {
                    Dr["TCreated"] = value;
                }
            }
        }
        public DateTime? TModified
        {
            get
            {
                if (Dr["TModified"] == null)
                {
                    return null;
                }
                return DateTime.Parse(Dr["TModified"].ToString());
            }
            set
            {
                if (value == null)
                {
                    Dr["TModified"] = null;
                }
                else
                {
                    Dr["TModified"] = value;
                }
            }
        }
        public string UCreated
        {
            get
            {
                if (Dr["UCreated"] == null)
                {
                    return null;
                }
                return Dr["UCreated"].ToString();
            }
            set
            {
                if (value == null)
                {
                    Dr["UCreated"] = null;
                }
                else
                {
                    Dr["UCreated"] = value;
                }
            }
        }
        public string UModified
        {
            get
            {
                if (Dr["UModified"] == null)
                {
                    return null;
                }
                return Dr["UModified"].ToString();
            }
            set
            {
                if (value == null)
                {
                    Dr["UModified"] = null;
                }
                else
                {
                    Dr["UModified"] = value;
                }
            }
        }
        public string Val
        {
            get
            {
                return Dr["Val"].ToString();
            }
            set
            {
                Dr["Val"] = value;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion

    }
}

