﻿using System;
using System.ComponentModel;
using System.Data;
using Innotelli.Utilities;
using Innotelli.Db;

namespace Innotelli.BO
{
    public class TSPrpsBOT06Fld
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        #endregion

        #region Properties
        private TDataRow mDr;
        public TDataRow Dr
        {
            get
            {
                return mDr;
            }
            set
            {
                mDr = value;
            }
        }

        #region Generated Properties
        public double Sort
        {
            get
            {
                return (double)Dr["Sort"];
            }
        }
        public bool PKey
        {
            get
            {
                return (bool)Dr["PKey"];
            }
        }
        public bool SKey
        {
            get
            {
                return (bool)Dr["SKey"];
            }
        }
        public string FldNm
        {
            get
            {
                return (string)Dr["FldNm"];
            }
        }
        public string FldAls
        {
            get
            {
                return (string)Dr["FldAls"];
            }
        }
        public string SelObjID
        {
            get
            {
                return (string)Dr["SelObjID"];
            }
        }
        public TDbRowID slkValLst
        {
            get
            {
                return (int?)Dr["slkValLst"];
            }
        }
        public int ValLstBndCol
        {
            get
            {
                return (int)Dr["ValLstBndCol"];
            }
        }
        public int? FldSize
        {
            get
            {
                return (int?)Dr["FldSize"];
            }
        }
        public bool Required
        {
            get
            {
                return (bool)Dr["Required"];
            }
        }
        public TDbRowID slkDftValType
        {
            get
            {
                return (int?)Dr["slkDftValType"];
            }
        }
        public string DftVal
        {
            get
            {
                return (string)Dr["DftVal"];
            }
        }
        public TDbRowID slkDftTbl
        {
            get
            {
                return (int?)Dr["slkDftTbl"];
            }
        }
        public string DftTblNm
        {
            get
            {
                return (string)Dr["DftTblNm"];
            }
        }
        public string DftFldNm
        {
            get
            {
                return (string)Dr["DftFldNm"];
            }
        }
        public string DftFldNm02
        {
            get
            {
                return (string)Dr["DftFldNm02"];
            }
        }
        public bool DupCp
        {
            get
            {
                return (bool)Dr["DupCp"];
            }
        }
        public TDbRowID slkSimpleFld
        {
            get
            {
                return (int?)Dr["slkSimpleFld"];
            }
        }
        public string SourceTbl
        {
            get
            {
                return (string)Dr["SourceTbl"];
            }
        }
        public string SourceFld
        {
            get
            {
                return (string)Dr["SourceFld"];
            }
        }
        public string Comment
        {
            get
            {
                return (string)Dr["Comment"];
            }
        }
        #endregion

        public ProjectedAttributeType AttributeType
        {
            get
            {
                return (ProjectedAttributeType)Dr["AttributeType"];
            }
        }
        public SimpleDataType SimpleDataType
        {
            get
            {
                return (SimpleDataType)(Dr["slkFldType"]);
            }
        }
        public SimpleDataTypeCat1s SimpleDataTypeCat1
        {
            get
            {
                return TSimpleDataType.GetCat1(SimpleDataType);
            }
        }

        public bool IsReadOnly
        {
            get
            {
                bool lReturnValue = false;

                lReturnValue = ((SimpleDataType == SimpleDataType.ItemNumber) || (AttributeType != ProjectedAttributeType.Normal));

                return lReturnValue;
            }
        }
        public bool IsNumeric
        {
            get
            {
                bool lReturnValue = false;

                switch (SimpleDataTypeCat1)
                {
                    case SimpleDataTypeCat1s.Integer:
                    case SimpleDataTypeCat1s.PreciseReal:
                    case SimpleDataTypeCat1s.UnpreciseReal:
                        lReturnValue = true;
                        break;
                    default:
                        lReturnValue = false;
                        break;
                }

                return lReturnValue;
            }
        }
        public bool IsDateTime
        {
            get
            {
                return (SimpleDataTypeCat1 == SimpleDataTypeCat1s.DateTime);
            }
        }

        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion

    }
}

