using System.Data;
using Innotelli.Db;

namespace Innotelli.BO
{
    public abstract class TBOT05
    {
        #region Members
        private TBOT06 mBOT06 = null;
        private TDataObject mDao = new TDataObject();

        #endregion

        #region Constructors
        public TBOT05()
        {
        }
        #endregion

        #region Properties
        public string ClassFullName
        {
            get
            {
                return this.GetType().Namespace + "." + this.GetType().Name;
            }
        }
        public string BOID
        {
            get
            {
                return this.GetType().Name;
            }
        }
        public DataTable Dt
        {
            get
            {
                return mDao.Dt;
            }
            set
            {
                mDao.Dt = value;
            }
        }
        public TDataRow Dr
        {
            get
            {
                return mDao.Dr;
            }
            set
            {
                mDao.Dr = value;
            }
        }
        public TBOT06 BOT06
        {
            get
            {
                return mBOT06;
            }
            set
            {
                mBOT06 = value;
            }
        }
        #endregion

        #region Functions
        public virtual void Prepare()
        {
        }
        public virtual bool Process()
        {
            bool lReturnValue = false;
            return lReturnValue;
        }
        #endregion
    }
}