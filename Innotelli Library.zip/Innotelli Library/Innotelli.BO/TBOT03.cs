using System.Data;
using Innotelli.Db;

namespace Innotelli.BO
{
    public abstract class TBOT03 : TBOBaseT01
    {
        #region Members
        #endregion

        #region Constructors
        public TBOT03()
        {
        }
        #endregion

        #region Properties
        public string DefaultViewName
        {
            get
            {
                return "A_" + BOID + "_DefaultView";
            }
        }
        private string mFilter = "";
        public string Filter
        {
            get
            {
                return mFilter;
            }
            set
            {
                mFilter = value;
            }
        }
        private TBOT04 mBOT04 = null;
        public TBOT04 BOT04
        {
            get
            {
                return mBOT04;
            }
            set
            {
                mBOT04 = value;
            }
        }
        #endregion

        #region Functions
        public virtual void LoadDataSet()
        {
            Dao.SQL.Stmt = "SELECT * FROM " + DefaultViewName;
            if (!string.IsNullOrEmpty(Filter))
            {
                Dao.SQL.AddToWhereClause(Filter);
            }
            Dao.OpenTable();
            Dao.Dt.TableName = BOID;
            AssignDtEventHandlers();
        }
        public virtual void Prepare()
        {
            LoadDataSet();
            BOT04.LoadDataSet();
        }
        public virtual bool Process()
        {
            bool lReturnValue = false;
            lReturnValue = mBOT04.RemoveCalColumns();
            return lReturnValue;
        }
        #endregion
    }
}