﻿using System.Collections;
using System.Data;

namespace Innotelli.BO
{
    public class TSPrpsTbls
    {
        #region Enums
        #endregion

        #region Members
        private DataTable mDt = null;
        private Hashtable[] mSPrpsTblHTs = null;
        public object mLocker = new object();
        #endregion

        #region Constructors
        public TSPrpsTbls()
        {
            mSPrpsTblHTs = new Hashtable[1];
            mSPrpsTblHTs[0] = new Hashtable();
            mDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("Tbl").Tables[0];
        }
        #endregion

        #region Properties
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }
        public int Count
        {
            get
            {
                return mDt.Rows.Count;
            }
        }
        public TSPrpsTbl this[string TblName]
        {
            get
            {
                TSPrpsTbl lReturnValue = null;
                DataRow[] lDrs = null;

                lock (mLocker)
                {
                    if (mSPrpsTblHTs[0][TblName] == null)
                    {
                        lDrs = mDt.Select("TblID = '" + TblName + "'");
                        if (lDrs.Length != 0)
                        {
                            mSPrpsTblHTs[0][TblName] = new TSPrpsTbl(lDrs[0]);
                        }
                    }
                }
                lReturnValue = (TSPrpsTbl)mSPrpsTblHTs[0][TblName];

                return lReturnValue;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}