﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Principal;
using System.Globalization;
using System.Collections;

namespace Innotelli.BO
{
    public class TUserIdentity : IIdentity
    {
        private static string mUserNameKey = "UserName";

        private static string mAuthenticationTypeString = "Database";

        private Hashtable mUserInfo;

        private TUserIdentity()
        {
        }

        private TUserIdentity(Hashtable aUserInfo)
        {
            this.mUserInfo = aUserInfo;
        }

        public static TUserIdentity CreateUserIdentity(Hashtable aUserInfo)
        {
            return new TUserIdentity(aUserInfo);
        }

        public string AuthenticationType
        {
            get
            {
                return mAuthenticationTypeString;
            }
        }

        public bool IsAuthenticated
        {
            get
            {
                return true;
            }
        }

        public string Name
        {
            get
            {
                return Convert.ToString(mUserInfo[mUserNameKey], CultureInfo.InvariantCulture).Trim();
            }
        }

        public string[] GetPropertyNames()
        {
            string[] PropertyNames = new string[mUserInfo.Count];
            int Count = 0;

            foreach (object Key in mUserInfo.Keys)
                PropertyNames[Count++] = (string)Key;

            return PropertyNames;
        }

        public string GetProperty(string aPropertyName)
        {
            return Convert.ToString(mUserInfo[aPropertyName], CultureInfo.InvariantCulture);
        }

        public void SetProperty(string aPropertyName, string aPropertyValue)
        {
            mUserInfo[aPropertyName] = aPropertyValue;
        }
    }
}
