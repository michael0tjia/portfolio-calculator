using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Text;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public static class TRowLock
    {
        public static string ClassFullName
        {
            get
            {
                return "Innotelli.BO.TRowLock";
            }
        }
        public static bool IsRowLock(string aTblNm, string aRowPK)
        {
            bool lReturnValue = true;
            DateTime lTmStmp = System.DateTime.Now;
            string lRowLockPK = null;
            TimeSpan lTimeDiff;

            lReturnValue = TDomain.Lookup("TmStmp", "RowLock", "TblNm = '" + aTblNm + "' and RowPK = " + aRowPK, out lTmStmp);
            if (lReturnValue)
            {
                lTimeDiff = System.DateTime.Now.Subtract(lTmStmp);

                if ((lTimeDiff.TotalMinutes) > TAppSettings.RowLockTimeOutMin)
                {
                    TDomain.LookupPK("RowLock", "TblNm = '" + aTblNm + "' and RowPK = " + aRowPK, out lRowLockPK);
                    DeleteRowLock(lRowLockPK);
                    lReturnValue = false;
                }
                else
                {
                    lReturnValue = true;
                }
            }
            return lReturnValue;
        }
        // This TmStmp is different from SQL Server TimeStamp

        public static bool AddRowLock(string aTblNm, string aRowPK, DateTime aTmStmp)
        {
            bool lReturnValue = false;
            TDataObject lDao = new TDataObject();

            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                lDao = new TDataObject();
                lDao.SQL.SetEmptyStmtByTable("RowLock");
                lDao.OpenTable();
                lDao.AddNewRow();
                lDao.Dr["TblNm"] = aTblNm;
                lDao.Dr["RowPK"] = aRowPK;
                lDao.Dr["TmStmp"] = TDtTm.DateTime(aTmStmp);
                lDao.UpdateRows();

                lReturnValue = true;
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();

                lReflectionParams["aTblNm"] = aTblNm;
                lReflectionParams["aRowPK"] = aRowPK;
                lReflectionParams["aTmStmp"] = aTmStmp;
                lReturnValue = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "AddRowLock", lReflectionParams);
            }

            return lReturnValue;
        }
        public static bool DeleteRowLock(string aPK)
        {
            bool lReturnValue = false;
            TSPrc lSPrc = new TSPrc();

            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                lReturnValue = lSPrc.DeleteRowByPK("RowLock", aPK);
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();

                lReflectionParams["aPK"] = aPK;
                lReturnValue = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "DeleteRowLock", lReflectionParams);
            }
            return lReturnValue;
        }

        public static bool CreateLock(string aTblNm, string aRowPK, ref string aPK, ref string aUserID)
        {

            TDataObject lDao = new TDataObject();
            DateTime lTmStmp = System.DateTime.Today;
            bool lReturnValue = false;

            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                lDao.SQL.Stmt = "SELECT * FROM RowLock WHERE TblNm = '" + aTblNm + "' AND RowPK = " + aRowPK;
                lDao.OpenTable();
                if (lDao.IsNoRow())
                {
                    lDao.AddNewRow();
                    lDao.Dr["TblNm"] = aTblNm;
                    lDao.Dr["RowPK"] = aRowPK;
                    lDao.Dr["TmStmp"] = TDtTm.DateTime(System.DateTime.Now);
                    lDao.Dr["slkUser"] = TCurrentUser.PK;
                    lDao.UpdateRows();
                    aPK = lDao.Dr[Innotelli.Utilities.TGC.PKeyName].ToString();
                    lReturnValue = true;
                }
                else
                {
                    aPK = lDao.Dr[Innotelli.Utilities.TGC.PKeyName].ToString();
                    lTmStmp = DateTime.Parse(lDao.Dr["TmStmp"].ToString());
                    TimeSpan lTimeDiff = DateTime.Now - lTmStmp;
                    if (lTimeDiff.TotalMinutes >= 5)
                    {
                        lDao.Dr["TmStmp"] = TDtTm.DateTime(System.DateTime.Now);
                        lDao.Dr["slkUser"] = TCurrentUser.PK;
                        lDao.UpdateRows();
                        lReturnValue = true;
                    }
                    else
                    {
                        TDomain.Lookup("UserID", "User", "prmykey = " + int.Parse(lDao.Dr["slkUser"].ToString()), out aUserID);
                        lReturnValue = false;
                    }
                }
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();

                lReflectionParams["aTblNm"] = aTblNm;
                lReflectionParams["aRowPK"] = aRowPK;
                if (aPK == null)
                {
                    aPK = "";
                }
                lReflectionParams["aPK"] = aPK;
                lReflectionParams["aUserID"] = aUserID;
                lReturnValue = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "CreateLock", lReflectionParams);
                aPK = (string)lReflectionParams["aPK"];
                aUserID = (string)lReflectionParams["aUserID"];
                if (aPK == "")
                {
                    aPK = null;
                }

            }
            
            return lReturnValue;
        }


        public static bool RefreshLock(string aTblNm, string aRowPK, ref string aPK)
        {
            TDataObject lDao = new TDataObject();
            bool lReturnValue = false;

            if (TAppSettings.ClientMode == ClientModes.ThickClient)
            {
                lDao.SQL.Stmt = "SELECT * FROM RowLock WHERE prmykey  = " + int.Parse(aPK);
                lDao.OpenTable();
                if (!lDao.IsNoRow())
                {
                    lDao.Dr["TmStmp"] = TDtTm.Time(System.DateTime.Now);
                    lDao.Dr["slkUser"] = TCurrentUser.PK;
                    lDao.UpdateRows();
                }
                else
                {
                    lDao.AddNewRow();
                    lDao.Dr["TblNm"] = aTblNm;
                    lDao.Dr["RowPK"] = aRowPK;
                    lDao.Dr["TmStmp"] = TDtTm.Time(System.DateTime.Now);
                    lDao.Dr["slkUser"] = TCurrentUser.PK;
                    lDao.UpdateRows();
                }
                aPK = lDao.Dr[Innotelli.Utilities.TGC.PKeyName].ToString();
                lReturnValue = true;
            }
            else
            {
                TReflectionParams lReflectionParams = new TReflectionParams();
                lReflectionParams["aTblNm"] = aTblNm;
                lReflectionParams["aRowPK"] = aRowPK;
                lReflectionParams["aPK"] = aPK;
                lReturnValue = (bool)TReflectionClient.ExecuteMethod(ClassFullName, "RefreshLock", lReflectionParams);
            }

            return lReturnValue;

        }

    }

}

