﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using Innotelli.Db;

namespace Innotelli.BO
{
    public class TBOT03Rows<T> where T : TBOT03Dr, new()
    {
        #region Members
        private Dictionary<int, T> mBOT03DrsDict = new Dictionary<int, T>();
        private TBOT03 mBOT03 = null;
        #endregion

        #region Constructors
        public TBOT03Rows(TBOT03 aBOT03)
        {
            mBOT03 = aBOT03;
        }
        #endregion

        #region Properties

        public int Count
        {
            get
            {
                return mBOT03.DefaultView.Count;
            }
        }
        #endregion

        #region Functions
        public T this[int aRowIndex]
        {
            get
            {
                T lReturnValue = default(T);

                if (!mBOT03DrsDict.TryGetValue(aRowIndex, out lReturnValue))
                {
                    mBOT03DrsDict.Add(aRowIndex, new T());
                    lReturnValue = (T)mBOT03DrsDict[aRowIndex];
                }
                lReturnValue.Dr = mBOT03.DefaultView[aRowIndex].Row;

                return lReturnValue;
            }
        }

        #endregion
    }
}
