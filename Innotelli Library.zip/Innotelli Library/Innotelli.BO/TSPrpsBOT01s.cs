﻿using System.Collections;
using System.Data;

namespace Innotelli.BO
{
    public class TSPrpsBOT01s
    {
        #region Enums
        #endregion

        #region Members
        private DataTable mDt = null;
        private Hashtable[] mSPrpsBOT01HTs = null;
        public object mLocker = new object();
        #endregion

        #region Constructors
        public TSPrpsBOT01s()
        {
            mSPrpsBOT01HTs = new Hashtable[2];
            mSPrpsBOT01HTs[0] = new Hashtable();
            mSPrpsBOT01HTs[1] = new Hashtable();
            mDt = Innotelli.Utilities.TSingletons.SysData01Rdr.GetSysData("BOT01").Tables[0];
        }
        #endregion

        #region Properties
        public DataTable Dt
        {
            get
            {
                return mDt;
            }
        }
        public int Count
        {
            get
            {
                return mDt.Rows.Count;
            }
        }
        public TSPrpsBOT01 this[int aRowIndex]
        {
            get
            {
                TSPrpsBOT01 lReturnValue = null;

                lock (mLocker)
                {
                    if (mSPrpsBOT01HTs[0][aRowIndex] == null)
                    {
                        mSPrpsBOT01HTs[0][aRowIndex] = new TSPrpsBOT01(mDt.Rows[aRowIndex]);
                        lReturnValue = (TSPrpsBOT01)mSPrpsBOT01HTs[0][aRowIndex];
                    }
                    else
                    {
                        lReturnValue = (TSPrpsBOT01)mSPrpsBOT01HTs[0][aRowIndex];
                        lReturnValue.Dr = mDt.Rows[aRowIndex];
                    }
                }
                return lReturnValue;
            }
        }
        public TSPrpsBOT01 this[string aBOID]
        {
            get
            {
                TSPrpsBOT01 lReturnValue = null;
                DataRow[] lDrs = null;

                lock (mLocker)
                {
                    lDrs = mDt.Select("BOT01ID = '" + aBOID + "'");
                    if (lDrs.Length != 0)
                    {
                        if (mSPrpsBOT01HTs[1][aBOID] == null)
                        {
                            mSPrpsBOT01HTs[1][aBOID] = new TSPrpsBOT01(lDrs[0]);
                            lReturnValue = (TSPrpsBOT01)mSPrpsBOT01HTs[1][aBOID];
                        }
                        else
                        {
                            lReturnValue = (TSPrpsBOT01)mSPrpsBOT01HTs[1][aBOID];
                            lReturnValue.Dr = lDrs[0];
                        }
                    }
                }    
                                    
                return lReturnValue;
            }
        }
        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}