using System;
using System.Data;
using Innotelli.Db;
using Innotelli.Utilities;

namespace Innotelli.BO
{
    public class TSPrpsBOT03
    {
        #region Enums
        #endregion

        #region Members
        #endregion

        #region Constructors
        public TSPrpsBOT03(TDataRow aDr)
        {
            mDr = aDr;
            mBOID = BOT03ID;
            mSPrpsBOT03Flds = new TSPrpsBOT03Flds(mBOID);
        }
        #endregion

        #region Properties
        private string mBOID = string.Empty;
        public string BOID
        {
            get
            {
                return mBOID;
            }
        }
        private TDataRow mDr = null;
        public TDataRow Dr
        {
            set
            {
                mDr = value;
            }
        }
        private TSPrpsBOT03Flds mSPrpsBOT03Flds = null;
        public TSPrpsBOT03Flds SPrpsBOT03Flds
        {
            get
            {
                return mSPrpsBOT03Flds;
            }
        }

        #region UI
        #endregion

        #region System Generated
        public string BOT03ID
        {
            get
            {
                return (string)mDr["BOT03ID"];
            }
            set
            {
                mDr["BOT03ID"] = value;
            }
        }
        public string MainViewSQLStmt
        {
            get
            {
                return (string)mDr["MainViewSQLStmt"];
            }
            set
            {
                mDr["MainViewSQLStmt"] = value;
            }
        }
        public string MainViewSQLLayout
        {
            get
            {
                return (string)mDr["MainViewSQLLayout"];
            }
            set
            {
                mDr["MainViewSQLLayout"] = value;
            }
        }

        public string BONameSpace
        {
            get
            {
                return (string)mDr["BONameSpace"];
            }
        }
        public string UINameSpace
        {
            get
            {
                return (string)mDr["UINameSpace"];
            }
        }
        public string FullBOClassName
        {
            get
            {
                return (string)mDr["FullBOClassName"];
            }
        }
        #endregion

        #endregion

        #region Event Handlers
        #endregion

        #region Functions
        #endregion
    }
}

