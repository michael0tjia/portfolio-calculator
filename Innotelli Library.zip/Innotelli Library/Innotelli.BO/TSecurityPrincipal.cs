﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Principal;
using System.Collections;
using System.Threading;
using System.Data;
using Innotelli.BO;

namespace Innotelli.BO
{
    public class TSecurityPrincipal : IPrincipal
    {
        Hashtable mSecurityGroups;
        Hashtable mSecurityRights;
        TUserIdentity mTheUserIdentity;

        private TSecurityPrincipal()
        {
        }

        private TSecurityPrincipal(Hashtable aSecurityGroups, Hashtable aSecurityRights, Hashtable aUserInfo)
        {
            this.mSecurityGroups = aSecurityGroups;
            this.mSecurityRights = aSecurityRights;

            mTheUserIdentity = TUserIdentity.CreateUserIdentity(aUserInfo);
        }

        public static TSecurityPrincipal CreatePrincipal(Hashtable aSecurityGroups, Hashtable aSecurityRights, Hashtable aUserInfo)
        {
            return new TSecurityPrincipal(aSecurityGroups, aSecurityRights, aUserInfo);
        }

        public static IPrincipal SetSecurityPrincipal(Hashtable aSecurityGroups, Hashtable aSecurityRights, Hashtable aUserInfo)
        {
            AppDomain.CurrentDomain.SetPrincipalPolicy(PrincipalPolicy.WindowsPrincipal);

            if (!(Thread.CurrentPrincipal is TSecurityPrincipal))
            {
                TSecurityPrincipal TheSecurityPrincipal = new TSecurityPrincipal(aSecurityGroups, aSecurityRights, aUserInfo);

                IPrincipal CurrentSecurityPrincipal = Thread.CurrentPrincipal;

                Thread.CurrentPrincipal = TheSecurityPrincipal;

                return CurrentSecurityPrincipal;
            }
            else
                return null;
        }

        public static void RestoreSecurityPrincipal(IPrincipal aOriginalPrincipal)
        {
            Thread.CurrentPrincipal = aOriginalPrincipal;
        }

        public IIdentity Identity
        {
            get
            {
                return mTheUserIdentity;
            }
        }

        public bool IsInRole(string aRole)
        {
            return mSecurityGroups.ContainsValue(aRole);
        }

        public bool HasPermission(Guid aPermission)
        {
            return mSecurityRights.ContainsValue(aPermission);
        }

        public static void RetrieveSecurityInformation(int aUserId, out Hashtable aSecurityGroups, out Hashtable aSecurityRights)
        {

            aSecurityGroups = new Hashtable();
            aSecurityRights = new Hashtable();
            TB01SecurityGroupAssign lB01SecurityGroupAssign = new TB01SecurityGroupAssign();
            //TB01SecurityGroup lB01SecurityGroup = new TB01SecurityGroup();
            TB01SecurityPermissionAssign lB01SecurityPermissionAssign = new TB01SecurityPermissionAssign();
            lB01SecurityGroupAssign.OtherFilter = "slkUser = " + aUserId;
            lB01SecurityGroupAssign.LoadDataSet();
            if (!lB01SecurityGroupAssign.IsNoRow())
            {
                lB01SecurityGroupAssign.MoveFirst();
                while (!lB01SecurityGroupAssign.EOF())
                {
                    aSecurityGroups.Add(lB01SecurityGroupAssign.Cr.prmykey, lB01SecurityGroupAssign.Cr.GroupName);
                    lB01SecurityPermissionAssign.OtherFilter = "slkGroup = " + lB01SecurityGroupAssign.Cr.slkGroup;
                    lB01SecurityPermissionAssign.LoadDataSet();
                    if (!lB01SecurityPermissionAssign.IsNoRow())
                    {
                        lB01SecurityPermissionAssign.MoveFirst();
                        while (!lB01SecurityPermissionAssign.EOF())
                        {
                            if (!aSecurityRights.ContainsValue(lB01SecurityPermissionAssign.Cr.PermissionGUID) && lB01SecurityPermissionAssign.Cr.PermissionAllow)
                            {
                                aSecurityRights.Add(lB01SecurityPermissionAssign.Cr.prmykey, lB01SecurityPermissionAssign.Cr.PermissionGUID);
                            }
                            lB01SecurityPermissionAssign.MoveNext();
                        }
                    }
                    lB01SecurityGroupAssign.MoveNext();
                }
            }
        }

        public static void RetrieveUserInformation(int aUserId, out Hashtable aUserInfo)
        {
            aUserInfo = new Hashtable();
            TB01SecurityUser lB01SecurityUser = new TB01SecurityUser();
            lB01SecurityUser.OtherFilter = "prmykey = " + aUserId;
            lB01SecurityUser.LoadDataSet();
            if (!lB01SecurityUser.IsNoRow())
            {
                aUserInfo.Add(lB01SecurityUser.Cr.prmykey, lB01SecurityUser.Cr.UserName);
            }
        }

    }
}
